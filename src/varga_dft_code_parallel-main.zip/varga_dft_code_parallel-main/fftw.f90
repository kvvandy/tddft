      subroutine cfftw(chd,n1,n2,n3,mode)
!
!     Interface with FFTW3 library
!
      implicit none
!
!     Input/Output variables:
!
      integer, intent(in) :: n1,n2,n3,mode
      complex*16, intent(inout) :: chd(n1,n2,n3)
include 'fftw3.f'
!
!     Work variables:
!
      integer            :: dirn,flg,len,succ
      integer(kind=8)    :: plan
      complex*16         :: fac
      character (len=10) :: file_name
!
!     parameters from fftw3.f
!
!      integer, parameter :: fftw_forward = -1
!      integer, parameter :: fftw_backward = +1
!      integer, parameter :: fftw_estimate = 64
!     ---------------------------------------------------------------
      len = n1*n2*n3 

      if (mode .gt. 0) then
         file_name = 'forwardfft'
         dirn = fftw_forward
      else
         file_name = 'backwrdfft'
         dirn = fftw_backward
      endif

      call dfftw_plan_dft_3d(plan, n1, n2, n3,chd,chd,dirn,fftw_estimate)
      call dfftw_execute(plan)
      call dfftw_destroy_plan(plan)
 
      if (mode .gt. 0) then
         fac = 1.d0/len
         chd=fac*chd
      endif

end subroutine cfftw
