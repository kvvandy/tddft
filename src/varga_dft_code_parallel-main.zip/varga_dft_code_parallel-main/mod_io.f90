MODULE MOD_IO
  USE MOD_GLOBAL
  implicit none
  integer :: charge_difference_has_been_set,ios
  real*8  :: previous_charge_difference,previous_charge_difference_up
  real*8  :: previous_charge_difference_down
  real*8, allocatable  :: v_total_3d(:)
CONTAINS

subroutine count_grid_points_in_planes()
	! This subroutine counts the number of grid points in each x-plane and
	! works for any box_type
	integer :: i,j

  allocate(n_points_x_plane(N_lattice_min(1):N_lattice_max(1)))
  allocate(n_points_y_plane(N_lattice_min(2):N_lattice_max(2)))
  allocate(n_points_z_plane(N_lattice_min(3):N_lattice_max(3)))
  n_points_x_plane=0; n_points_y_plane=0; n_points_z_plane=0

  if(box_type==1) then ! rectangular box
    do i=1,N_lattice_points
      j=lattice(1,i)+1; n_points_x_plane(j)=n_points_x_plane(j)+1
      j=lattice(2,i)+1; n_points_y_plane(j)=n_points_y_plane(j)+1
      j=lattice(3,i)+1; n_points_z_plane(j)=n_points_z_plane(j)+1
    enddo
  else ! other box types
    do i=1,N_lattice_points
      j=lattice(1,i); n_points_x_plane(j)=n_points_x_plane(j)+1
      j=lattice(2,i); n_points_y_plane(j)=n_points_y_plane(j)+1
      j=lattice(3,i); n_points_z_plane(j)=n_points_z_plane(j)+1
    enddo
  endif
end subroutine count_grid_points_in_planes

SUBROUTINE output_3D_total_potential(it)
  integer             :: i,j,it
  real*8              :: min_v_t_3d,max_v_t_3d,ramp,t,shift,sum_a,sum_b
!  real*8,allocatable  :: v_total_3d_1(:)

  t=it*time_step
  ramp=1.d0
  if((ramp_time>0.d0).AND.(t<ramp_time)) ramp=t/ramp_time

  min_v_t_3d=99999.d0
  max_v_t_3d=-99999.d0

  allocate(v_total_3d(N_lattice_points))

  do i=1,N_lattice_points
    if(spin_polarized) then
   	  v_total_3d(i)=v_exchange_up(i)+v_exchange_down(i)+v_hartree(i)+v_l_pp(i)
	  else
  	  v_total_3d(i)=v_exchange(i)+v_hartree(i)+v_l_pp(i)
	  endif

		if(run_type==41) v_total_3d(i)=v_total_3d(i)+V_bias_pot(i)
	  if(using_v_ext) v_total_3d(i)=v_total_3d(i)+ramp*v_ext(i)
           if(using_v_step) v_total_3d(i)=v_total_3d(i)+ramp*v_steppot(i)
	  if(using_v_laser1) v_total_3d(i)=v_total_3d(i)+V_laser1(i)*factor_laser1
	  if(using_v_laser2) v_total_3d(i)=v_total_3d(i)+V_laser2(i)*factor_laser2
	  if(using_v_laser3) v_total_3d(i)=v_total_3d(i)+V_laser3(i)*factor_laser3

	  if(v_total_3d(i)<min_v_t_3d) min_v_t_3d=v_total_3d(i)
	  if(v_total_3d(i)>max_v_t_3d) max_v_t_3d=v_total_3d(i)
  enddo

  ! Calculate the average potential value on the x boundaries
  sum_a=0.d0
  sum_b=0.d0
  do i=1,N_lattice(2)
    do j=1,N_lattice(3)
      sum_a=sum_a+v_total_3d(Lattice_inv_xyz(1,i,j))
      sum_b=sum_b+v_total_3d(Lattice_inv_xyz(N_lattice(1),i,j))
    enddo
  enddo
  sum_a=sum_a/(N_lattice(2)*N_lattice(3))
  sum_b=sum_b/(N_lattice(2)*N_lattice(3))
  shift=(sum_a+sum_b)/2.d0

  ! Output to files
  open(total_3D_potential_file,file=trim(adjustl(total_3D_potential_filename)))
  open(total_3D_potential_file_shifted,file=trim(adjustl(total_3D_potential_filename_shifted)))
  open(total_3D_potential_file_VisIt,file=trim(adjustl(total_3D_potential_filename_VisIt)))
  write(total_3D_potential_file_VisIt,*)"x y z potential"
  do i=1,N_lattice_points
    write(total_3D_potential_file,'(ES16.8)')v_total_3d(i)
    write(total_3D_potential_file_shifted,'(ES16.8)')v_total_3d(i)-shift
	  write(total_3D_potential_file_VisIt,'(4ES16.8)')grid_point(1,i),grid_point(2,i),grid_point(3,i),v_total_3d(i)
	enddo
  close(total_3D_potential_file)
  close(total_3D_potential_file_shifted)
  close(total_3D_potential_file_VisIt)

  write(log_file,*)
  write(log_file,*)"Total 3D potential written to ",trim(adjustl(total_3D_potential_filename))
  write(log_file,*)"Shifted total 3D potential written to ",trim(adjustl(total_3D_potential_filename_shifted))
  write(log_file,*)"VisIt-compatible Point3D format file written to ",trim(adjustl(total_3D_potential_filename_VisIt))
  write(log_file,*)"Min potential value: ",min_v_t_3d
  write(log_file,*)"Max potential value: ",max_v_t_3d
  write(log_file,*)"Average potential value at left (x=1) x boundary: ",sum_a
  write(log_file,*)"Average potential value at right (x=N_lattice(1)) x boundary: ",sum_b
  write(log_file,*)"Potential shift value: ",shift
  write(log_file,*)
  deallocate(v_total_3d)
END SUBROUTINE output_3D_total_potential

SUBROUTINE plot(it)
  integer            :: it,i,ii,j,imin,imax,axis,np,counter
  real*8             :: da,temp,coordinate,t,ramp,v_total_1d,min_v_t_3d,max_v_t_3d
  real*8,allocatable :: output(:,:)
  real*8,allocatable :: v_exchange_1d(:),v_hartree_1d(:),v_l_pp_1d(:),v_ext_1d(:)
  real*8,allocatable :: v_laser1_1d(:),v_laser2_1d(:),v_laser3_1d(:),v_bias_pot_1d(:)
  integer,save       :: call_count=0

  if(.NOT.output_plot) return

  t=it*time_step
  ramp=1.d0
  if((ramp_time>0.d0).AND.(t<ramp_time)) ramp=t/ramp_time

  axis=1

  call_count=call_count+1
  if(call_count==1) call count_grid_points_in_planes()

  da=grid_volume/grid_step(axis)
  imin=N_lattice_min(axis)
  imax=N_lattice_max(axis)

  if(spin_polarized) then
	  allocate(output(imin:imax,6))
	else
	  allocate(output(imin:imax,2))
	endif
  output=0.d0

  allocate(v_exchange_1d(imin:imax),v_hartree_1d(imin:imax),v_l_pp_1d(imin:imax))
  v_exchange_1d=0.d0; v_hartree_1d=0.d0; v_l_pp_1d=0.d0
  if(run_type==41) then
  	allocate(v_bias_pot_1d(imin:imax))
  	v_bias_pot_1d=0.d0
  endif
  if(using_v_ext) then
    allocate(v_ext_1d(imin:imax))
    v_ext_1d=0.d0
  endif
  if(using_v_laser1) then
    allocate(v_laser1_1d(imin:imax))
    v_laser1_1d=0.d0
  endif
  if(using_v_laser2) then
    allocate(v_laser2_1d(imin:imax))
    v_laser2_1d=0.d0
  endif
  if(using_v_laser3) then
    allocate(v_laser3_1d(imin:imax))
    v_laser3_1d=0.d0
  endif

  ! Project various quantities onto the specified axis
  do i=1,N_lattice_points
    if(box_type==1) then
      ii=Lattice(axis,i)+1 ! rectangular box
    else
      ii=Lattice(axis,i)   ! other box types
    endif

    counter=1
    output(ii,counter)=output(ii,counter)+density(i); counter=counter+1
    if(spin_polarized) then
	    output(ii,counter)=output(ii,counter)+density_up(i); counter=counter+1
  	  output(ii,counter)=output(ii,counter)+density_down(i); counter=counter+1
  	endif

    temp=V_hartree(i)+V_l_pp(i)
    if(run_type==41) temp=temp+V_bias_pot(i)
    if(using_v_ext) temp=temp+ramp*v_ext(i)
    if(using_v_laser1) temp=temp+V_laser1(i)*factor_laser1
    if(using_v_laser2) temp=temp+V_laser2(i)*factor_laser2
    if(using_v_laser3) temp=temp+V_laser3(i)*factor_laser3

    output(ii,counter)=output(ii,counter)+temp+v_exchange(i); counter=counter+1
 	  if(spin_polarized) then
      output(ii,counter)=output(ii,counter)+temp+v_exchange_up(i); counter=counter+1
      output(ii,counter)=output(ii,counter)+temp+v_exchange_down(i); counter=counter+1
    endif

    v_exchange_1d(ii)=v_exchange_1d(ii)+v_exchange(i)
    v_hartree_1d(ii)=v_hartree_1d(ii)+v_hartree(i)
    v_l_pp_1d(ii)=v_l_pp_1d(ii)+v_l_pp(i)
    if(run_type==41) v_bias_pot_1d(ii)=v_bias_pot_1d(ii)+V_bias_pot(i)
    if(using_v_ext) v_ext_1d(ii)=v_ext_1d(ii)+ramp*v_ext(i)
    if(using_v_laser1) v_laser1_1d(ii)=v_laser1_1d(ii)+V_laser1(i)*factor_laser1
    if(using_v_laser2) v_laser2_1d(ii)=v_laser2_1d(ii)+V_laser2(i)*factor_laser2
    if(using_v_laser3) v_laser3_1d(ii)=v_laser3_1d(ii)+V_laser3(i)*factor_laser3
  enddo

  output(:,1)=output(:,1)*da
  if(spin_polarized) then
    output(:,2)=output(:,2)*da
    output(:,3)=output(:,3)*da
  endif

  do i=imin,imax
    select case(axis)
      case(1)
        np=n_points_x_plane(i)
        coordinate=xgrid(i)
      case(2)
        np=n_points_y_plane(i)
        coordinate=ygrid(i)
      case(3)
        np=n_points_z_plane(i)
        coordinate=zgrid(i)
    end select

    write(projection_1d_file,'(ES16.8,a)',advance='no')coordinate,tab_char
    do j=1,(counter-1)
      write(projection_1d_file,'(ES16.8)',advance='no')output(i,j)/np
      if(j<(counter-1)) write(projection_1d_file,'(a)',advance='no')tab_char
    enddo
    write(projection_1d_file,*)

    v_total_1d=v_exchange_1d(i)+v_hartree_1d(i)+v_l_pp_1d(i)
    if(run_type==41) v_total_1d=v_total_1d+v_bias_pot_1d(i)
		if(using_v_ext) v_total_1d=v_total_1d+v_ext_1d(i)
		if(using_v_laser1) v_total_1d=v_total_1d+v_laser1_1d(i)
		if(using_v_laser2) v_total_1d=v_total_1d+v_laser2_1d(i)
		if(using_v_laser3) v_total_1d=v_total_1d+v_laser3_1d(i)

		if(abs(coordinate)<1d-20) coordinate=0.d0
		if(abs(v_total_1d)<1d-20) v_total_1d=0.d0
		if(abs(v_exchange_1d(i))<1d-20) v_exchange_1d(i)=0.d0
		if(abs(v_hartree_1d(i))<1d-20) v_hartree_1d(i)=0.d0
		if(abs(v_l_pp_1d(i))<1d-20) v_l_pp_1d(i)=0.d0
    if(run_type==41) then
			if(abs(v_bias_pot_1d(i))<1d-20) v_bias_pot_1d(i)=0.d0
		endif
    if(using_v_ext) then
			if(abs(v_ext_1d(i))<1d-20) v_ext_1d(i)=0.d0
		endif
    if(using_v_laser1) then
			if(abs(v_laser1_1d(i))<1d-20) v_laser1_1d(i)=0.d0
		endif
    if(using_v_laser2) then
			if(abs(v_laser2_1d(i))<1d-20) v_laser2_1d(i)=0.d0
		endif
    if(using_v_laser3) then
			if(abs(v_laser3_1d(i))<1d-20) v_laser3_1d(i)=0.d0
		endif



    !write(707,'(4(ES16.8,a),ES16.8)',advance='no')coordinate,tab_char,v_total_1d/np, &
    !  tab_char,v_exchange_1d(i)/np,tab_char,v_hartree_1d(i)/np,tab_char,v_l_pp_1d(i)/np
    !if(using_v_ext) write(707,'(a,ES16.8)',advance='no')tab_char,v_ext_1d(i)/np
    !if(using_v_laser1) write(707,'(a,ES16.8)',advance='no')tab_char,v_laser1_1d(i)/np
    !if(using_v_laser2) write(707,'(a,ES16.8)',advance='no')tab_char,v_laser2_1d(i)/np
    !if(using_v_laser3) write(707,'(a,ES16.8)',advance='no')tab_char,v_laser3_1d(i)/np
    !write(707,*)
  enddo
  write(projection_1d_file,*)
  !write(707,*)
  deallocate(output)

  deallocate(v_exchange_1d,v_hartree_1d,v_l_pp_1d)
  if(run_type==41) deallocate(v_bias_pot_1d)
  if(using_v_ext) deallocate(v_ext_1d)
  if(using_v_laser1) deallocate(v_laser1_1d)
  if(using_v_laser2) deallocate(v_laser2_1d)
  if(using_v_laser3) deallocate(v_laser3_1d)
END SUBROUTINE plot

SUBROUTINE plot_time(it)
  integer                :: i,j,k,m,j1,j2,k1,k2,k3,ka,kb1,kb2,orbital,it,num_mr,im,ind
  integer,allocatable    :: ind_counts(:)
  real*8                 :: current_from_charge,x,da,dj,drho,charge_difference
  real*8                 :: charge_difference_up,charge_difference_down
  real*8                 :: current_from_charge_up,current_from_charge_down
  real*8,allocatable     :: charge_sum(:),current_sum(:),density_slice(:,:,:)
  real*8,allocatable     :: orbital_current(:,:),orbital_density(:,:)
  real*8,allocatable     :: charge_sum_up(:),charge_sum_down(:)
  real*8,allocatable     :: current_sum_up(:),current_sum_down(:)
  real*8,allocatable     :: orbital_density_up(:,:),orbital_density_down(:,:)
  real*8,allocatable     :: orbital_current_up(:,:),orbital_current_down(:,:)
  real*8,allocatable     :: density_slice_up(:,:,:),density_slice_down(:,:,:)
  complex*16             :: the_sum
  complex*16,allocatable :: phi_orbital(:),tr_basis(:,:)
  character*255          :: filename,it_string

  if(.NOT.output_plot_time) return

  ! TODO: add code that works for box_basis_type==2
  if(box_basis_type==2) return

  write(it_string,*)it
  num_mr=size(mr)
  allocate(ind_counts(num_mr+1),charge_sum(num_mr+1),current_sum(num_mr))
  allocate(density_slice(num_mr,N_lattice(2),N_lattice(3)))
  allocate(orbital_current(n_orbitals,num_mr),orbital_density(n_orbitals,n_lattice(1)))

  if(spin_polarized) then
    allocate(density_slice_up(num_mr,N_lattice(2),N_lattice(3)))
    allocate(density_slice_down(num_mr,N_lattice(2),N_lattice(3)))
    allocate(charge_sum_up(num_mr+1),charge_sum_down(num_mr+1))
    allocate(current_sum_up(num_mr),current_sum_down(num_mr))
    allocate(orbital_density_up(n_orbitals_up,n_lattice(1)))
    allocate(orbital_density_down(n_orbitals_down,n_lattice(1)))
    allocate(orbital_current_up(n_orbitals_up,num_mr))
    allocate(orbital_current_down(n_orbitals_down,num_mr))
    density_slice_up=0.d0; density_slice_down=0.d0
    charge_sum_up=0.d0; charge_sum_down=0.d0
    current_sum_up=0.d0; current_sum_down=0.d0
    orbital_density_up=0.d0; orbital_density_down=0.d0
    orbital_current_up=0.d0; orbital_current_down=0.d0
  endif

  density_slice=0.d0
  charge_sum=0.d0
  current_sum=0.d0
  orbital_density=0.d0
  orbital_current=0.d0

  allocate(phi_orbital(N_Lattice_points))
  do orbital=1,n_orbitals
    ! Only need to consider occupied orbitals here
    if(abs(occupation(orbital))<1.d-10) cycle

    ! Get the orbital
    if(allocated(Psi_c)) then
      phi_orbital(:)=Psi_c(:,orbital)
    else
      if(box_basis_type==1) then
        phi_orbital=(0.d0,0.d0)
        do j=1,N_diag
          j2=basis_atom(2,j)
          do k=1,int_points(j2)
            k1=ind_basis(k,j2)
            phi_orbital(k1)=phi_orbital(k1)+cf_basis(j,orbital)*Psi_basis_r(k,j)
          enddo
        enddo
      elseif(box_basis_type==3) then
        phi_orbital=(0.d0,0.d0)
        do j=1,N_diag
          j2=basis_atom(2,j)
          do k=1,int_points(j2)
            k1=ind_basis(k,j2)
            phi_orbital(k1)=phi_orbital(k1)+tr_basis(j,orbital)*Psi_basis_r(k,j)
          enddo
        enddo
      endif
    endif

    ! Calculate the charge in each measurement region and project the
    ! orbital's density onto the x axis
    do i=1,N_lattice_points
      ! See which measurement region this is
      j=Lattice(1,i)+1
      ind=num_mr+1
      do k=1,num_mr
        if(j<mr(k)) then
          ind=k
          exit
        endif
      enddo

      ! Calculate the charge
      drho=occupation(orbital)*real(Conjg(phi_orbital(i))*phi_orbital(i))
      charge_sum(ind)=charge_sum(ind)+drho
      orbital_density(orbital,j)=orbital_density(orbital,j)+drho
      if(spin_polarized) then
        if(orbital<=N_orbitals_down) then
          charge_sum_down(ind)=charge_sum_down(ind)+drho
          orbital_density_down(orbital,j)=orbital_density_down(orbital,j)+drho
        else
          charge_sum_up(ind)=charge_sum_up(ind)+drho
          orbital_density_up(orbital-n_orbitals_down,j)=orbital_density_up(orbital-n_orbitals_down,j)+drho
        endif
      endif
    enddo

    !Here used to be a fragment of code that calculated current density

    ! For each measurement plane, get the yz density slice and total current through the slice
    do k=1,num_mr
      do i=1,N_Lattice(2)
        do j=1,N_Lattice(3)
          ka=Lattice_inv_xyz(mr(k),i,j)
          drho=occupation(orbital)*real(Conjg(phi_orbital(ka))*phi_orbital(ka))
          density_slice(k,i,j)=density_slice(k,i,j)+drho

          if(spin_polarized) then
            if(orbital<=N_orbitals_up) then
              density_slice_up(k,i,j)=density_slice_up(k,i,j)+drho
            else
              density_slice_down(k,i,j)=density_slice_down(k,i,j)+drho
            endif
          endif

          ! Calculate the gradient term for the current
          the_sum=0.d0
	        do m=1,4
	          kb1=Lattice_inv_xyz(mr(k)+m,i,j)
	          kb2=Lattice_inv_xyz(mr(k)-m,i,j)
	          the_sum=the_sum+fd_coeff_first_derivative(m)*(phi_orbital(kb1)-phi_orbital(kb2))
	        enddo

          dj=imag(Conjg(phi_orbital(ka))*the_sum)*occupation(orbital)
          orbital_current(orbital,k)=orbital_current(orbital,k)+dj
          current_sum(k)=current_sum(k)+dj

          if(spin_polarized) then
            if(orbital<=N_orbitals_down) then
              orbital_current_down(orbital,k)=orbital_current_down(orbital,k)+dj
              current_sum_down(k)=current_sum_down(k)+dj
            else
              orbital_current_up(orbital-n_orbitals_down,k)=orbital_current_up(orbital-n_orbitals_down,k)+dj
              current_sum_up(k)=current_sum_up(k)+dj
            endif
          endif

        enddo
      enddo
    enddo
  enddo ! end of loop over orbitals

  charge_sum=charge_sum*grid_volume
  da=grid_step(2)*grid_step(3)
  current_sum=(hbar*c_squared/electron_mass)*current_sum*current_conversion_factor*da/grid_step(1)
  orbital_current=(hbar*c_squared/electron_mass)*orbital_current*current_conversion_factor*da/grid_step(1)

  if(spin_polarized) then
    charge_sum_up=charge_sum_up*grid_volume
    charge_sum_down=charge_sum_down*grid_volume
    current_sum_up=(hbar*c_squared/electron_mass)*current_sum_up*current_conversion_factor*da/grid_step(1)
    current_sum_down=(hbar*c_squared/electron_mass)*current_sum_down*current_conversion_factor*da/grid_step(1)
  	orbital_current_up=(hbar*c_squared/electron_mass)*orbital_current_up*current_conversion_factor*da/grid_step(1)
	  orbital_current_down=(hbar*c_squared/electron_mass)*orbital_current_down*current_conversion_factor*da/grid_step(1)
  endif

  if(box_basis_type==3) deallocate(tr_basis)

  charge_difference=charge_sum(num_mr+1)-charge_sum(1)
  if(spin_polarized) then
    charge_difference_up=charge_sum_up(num_mr+1)-charge_sum_up(1)
    charge_difference_down=charge_sum_down(num_mr+1)-charge_sum_down(1)
  endif

  if(charge_difference_has_been_set==1) then
    current_from_charge=current_conversion_factor*(charge_difference-previous_charge_difference) &
      /(td_data_output_frequency*time_step*2.d0)
    if(spin_polarized) then
      current_from_charge_up=current_conversion_factor*(charge_difference_up-previous_charge_difference_up) &
        /(td_data_output_frequency*time_step*2.d0)
      current_from_charge_down=current_conversion_factor*(charge_difference_down-previous_charge_difference_down) &
        /(td_data_output_frequency*time_step*2.d0)
    endif
  else
    current_from_charge=0.d0
    if(spin_polarized) then
      current_from_charge_up=0.d0
      current_from_charge_down=0.d0
    endif
    charge_difference_has_been_set=1
  endif
  previous_charge_difference=charge_difference
  if(spin_polarized) then
    previous_charge_difference_up=charge_difference_up
    previous_charge_difference_down=charge_difference_down
  endif

  ! Output the total charge, and the current determined by the charge in the outer
  ! measurement regions. Also output is the average current through measurement
  ! region planes (calculated using the wavefunctions, not the charge).
  if(spin_polarized) then
    write(mr_current_from_charge_file,'(9(ES16.8,a),ES16.8)')it*time_step,tab_char, &
      sum(charge_sum_up),tab_char,current_from_charge_up,tab_char,sum(current_sum_up)/dfloat(num_mr),tab_char, &
      sum(charge_sum_down),tab_char,current_from_charge_down,tab_char,sum(current_sum_down)/dfloat(num_mr),tab_char, &
      sum(charge_sum),tab_char,current_from_charge,tab_char,sum(current_sum)/dfloat(num_mr)
  else
    write(mr_current_from_charge_file,'(3(ES16.8,a),ES16.8)')it*time_step,tab_char, &
      sum(charge_sum),tab_char,current_from_charge,tab_char,sum(current_sum)/dfloat(num_mr)
  endif

  ! Output the charge in each measurement region
  write(mr_charge_file,'(ES16.8,a)',advance="no")it*time_step,tab_char
  if(spin_polarized) then
    do i=1,(num_mr+1)
      write(mr_charge_file,'(3(ES16.8,a))',advance="no")charge_sum(i),tab_char, &
        charge_sum_up(i),tab_char,charge_sum_down(i),tab_char
    enddo
  else
    do i=1,(num_mr+1)
      write(mr_charge_file,'(ES16.8,a)',advance="no")charge_sum(i),tab_char
    enddo
  endif
  write(mr_charge_file,*)

  ! Output the current through each measurement plane
  write(mr_current_file,'(ES16.8,a)',advance="no")it*time_step,tab_char
  if(spin_polarized) then
    do i=1,num_mr
      write(mr_current_file,'(3(ES16.8,a))',advance="no")current_sum(i),tab_char, &
        current_sum_up(i),tab_char,current_sum_down(i),tab_char
    enddo
  else
    do i=1,num_mr
      write(mr_current_file,'(ES16.8,a)',advance="no")current_sum(i),tab_char
    enddo
  endif
  write(mr_current_file,*)

  if(output_mr_orbital_charge) then
    ! Output the charge per orbital projected onto the x axis
    if(spin_polarized) then
		  do i=1,n_lattice(1)
		    write(mr_orbital_charge_file,'(ES16.8,a)',advance="no")xgrid(i),tab_char
		    do j=1,n_orbitals
		      write(mr_orbital_charge_file,'(3(ES16.8,a))',advance="no")orbital_density(j,i),tab_char, &
		      	orbital_density_up(j,i),tab_char,orbital_density_down(j,i),tab_char
		    enddo
		    write(mr_orbital_charge_file,*)
		  enddo
		  write(mr_orbital_charge_file,*)
    else
		  do i=1,n_lattice(1)
		    write(mr_orbital_charge_file,'(ES16.8,a)',advance="no")xgrid(i),tab_char
		    do j=1,n_orbitals
		      write(mr_orbital_charge_file,'(ES16.8,a)',advance="no")orbital_density(j,i),tab_char
		    enddo
		    write(mr_orbital_charge_file,*)
		  enddo
		  write(mr_orbital_charge_file,*)
    endif
  endif

  ! Output the current per orbital through each measurement plane
  if(spin_polarized) then
		do j=1,n_orbitals
		  write(mr_orbital_current_file,'(i10,a,2(ES16.8,a))',advance="no")j,tab_char, &
		  	occupation(j),tab_char,sp_energy(j),tab_char
		  do i=1,num_mr
		    write(mr_orbital_current_file,'(3(ES16.8,a))',advance="no")orbital_current(j,i),tab_char, &
		    	orbital_current_up(j,i),tab_char,orbital_current_down(j,i),tab_char
		  enddo
		  write(mr_orbital_current_file,*)
		enddo
		write(mr_orbital_current_file,*)
  else
		do j=1,n_orbitals
		  write(mr_orbital_current_file,'(i10,a,2(ES16.8,a))',advance="no")j,tab_char, &
		  	occupation(j),tab_char,sp_energy(j),tab_char
		  do i=1,num_mr
		    write(mr_orbital_current_file,'(ES16.8,a)',advance="no")orbital_current(j,i),tab_char
		  enddo
		  write(mr_orbital_current_file,*)
		enddo
		write(mr_orbital_current_file,*)
  endif

  if(output_mr_density_slice) then
    ! Output the yz density slices
!    do k=1,num_mr
!      do i=1,N_lattice(2)
!        do j=1,N_lattice(3)
!          if(spin_polarized) then
!            write(mr_density_slice_file,'(3ES16.8)')density_slice(k,i,j), &
!            	density_slice_up(k,i,j),density_slice_down(k,i,j)
!          else
!            write(mr_density_slice_file,'(ES16.8)')density_slice(k,i,j)
!          endif
!        enddo
!      enddo
!    enddo
!    write(mr_density_slice_file,*)

    do k=1,num_mr
      write(filename,'(5a)')"mr_density_yz_slice_",char(64+k),"_t_", &
        trim(adjustl(it_string)),".3D"
      open(mr_yz_density_slice_file,file=trim(adjustl(filename)))
      write(mr_yz_density_slice_file,'(a)')"x y z density"
      do i=1,N_lattice(2)
        do j=1,N_lattice(3)
          if(spin_polarized) then
            write(mr_yz_density_slice_file,'(3ES16.8)')density_slice(k,i,j), &
            	density_slice_up(k,i,j),density_slice_down(k,i,j)
          else
            write(mr_yz_density_slice_file,'(4ES16.8)')xmr(k),ygrid(i),zgrid(j),density_slice(k,i,j)
          endif
        enddo
      enddo
      close(mr_yz_density_slice_file)
    enddo

  endif
!write(total_3D_potential_file_VisIt,'(4ES16.8)')grid_point(1,i),grid_point(2,i),grid_point(3,i),v_total_3d(i)
  deallocate(ind_counts,phi_orbital,charge_sum,current_sum,density_slice,orbital_current,orbital_density)
  if(spin_polarized) then
    deallocate(density_slice_up,density_slice_down)
    deallocate(charge_sum_up,charge_sum_down,orbital_density_up,orbital_density_down)
    deallocate(current_sum_up,current_sum_down,orbital_current_up,orbital_current_down)
  endif
END SUBROUTINE plot_time


SUBROUTINE gnuplot_2D(gnuplot_filename,data_filename,output_basename,nx,ny)
  integer          :: nx,ny
  character(len=*) :: gnuplot_filename,data_filename,output_basename
  character*255    :: temp1,temp2

  write(temp1,*)nx
  write(temp2,*)ny

  open(gnuplot_file,file=trim(adjustl(gnuplot_filename)))

  write(gnuplot_file,'(a)')'set term png'
  write(gnuplot_file,'(3a)')'set output "',trim(adjustl(output_basename)),'.png"'
  write(gnuplot_file,'(a)')'set xlabel "X"'
  write(gnuplot_file,'(a)')'set ylabel "Y"'
  write(gnuplot_file,'(a)')'set palette rgbformulae 22,13,-31'
  write(gnuplot_file,'(3a)')'set xrange[1:',trim(adjustl(temp1)),']'
  write(gnuplot_file,'(3a)')'set yrange[1:',trim(adjustl(temp2)),']'
  write(gnuplot_file,'(a)')'set pm3d map'
  write(gnuplot_file,'(a)')'set size square'
  write(gnuplot_file,'(3a)')'splot "',trim(adjustl(data_filename)),'" notitle with pm3d'
  write(gnuplot_file,'(a)')'set term postscript eps enhanced color'
  write(gnuplot_file,'(3a)')'set output "',trim(adjustl(output_basename)),'.eps"'
  write(gnuplot_file,'(a)')'replot'
  close(gnuplot_file)

  write(temp1,'(2a)')"gnuplot ",trim(adjustl(gnuplot_filename))
  call system(temp1)
END SUBROUTINE gnuplot_2D

SUBROUTINE gnuplot_3D(gnuplot_filename,data_filename,output_basename,nx,ny)
  integer          :: nx,ny
  character(len=*) :: gnuplot_filename,data_filename,output_basename
  character*255    :: temp1,temp2

  write(temp1,*)nx
  write(temp2,*)ny

  open(gnuplot_file,file=trim(adjustl(gnuplot_filename)))

  write(gnuplot_file,'(a)')'set term png'
  write(gnuplot_file,'(3a)')'set output "',trim(adjustl(output_basename)),'.png"'
  write(gnuplot_file,'(a)')'set xlabel "X"'
  write(gnuplot_file,'(a)')'set ylabel "Y"'
  write(gnuplot_file,'(a)')'set palette rgbformulae 22,13,-31'
  write(gnuplot_file,'(3a)')'set xrange[1:',trim(adjustl(temp1)),']'
  write(gnuplot_file,'(3a)')'set yrange[1:',trim(adjustl(temp2)),']'
  write(gnuplot_file,'(3a)')'splot "',trim(adjustl(data_filename)),'" notitle with pm3d'
  write(gnuplot_file,'(a)')'set term postscript eps enhanced color'
  write(gnuplot_file,'(3a)')'set output "',trim(adjustl(output_basename)),'.eps"'
  write(gnuplot_file,'(a)')'replot'
  close(gnuplot_file)

  write(temp1,'(2a)')"gnuplot ",trim(adjustl(gnuplot_filename))
  call system(temp1)
END SUBROUTINE gnuplot_3D

FUNCTION get_file_line(file_ID,file_line,num_elements)
  ! Returns true if it can find a non-blank line that isn't entirely a comment.
  ! Anything after a '#' is a comment. Otherwise, return false.
  integer          :: i,file_ID
  integer,optional :: num_elements
  logical          :: get_file_line
  character(len=*) :: file_line

  file_line=""
  get_file_line=.FALSE.
  do
    read(file_ID,'(a)',end=110)file_line
    if(len_trim(adjustl(file_line))/=0) then
      i=index(file_line,'#')
      if(i>0) then
	file_line=file_line(1:i-1)
      endif
      if(len_trim(adjustl(file_line))/=0) exit
    endif
  enddo
  get_file_line=.TRUE.
110 if(present(num_elements)) num_elements=get_num_elements(file_line)
END FUNCTION get_file_line

FUNCTION get_num_elements(string)
  integer            :: get_num_elements,i,j,length
  character(len=*)   :: string
  character(len=len_trim(adjustl(string)))      :: temp
  character          :: temp_string(255)
  logical            :: in_whitespace
  character(1)       :: ch1
  real*8              :: diff

  length=len_trim(adjustl(string))
  if(length==0) then
    get_num_elements=0
    return
  endif

  temp=trim(adjustl(string))
  get_num_elements=1
  in_whitespace=.FALSE.

  do i=1,length
    ch1=temp(i:i)
    if((ch1/=' ').AND.(ch1/=char(9))) then ! found a non-whitespace character
      in_whitespace=.FALSE.
    else ! found a whitespace character
      if(.NOT.in_whitespace) then
      	get_num_elements=get_num_elements+1
      endif
      in_whitespace=.TRUE.
    endif
  enddo
  if (ch1==char(9)) get_num_elements=get_num_elements-1
END FUNCTION get_num_elements

SUBROUTINE input_atom
  integer :: i,k,k1,k2,k3,num_i,num_o,j,i1,i2,i3,kk,atom,it,jt,grid,N(3),pair,l,m,error_code,num_elements
  real*8  :: xx,c1,c2,dr,c,x,xl,xr,yr,yl
  character*255 :: str,stradj,file_line,full_filename,full_filename2
  character*1   :: str1
  integer       :: readerr,N_total_atom_gs1,N_total_atom_gs2,combine_grid_info_lat(3)
  real*8        :: combine_grid_info(3),diff
  logical       :: file_exists

  call input_control

if(.NOT.combine_gs) then
  if(specify_dft_inp_path) then
    write(full_filename,'(2a)')trim(adjustl(dft_inp_path)),trim(adjustl(structure_input_filename))
  else
    write(full_filename,'(2a)')trim(adjustl(gs_path)),trim(adjustl(structure_input_filename))
  end if
  
  write(log_file,*)"Structure data full filename: ",trim(adjustl(full_filename))
  open(structure_input_file,file=trim(adjustl(full_filename)),action='read',status='old',iostat=error_code)
  if(error_code/=0) then
    write(log_file,'(3a)')"ERROR: cannot open file '",trim(adjustl(full_filename)),"' in input_atom"
    stop
  endif

  if(get_file_line(structure_input_file,file_line,num_elements)) then
    if(num_elements==4) then
      read(file_line,*)N_total_atom,N_atom_L,N_atom_C,N_atom_R
    else
      write(log_file,*)"ERROR: Invalid number of items in input file line:"
      write(log_file,*)trim(adjustl(file_line))
      stop
    endif
  else
    write(log_file,*)"ERROR: premature end of structure input file"
    stop
  endif

  i=N_total_atom
  allocate(Position(3,i),Position_init(3,i),closest_ion_init(i))
  allocate(l_max_basis(i),N_ao(i),atom_index(i),gauss_p(ngm),box_atom(i))
  if(read_isotope_mass) then
    allocate(isotope_masses(i))
	write(log_file,*) "will read in atom XYZ position, atomic number, box, mass(amu)" 
  end if
    allocate(atom_movable(N_total_atom))
    atom_movable=.TRUE.

  do k=1,N_total_atom
    if(get_file_line(structure_input_file,file_line,num_elements)) then
	  if(read_isotope_mass) then
        if(num_elements==6) then
          read(file_line,*)(Position(i,k),i=1,3),atom_index(k),box_atom(k),isotope_masses(k)
		  write(log_file,'(a,i3,3F12.5,2i3,F12.5)') "atom ",k,Position(1:3,k),atom_index(k),box_atom(k),isotope_masses(k)
        else
          write(log_file,*)"ERROR: Invalid number of items in input file line:"
          write(log_file,*)trim(adjustl(file_line))
          stop
        endif
	  else
        if(num_elements==5) then
          read(file_line,*)(Position(i,k),i=1,3),atom_index(k),box_atom(k)
        elseif((.not.move_all_atoms).AND.(num_elements==6)) then
          read(file_line,*)(Position(i,k),i=1,3),atom_index(k),box_atom(k),atom_movable(k)
        else
          write(log_file,*)"ERROR: Invalid number of items in input file line:"
          write(log_file,*)trim(adjustl(file_line))
          stop
        endif
	  end if
    else
      write(log_file,*)"ERROR: premature end of structure input file"
      stop
    endif
  enddo
  
else ! read number of atoms from both input files before allocating
  if(specify_dft_inp_path) then
    write(full_filename,'(2a)')trim(adjustl(dft_inp_path)),trim(adjustl(structure_input_filename))
  else
    write(full_filename,'(2a)')trim(adjustl(gs_path)),trim(adjustl(structure_input_filename))
  end if
  write(log_file,*)"Structure data full filename: ",trim(adjustl(full_filename))
  open(structure_input_file,file=trim(adjustl(full_filename)),action='read',status='old',iostat=error_code)
  if(error_code/=0) then
    write(log_file,'(3a)')"ERROR: cannot open file '",trim(adjustl(full_filename)),"' in input_atom"
    stop
  endif
  write(full_filename2,'(2a)')trim(adjustl(combine_gs_2path)),trim(adjustl(structure_input_filename))
  write(log_file,*)"Structure datafile 2 full filename: ",trim(adjustl(full_filename2))
  open(structure_input_file2,file=trim(adjustl(full_filename2)),action='read',status='old',iostat=error_code)
  if(error_code/=0) then
    write(log_file,'(3a)')"ERROR: cannot open file '",trim(adjustl(full_filename2)),"' in input_atom"
    stop
  endif

  if(get_file_line(structure_input_file,file_line,num_elements)) then
    if(num_elements==4) then
      read(file_line,*)N_total_atom_gs1,N_atom_L,N_atom_C,N_atom_R
    else
      write(log_file,*)"ERROR: Invalid number of items in input file line:"
      write(log_file,*)trim(adjustl(file_line))
      stop
    endif
  else
    write(log_file,*)"ERROR: premature end of structure input file"
    stop
  endif
  if(get_file_line(structure_input_file2,file_line,num_elements)) then
    if(num_elements==4) then
      read(file_line,*)N_total_atom_gs2,N_atom_L,N_atom_C,N_atom_R
    else
      write(log_file,*)"ERROR: Invalid number of items in input file line:"
      write(log_file,*)trim(adjustl(file_line))
      stop
    endif
  else
    write(log_file,*)"ERROR: premature end of structure input file"
    stop
  endif
  N_total_atom=N_total_atom_gs1+N_total_atom_gs2
  combine_gs_num_atom_file1=N_total_atom_gs1
  combine_gs_num_atom_file2=N_total_atom_gs2
  
  i=N_total_atom
  allocate(Position(3,i),Position_init(3,i),closest_ion_init(i))
  allocate(l_max_basis(i),N_ao(i),atom_index(i),gauss_p(ngm),box_atom(i))
    
    allocate(atom_movable(N_total_atom))
    atom_movable=.TRUE.

  do k=1,N_total_atom_gs1
    if(get_file_line(structure_input_file,file_line,num_elements)) then
      if(num_elements==5) then
        read(file_line,*)(Position(i,k),i=1,3),atom_index(k),box_atom(k)
      elseif((.not.move_all_atoms).AND.(num_elements==6)) then
        read(file_line,*)(Position(i,k),i=1,3),atom_index(k),box_atom(k),atom_movable(k)
      else
        write(log_file,*)"ERROR: Invalid number of items in input file line:"
        write(log_file,*)trim(adjustl(file_line))
        stop
      endif
	  write(log_file,'(a,4F16.7,i4)') "read file 1",Position(1:3,k),atom_index(k)
    else
      write(log_file,*)"ERROR: premature end of structure input file"
      stop
    endif
  enddo

  do k=N_total_atom_gs1+1,N_total_atom
    if(get_file_line(structure_input_file2,file_line,num_elements)) then
      if(num_elements==5) then
        read(file_line,*)(Position(i,k),i=1,3),atom_index(k),box_atom(k)
      elseif((.not.move_all_atoms).AND.(num_elements==6)) then
        read(file_line,*)(Position(i,k),i=1,3),atom_index(k),box_atom(k),atom_movable(k)
      else
        write(log_file,*)"ERROR: Invalid number of items in input file line:"
        write(log_file,*)trim(adjustl(file_line))
        stop
      endif
	  write(log_file,'(a,4F16.7,i4)') "read file 2",Position(1:3,k),atom_index(k)
    else
      write(log_file,*)"ERROR: premature end of structure input file2"
      stop
    endif
  enddo
  
end if
  
  
  Position_init=Position

  if((run_type==19).OR.(run_type==20)) box_atom=1

  N_box=maxval(box_atom)
  write(log_file,*)"N_box: ",N_box

  ! Count the number of different elements
  N_Species=0
  do k=1,N_total_atom
    k2=0
    do k1=1,k-1
	  if(read_isotope_mass) then
	    diff=(isotope_masses(k1)-isotope_masses(k))
		if((diff<1.0d-4).AND.(atom_index(k1)==atom_index(k))) k2=1
	  else
        if(atom_index(k1)==atom_index(k)) k2=1
	  end if
    enddo
    if(k2==0)  then
      N_Species=N_Species+1
      elem(atom_index(k))=N_species
      z_atom(N_species)=atom_index(k)
	  if(read_isotope_mass) m_atom(N_species)=isotope_masses(k)
    endif
  enddo


  do k=1,N_total_atom
    atom_index(k)=elem(atom_index(k))
  enddo

  allocate(N_ao_l(0:lexp,N_species))

  if(.not.periodic) then
    if(box_type==1) then ! rectangular box
      if(get_file_line(structure_input_file,file_line,num_elements)) then
        if(num_elements==4) then
          read(file_line,*)grid_step(1),n_lattice(1),n_lattice(2),n_lattice(3)
          grid_step(2)=grid_step(1)
          grid_step(3)=grid_step(1)
        elseif(num_elements==6) then
          read(file_line,*)grid_step(1),grid_step(2),grid_step(3),n_lattice(1),n_lattice(2),n_lattice(3)
        else
          write(log_file,*)"ERROR: Invalid number of step sizes and/or lattice sizes in input file line:"
          write(log_file,*)trim(adjustl(file_line))
          stop
        endif
      else
        write(log_file,*)"ERROR: premature end of structure input file"
        stop
      endif
      write(log_file,*)'rectangular box'
    elseif(box_type==2) then ! spherical box
      if(get_file_line(structure_input_file,file_line,num_elements)) then
        if(num_elements==2) then
          read(file_line,*)Grid_step(1),Box_radius
          grid_step(2)=grid_step(1)
          grid_step(3)=grid_step(1)
          N_Lattice=Box_radius/grid_step(1)+1
        else
          write(log_file,*)"ERROR: expecting step size and box radius in input file line:"
          write(log_file,*)trim(adjustl(file_line))
          stop
        endif
      else
        write(log_file,*)"ERROR: premature end of structure input file"
        stop
      endif
      write(log_file,*)'spherical box, box radius:',box_radius
    else if(box_type==3) then ! grape box
     if(get_file_line(structure_input_file,file_line,num_elements)) then
       if(num_elements==1) then
         read(file_line,*)grid_step(1)
         grid_step(2)=grid_step(1)
         grid_step(3)=grid_step(1)
       elseif(num_elements==2) then
         read(file_line,*)grid_step(1)
         grid_step(2)=grid_step(1)
         grid_step(3)=grid_step(1)
         write(log_file,*)"WARNING: ignore all but the first value in input file line:"
         write(log_file,*)trim(adjustl(file_line))
         write(log_file,*)"Lattice size is not read from file"
         write(log_file,*)"Lattice size is always set automatically for box_type=3"
       elseif(num_elements==3) then
         read(file_line,*)grid_step(1),grid_step(2),grid_step(3)
       elseif(num_elements==4) then
         read(file_line,*)grid_step(1)
         grid_step(2)=grid_step(1)
         grid_step(3)=grid_step(1)
         write(log_file,*)"WARNING: ignore all but the first value in input file line:"
         write(log_file,*)trim(adjustl(file_line))
         write(log_file,*)"Lattice size is not read from file"
         write(log_file,*)"Lattice size is always set automatically for box_type=3"
       elseif(num_elements==6) then
         read(file_line,*)grid_step(1),grid_step(2),grid_step(3)
         write(log_file,*)"WARNING: ignore all but the first three values in input file line:"
         write(log_file,*)trim(adjustl(file_line))
         write(log_file,*)"Lattice size is not read from file"
         write(log_file,*)"Lattice size is always set automatically for box_type=3"
       else
          write(log_file,*)"ERROR: Invalid number of lattice sizes in input file line:"
          write(log_file,*)trim(adjustl(file_line))
          stop
       endif
     else
       write(log_file,*)"ERROR: premature end of structure input file"
       stop
     endif
     write(log_file,*)'grape box'
   endif
  else ! rectangular box with periodic boundary conditions
    if(get_file_line(structure_input_file,file_line,num_elements)) then
      if(num_elements==6) then
        read(file_line,*)Grid_step(1),grid_step(2),grid_step(3),N_Lattice(1),N_lattice(2),N_lattice(3)
      else
        write(log_file,*)"ERROR: With periodic, need three step sizes and three lattice sizes in input file line:"
        write(log_file,*)trim(adjustl(file_line))
        stop
      endif
    else
      write(log_file,*)"ERROR: premature end of structure input file"
      stop
    endif
    write(log_file,*)'rectanglar box, periodic boundary conditions'
    if((-1)**N_Lattice(1)>=0) then
      write(log_file,*)"ERROR: With periodic, N_Lattice(1) should be odd"
      write(log_file,*)trim(adjustl(file_line))
      stop
    endif
    if((-1)**N_Lattice(2)>=0) then
      write(log_file,*)"ERROR: With periodic, N_Lattice(2) should be odd"
      write(log_file,*)trim(adjustl(file_line))
      stop
    endif
    if((-1)**N_Lattice(3)>=0) then
      write(log_file,*)"ERROR: With periodic, N_Lattice(3) should be odd"
      write(log_file,*)trim(adjustl(file_line))
      stop
    endif

  endif

  if(combine_gs) then ! make sure grids are the same
      if(get_file_line(structure_input_file2,file_line,num_elements)) then
        if(num_elements==4) then
          read(file_line,*)combine_grid_info(1),combine_grid_info_lat(1),combine_grid_info_lat(2),combine_grid_info_lat(3)
          combine_grid_info(2)=combine_grid_info(1)
          combine_grid_info(3)=combine_grid_info(1)
        elseif(num_elements==6) then
          read(file_line,*)combine_grid_info(1),combine_grid_info(2),combine_grid_info(3),combine_grid_info_lat(1) &
		                   &,combine_grid_info_lat(2),combine_grid_info_lat(3)
        else
          write(log_file,*)"ERROR: Invalid number of step sizes and/or lattice sizes in input file line:"
          write(log_file,*)trim(adjustl(file_line))
          stop
        endif
		if(combine_grid_info(1)/=grid_step(1)) then
		  write(log_file,*) "grids do not match between the 2 gs calculations"
		  write(log_file,*) 1,combine_grid_info(1),grid_step(1)
		  stop
		end if
		if(combine_grid_info(2)/=grid_step(2)) then
		  write(log_file,*) "grids do not match between the 2 gs calculations"
		  write(log_file,*) 2,combine_grid_info(2),grid_step(2)
		  stop
		end if
		if(combine_grid_info(3)/=grid_step(3)) then
		  write(log_file,*) "grids do not match between the 2 gs calculations"
		  write(log_file,*) 3,combine_grid_info(3),grid_step(3)
		  stop
		end if
		if(combine_grid_info_lat(1)/=n_lattice(1)) then
		  write(log_file,*) "grids do not match between the 2 gs calculations"
		  write(log_file,*) 4,combine_grid_info_lat(1),n_lattice(1)
		  stop
		end if
		if(combine_grid_info_lat(2)/=n_lattice(2)) then
		  write(log_file,*) "grids do not match between the 2 gs calculations"
		  write(log_file,*) 5,combine_grid_info_lat(2),n_lattice(2)
		  stop
		end if
		if(combine_grid_info_lat(3)/=n_lattice(3)) then
		  write(log_file,*) "grids do not match between the 2 gs calculations"
		  write(log_file,*) 6,combine_grid_info_lat(3),n_lattice(3)
		  stop
		end if
      else
        write(log_file,*)"ERROR: premature end of structure input file"
        stop
      endif
  end if
  
  if(spin_polarized)then
    if(get_file_line(structure_input_file,file_line,num_elements)) then
      if(num_elements==2) then
        read(file_line,*) N_orbitals_down,N_orbitals_up
      else
        write(log_file,*)"ERROR: Invalid number of items in input file line:"
        write(log_file,*)trim(adjustl(file_line))
        stop
      endif
    else
      write(log_file,*)"ERROR: premature end of structure input file"
      stop
    endif
  endif

  allocate(Nx_box(N_box),N_box_basis(N_box),box_opt(N_box))

  N_box_basis=0

  if(box_basis_type==2) then
    do i=1,N_box
      if(get_file_line(structure_input_file,file_line,num_elements)) then
        if(num_elements==4) then
          read(file_line,*)j,Nx_box(i),N_box_basis(i),box_opt(i)
        else
          write(log_file,*)"ERROR: Invalid number of items in input file line:"
          write(log_file,*)trim(adjustl(file_line))
          stop
        endif
      else
        write(log_file,*)"ERROR: premature end of structure input file"
        stop
      endif
    enddo
  endif

  if(dendiv_output) then
    if(get_file_line(structure_input_file,file_line,num_elements)) then
      if(num_elements==2) then
        read(file_line,*)j,Nx_box(1)
      else
        write(log_file,*)"ERROR: Invalid number of items in input file line:"
        write(log_file,*)trim(adjustl(file_line))
        stop
      endif
    else
      write(log_file,*)"ERROR: premature end of structure input file"
      stop
    endif
  endif

  close(structure_input_file)
  close(structure_input_file2)
  write(log_file,*)'input_atom     :  OK'
END SUBROUTINE input_atom

SUBROUTINE input_basis
  integer       :: i,j,l,it,k,kk,atom,m,ll,error_code
  real*8        :: dd,c(Ngm)
  character*255 :: full_filename,symbol

  write(full_filename,'(2a)')trim(adjustl(bf_path)),trim(adjustl(gb_dat_filename))
  write(log_file,*)"GB data full filename: ",trim(adjustl(full_filename))

  open(gb_dat_file,file=trim(adjustl(full_filename)),action='read',status='old',iostat=error_code)
  if(error_code/=0) then
    write(log_file,'(3a)')"ERROR: cannot open file '",trim(adjustl(full_filename)),"' in input_basis"
    stop
  endif

  read(gb_dat_file,*)Ng,a0,x0,isg
  close(gb_dat_file)
  N_ao_max=Ng*(lexp+1)**2

  allocate(c_exp(Ng,Ng,0:lexp,N_species_max),atom_occ(N_ao_max,0:lexp,N_species_max))
  allocate(basis_ind(ng,-lexp:lexp,0:lexp,N_total_atom))

  l_max_basis=0
  if(.NOT.contracted) then
    do k=1,N_total_atom
      i=atom_index(k)
      if(z_atom(i)/=0) then
        l_max_basis(i)=lexp
        N_ao(i)=(l_max_basis(i)+1)**2*Ng
        do l=0,lexp
          N_ao_l(l,i)=Ng
        enddo
      else
        l_max_basis(i)=0
        N_ao(i)=1
        N_ao_l(:,i)=0
        N_ao_l(0,i)=1
      endif
    enddo

    do it=1,N_species
      if(z_atom(it)/=0) then
        do l=0,lexp
          do i=1,N_ao_l(l,it)
            do j=1,Ng
              dd=0.d0
              if(i==j) dd=1.d0
              c_exp(j,i,l,it)=dd
            enddo
          enddo
        enddo
      else
        c_exp(:,1,0,it)=0.d0
        c_exp(isg,1,0,it)=1.d0
      endif
    enddo
  else
    do atom=1,N_species
      k=z_atom(atom)
      it=atom
      if(z_atom(it)/=0) then
				l_max_basis(it)=lexp

				symbol=element_symbols(k)
				call convert_to_lowercase(symbol)
				write(full_filename,'(3a)')trim(adjustl(bf_path)),trim(adjustl(symbol)),trim(adjustl(bf_suffix))
				write(log_file,*)"LCAO basis functions full_filename: ",trim(adjustl(full_filename))

				open(bf_file,file=trim(adjustl(full_filename)),action='read',status='old',iostat=error_code)
				if(error_code/=0) then
					write(log_file,'(3a)')"ERROR: cannot open file '",trim(adjustl(full_filename)),"' in input_basis"
					stop
				endif

				read(bf_file,*)i,(N_ao_l(l,it),l=0,lexp)
				write(log_file,*)i,(N_ao_l(l,it),l=0,lexp)
				if(i/=Ng) then
					write(log_file,*)"ERROR: wrong basis1"
					stop
				endif

				do l=0,lexp
					if(N_ao_l(l,it)>Ng) then
						write(log_file,*)"ERROR: wrong basis2"
						stop
					endif

					do j=1,Ng
						read(bf_file,*)dd,ll
						if(ll/=l) then
							write(log_file,*)"ERROR: wrong basis3"
							stop
						endif
						do m=1,Ng
							read(bf_file,*)c(m)
						enddo
						if(j<=N_ao_l(l,it)) then
							atom_occ(j,l,it)=dd
							do m=1,Ng
								c_exp(m,j,l,it)=c(m)
							enddo
						endif
					enddo
				enddo
      else
				l_max_basis(it)=0
				N_ao_l(:,it)=0
				N_ao_l(0,it)=1
				c_exp(:,1,0,it)=0.d0
				c_exp(isg,1,0,it)=1.d0
      endif

      kk=0
      do l=0,lexp
        do m=-l,l
          do i=1,N_ao_l(l,it)
            kk=kk+1
          enddo
        enddo
      enddo
      N_ao(it)=kk
      close(bf_file)
	  write(log_file,'(a,i3,a,a,i5)') "ATOMBASISINFO ",it," ",trim(adjustl(symbol)),N_ao(it)
    enddo
  endif

  i=0
  do atom=1,N_total_atom
    it=atom_index(atom)
    j=0
    do l=0,l_max_basis(it)
      do m=-l,l
        do k=1,N_ao_l(l,it)
          i=i+1
          j=j+1
          basis_ind(k,m,l,atom)=i
        enddo
      enddo
    enddo
  enddo
  N_diag=i
  write(log_file,*)"N_diag: ",N_diag

  N_box_basis=0
  do i=1,N_total_atom
    do j=1,N_ao(atom_index(i))
      N_box_basis(box_atom(i))=N_box_basis(box_atom(i))+1
    enddo
  enddo

  write(log_file,*)"N_box_basis:"
  do i=1,N_box
    write(log_file,*)N_box_basis(i)
  enddo

  allocate(basis_atom(2,N_diag),basis_atom_inv(N_ao_max,N_total_atom))

  kk=0
  do atom=1,N_total_atom
    do i=1,N_ao(atom_index(atom))
      kk=kk+1
      basis_atom(1,kk)=i
      basis_atom(2,kk)=atom
      basis_atom_inv(i,atom)=kk
    enddo
  enddo

  if(maxval(L_max_basis)>6) then
    write(log_file,*)"l_max_basis > 6"
    stop
  endif
END SUBROUTINE input_basis

SUBROUTINE output_scf
  integer :: i

  if (large_file_format(1:5)=='ascii') then
     open(scf_data_file,file=trim(adjustl(scf_data_filename)))
     write(scf_data_file,*)N_Lattice(1),N_Lattice(2),N_Lattice(3)
     if (complexbasis) then
        do i=1,N_Lattice_points
           write(scf_data_file,'(2ES16.8)') density(i)
        end do
     else if(spin_polarized) then
        do i=1,N_Lattice_points
           write(scf_data_file,'(2ES16.8)')density_up(i),density_down(i)
        end do
     else
        do i=1,N_Lattice_points
           write(scf_data_file,'(3ES16.8)')V_hartree(i),V_exchange(i),density(i)
        end do
     endif
     close(scf_data_file)
  else
     open(scf_data_file,file=trim(adjustl(scf_data_filename)),form='unformatted')
     write(scf_data_file) N_Lattice(1),N_Lattice(2),N_Lattice(3)
     if (complexbasis) then
        write(scf_data_file) density
     else if(spin_polarized) then
        write(scf_data_file) density_up,density_down
     else
        write(scf_data_file) V_hartree,V_exchange,density
     endif
     close(scf_data_file)
  endif
END SUBROUTINE output_scf

SUBROUTINE input_control
  character*255 :: filename

  map_block_size=20
  map_subblock_size=2

  charge_difference_has_been_set=0

  ! Set default values
  num_AO_setup_iterations_for_grid=20
  plot_bands=.FALSE.
  check_convergence_td=.FALSE.
  vdw_stretch_x=3.0d0
  vdw_stretch_y=3.0d0
  vdw_stretch_z=3.0d0
  boundary_space_xL=5.0d0
  boundary_space_xR=5.0d0
  boundary_space_yL=5.0d0
  boundary_space_yR=5.0d0
  boundary_space_zL=5.0d0
  boundary_space_zR=5.0d0
  fine_grid_spacing=0.05d0
  use_fine_grid=.FALSE.
  output_plot=.TRUE.
  output_plot_time=.TRUE.
  output_mr_density_slice=.true.
  output_mr_orbital_charge=.true.
  complexbasis=.FALSE.
  move_all_atoms=.TRUE.
  optics_key='hyp'
  Hyp_info=  'efish.info'        ! Hyp_info
  XC_in='PZ'                     ! XC kernel
  CG_Solver='CG'                 ! CG solver
  process='EFISH'                ! process
  dir='xyz'                      ! dir
  field_dir='x'                  ! field direction
  hw(1)=1.175d0             ! hw1
  hw(2)= 0.0001d0           !  hw2
  dendiv_output=.FALSE.
  md_damping_coeff=0.0d0  !friction coefficient for ionic motion
  save_trajectory=.TRUE.
  trajectory_output_frequency=50
  moldyn_output_level=5
  moldyn_output_frequency=10 ! number of ion movement iterations between molecular dynamics output
  ion_velocity_init_seed=0
  spin_polarized=.FALSE.
  continuation=.FALSE.
  box_basis_type=0
  move_atoms=.FALSE.
  use_average_atomic_mass=.TRUE.
  atomic_movement_frequency=1
  av_kin_energy_ions=0.d0
  temperature_ions=0.d0
  input_initial_velocity=.FALSE. !Arthur
  moldyn_type='ehrenfest'
  generate_bmd_seed=.FALSE.
  bmd_seed=0
  bmd_n_walker_steps=1000
  bmd_walker_step_supplied=.FALSE.
  
  tot_td_pot_output_freq=1000000000.d0 !Arthur: large enough to never happen as default
  output_tot_td_pot=.FALSE. !Arthur

  output_inner_product_frequency=1000000000.d0 !Arthur: large enough to never happen as default
  output_inner_product=.FALSE. !Arthur
  
  suppress_field_upon_ion_motion=.false.
  field_suppression_timescale=1.0d0
  field_suppression_power=2.0d0
  field_suppression_on=.false.
  field_suppression_start_time=1.0d10
  field_suppression_trd=0.1d0
  
  calculate_forces=.true.

  offdiag_elem_check_frequency=1000000
  num_large_offdiag_elem_reported=10

  use_checkpoint=.false.
  checkpoint_save_frequency=500

  !Arthur: lanczos parameters
  lanczos_update_frequency=1
  num_lanczos_vec=30

  ! Laser
  laser1_start_x=-10000.d0
  laser1_end_x=10000.d0
  laser1_start_y=-10000.d0
  laser1_end_y=10000.d0
  laser1_start_z=-10000.d0
  laser1_end_z=10000.d0

  laser2_start_x=-10000.d0
  laser2_end_x=10000.d0
  laser2_start_y=-10000.d0
  laser2_end_y=10000.d0
  laser2_start_z=-10000.d0
  laser2_end_z=10000.d0

  laser3_start_x=-10000.d0
  laser3_end_x=10000.d0
  laser3_start_y=-10000.d0
  laser3_end_y=10000.d0
  laser3_start_z=-10000.d0
  laser3_end_z=10000.d0
 !laser1_start=-10000.d0
 !laser1_end=10000.d0
 !laser2_start=-10000.d0
 !laser2_end=10000.d0
 !laser3_start=-10000.d0
 !laser3_end=10000.d0
  E_laser1=0.d0
  E_laser2=0.d0
  E_laser3=0.d0
  laser_frequency1=0.d0
  laser_frequency2=0.d0
  laser_frequency3=0.d0
  laser_phase1=0.d0
  laser_phase2=0.d0
  laser_phase3=0.d0
  laser_envelope_type1='gaussian'
  laser_envelope_type2='gaussian'
  laser_envelope_type3='gaussian'
  laser_pulse_width1=-1.d0 ! negative means laser is always on
  laser_pulse_width2=-1.d0
  laser_pulse_width3=-1.d0
  laser_pulse_shift1=0.0d0
  laser_pulse_shift2=0.0d0
  laser_pulse_shift3=0.0d0
  laser_envelope_up_point1=5.0d0
  laser_envelope_up_point2=5.0d0
  laser_envelope_up_point3=5.0d0
  laser_envelope_down_point1=10000.0d0
  laser_envelope_down_point2=10000.0d0
  laser_envelope_down_point3=10000.0d0
  laser_envelope_up_steepness1=5.0d0
  laser_envelope_up_steepness2=5.0d0
  laser_envelope_up_steepness3=5.0d0
  laser_envelope_down_steepness1=5.0d0
  laser_envelope_down_steepness2=5.0d0
  laser_envelope_down_steepness3=5.0d0
  T_sin_sq1=0.d0      ! Frequency parameters for a sin^2 laser envelope
  T_sin_sq2=0.d0      !
  T_sin_sq3=0.d0      !
  omega_sin_sq1=0.d0  ! omega_sin_sq OR f_sin_sq may be assigned, but not both.
  omega_sin_sq2=0.d0  !
  omega_sin_sq3=0.d0  !
  f_sin_sq1=0.d0      !
  f_sin_sq2=0.d0      !
  f_sin_sq3=0.d0      !
  !Projectile stuff
  use_projectile=.false.
  !initial position of the energetic particle
  projectile_x0=-100.0d0
  projectile_y0=0.0d0
  projectile_z0=0.0d0
  !initial direction of the motion
  projectile_nx0=1.0d0
  projectile_ny0=0.0d0
  projectile_nz0=0.0d0
  !mass and charge (by default it is the H^+ ion)
  projectile_charge=1.0d0
  projectile_mass=element_average_atomic_mass(1) !this value be multiplied by mass_convfactor
  !kinetic energy (in eV)
  projectile_energy=1.0d5
  !Coulomb potential control
  projectile_potential_soft_param=1.0d-5
  !Specify if the projectile coordinates/trajectory is output
  output_projectile_trajectory=.false.

  output_dipole_moment=.false.
  ! vdw force 
  use_vdw=.false.
  damping_vdw=.false.
  !Optical absorption stuff
  dipole_direction=0        ! 0 indicates all three directions
  exp_kick_strength=0.01d0  ! Exponential kick strength, f, in exp(i*f*x) perturbation.
  exp_kick_center_x=0.0d0   ! Defines the position of the sphere center. The exponential
  exp_kick_center_y=0.0d0   ! perturbation will be applied only within this spehere.
  exp_kick_center_z=0.0d0
  exp_kick_radius=sqrt(huge(exp_kick_radius)/2.0d0) !By default, the sphere size is infinite
  dip_mom_region_inf=.true. !.true. if dipole moment is evaluated by integrating density everywhere
  dip_mom_region_radius=sqrt(huge(dip_mom_region_radius)/2.0d0)
  dip_mom_region_center_x=0.0d0
  dip_mom_region_center_y=0.0d0
  dip_mom_region_center_z=0.0d0
  dpm_stretch_x=1.d0
  dpm_stretch_y=1.d0
  dpm_stretch_z=1.d0

  ramp_time=0.d0
  rwf_sm=0.001d0
  min_basis_size_for_cg=1000
  N_iteration_cg=4     ! number of CG iterations
  N_iteration_cg_gen=1 ! number of CG iterations, for generalized CG
  check_convergence=.FALSE.
  !Set a default number of empty orbitals depending on the run_type
  excitation_jump=0
  gs_laser_switch=0.d0
  psi_output_frequency=1000000000.d0 !Arthur: large enough to never happen as default
  output_full_td_density=.FALSE. ! enables/disables output of time-dependent density
  output_orb_current=.FALSE. !shenglai
  output_orb_density=.False. !shenglai
  no_scf_density=.False.
  output_td_psi=.FALSE.   !enables/disables output of wavefunction   (Jorge)
  output_coordinate_map=.FALSE.  !enables disables the output of the file with the coordinate mapping (Jorge)
  output_full_td_current_density=.FALSE. ! enables/disables output of time-dependent current density
  output_full_td_sp_energy=.FALSE. !shenglai
  non_local_current=.FALSE. !shenglai
  init_random=.FALSE. !shenglai
  transport_cap=.FALSE. !shenglai
  cap_to_edge=.FALSE. !shenglai
  huge_cap_edge=.FALSE. !shenglai
  output_orbitals=.FALSE. ! enables/disables output of time-dependent orbitals
  output_orbitals2=.false. ! enables/disables output of absolute squares of time-dependent orbitals
  gs_data_output_frequency=10 ! number of iterations between ground state data output
  gs_dens_output_frequency=1000 ! number of iterations between ground state density output
  td_data_output_frequency=10 ! number of iterations between time-dependent data output
  td_density_output_frequency=20 ! number of iterations between time-dependent density output, if enabled
  td_current_density_output_frequency=20 ! number of iterations between time-dependent current density output, if enabled
 td_sp_energy_output_frequency=20 
 td_orb_current_output_frequency=20
  orbital_output_num=1 !number of time-dependent orbitals which will be outputted, counting from HOMO 
                          !(1 - only HOMO, 2 - HOMO and HOMO-1, etc.)
  orbital_up_output_num=1
  orbital_down_output_num=1  
  td_orbital_output_frequency=20
  orb_en_comp_output_frequency=20 !number of iterations between output of orbital energy components
  orb_en_comp_output_level=0 !number of outputted energy components for each orbital
  gs_path=default_gs_path
  bg_beta=7.d0
  N_scf_iter_max=100
  N_non_scf_iter_max=0 !Arthur's notes: This is for converging high LUMO's.  Only use if density is sufficiently converged.
  N_opt=100
  time_step=0.001d0
  N_time_steps=0
  grid_type=1
  cap_left=-100000.d0
  cap_right=100000.d0  
  cap_left1=-100000.d0
  cap_right1=100000.d0
  cap_left2=-100000.d0
  cap_right2=100000.d0
  cap_left3=-100000.d0
  cap_right3=100000.d0
  injection_x1=100000
  injection_x2=100000
  injection_y1=100000
  injection_y2=100000
  injection_z1=100000
  injection_z2=100000
  save_cap=.false.
  add_projector_cap=.false.
  using_injection=.false.
  E_ext=0.d0
  V_step=0.d0
  V_step_end=0.d0
  buffer=0.d0
  source_type=0
  box_type=1
  tddft_type=2
  wp_momentum=0.d0
  wp_center=0.d0
  wp_width=1.d0
  use_high_energy_wp=.FALSE.
  mixer_type=0    !0=linear,1=pulay
  mixer_hist=5
  mixer_weight=20.d0
  mixer_beta=0.025d0
  mixer_ibeta=0.01d0
  mixer_kbeta=0.05d0
  mixer_ninit=3
  mixer_nkick=0
  mixer_abeta=.FALSE.
  mixer_a0=0.95d0
  mixer_dynamic = .FALSE.
  mixer_beta_min=0.001d0
  mixer_beta_max=0.2d0
  mixer_dyn_f1 = 0.5d0
  mixer_dyn_f2 = 2.0d0
  ediff=1.0d-5
  pdiff=1.0d-4
  periodic=.FALSE.
  transport=.FALSE.
  contracted=.TRUE.
  E_fermi=0.d0
  V_bias=0.d0
  fd_p_full=.FALSE.
  fermi_energy_search=.FALSE.
  td_density_output_format="default"
  td_current_density_output_format="default"
  td_total_3D_potential_output_format="default" 
  large_file_format="ascii"  ! ascii or binary
  propagator="taylor" ! taylor or lanczos or lanczos_gs
  structure_input_filename="dft.inp"
  cap_parameter=0.3d0
  cap_buffer=0.d0 !shenglai
  save_lattice_view=.false.

  !kpoint controls
  kpoint_type='g'
  nkv=1

  !basis caching controls
  n_basis_cache=10000
  cache_basis=.false.
  radial_fine_grid=0.001d0

  recalc_kpoint = .true.

  orbital_index=0
  
  ! Read parameter values from a file
  call parse(trim(adjustl(control_input_filename)))

  write(log_file,*)'pp_path: ',trim(adjustl(pp_path))
  write(log_file,*)'bf_path: ',trim(adjustl(bf_path))
  write(log_file,*)'gs_path: ',trim(adjustl(gs_path))
  write(log_file,*)'run_type',run_type
  write(log_file,*)'continuation',continuation

  if (default_N_empty) then
    select case (run_type)
    case(9, 14, 24, 25, 60, 77, 78, 79)
      N_empty=0
    case default
      N_empty=5
    endselect
  endif

  if((.NOT.continuation).AND.(run_type>20)) then
    if((run_type/=25).AND.(run_type/=60).AND.(run_type/=77).AND.(run_type/=78).AND.(run_type/=79)) then
      write(log_file,*)"ERROR: this run type only works in continuation mode"
      stop
	endif
  endif

  select case(run_type)
    case(14) ! dft_grid
      write(log_file,*)'run type:  dft_grid'
      potint_analytic=.FALSE.
      grid_calculation=.TRUE.

    case(24) ! tddft_grid
      write(log_file,*)'run type:  tddft_grid'
      potint_analytic=.FALSE.
      grid_calculation=.TRUE.

    case(77) ! cody:   optimize on grid
      write(log_file,*)'run type: optimize on grid using GS forces'
      potint_analytic=.FALSE.
      grid_calculation=.TRUE.
      periodic=.FALSE.	  ! periodic may be added in but periodic boundaries need consideration

    case(78) ! cody:   print grid info. Runs SCF procedure
      write(log_file,*)'run type: print grid information. Run SCF first or read in'
      potint_analytic=.FALSE.
      grid_calculation=.TRUE.
      periodic=.FALSE.	  ! periodic may be added in but periodic boundaries need consideration

    case(79) ! cody:   print grid info. Runs SCF procedure
      write(log_file,*)'run type: print lattice information. No calculation performed'
      potint_analytic=.FALSE.
      grid_calculation=.TRUE.
      periodic=.FALSE.	  ! periodic may be added in but periodic boundaries need consideration

	  
    case default
      write(log_file,*)'run type:  Incorrect mode'
      stop
  end select

  if(box_type==2) then
    if(.NOT.grid_calculation) then
      write(log_file,*)"ERROR: spherical box only works with grid_calculation"
      stop
    endif
    if(grid_type/=1) then
      write(log_file,*)"ERROR: spherical box only works with finite differences"
      stop
    endif
  endif
  if(box_type==3) then
    if(.NOT.grid_calculation) then
      write(log_file,*)"ERROR: grape box only works with grid_calculation"
      stop
    endif
    if(grid_type/=1) then
      write(log_file,*)"ERROR: grape box only works with finite differences"
      stop
    endif
  endif
end subroutine input_control

FUNCTION get_num_mr(input_filename)
  integer          :: i,j,get_num_mr,the_index,error_code
  real*8           :: the_value
  character(len=*) :: input_filename
  character*255    :: file_line,the_key,value_string

  get_num_mr=0

  open(get_num_mr_file,file=trim(adjustl(input_filename)),action='read',status='old',iostat=error_code)
  if(error_code/=0) then
    write(log_file,'(3a)')"ERROR: cannot open file '",trim(adjustl(input_filename)),"' in get_num_mr"
    stop
  endif

  do
    read(get_num_mr_file,'(a)',end=111)file_line

    ! Ignore anything on the line that appears after a #
    i=index(file_line,'#')
    if(i>0) then
      file_line=file_line(1:i-1)
    endif

    i=index(file_line,'=')
    if(i>0) then
      read(file_line(1:i-1),'(a)')the_key
      read(file_line(i+1:),'(a)')value_string
      call convert_to_lowercase(the_key)

      j=index(the_key,"xmr")
      if(j>0) then
        get_num_mr=get_num_mr+1
        cycle
      endif
    endif
  enddo
111 close(get_num_mr_file)
END FUNCTION get_num_mr

SUBROUTINE parse_quick(input_filename) ! read in the control file before anything else to grab some key params
implicit none
character(len=*) :: input_filename
character*255    :: file_line,the_key,value_string
integer          :: i,j,error_code

  open(parse_file,file=trim(adjustl(input_filename)),action='read',status='old',iostat=error_code)
  if(error_code/=0) then
    write(*,'(3a)')"ERROR: cannot open file '",trim(adjustl(input_filename)),"' in parse"
    stop
  endif
  do
    read(parse_file,'(a)',end=110)file_line

    ! Ignore anything on the line that appears after a #
    i=index(file_line,'#')
    if(i>0) then
      file_line=file_line(1:i-1)
    endif
    i=index(file_line,'=')
    if(i==0) then
      cycle
    else
      read(file_line(1:i-1),'(a)')the_key
      read(file_line(i+1:),'(a)')value_string
      call convert_to_lowercase(the_key)
	  ! ----------------- BEGIN POSSIBLE SPECIAL KEYWORDS
	  if(trim(adjustl(the_key))=="change_name_monitor") then
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            change_name_monitor=.TRUE.
			write(*,*) "change_name_monitor=.TRUE."
          else
            change_name_monitor=.FALSE.
          endif
	  end if
	  if(trim(adjustl(the_key))=="do_not_overwrite") then
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            do_not_overwrite=.TRUE.
			write(*,*) "do_not_overwrite=.TRUE."
          else
            do_not_overwrite=.FALSE.
          endif
	  end if
	  if(trim(adjustl(the_key))=="smart_restart_detect") then
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            smart_restart_detect=.TRUE.
			write(*,*) "smart_restart_detect=.TRUE."
          else
            smart_restart_detect=.FALSE.
          endif
	  end if
	  if(trim(adjustl(the_key))=="split_up_gen_nlpp") then
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            split_up_gen_nlpp=.TRUE.
			write(*,*) "split_up_gen_nlpp=.TRUE."
          else
            split_up_gen_nlpp=.FALSE.
          endif
	  end if
	  
	  
	  ! ----------------- END POSSIBLE SPECIAL KEYWORDS
    endif
  enddo
110 close(parse_file)
  
END SUBROUTINE parse_quick

SUBROUTINE parse(input_filename)
  integer          :: i,j,set_pp_path,set_bf_path,the_index,num_mr,found_user_mr,error_code
  integer          :: temperature_counter,projectile_energy_counter,projectile_v0_counter
  real*8           :: the_value
  character(len=*) :: input_filename
  character*255    :: file_line,the_key,value_string,temp_string
  integer          :: laser1freqset,laser2freqset,laser3freqset
  integer          :: laser1intenset,laser2intenset,laser3intenset
  real*8           :: laser_wavelength1,laser_wavelength2,laser_wavelength3
  real*8           :: laser_intensity1,laser_intensity2,laser_intensity3
  real*8           :: s

  num_mr=get_num_mr(input_filename)
  if(num_mr==0) then
    found_user_mr=0
    num_mr=2
  else
    found_user_mr=1
  endif

  allocate(mr(num_mr),xmr(num_mr),user_set_xmr(num_mr))
  user_set_xmr=0

  temperature_counter=0
  projectile_energy_counter=0
  projectile_v0_counter=0
  set_pp_path=0
  set_bf_path=0
  laser1freqset=0
  laser2freqset=0
  laser3freqset=0
  laser1intenset=0
  laser2intenset=0
  laser3intenset=0

  open(parse_file,file=trim(adjustl(input_filename)),action='read',status='old',iostat=error_code)
  if(error_code/=0) then
    write(log_file,'(3a)')"ERROR: cannot open file '",trim(adjustl(input_filename)),"' in parse"
    stop
  endif
  do
    read(parse_file,'(a)',end=110)file_line

    ! Ignore anything on the line that appears after a #
    i=index(file_line,'#')
    if(i>0) then
      file_line=file_line(1:i-1)
    endif

    i=index(file_line,'=')
    if(i==0) then
      cycle
    else
      read(file_line(1:i-1),'(a)')the_key
      read(file_line(i+1:),'(a)')value_string
      call convert_to_lowercase(the_key)

      if(found_user_mr==1) then
			  j=index(the_key,"xmr")
			  if(j>0) then
			    read(the_key(j+3:),*)the_index
			    read(value_string,*)xmr(the_index)
			    user_set_xmr(the_index)=1
			    cycle
			  endif
      endif

      select case(trim(adjustl(the_key)))
        case("num_ao_setup_iterations_for_grid")
          read(value_string,*)num_AO_setup_iterations_for_grid
        case("map_block_size")
          read(value_string,*)map_block_size
        case("map_subblock_size")
          read(value_string,*)map_subblock_size          
        case("cap_parameter")
          read(value_string,*)cap_parameter
        case("cap_buffer") !shenglai
          read(value_string,*)cap_buffer
        case("trajectory_output_frequency")
          read(value_string,*)trajectory_output_frequency
        case("moldyn_output_level")
          read(value_string,*)moldyn_output_level
        case("moldyn_output_frequency")
          read(value_string,*)moldyn_output_frequency
        case("atomic_movement_frequency")
          read(value_string,*)atomic_movement_frequency
        case("bmd_seed")
          read(value_string,*)bmd_seed  
        case("bmd_n_walker_steps")
          read(value_string,*)bmd_n_walker_steps       
        case("bmd_walker_step")
          read(value_string,*)bmd_walker_step
          bmd_walker_step_supplied=.TRUE.
        case("e_fermi")
          read(value_string,*)e_fermi
        case("v_bias")
          read(value_string,*)v_bias 
      	case("min_basis_size_for_cg")
          read(value_string,*)min_basis_size_for_cg        
      	case("n_iteration_cg")
          read(value_string,*)N_iteration_cg
        case("n_iteration_cg_gen")
          read(value_string,*)N_iteration_cg_gen
        case("n_empty")
          read(value_string,*)N_empty
          default_N_empty=.false.
        case("excitation_jump")
          read(value_string,*)excitation_jump
        case("gs_data_output_frequency")
          read(value_string,*)gs_data_output_frequency
        case("gs_dens_output_frequency")
          read(value_string,*)gs_dens_output_frequency
        case("td_data_output_frequency")
          read(value_string,*)td_data_output_frequency
        case("td_density_output_frequency")
          read(value_string,*)td_density_output_frequency
        case("orbital_output_num")
          read(value_string,*)orbital_output_num
        case("orbital_up_output_num")
          read(value_string,*)orbital_up_output_num
        case("orbital_down_output_num")
          read(value_string,*)orbital_down_output_num          
        case("td_current_density_output_frequency")
          read(value_string,*)td_current_density_output_frequency
        case("td_orb_current_output_frequency")
          read(value_string,*)td_orb_current_output_frequency
        case("td_orbital_output_frequency")
          read(value_string,*)td_orbital_output_frequency 
        case("orb_num")
          read(value_string,*)orb_num         
        case("orb_en_comp_output_frequency")
          read(value_string,*)orb_en_comp_output_frequency
        case("orb_en_comp_output_level")
          read(value_string,*)orb_en_comp_output_level
        case("time_step")
          read(value_string,*)time_step
        case("grid_type")
          read(value_string,*)grid_type
        case("fine_grid_spacing")
          read(value_string,*)fine_grid_spacing
        case("n_time_steps")
          read(value_string,*)n_time_steps
        case("n_scf_iter_max")
          read(value_string,*)n_scf_iter_max
       case("n_non_scf_iter_max")
          read(value_string,*)n_non_scf_iter_max
        case("calculate_forces")
          read(value_string,*)calculate_forces
        case("optics_key")
          read(value_string,*)optics_key
        case("hyp_info")
          read(value_string,*)Hyp_info
        case("xc_in")
          read(value_string,*)XC_in
        case("cg_solver")
          read(value_string,*)CG_Solver
        case("process")
          read(value_string,*)process
        case("dir")
          read(value_string,*)dir
        case("hw(1)")
          read(value_string,*) hw(1)
        case("hw(2)")
          read(value_string,*) hw(2)
        case("n_opt")
          read(value_string,*)n_opt
        case("rwf_sm")
          read(value_string,*)rwf_sm
        case("ramp_time")
          read(value_string,*)ramp_time
        case("vdw_stretch_x")
          read(value_string,*)vdw_stretch_x
        case("vdw_stretch_y")
          read(value_string,*)vdw_stretch_y
        case("vdw_stretch_z")
          read(value_string,*)vdw_stretch_z
        case("boundary_space_xL")
          read(value_string,*)boundary_space_xL
        case("boundary_space_xR")
          read(value_string,*)boundary_space_xR
        case("boundary_space_yL")
          read(value_string,*)boundary_space_yL
        case("boundary_space_yR")
          read(value_string,*)boundary_space_yR
        case("boundary_space_zL")
          read(value_string,*)boundary_space_zL
        case("boundary_space_zR")
          read(value_string,*)boundary_space_zR
        case("psi_output_frequency") !Arthur
          read(value_string,*) psi_output_frequency
     !   case("psi_td_frequency") !Jorge
         ! read(value_string,*) psi_output_frequency
       case("tot_td_pot_output_freq") !Arthur
          read(value_string,*) tot_td_pot_output_freq
       case("output_tot_td_pot") !Arthur                                                                     
          read(value_string,*) output_tot_td_pot
       case("output_inner_product") !Arthur
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
               .OR.(trim(adjustl(value_string))==".true.")) then
             output_inner_product=.TRUE.
          else
             output_inner_product=.FALSE.
          endif
       case("output_inner_product_frequency") !Arthur
          read(value_string,*) output_inner_product_frequency

       case("output_inner_product_s2") !cody
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
               .OR.(trim(adjustl(value_string))==".true.")) then
             output_inner_product_s2=.TRUE.
			 write(log_file,*) 'Output inner products using style 2'
          else
             output_inner_product_s2=.FALSE.
          endif
		  
       case("output_inner_product_virtual") !cody
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
               .OR.(trim(adjustl(value_string))==".true.")) then
             output_inner_product_virtual=.TRUE.
			 write(log_file,*) 'evaluate inner products with virtual orbitals'
          else
             output_inner_product_virtual=.FALSE.
          endif	  	   

       case("load_virtual_orbitals") !cody
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
               .OR.(trim(adjustl(value_string))==".true.")) then
             load_virtual_orbitals=.TRUE.
			 write(log_file,*) 'load virtual orbitals from wavefuntion file'
          else
             load_virtual_orbitals=.FALSE.
          endif	  
		  
! External potentials
!        case("v_bias_magnitude")
!          read(value_string,*)V_bias_magnitude
!        case("bias_start")
!          read(value_string,*)bias_start
!        case("bias_end")
!          read(value_string,*)bias_end
        case("e_ext")
          read(value_string,*) E_ext
		case("e_ext_direction")
          read(value_string,*) E_ext_direction
        case("laser1_start_x")
          read(value_string,*)laser1_start_x
        case("v_step") !shenglai
          read(value_string,*)V_step
        case("v_step_end") !shenglai
          read(value_string,*)V_step_end
        case("buffer") !shenglai
          read(value_string,*)buffer
        case("source_type") !shenglai                                     
          read(value_string,*)source_type
        case("td_sp_energy_output_frequency") !shenglai
          read(value_string,*)td_sp_energy_output_frequency
        case("laser1_end_x")
          read(value_string,*)laser1_end_x
        case("laser1_start_y")
          read(value_string,*)laser1_start_y
        case("laser1_end_y")
          read(value_string,*)laser1_end_y
        case("laser1_start_z")
          read(value_string,*)laser1_start_z
        case("laser1_end_z")
          read(value_string,*)laser1_end_z
        case("laser2_start_x")
          read(value_string,*)laser2_start_x
        case("laser2_end_x")
          read(value_string,*)laser2_end_x
        case("laser2_start_y")
          read(value_string,*)laser2_start_y
        case("laser2_end_y")
          read(value_string,*)laser2_end_y
        case("laser2_start_z")
          read(value_string,*)laser2_start_z
        case("laser2_end_z")
          read(value_string,*)laser2_end_z
        case("laser3_start_x")
          read(value_string,*)laser3_start_x
        case("laser3_end_x")
          read(value_string,*)laser3_end_x
        case("laser3_start_y")
          read(value_string,*)laser3_start_y
        case("laser3_end_y")
          read(value_string,*)laser3_end_y
        case("laser3_start_z")
          read(value_string,*)laser3_start_z
        case("laser3_end_z")
          read(value_string,*)laser3_end_z
        case("e_laser1")
          read(value_string,*)E_laser1
          laser1intenset=laser1intenset+1
        case("md_damping_coeff")
          read(value_string,*)md_damping_coeff
        case("ion_velocity_init_seed")
          read(value_string,*)ion_velocity_init_seed
        case("av_kin_energy_ions")
          read(value_string,*)av_kin_energy_ions
          temperature_ions=(2.0d0/3.0d0)*av_kin_energy_ions/k_Boltzmann
          temperature_counter=temperature_counter+1
        case("temperature_ions")
          read(value_string,*)temperature_ions
          av_kin_energy_ions=1.5d0*temperature_ions*k_Boltzmann
          temperature_counter=temperature_counter+1
        
       case("input_initial_velocity") !Arthur
          read(value_string,*) input_initial_velocity
        case("boosted_orbital")!shenglai
            read(value_string,*)boosted_orbital
            boost=.true.
        case("boost_around_atom_idx")!cody
            read(value_string,*)boost_around_atom_idx
            boost_around_atom=.true.               
        case("boost_around_atom_rad")!cody
            read(value_string,*)boost_around_atom_rad

        case("field_suppression_timescale")
          read(value_string,*)field_suppression_timescale  
        case("field_suppression_power")
          read(value_string,*)field_suppression_power   
        case("field_suppression_trd")
          read(value_string,*)field_suppression_trd

        case("laser_envelope_type1")
          read(value_string,*)laser_envelope_type1
          if((laser_envelope_type1/='gaussian').and.(laser_envelope_type1/='fermi').and.  &
             (laser_envelope_type1/='doublefermi').and.laser_envelope_type1/='sin_sq') then
             write(log_file,*) 'Error: invalid envelope type for laser 1: ',laser_envelope_type1
             stop
          endif
        case("laser_envelope_type2")
          read(value_string,*)laser_envelope_type2
          if((laser_envelope_type2/='gaussian').and.(laser_envelope_type2/='fermi').and.  &
             (laser_envelope_type2/='doublefermi').and.laser_envelope_type2/='sin_sq') then
             write(log_file,*) 'Error: invalid envelope type for laser 2: ',laser_envelope_type2
             stop
          endif
        case("laser_envelope_type3")
          read(value_string,*)laser_envelope_type3
          if((laser_envelope_type3/='gaussian').and.(laser_envelope_type3/='fermi').and.  &
             (laser_envelope_type3/='doublefermi').and.laser_envelope_type3/='sin_sq') then
             write(log_file,*) 'Error: invalid envelope type for laser 3: ',laser_envelope_type3
             stop
          endif
        case("laser_intensity1")
          !instead of setting laser field amplitude in Volts/A one can
          !specify the laser intensity in Watts/m^2, which will be converted
          !to the laser amplitude right away.
          read(value_string,*)laser_intensity1
          E_laser1=2.74492372749469d-09*sqrt(laser_intensity1)
          laser1intenset=laser1intenset+1
        case("e_laser2")
          read(value_string,*)E_laser2
          laser2intenset=laser2intenset+1
        case("laser_intensity2")
          !instead of setting laser field amplitude in Volts/A one can
          !specify the laser intensity in Watts/m^2, which will be converted
          !to the laser amplitude right away.
          read(value_string,*)laser_intensity2
          E_laser2=2.74492372749469d-09*sqrt(laser_intensity2)
          laser2intenset=laser2intenset+1
        case("e_laser3")
          read(value_string,*)E_laser3
          laser3intenset=laser3intenset+1
        case("laser_intensity3")
          !instead of setting laser field amplitude in Volts/A one can
          !specify the laser intensity in Watts/m^2, which will be converted
          !to the laser amplitude right away.
          read(value_string,*)laser_intensity3
          E_laser3=2.74492372749469d-09*sqrt(laser_intensity3)
          laser3intenset=laser3intenset+1
        case("laser_frequency1")
          read(value_string,*)laser_frequency1
          laser1freqset=laser1freqset+1
        case("laser_wavelength1")
          !instead of setting laser frequency in rad/fs one can
          !specify the wavelength in nanometers, which will be converted
          !to frequency right away
          read(value_string,*)laser_wavelength1
          laser_frequency1=2.d0*pi*sqrt(c_squared)/(10.d0*laser_wavelength1)
          laser1freqset=laser1freqset+1
        case("laser_pulse_width1")
          read(value_string,*)laser_pulse_width1
        case("laser_pulse_shift1")
          read(value_string,*) laser_pulse_shift1
        case("laser_frequency2")
          read(value_string,*)laser_frequency2
          laser2freqset=laser2freqset+1
        case("laser_wavelength2")
          !instead of setting laser frequency in rad/fs one can
          !specify the wavelength in nanometers, which will be converted
          !to frequency right away
          read(value_string,*)laser_wavelength2
          laser_frequency2=2.d0*pi*sqrt(c_squared)/(10.d0*laser_wavelength2)
          laser2freqset=laser2freqset+1
        case("laser_pulse_width2")
          read(value_string,*)laser_pulse_width2
        case("laser_pulse_shift2")
          read(value_string,*) laser_pulse_shift2
        case("laser_frequency3")
          read(value_string,*)laser_frequency3
          laser3freqset=laser3freqset+1
        case("laser_wavelength3")
          !instead of setting laser frequency in rad/fs one can
          !specify the wavelength in nanometers, which will be converted
          !to frequency right away
          read(value_string,*)laser_wavelength3
          laser_frequency3=2.d0*pi*sqrt(c_squared)/(10.d0*laser_wavelength3)
          laser3freqset=laser3freqset+1
        case("laser_pulse_width3")
          read(value_string,*)laser_pulse_width3
        case("laser_pulse_shift3")
          read(value_string,*) laser_pulse_shift3
        case("laser_phase1")
          read(value_string,*)laser_phase1
        case("laser_phase2")
          read(value_string,*)laser_phase2
        case("laser_phase3")
          read(value_string,*)laser_phase3
        case("laser_envelope_up_point1")
          read(value_string,*)laser_envelope_up_point1
        case("laser_envelope_up_point2")
          read(value_string,*)laser_envelope_up_point2
        case("laser_envelope_up_point3")
          read(value_string,*)laser_envelope_up_point3
        case("laser_envelope_up_steepness1")
          read(value_string,*)laser_envelope_up_steepness1
        case("laser_envelope_up_steepness2")
          read(value_string,*)laser_envelope_up_steepness2
        case("laser_envelope_up_steepness3")
          read(value_string,*)laser_envelope_up_steepness3
        case("laser_envelope_down_point1")
          read(value_string,*)laser_envelope_down_point1
        case("laser_envelope_down_point2")
          read(value_string,*)laser_envelope_down_point2
        case("laser_envelope_down_point3")
          read(value_string,*)laser_envelope_down_point3
        case("laser_envelope_down_steepness1")
          read(value_string,*)laser_envelope_down_steepness1
        case("laser_envelope_down_steepness2")
          read(value_string,*)laser_envelope_down_steepness2
        case("laser_envelope_down_steepness3")
          read(value_string,*)laser_envelope_down_steepness3
        case("f_sin_sq1")
          read(value_string,*)f_sin_sq1
        case("f_sin_sq2")
          read(value_string,*)f_sin_sq2
        case("f_sin_sq3")
          read(value_string,*)f_sin_sq3
        case("omega_sin_sq1")
          read(value_string,*)omega_sin_sq1
        case("omega_sin_sq2")
          read(value_string,*)omega_sin_sq2
        case("omega_sin_sq3")
          read(value_string,*)omega_sin_sq3
        case("gs_laser_switch(1)")
          read(value_string,*)gs_laser_switch(1)
        case("gs_laser_switch(2)")
          read(value_string,*)gs_laser_switch(2)
        case("gs_laser_switch(3)")
          read(value_string,*)gs_laser_switch(3)
          ! cody: read laser from file
        case("laser_from_file")
		  !read(value_string,*) laser_xyz_filename
		  !laser_xyz_filename = trim(laser_xyz_filename)
          write(laser_xyz_filename,'(a)')trim(adjustl(value_string))
		  using_v_fromfile=.TRUE.
          call laser_read_from_file

        case("use_projectile")
          read(value_string,*)use_projectile
!  Projectile
        case("use_vdw") !shenglai
           call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            use_vdw=.TRUE.
          else
            use_vdw=.FALSE.
          endif
        case("damping_vdw") !shenglai                                               
           call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            damping_vdw=.TRUE.
          else
            damping_vdw=.FALSE.
          endif     
        case("projectile_x0")
          read(value_string,*)projectile_x0
        case("projectile_y0")
          read(value_string,*)projectile_y0
        case("projectile_z0")
          read(value_string,*)projectile_z0
        case("projectile_nx0")
          read(value_string,*)projectile_nx0
        case("projectile_ny0")
          read(value_string,*)projectile_ny0
        case("projectile_nz0")
          read(value_string,*)projectile_nz0
        case("projectile_energy")
          read(value_string,*)projectile_energy
          projectile_energy_counter=1
        case("projectile_v0")
          read(value_string,*)projectile_v0
          projectile_v0_counter=1
        case("projectile_mass")
          read(value_string,*)projectile_mass
        case("projectile_charge")
          read(value_string,*)projectile_charge
        case("projectile_potential_soft_param")
          read(value_string,*)projectile_potential_soft_param
        case("output_projectile_trajectory")
          read(value_string,*)output_projectile_trajectory
	   ! cody  add projectile to GS
       case("add_projectile_to_gs")
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            add_projectile_to_gs=.TRUE.
			write(log_file,*) ' Add projectile charge to grid for GS calculation'
          else
            add_projectile_to_gs=.FALSE.
          endif
		  
        case("orbital_index")
          read(value_string,*)orbital_index

!  Wave packet
        case("wp_width(1)")
          read(value_string,*)wp_width(1)
        case("wp_width(2)")
          read(value_string,*)wp_width(2)
        case("wp_width(3)")
          read(value_string,*)wp_width(3)
        case("wp_momentum(1)")
          read(value_string,*)wp_momentum(1)
        case("wp_momentum(2)")
          read(value_string,*)wp_momentum(2)
        case("wp_momentum(3)")
          read(value_string,*)wp_momentum(3)
        case("wp_center(1)")
          read(value_string,*)wp_center(1)
        case("wp_center(2)")
          read(value_string,*)wp_center(2)
        case("wp_center(3)")
          read(value_string,*)wp_center(3)
!
        case("bg_beta")
          read(value_string,*)bg_beta
        case("cap_left")
          read(value_string,*)cap_left
          cap_left1=cap_left
        case("cap_right")
          read(value_string,*)cap_right 
          cap_right1=cap_right
        case("cap_left1")
          read(value_string,*)cap_left1
          cap_left=cap_left1
        case("cap_right1")
          read(value_string,*)cap_right1
          cap_right=cap_right1
        case("cap_left2")
          read(value_string,*)cap_left2
        case("cap_right2")
          read(value_string,*)cap_right2
        case("cap_left3")
          read(value_string,*)cap_left3
        case("cap_right3")
          read(value_string,*)cap_right3
        case("injection_x1")
          read(value_string,*)injection_x1 
        case("injection_x2")
          read(value_string,*)injection_x2
		  inject_source_nonsingular=.TRUE.
        case("injection_y1")
          read(value_string,*)injection_y1
        case("injection_y2")
          read(value_string,*)injection_y2
          inject_source_nonsingular=.TRUE.		  
        case("injection_z1")
          read(value_string,*)injection_z1
        case("injection_z2")
          read(value_string,*)injection_z2
		  inject_source_nonsingular=.TRUE.
        case("injection_e")
          read(value_string,*)injection_E
        case("injection_p2_x1")
          read(value_string,*)injection_p2_x1 
        case("injection_p2_y1")
          read(value_string,*)injection_p2_y1 
        case("injection_p2_z1")
          read(value_string,*)injection_p2_z1 
        case("injection_p2_e")
          read(value_string,*)injection_p2_E
		  
        case("tddft_type")
          read(value_string,*)tddft_type
        case("box_type")
          read(value_string,*)box_type
        case("run_type")
          read(value_string,*)run_type
        case("output_dipole_moment")
          read(value_string,*)output_dipole_moment
        case("dipole_direction")
          read(value_string,*)dipole_direction
        case("exp_kick_strength")
            read(value_string,*)exp_kick_strength
        case("exp_kick_center_x")
            read(value_string,*)exp_kick_center_x
        case("exp_kick_center_y")
            read(value_string,*)exp_kick_center_y
        case("exp_kick_center_z")
            read(value_string,*)exp_kick_center_z
        case("exp_kick_radius")
            read(value_string,*)exp_kick_radius
        case("dip_mom_region_inf")
            read(value_string,*)dip_mom_region_inf
        case("dip_mom_region_radius")
            read(value_string,*)dip_mom_region_radius
        case("dip_mom_region_center_x")
            read(value_string,*)dip_mom_region_center_x
        case("dip_mom_region_center_y")
            read(value_string,*)dip_mom_region_center_y
        case("dip_mom_region_center_z")
            read(value_string,*)dip_mom_region_center_z
        case("dpm_stretch_x")
            read(value_string,*)dpm_stretch_x
        case("dpm_stretch_y")
            read(value_string,*)dpm_stretch_y
        case("dpm_stretch_z")
            read(value_string,*)dpm_stretch_z
        case("save_lattice_view")
          read(value_string,*)save_lattice_view
        case("structure_input_filename")
          structure_input_filename=trim(adjustl(value_string))
        case("td_density_output_format")
          td_density_output_format=trim(adjustl(value_string))
          if((trim(adjustl(value_string))/="default").AND. &
             (trim(adjustl(value_string))/="bov").AND. &
             (trim(adjustl(value_string))/="opendx")) then
            write(log_file,'(2a)')"ERROR: Invalid td_density_output_format type: ",trim(adjustl(value_string))
            stop
          endif
        case("td_current_density_output_format")
          td_current_density_output_format=trim(adjustl(value_string))
          if((trim(adjustl(value_string))/="default").AND. &
             (trim(adjustl(value_string))/="bov").AND. &
             (trim(adjustl(value_string))/="opendx")) then
            write(log_file,'(2a)')"ERROR: Invalid td_current_density_output_format type: ",trim(adjustl(value_string))
            stop
          endif
         case("td_total_3D_potential_output_format")
          td_total_3D_potential_output_format=trim(adjustl(value_string))
          if((trim(adjustl(value_string))/="default").AND. &
             (trim(adjustl(value_string))/="bov").AND. &
             (trim(adjustl(value_string))/="opendx")) then
            write(log_file,'(2a)')"ERROR: Invalid td_current_density_output_format type: ",trim(adjustl(value_string))
            stop
          endif
         case("large_file_format")
          large_file_format=trim(adjustl(value_string))
          if ((trim(adjustl(value_string))/="ascii").and. &
              (trim(adjustl(value_string))/="binary")) then
            write(log_file,'(2a)')"ERROR: Invalid large_file_format : ",trim(adjustl(value_string))
            stop
          endif
         case("propagator")
          !propagator=trim(adjustl(value_string))
          if (trim(adjustl(value_string))=="taylor") then
    		  propagator="taylor"
		  else if (trim(adjustl(value_string))=="taylor_fd_velocity") then
    		  propagator="taylor_fd_velocity"
          else if (trim(adjustl(value_string))=="taylor_wfft") then
    		  propagator="taylor_wfft"
		  else if (trim(adjustl(value_string))=="taylor_all") then
    		  propagator="taylor_all"
		  else if (trim(adjustl(value_string))=="taylor_all3d") then
    		  propagator="taylor_all3d"
          else if (trim(adjustl(value_string))=="lanczos") then
    		  propagator="lanczos"
          else if (trim(adjustl(value_string))=="lanczos_gs") then
    		  propagator="lanczos_gs"
          else if (trim(adjustl(value_string))=="lanczos_cn") then
    		  propagator="lanczos_cn"
          else if (trim(adjustl(value_string))=="split_v_krk") then
    		  propagator="split_v_krk"
          else if (trim(adjustl(value_string))=="split_v_krk_imagt") then
    		  propagator="split_v_krk_imagt"
          else if (trim(adjustl(value_string))=="split_v_rkr") then
    		  propagator="split_v_rkr"
          else if (trim(adjustl(value_string))=="split_v_mix") then
    		  propagator="split_v_mix"
          else if (trim(adjustl(value_string))=="split_cap") then
    		  propagator="split_cap"
          else if (trim(adjustl(value_string))=="split_grid") then
    		  propagator="split_grid"
          else if (trim(adjustl(value_string))=="tay_subset") then
    		  propagator="tay_subset"
          else if (trim(adjustl(value_string))=="tay_no_pot") then
    		  propagator="tay_no_pot"
          else if (trim(adjustl(value_string))=="none") then
    		  propagator="none"
		  else 
             write(log_file,'(2a)')"Warning: invalid propagator : ",trim(adjustl(value_string))
             stop

          endif
		  write(log_file,*) "Propagator set to ",trim(adjustl(propagator))
		  
        case("lanczos_update_frequency")
            read(value_string,*)lanczos_update_frequency
        case("num_lanczos_vec")
            read(value_string,*)num_lanczos_vec
        case("use_checkpoint")
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            use_checkpoint=.TRUE.
          else
            use_checkpoint=.FALSE.
          endif
        case("checkpoint_save_frequency")
          read(value_string,*)checkpoint_save_frequency
        case("pp_path")
          write(pp_path,'(a)')trim(adjustl(check_trailing_slash(value_string)))
          set_pp_path=1
        case("bf_path")
          write(bf_path,'(a)')trim(adjustl(check_trailing_slash(value_string)))
          set_bf_path=1
        case("gs_path")
          write(gs_path,'(a)')trim(adjustl(check_trailing_slash(value_string)))
		case("dft_inp_path")
		  write(dft_inp_path,'(a)')trim(adjustl(check_trailing_slash(value_string)))
		  specify_dft_inp_path=.TRUE.
		  write(log_file,*) "dft_inp_path=",dft_inp_path
		  
        case("use_high_energy_wp")
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            use_high_energy_wp=.TRUE.
          else
            use_high_energy_wp=.FALSE.
          endif
        case("check_convergence")
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            check_convergence=.TRUE.
          else
            check_convergence=.FALSE.
          endif
				case("check_convergence_td")
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            check_convergence_td=.TRUE.
          else
            check_convergence_td=.FALSE.
          endif
        case("output_full_td_density")
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            output_full_td_density=.TRUE.
          else
            output_full_td_density=.FALSE.
          endif
          case("output_orb_current") !shenglai
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            output_orb_current=.TRUE.
          else
            output_orb_current=.FALSE.
          endif
           case("output_orb_density") !shenglai
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            output_orb_density=.TRUE.
          else
            output_orb_density=.FALSE.
          endif
          case("no_scf_density") !shenglai
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            no_scf_density=.TRUE.
          else
            no_scf_density=.FALSE.
          endif
         
          
          case("output_td_psi")   !Jorge this makes a flag to enable the output of psi in TD calculations
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            output_td_psi=.TRUE.
          else
            output_td_psi=.FALSE.
          endif    
          
          case("output_coordinate_map")   !Jorge this makes a flag to enable the output of the coordinate map
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            output_coordinate_map=.TRUE.
          else
            output_coordinate_map=.FALSE.
          endif    
                 
          
          
          
        case("output_orbitals")
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            output_orbitals=.TRUE.
          else
            output_orbitals=.FALSE.
          endif   
        case("output_orbitals2")
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            output_orbitals2=.TRUE.
          else
            output_orbitals2=.FALSE.
          endif 
		  
        case("restart_update_frequency") ! cody   write restart information

		  write_restart=.TRUE.
		  read(value_string,*) restart_update_frequency
		  restart_update_iter=0
          write(log_file,*) 'Write restart file every ',restart_update_frequency,' time steps'
        case("write_restart")
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            write_restart=.TRUE.
          else
            write_restart=.FALSE.
          endif
		  
        case("resume_from_restart_taylor") ! cody   write restart information
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            resume_from_restart_taylor=.TRUE.
			! restart_last_file_written=0
			write(log_file,*) 'Calculation should restart'
          end if

        case("keep_all_restart_taylor") ! cody   do not overwrite restart information (keep all)
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            keep_all_restart=.TRUE.
			write(log_file,*) 'Restart files will not be overwritten'
          end if

        case("output_full_td_current_density")
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            output_full_td_current_density=.TRUE.
          else
            output_full_td_current_density=.FALSE.
          endif

         case("output_td_sp_energy") !shenglai
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            output_full_td_sp_energy=.TRUE.
          else
            output_full_td_sp_energy=.FALSE.
          endif    
          case("non_local_current") !shenglai
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            non_local_current=.TRUE.
          else
            non_local_current=.FALSE.
          endif    
         case("init_random") !shenglai
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            init_random=.TRUE.
          else
            init_random=.FALSE.
          endif    
          case("transport_cap") !shenglai
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            transport_cap=.TRUE.
          else
            transport_cap=.FALSE.
          endif    
        case("cap_to_edge") !shenglai
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            cap_to_edge=.TRUE.
          else
            cap_to_edge=.FALSE.
          endif    
         case("huge_cap_edge") !shenglai
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            huge_cap_edge=.TRUE.
          else
            huge_cap_edge=.FALSE.
          endif    


        case("use_fine_grid")
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            use_fine_grid=.TRUE.
          else
            use_fine_grid=.FALSE.
          endif
        case("output_plot")
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            output_plot=.TRUE.
          else
            output_plot=.FALSE.
          endif

        case("output_plot_time")
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            output_plot_time=.TRUE.
          else
            output_plot_time=.FALSE.
          endif

        case("output_mr_density_slice")
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            output_mr_density_slice=.TRUE.
          else
            output_mr_density_slice=.FALSE.
          endif

        case("output_mr_orbital_charge")
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            output_mr_orbital_charge=.TRUE.
          else
            output_mr_orbital_charge=.FALSE.
          endif

        case("move_all_atoms")
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            move_all_atoms=.TRUE.
          else
            move_all_atoms=.FALSE.
          endif
          
        case("moldyn_type")  
          call convert_to_lowercase(value_string)         
          read(value_string,*)moldyn_type
          if((moldyn_type/='ehrenfest').and.(moldyn_type/='bohmian')) then
             write(log_file,*) 'Error: invalid molecular dynamics type: ',moldyn_type
             write(log_file,*) 'Must be either ehrenfest of bohmian'
             stop
          endif

        case("generate_bmd_seed")
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            generate_bmd_seed=.TRUE.
          else
            generate_bmd_seed=.FALSE.
          endif          
         
        case("save_trajectory")
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            save_trajectory=.TRUE.
          else
            save_trajectory=.FALSE.
          endif

        case("save_cap")
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            save_cap=.TRUE.
          else
            save_cap=.FALSE.
          endif       
       
        case("add_projector_cap") !shenglai
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            add_projector_cap=.TRUE.
          else
            add_projector_cap=.FALSE.
         endif
       
        case("using_injection") !shenglai
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            using_injection=.TRUE.
          else
            using_injection=.FALSE.
         endif

        case("use_average_atomic_mass")
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            use_average_atomic_mass=.TRUE.
          else
            use_average_atomic_mass=.FALSE.
          endif

        case("spin_polarized")
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            spin_polarized=.TRUE.
          else
            spin_polarized=.FALSE.
          endif
        case("spin_up")
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            spin_up=.TRUE.
          else
            spin_down=.FALSE.
		  end if
		  
        case("spin_down")
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            spin_down=.TRUE.
          else
            spin_down=.FALSE.
          end if


        case("move_atoms")
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            move_atoms=.TRUE.
          else
            move_atoms=.FALSE.
          endif
          
        case("suppress_field_upon_ion_motion")
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            suppress_field_upon_ion_motion=.TRUE.
          else
            suppress_field_upon_ion_motion=.FALSE.
          endif          

        case("dendiv_output")
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            dendiv_output=.TRUE.
          else
            dendiv_output=.FALSE.
          endif

        case("continuation")
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            continuation=.TRUE.
          else
            continuation=.FALSE.
          endif

        case("periodic")
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            periodic=.TRUE.
          else
            periodic=.FALSE.
          endif


        case("plot_bands")
           call convert_to_lowercase(value_string)
           if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
                .OR.(trim(adjustl(value_string))==".true.")) then
              plot_bands=.TRUE.
           else
              plot_bands=.FALSE.
           endif

        case("transport")
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            transport=.TRUE.
          else
            transport=.FALSE.
          endif

       case("fermi_energy_search")
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
               .OR.(trim(adjustl(value_string))==".true.")) then
             fermi_energy_search=.TRUE.
          else
             fermi_energy_search=.FALSE.
          endif

       case("cache_basis")
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
               .OR.(trim(adjustl(value_string))==".true.")) then
             cache_basis=.TRUE.
          else
             cache_basis=.FALSE.
          endif

       case("recalc_kpoint")
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
               .OR.(trim(adjustl(value_string))==".true.")) then
             recalc_kpoint=.TRUE.
          else
             recalc_kpoint=.FALSE.
          endif

       case("kpoint_type")
          call convert_to_lowercase(value_string)
          temp_string = trim(adjustl(value_string))
          kpoint_type=temp_string(1:1)

       case("nkx")
          read(value_string,*) nkv(1)
       case("nky")
          read(value_string,*) nkv(2)
       case("nkz")
          read(value_string,*) nkv(3)

       case("n_basis_cache")
          read(value_string,*) n_basis_cache
       case("radial_fine_grid")
          read(value_string,*) radial_fine_grid


       case("mixer_type")
          read(value_string,*)mixer_type
       case("mixer_hist")
          read(value_string,*)mixer_hist
       case("mixer_weight")
          read(value_string,*)mixer_weight
       case("mixer_beta")
          read(value_string,*)mixer_beta
       case("mixer_ibeta")
          read(value_string,*)mixer_ibeta
       case("mixer_kbeta")
          read(value_string,*)mixer_kbeta
       case("mixer_ninit")
          read(value_string,*)mixer_ninit
       case("mixer_nkick")
          read(value_string,*)mixer_nkick
       case("mixer_abeta")
          read(value_string,*)mixer_abeta
       case("mixer_beta_min")
          read(value_string,*)mixer_beta_min
       case("mixer_beta_max")
          read(value_string,*)mixer_beta_max
       case("mixer_a0")
          read(value_string,*)mixer_a0
       case("mixer_dynamic")
          read(value_string,*)mixer_dynamic
       case("mixer_dyn_f1")
          read(value_string,*)mixer_dyn_f1
       case("mixer_dyn_f2")
          read(value_string,*)mixer_dyn_f2
       case("ediff")
          read(value_string,*)ediff
       case("pdiff")
          read(value_string,*)pdiff

       case("offdiag_elem_check_frequency")
          read(value_string,*) offdiag_elem_check_frequency
       case("num_large_offdiag_elem_reported")
          read(value_string,*) num_large_offdiag_elem_reported

	   ! cody  single point source injection controls
       case("output_source_td_density")
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            output_source_td_density=.TRUE.
			write(log_file,*) ' output_source_td_density=TRUE'
          else
            output_source_td_density=.FALSE.
          endif

       case("output_source_td_dens_frequency")
           output_source_td_density=.TRUE.
		   read(value_string,*) output_source_td_dens_frequency
		   write(log_file,*) ' output source TD density every ', output_source_td_dens_frequency,' steps'

       case("source_converg_value1")
		   read(value_string,*) source_converg_value1
		   write(log_file,*) ' Single point source injection convergence threashold 1 = ',source_converg_value1
       case("source_converg_value2")
		   read(value_string,*) source_converg_value2
		   write(log_file,*) ' Single point source injection convergence threashold 2 = ',source_converg_value2
       case("source_check_congerg_freq")
		   read(value_string,*) source_check_congerg_freq
		   if(source_check_congerg_freq==0) then
		     write(log_file,*) ' source_check_congerg_freq cannot have frequency of 0!'
			 stop
		   end if

		   ! Cody
       case("inject_save_wf_points")
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            inject_save_wf_points=.TRUE.
			write(log_file,*) ' Save injected Phi at discrete points '
          else
            inject_save_wf_points=.FALSE.
          endif
       case("inject_save_x_left")
		   read(value_string,*) inject_save_x_left		   
       case("inject_save_x_right")
		   read(value_string,*) inject_save_x_right	
       case("inject_save_y_left")
		   read(value_string,*) inject_save_y_left	
       case("inject_save_y_right")
		   read(value_string,*) inject_save_y_right	
       case("inject_save_z_left")
		   read(value_string,*) inject_save_z_left	
       case("inject_save_z_right")
		   read(value_string,*) inject_save_z_right			   
       case("inject_save_freq")
		   read(value_string,*) inject_save_freq		   
       case("inject_save_skip_nstep")
		   read(value_string,*) inject_save_skip_nstep		   
		   
		   
	   ! cody   calculate Dipole moment for projectiles simulations
       case("print_dipole_moment_projectile")
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            print_dipole_moment_projectile=.TRUE.
			write(log_file,*) ' Print dipole moment in projectile simulations (not including projectile). '
          else
            print_dipole_moment_projectile=.FALSE.
          endif
		  
	   !cody
       case("printf_and_quit")
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            printf_and_quit=.TRUE.
			write(log_file,*) ' Calculated GS forces, print them and quit '
          else
            printf_and_quit=.FALSE.
          endif
	   ! cody
       case("set_homo_occ_amount")
		   read(value_string,*) set_homo_occ_amount	
           set_occupation_HOMO=.TRUE.
		   write(log_file,*) ' set there to be ',set_homo_occ_amount,' electrons in HOMO'
       case("set_homom1_occ_amount")
		   read(value_string,*) set_homom1_occ_amount	
           set_occupation_HOMOm1=.TRUE.
		   write(log_file,*) ' set there to be ',set_homom1_occ_amount,' electrons in HOMO-1'
	   ! cody  single point source injection controls
       case("print_ion_forces")
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            print_ion_forces=.TRUE.
			write(log_file,*) ' Print forces on ions. '
			write(log_file,*) ' Use same frequency as for Molecular Dynamics file. see trajectory_output_frequency'
          else
            print_ion_forces=.FALSE.
          endif
		  
	   ! cody  		  
       case("n_opt_grid_steps")
		   read(value_string,*) N_opt_grid_steps		  
       case("opt_grid_step_size")
		   read(value_string,*) opt_grid_step_size			  
       case("opt_grid_force_k")
		   read(value_string,*) opt_grid_force_k			  

	   ! cody  mask function and Volkov controls
       case("use_mask_volkov")
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            use_mask_volkov=.TRUE.
			write(log_file,*) ' use_mask_volkov=true use mask function and volkov propagation '
          else
            use_mask_volkov=.FALSE.
          endif
       case("volkov_distance1")
		   read(value_string,*) volkov_distance(1)
       case("volkov_distance2")
		   read(value_string,*) volkov_distance(2)
       case("volkov_distance3")
		   read(value_string,*) volkov_distance(3)
       case("volkov_mask_depth")
		   read(value_string,*) volkov_mask_depth
       case("mask_func_freq")
		   read(value_string,*) mask_func_freq	
       case("volkov_save_dens")
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            volkov_save_dens=.TRUE.
			write(log_file,*) ' volkov_save_dens=true, saving densities in volkov region '
          else
            volkov_save_dens=.FALSE.
          endif		   
       case("volkov_save_dens_freq")
		   read(value_string,*) volkov_save_dens_freq
       case("volkov_save_1d_dens_freq")
		   read(value_string,*) volkov_save_1d_dens_freq
       case("volkov_save_dslice")
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            volkov_save_dslice=.TRUE.
			write(log_file,*) ' volkov_save_dslice=true, saving density slices in volkov region '
          else
            volkov_save_dslice=.FALSE.
          endif		
		  
       case("maskv_save_pes")
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            maskV_save_PES=.TRUE.
			write(log_file,*) ' maskV_save_PES=true, saving PhotoElectron momenta from volkov region '
          else
            maskV_save_PES=.FALSE.
          endif		

       case("maskv_save_multi_pes")
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            maskV_save_multi_PES=.TRUE.
			write(log_file,*) ' maskV_save_multi_PES=true, saving PhotoElectron momenta from volkov region at regular intervals'
          else
            maskV_save_multi_PES=.FALSE.
          endif		
       case("maskv_save_multi_pes_avgs")
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            maskV_save_multi_PES_avgs=.TRUE.
			write(log_file,*) ' maskV_save_multi_PES_avgs=true, saving'
			write(log_file,*) ' PhotoElectron momenta averages along planes from volkov region at regular intervals'
          else
            maskV_save_multi_PES_avgs=.FALSE.
          endif	
       case("maskv_save_multi_pes_full")
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            maskV_save_multi_PES_full=.TRUE.
			write(log_file,*) ' maskV_save_multi_PES_full=true, saving full PhotoElectron momenta from volkov region at regular intervals'
          else
            maskV_save_multi_PES_full=.FALSE.
          endif	
		  
       case("maskv_save_multi_pes_freq")
		   read(value_string,*) maskV_save_multi_PES_freq		
		   
       case("volkov_capdist_x")
		   read(value_string,*) volkov_capdist_x			  
       case("volkov_capdist_y")
		   read(value_string,*) volkov_capdist_y			  
       case("volkov_capdist_z")
		   read(value_string,*) volkov_capdist_z			  
       case("volkov_capparm")
		   read(value_string,*) volkov_capparm		  

       case("use_split_op_cpximagtime")
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            use_split_op_cpximagtime=.TRUE.
			write(log_file,*) ' use_split_op_cpximagtime=true   use complex time factor for minimization to true GS'
          else
            use_split_op_cpximagtime=.FALSE.
          endif
       case("split_op_imag_ts_phase")
		   read(value_string,*) split_op_imag_ts_phase
       case("split_op_num_imag_ts")
		   read(value_string,*) split_op_num_imag_ts
       case("split_op_num_ramp_ts")
		   read(value_string,*) split_op_num_ramp_ts
       case("split_op_inital_imag_ts")
		   read(value_string,*) split_op_inital_imag_ts
       case("split_op_num_imag_tsdecay")
		   read(value_string,*) split_op_num_imag_tsdecay
		   
       case("no_crappy_mapping")
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            no_crappy_mapping=.TRUE.
          else
            no_crappy_mapping=.FALSE.
          endif

       case("limit_lattice_near_atoms")
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            limit_lattice_near_atoms=.TRUE.
          else
            limit_lattice_near_atoms=.FALSE.
          endif

       case("limit_lattice_near_rad")
		   read(value_string,*) limit_lattice_near_rad

       case("split_op_save_imagt_gs")
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            split_op_save_imagt_gs=.TRUE.
          else
            split_op_save_imagt_gs=.FALSE.
          endif		  
		  

	   !cody
       case("td_prop_empty")
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            td_prop_empty=.TRUE.
			write(log_file,*) ' propagation of unoccupied TD orbitals active. '
          else
            td_prop_empty=.FALSE.
          endif
	   !cody
       case("td_calc_dipolestr")
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            td_calc_dipoleStr=.TRUE.
			write(log_file,*) ' calculation of Rotational Str of TD orbitals active. '
          else
            td_calc_dipoleStr=.FALSE.
          endif
	   ! cody  		  
       case("td_calc_dipolestr_dir")
		   read(value_string,*) td_calc_dipoleStr_dir
           write(log_file,*) ' Calc DS in direction ',td_calc_dipoleStr_dir
		   
	   !  turn on switch mode     cody and kara coded this 
       case("switch_mode")
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            switch_mode=.TRUE.
			write(log_file,*) ' switch mode active. '
          else
            switch_mode=.FALSE.
          endif
       case("switch_proj_z")
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            switch_proj_z=.TRUE.
			write(log_file,*) ' switch_proj_z mode active. '
          else
            switch_proj_z=.FALSE.
          endif
		case("switch_proj_z_min")
		   read(value_string,*) switch_proj_z_min
		   switch_proj_z=.TRUE.
		   write(log_file,*) ' switch mode min projectile in Z direction=',switch_proj_z_min
       case("switch_check_ioniz")! 
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            switch_check_ioniz=.TRUE.
			write(log_file,*) ' switch mode track ionization. '
          else
            switch_check_ioniz=.FALSE.
          endif
       case("switch_ioniz_max")
		   read(value_string,*) switch_ioniz_max
		   
	   ! cody
       case("projectile_fine_eom")
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            projectile_fine_eom=.TRUE.
			write(log_file,*) ' projectile_fine_eom=true fine integration of projectile motion active. '
          else
            projectile_fine_eom=.FALSE.
          endif		  
       case("projectile_fine_eom_inum")
		   read(value_string,*) projectile_fine_eom_inum
		   
	   ! cody
       case("projectile_ion_full_charge")
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            projectile_ion_full_charge=.TRUE.
			write(log_file,*) ' projectile_ion_full_charge=Using full ion charge for F with projectile. '
          else
            projectile_ion_full_charge=.FALSE.
          endif	

		  ! cody
       case("calc_dpm_elec_nuc")
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            calc_dpm_elec_nuc=.TRUE.
			write(log_file,*) ' calc_dpm_elec_nuc=true. Calculate and print DPM separately for electrons and nuclei '
          else
            calc_dpm_elec_nuc=.FALSE.
          endif
       case("md_subtract_com_motion")
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            md_subtract_com_motion=.TRUE.
			write(log_file,*) ' md_subtract_com_motion=true. Subtract out COM motion from MD '
          else
            md_subtract_com_motion=.FALSE.
          endif
		  
	   ! cody
       case("read_isotope_mass")
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            read_isotope_mass=.TRUE.
			write(log_file,*) ' read_isotope_mass=true. '
			write(log_file,*) ' must give extra line in coordinate file with mass. '
          else
            read_isotope_mass=.FALSE.
          endif	
		  
		  
	   ! cody
       case("md_give_inf_mass_specific")
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            md_give_inf_mass_specific=.TRUE.
			write(log_file,*) ' md_give_inf_mass_specific=true. '
          else
            md_give_inf_mass_specific=.FALSE.
          endif			  
       case("md_inf_mass_numberofatoms")
		   read(value_string,*) md_inf_mass_numberofatoms
       case("md_inf_mass_string")
		   write(md_inf_mass_string,*) value_string

       case("remove_dens_around_atom_rad")
		   read(value_string,*) remove_dens_around_atom_rad
       case("remove_dens_around_atom_idx")
		   read(value_string,*) remove_dens_around_atom_idx
           if(remove_dens_around_atom_idx>0) then
		     remove_dens_around_atom=.true.
		   end if

       case("man_set_n_orbitals_num")
		   read(value_string,*) man_set_N_orbitals_num
		   man_set_N_orbitals=.true.

       case("split_region_mode")
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            split_region_mode=.TRUE.
			write(log_file,*) ' split_region_mode=true. '
          else
            split_region_mode=.FALSE.
          endif
       case("split_region_plane_z")
		   read(value_string,*) split_region_plane_z
       case("split_region_n_orb_lower")
		   read(value_string,*) split_region_n_orb_lower		   
       case("split_region_n_orb_upper")
		   read(value_string,*) split_region_n_orb_upper

       case("combine_gs")
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            combine_gs=.TRUE.
			write(log_file,*) ' combine_gs=true. '
          else
            combine_gs=.FALSE.
          endif
       case("combine_gs_2path")
          write(combine_gs_2path,'(a)')trim(adjustl(check_trailing_slash(value_string)))
       case("combine_gs_num_orb_1")
		   read(value_string,*) combine_gs_num_orb_1
       case("combine_gs_num_orb_2")
		   read(value_string,*) combine_gs_num_orb_2

       case("combine_gs_boost2")
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            combine_gs_boost2=.TRUE.
			write(log_file,*) ' combine_gs_boost2=true. '
          else
            combine_gs_boost2=.FALSE.
          endif
       case("combine_gs_boost_vx")
		   read(value_string,*) combine_gs_boost_vx
       case("combine_gs_boost_vy")
		   read(value_string,*) combine_gs_boost_vy
       case("combine_gs_boost_vz")
		   read(value_string,*) combine_gs_boost_vz
		   
	   ! cody
       case("projectile_calc_near_elec")
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            projectile_calc_near_elec=.TRUE.
			write(log_file,*) ' projectile_calc_near_elec=true. '
          else
            projectile_calc_near_elec=.FALSE.
          endif		
       case("projectile_calc_near_elec_dist")
		   read(value_string,*) projectile_calc_near_elec_dist

	   ! cody
       case("resolve_gs")
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            resolve_gs=.TRUE.
			write(log_file,*) ' resolve_gs=true. '
          else
            resolve_gs=.FALSE.
          endif				   

	   ! cody
       case("calc_force_gs_psi")
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            calc_force_gs_psi=.TRUE.
          else
            calc_force_gs_psi=.FALSE.
          endif	
       case("calc_force_gs_psi_frequency")
		   read(value_string,*) calc_force_gs_psi_frequency

       case("resolve_gs_min_iter")
		   read(value_string,*) resolve_gs_min_iter
		   
	   ! cody
       case("save_timings")
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            save_timings=.TRUE.
			write(log_file,*) ' save_timings=true. '
          else
            save_timings=.FALSE.
          endif		

	   ! cody
       case("do_dealloc_psi")
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            do_dealloc_psi=.TRUE.
			write(log_file,*) ' do_dealloc_psi=true. deallocate psi to save memory'
          else
            do_dealloc_psi=.FALSE.
          endif

	   ! cody
       case("output_td_current_density_slices")
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            output_td_current_density_slices=.TRUE.
          else
            output_td_current_density_slices=.FALSE.
          endif
       case("td_current_density_slice_output_frequency")
		   read(value_string,*) td_current_density_slice_output_frequency

	   ! cody
       case("output_td_current_cell_sum")
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            output_td_current_cell_sum=.TRUE.
          else
            output_td_current_cell_sum=.FALSE.
          endif
       case("output_td_current_cell_sum_frequency")
		   read(value_string,*) output_td_current_cell_sum_frequency

	   ! cody
       case("output_td_current_atom_sum")
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            output_td_current_atom_sum=.TRUE.
          else
            output_td_current_atom_sum=.FALSE.
          endif
       case("output_td_current_atom_sum_frequency")
		   read(value_string,*) output_td_current_atom_sum_frequency
       case("output_td_current_atom_sum_beta")
		   read(value_string,*) output_td_current_atom_sum_beta
       case("td_current_plane_cutoff")
		   read(value_string,*) td_current_plane_cutoff   
		   
		   
	   ! cody
       case("output_td_line_current_orbital")
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            output_td_line_current_orbital=.TRUE.
          else
            output_td_line_current_orbital=.FALSE.
          endif
       case("output_td_line_current_orbital_frequency")
		   read(value_string,*) output_td_line_current_orbital_frequency
       case("output_td_line_current_orbital_stride")
		   read(value_string,*) output_td_line_current_orbital_stride
       case("output_td_xyslice_current_orbital_frequency")
		   read(value_string,*) output_td_xyslice_current_orbital_frequency
	   ! cody
       case("print_enediff")
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            print_enediff=.TRUE.
          else
            print_enediff=.FALSE.
          endif
		   
	   ! cody
       case("setup_rad_basis")
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            setup_rad_basis=.TRUE.
          else
            setup_rad_basis=.FALSE.
          endif

	   ! cody
       case("print_orb_ene_comp_split")
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            print_orb_ene_comp_split=.TRUE.
          else
            print_orb_ene_comp_split=.FALSE.
          endif
       
	   case("mpi_debug") ! cody,
		   read(value_string,*) MPI_debug
		   
       case("debug_force_output")
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            debug_force_output=.TRUE.
          else
            debug_force_output=.FALSE.
          endif
		  
       case("calc_energy_freq") ! cody,
		   read(value_string,*) calc_energy_freq

       case("debug_output_level") ! cody,
		   read(value_string,*) debug_output_level

	   ! cody
       case("use_adsic")
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            use_adsic=.TRUE.
          else
            use_adsic=.FALSE.
          endif
       
	   case("n_orb_prop") ! cody,
		   read(value_string,*) n_orb_prop

       case("print_fragment_info")
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            print_fragment_info=.TRUE.
          else
            print_fragment_info=.FALSE.
          endif
	   case("print_fragment_freq") ! cody,
		   read(value_string,*) print_fragment_freq
	   case("fragment_dens_rad") ! cody,
		   read(value_string,*) fragment_dens_rad
		   
       case("print_bond_info")
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            print_bond_info=.TRUE.
          else
            print_bond_info=.FALSE.
          endif
	   case("print_bond_freq") ! cody,
		   read(value_string,*) print_bond_freq

! read_initial_occupation 
       case("read_initial_occupation")
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            read_initial_occupation=.TRUE.
          else
            read_initial_occupation=.FALSE.
          endif
		  
       case("only_propagate_occupied")
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            only_propagate_occupied=.TRUE.
          else
            only_propagate_occupied=.FALSE.
          endif

       case("do_not_overwrite")
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            do_not_overwrite=.TRUE.
          else
            do_not_overwrite=.FALSE.
          endif
       case("change_name_monitor")
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            change_name_monitor=.TRUE.
          else
            change_name_monitor=.FALSE.
          endif
		  
       case("smart_restart_detect")
	      write(log_file,*) "Parse:smart_restart_detect was handled at startup"
		   
	   case("nl_pp_mode") ! cody, change way of doing the nl_pp
		   read(value_string,*) nl_pp_mode
		   
	   case("xc_functional_mode") ! default =6 = perdew and zunger LDA
		   read(value_string,*) xc_functional_mode
		   
	   case("xc_lib_ex_num") 
		   read(value_string,*) xc_lib_ex_num
	   case("xc_lib_cor_num")
		   read(value_string,*) xc_lib_cor_num
		   
	   case("xc_v_error_t") 
		   read(value_string,*) xc_v_error_t

	   case("xc_v_check_t") 
		   read(value_string,*) xc_v_check_t
	
       case("split_up_gen_nlpp")
          write(log_file,*) "Parse:split_up_gen_nlpp was handled at startup"
	
       case("traj_debug")
          call convert_to_lowercase(value_string)
          if((trim(adjustl(value_string))=="t").OR.(trim(adjustl(value_string))=="true") &
            .OR.(trim(adjustl(value_string))==".true.")) then
            traj_debug=.TRUE.
          else
            traj_debug=.FALSE.
          endif
	
       case default
          write(log_file,'(2a)')"ERROR: Invalid variable name: ",trim(adjustl(the_key))
          stop		   
       end select
    endif
 enddo
110 close(parse_file)

  if (orbital_output_num<1) orbital_output_num=1
  if (orbital_up_output_num<1) orbital_up_output_num=1
  if (orbital_down_output_num<1) orbital_down_output_num=1
  
  if (N_empty<excitation_jump) then
    N_empty=excitation_jump
    write(log_file,*)"WARNING: N_empty < excitation_jump"
    write(log_file,*)"N_empty has been increased to match the value of excitation_jump"
  endif

  if(temperature_counter>1) then
    write(log_file,*)"ERROR: only one of temperature_ions and av_kin_energy_ions may be set"
    stop
  endif

  projectile_mass=projectile_mass*mass_convfactor
  projectile_invmass=1.0d0/projectile_mass
  if((projectile_energy_counter==1).and.(projectile_v0_counter==1)) then
    write(log_file,*)"ERROR: only one of projectile_energy and projectile_v0 may be set"
    stop
  endif
  if((projectile_energy_counter==0).and.(projectile_v0_counter==1)) then
    if (abs(projectile_v0)>c_light) then
      write(log_file,*)"ERROR: projectile_v0 exceeds speed of light, ",c_light," Angstrom/fs"
      stop
    endif
    !Classical expression
    projectile_energy=0.5d0*projectile_mass*projectile_v0**2
    !!Relativistic expression:
    !projectile_energy=projectile_mass*c_squared*( &
    !  sqrt(c_squared*projectile_v0**2/(c_squared-projectile_v0**2))-1.0d0)
  endif
  if(projectile_v0_counter==0) then
    !Classical expression
    projectile_v0=sqrt(2*projectile_energy/projectile_mass)
    !!Relativistic expression:
    !projectile_v0=c_light/sqrt(1.0d0+c_squared**2*projectile_mass**2/ &
    !  (projectile_energy**2+2*projectile_energy*projectile_mass*c_squared))
  endif
  if (use_projectile) then
    projectile_x=projectile_x0
    projectile_y=projectile_y0
    projectile_z=projectile_z0
    s=1/sqrt(projectile_nx0**2+projectile_ny0**2+projectile_nz0**2)
    projectile_nx=projectile_nx*s
    projectile_ny=projectile_ny*s
    projectile_nz=projectile_nz*s
    projectile_nx=projectile_nx0
    projectile_ny=projectile_ny0
    projectile_nz=projectile_nz0
    projectile_vx=projectile_v0*projectile_nx
    projectile_vy=projectile_v0*projectile_ny
    projectile_vz=projectile_v0*projectile_nz
  else
    output_projectile_trajectory=.false.
  endif

  if(set_pp_path==0) then
    write(log_file,*)"ERROR: pp_path must be set"
    stop
  endif
  if(set_bf_path==0) then
    write(log_file,*)"ERROR: bf_path must be set"
    stop
  endif

  if (laser1freqset>1) then
    write(log_file,*) 'ERROR: the frequency of laser 1 is set ambiguously. Please'
    write(log_file,*) 'use either laser_wavelength1 (in rad/fs) or laser_frequency1 (in nm)'
    stop
  endif
  if (laser2freqset>1) then
    write(log_file,*) 'ERROR: the frequency of laser 2 is set ambiguously. Please'
    write(log_file,*) 'use either laser_wavelength2 (in rad/fs) or laser_frequency2 (in nm)'
    stop
  endif
  if (laser3freqset>1) then
    write(log_file,*) 'ERROR: the frequency of laser 3 is set ambiguously. Please'
    write(log_file,*) 'use either laser_wavelength3 (in rad/fs) or laser_frequency3 (in nm)'
    stop
  endif
  if (laser1intenset>1) then
    write(log_file,*) 'ERROR: the amplitude of laser 1 is set ambiguously. Please use'
    write(log_file,*) 'either e_laser1 (in Volts/Angstrom) or laser_intensity1 (in Watts/m^2)'
    stop
  endif
  if (laser2intenset>1) then
    write(log_file,*) 'ERROR: the amplitude of laser 2 is set ambiguously. Please use'
    write(log_file,*) 'either e_laser2 (in Volts/Angstrom) or laser_intensity2 (in Watts/m^2)'
    stop
  endif
  if (laser3intenset>1) then
    write(log_file,*) 'ERROR: the amplitude of laser 3 is set ambiguously. Please use'
    write(log_file,*) 'either e_laser3 (in Volts/Angstrom) or laser_intensity3 (in Watts/m^2)'
    stop
  endif

  if(using_v_fromfile) then ! cody   sanity checks for reading external field from file
     if    ((using_v_laser1).or.(using_v_laser1).or.(using_v_laser1).or.(using_v_ext)) then
        write(log_file,*) 'ERROR: cannot set a laser or external field when reading external'
		write(log_file,*) '       field from file!'
        stop
     endif   
	 if( (laser_xyz_t(1,2) - laser_xyz_t(1,1)) /= time_step ) then
        write(log_file,*) 'WARNING: time step in external field file and control file do not match!'
		write(log_file,*) ' Double check that interpolation is correct'
	 endif
  endif
  
  
  if ( write_restart) then
     if( atomic_movement_frequency > restart_update_frequency) then ! cody
       write(log_file,*) 'With restart, the restart_update_frequency must be an integer '
   	   write(log_file,*) 'multiple of the atomic_movement_frequency '
	   stop
     end if
     if( mod(restart_update_frequency,atomic_movement_frequency) .NE. 0) then ! cody
       write(log_file,*) 'With restart, the restart_update_frequency must be an integer '
   	   write(log_file,*) 'multiple of the atomic_movement_frequency '
	   stop
     end if
  end if
  
  ! cody  sanity check for output_inner_product_s2 
  if ( (output_inner_product_s2).AND.(run_type.NE.24)) then
     write(log_file,*) ' Cannot use output_inner_product_s2 with run_type other than 24'
	 stop
  
  endif
  
  ! cody  sanity check for add_projectile_to_gs
  if (add_projectile_to_gs) then
     if(run_type/=14) then
	    write(log_file,*) 'Cannot add projectile potential to anything other than ground state calculation'
		stop
	 endif
  endif   
  
  if(save_trajectory) then
    if(mod(trajectory_output_frequency,atomic_movement_frequency)/=0) then
      write(log_file,*) 'trajectory_output_frequency=',trajectory_output_frequency
	  write(log_file,*) ' is not divisible by atomic_movement_frequency=',atomic_movement_frequency
      stop
	end if
  end if
  
  ! cody sanity checks for volkov code
  if(use_mask_volkov) then
    if(volkov_save_dens) then
      if(mod(volkov_save_dens_freq,mask_func_freq).ne.0) then
	    write(log_file,'(a)') 'must save volkov densities when evaluating the mask'
		write(log_file,'(a)') 'choose volkov_save_dens_freq to be a multiple of mask_func_freq'
		stop
	  end if
    end if
  end if
  
  ! cody sanity check for  remove_homo_occ_amount
  if (set_occupation_HOMO) then
	    write(log_file,*) 'set_homo_occ_amount option removes electrons from the occupation variable'
		write(log_file,*) 'This may not work for any calculations that have been'
		write(log_file,*) 'previously run with the TDDFT code'
		write(log_file,*) '  Also only the initalization is changed. The saved wavefunction'
		write(log_file,*) '  will be normailized and continuation will not known about how'
		write(log_file,*) '  many electrons are missing specified by this option.'
    select case (run_type)
    case(14,24,77,78)
        if( (set_homo_occ_amount>2.d0).OR.(set_homo_occ_amount<0.d0)) then
		  write(log_file,*) 'set_homo_occ_amount -- must specify a number between 2 and 0 !!!'
		  stop
		end if
		if( (spin_polarized).AND.(set_homo_occ_amount>1.d0)) then
		  write(log_file,*) 'set_homo_occ_amount and spin_polarized must be between 1 and 0 !!!'
		  stop		
		end if
    case default
        write(log_file,*) 'untested run_type with set_homo_occ_amount!!!'
		stop
    endselect
	if (N_empty .NE. 0 .and. spin_polarized) then
        write(log_file,*) 'set_occupation_HOMO with empty orbitals and spin polarization will not work'
		stop	
	end if
  end if
  if((run_type.NE.77).AND.(printf_and_quit)) then
         write(log_file,*) 'Print forces and quit only works for mode 78'
		stop	   
  end if  
  
  ! sanity check for projectile_fine_eom
  if(projectile_fine_eom) then
    atomic_movement_frequency=1
	write(log_file,*) "projectile_fine_eom=true"
	write(log_file,*) "atomic_movement_frequency is set to 1 by default"
    if(md_subtract_COM_motion) then
	  write(log_file,*) "cannot use md_subtract_COM_motion with projectile_fine_eom!"
	  stop
	end if
  end if
  
  if(.NOT.projectile_ion_full_charge) then
    write(log_file,*) "projectile_ion_full_charge=FALSE"
	write(log_file,*) " Projectile ion forces will not be correct for near impact."
  end if
  
  if(md_give_inf_mass_specific) then
    if(projectile_fine_eom) then
	  write(log_file,*) "cannot use projectile_fine_eom and md_give_inf_mass_specific at the same time"
	  stop
	end if

  end if
  
  if(read_isotope_mass) then
	if(combine_gs) then
	  write(log_file,*) "cannot use combine_gs and md_give_inf_mass_specific at the same time"
	  stop
	end if
  end if
  
  if(propagator=="taylor_all".or.propagator=="taylor_all3d") then
    if(grid_type/=1) then
	  write(log_file,*) "grid type must be 1 with propagator=taylor_all"
	  stop
	end if
    if(use_high_energy_wp) then
	  write(log_file,*) "cannot use use_high_energy_wp with propagator=taylor_all"
	  stop
	end if
	if(spin_polarized) then
	  write(log_file,*) "cannot use spin_polarized with propagator=taylor_all"
	  stop
	end if
  end if
  
  if(do_dealloc_psi) then
    if(output_inner_product) then
	  write(log_file,*) "cannot use output_inner_product with do_dealloc_psi!"
	  stop	
	end if
  end if
  
  if(output_td_line_current_orbital) then
    if(using_injection) then
	  write(log_file,*) "cannot use output_td_line_current_orbital with using_injection!"
	  stop		  
	end if
	if(.NOT.non_local_current) then
	  write(log_file,*) "must use non_local_current with output_td_line_current_orbital!"
	  stop		 
	end if
  end if
  
  if(calc_energy_freq/=1) then
    if(mod(orb_en_comp_output_frequency,calc_energy_freq)/=0) then
	  write(log_file,*) "orb_en_comp_output_frequency must be an integer multiple of calc_energy_freq"
	  write(log_file,*) orb_en_comp_output_frequency,calc_energy_freq
	  stop
    end if
  end if

  if(remove_dens_around_atom) then
    write(log_file,*) "remove_dens_around_atom=.true."
	write(log_file,*) " This will remove any part of the wavefunction"
	write(log_file,*) " That is within radius",remove_dens_around_atom_rad
	write(log_file,*) " Of atom ",remove_dens_around_atom_idx
    if(run_type/=14) then
	  write(log_file,*) "Only for solving GS with grid: run_type=14"
	  stop
	end if
	if(periodic) then
	  write(log_file,*) "Cannot do with periodic"
	  stop
	end if
  end if

  if(man_set_N_orbitals) then
    if(spin_polarized) then
      write(log_file,*) "cannot do man_set_N_orbitals and spin_polarized"
	  stop
    end if
	if(excitation_jump>1) then
      write(log_file,*) "cannot do man_set_N_orbitals and excitation_jump"
	  stop
	end if
	write(log_file,*) "man_set_N_orbitals_num=",man_set_N_orbitals_num
	write(log_file,*) " Manually set the number of orbitals"
  end if
  
  if(combine_gs) then
    man_set_N_orbitals=.true.
	write(log_file,*) "combine_gs==true, automatically setting man_set_N_orbitals=.true."
	man_set_N_orbitals_num=combine_gs_num_orb_1+combine_gs_num_orb_2
    if(box_type/=1) then
	  write(log_file,*) "combine_gs==true must have box_type==1"
	  stop
	end if
	if(spin_polarized) then
	  write(log_file,*) "combine_gs==true not supported with spin polarized"
	  stop	
	end if
	if(periodic) then
	  write(log_file,*) "combine_gs==true not supported with periodic"
	  stop	
	end if
	if(load_virtual_orbitals) then
	  write(log_file,*) "combine_gs==true and load_virtual_orbitals is done by setting the proper number of orbitals manually"
	  stop	
	end if
  end if
  
  if(combine_gs_boost2) then
    if(input_initial_velocity) then
	  write(log_file,*) "combine_gs_boost2==true and input_initial_velocity==true are incompatible"
	  stop	
	end if
  
  end if
  
  if(use_adsic) then
    write(log_file,*) "Using average-density self-interaction correction"
	write(log_file,*) "  see  C Legrand et al 2002 J. Phys. B: At. Mol. Opt. Phys. 35 1115"
	write(log_file,*) "  Do you know what the hell you are doing? I sure hope so..."
    if(spin_polarized) then
	  write(log_file,*) "use_adsic  Not yet coded for spin polarized"
	  stop
	end if
  end if
  
  ! sanity check for tay_subset propagation
  if(propagator=="tay_subset") then
    if(n_orb_prop<1) then
	  write(log_file,*) "n_orb_prop must be > 1"
	  stop
	end if
  end if
  
  !sanity check for printing fragmentation info
  if(print_fragment_info) then
    if(.NOT.move_atoms) then
	  write(log_file,*) "move_atoms=true to print fragment info"
	  stop
	end if
	if(mod(print_fragment_freq,atomic_movement_frequency)/=0) then
	  write(log_file,*) "print_fragment_freq must be divisible by atomic_movement_frequency"
	  stop
	end if
  end if

  !sanity check for printing bond info
  if(print_bond_info) then
    if(.NOT.move_atoms) then
	  write(log_file,*) "move_atoms=true to print bond info"
	  stop
	end if
	if(mod(print_bond_freq,atomic_movement_frequency)/=0) then
	  write(log_file,*) "print_bond_freq must be divisible by atomic_movement_frequency"
	  stop
	end if
  end if  

  !sanity checks for MPI version
  if (add_projector_cap) then
    write(log_file,*) "add_projector_cap not supported"
	STOP
  endif
  if(resolve_gs .or. calc_force_gs_psi) then
    write(log_file,*) "resolve_gs and calc_force_gs_psi not supported"
	STOP
  endif
  if(suppress_field_upon_ion_motion) then
    write(log_file,*) "suppress_field_upon_ion_motion not supported"
	STOP
  endif
  ! sanity checks for restart
  if(write_restart) then 
    if(print_orb_ene_comp_split) then
	  write(log_file,*) "Cannot do print_orb_ene_comp_split=true with restart"
	  stop
	end if
  end if
 
  
  ! output XC mode
  write(log_file,*) "xc_functional_mode=",xc_functional_mode
  if(xc_functional_mode==0) write(log_file,*) "functional = Legacy LDA mode"
  if(xc_functional_mode==1) write(log_file,*) "functional = Wigner Correlation"
  if(xc_functional_mode==2) write(log_file,*) "functional = Hedin-Lundqvist (HL) Approximation"
  if(xc_functional_mode==3) write(log_file,*) "functional = Ceperley-Alder (CA) / Perdew-Zunger (PZ) LDA"
  if(xc_functional_mode==4) write(log_file,*) "functional = Perdew 1992 GGA (which might be Perdew-Wang 1991 (PW91))"
  if(xc_functional_mode==5) write(log_file,*) "functional = Becke/Perdew GGA (which might be BP86) [J.P.Perdew, PRB 33, 8822 (1986) and PRB 34, 7406 (1986)]"
  if(xc_functional_mode==6) write(log_file,*) "functional = Perdew-Zunger (PZ) LDA"
  if(xc_functional_mode==7) write(log_file,*) "functional Use Libxc"
  
  if(xc_functional_mode==1) then
	  write(log_file,*) "Wigner Correlation not yet supported"
	  stop
  end if
  if(xc_functional_mode>7) then
	  write(log_file,*) "unrecognized xc_functional_mode"
	  stop
  end if
  
  ! full list of variables 
  open(101010,file="all_variable_file.txt",status="replace")
write(101010,*) "  map_block_size=",  map_block_size
write(101010,*) "  map_subblock_size=",  map_subblock_size
write(101010,*) "  charge_difference_has_been_set=",  charge_difference_has_been_set
write(101010,*) "  num_AO_setup_iterations_for_grid=",  num_AO_setup_iterations_for_grid
write(101010,*) "  plot_bands=",  plot_bands
write(101010,*) "  check_convergence_td=",  check_convergence_td
write(101010,*) "  vdw_stretch_x=",  vdw_stretch_x
write(101010,*) "  vdw_stretch_y=",  vdw_stretch_y
write(101010,*) "  vdw_stretch_z=",  vdw_stretch_z
write(101010,*) "  boundary_space_xL=",  boundary_space_xL
write(101010,*) "  boundary_space_xR=",  boundary_space_xR
write(101010,*) "  boundary_space_yL=",  boundary_space_yL
write(101010,*) "  boundary_space_yR=",  boundary_space_yR
write(101010,*) "  boundary_space_zL=",  boundary_space_zL
write(101010,*) "  boundary_space_zR=",  boundary_space_zR
write(101010,*) "  fine_grid_spacing=",  fine_grid_spacing
write(101010,*) "  use_fine_grid=",  use_fine_grid
write(101010,*) "  output_plot=",  output_plot
write(101010,*) "  output_plot_time=",  output_plot_time
write(101010,*) "  output_mr_density_slice=",  output_mr_density_slice
write(101010,*) "  output_mr_orbital_charge=",  output_mr_orbital_charge
write(101010,*) "  complexbasis=",  complexbasis
write(101010,*) "  move_all_atoms=",  move_all_atoms
write(101010,*) "  optics_key=",  optics_key
write(101010,*) "  Hyp_info=",  Hyp_info
write(101010,*) "  XC_in=",  XC_in
write(101010,*) "  CG_Solver=",  CG_Solver
write(101010,*) "  process=",  process
write(101010,*) "  dir=",  dir
write(101010,*) "  field_dir=",  field_dir
write(101010,*) "  hw(1)=",  hw(1)
write(101010,*) "  hw(2)=",  hw(2)
write(101010,*) "  dendiv_output=",  dendiv_output
write(101010,*) "  md_damping_coeff=",  md_damping_coeff
write(101010,*) "  save_trajectory=",  save_trajectory
write(101010,*) "  trajectory_output_frequency=",  trajectory_output_frequency
write(101010,*) "  moldyn_output_level=",  moldyn_output_level
write(101010,*) "  moldyn_output_frequency=",  moldyn_output_frequency
write(101010,*) "  ion_velocity_init_seed=",  ion_velocity_init_seed
write(101010,*) "  spin_polarized=",  spin_polarized
write(101010,*) "  continuation=",  continuation
write(101010,*) "  box_basis_type=",  box_basis_type
write(101010,*) "  move_atoms=",  move_atoms
write(101010,*) "  use_average_atomic_mass=",  use_average_atomic_mass
write(101010,*) "  atomic_movement_frequency=",  atomic_movement_frequency
write(101010,*) "  av_kin_energy_ions=",  av_kin_energy_ions
write(101010,*) "  temperature_ions=",  temperature_ions
write(101010,*) "  input_initial_velocity=",  input_initial_velocity
write(101010,*) "  moldyn_type=",  moldyn_type
write(101010,*) "  generate_bmd_seed=",  generate_bmd_seed
write(101010,*) "  bmd_seed=",  bmd_seed
write(101010,*) "  bmd_n_walker_steps=",  bmd_n_walker_steps
write(101010,*) "  bmd_walker_step_supplied=",  bmd_walker_step_supplied
write(101010,*) "  tot_td_pot_output_freq=",  tot_td_pot_output_freq
write(101010,*) "  output_tot_td_pot=",  output_tot_td_pot
write(101010,*) "  output_inner_product_frequency=",  output_inner_product_frequency
write(101010,*) "  output_inner_product=",  output_inner_product
write(101010,*) "  suppress_field_upon_ion_motion=",  suppress_field_upon_ion_motion
write(101010,*) "  field_suppression_timescale=",  field_suppression_timescale
write(101010,*) "  field_suppression_power=",  field_suppression_power
write(101010,*) "  field_suppression_on=",  field_suppression_on
write(101010,*) "  field_suppression_start_time=",  field_suppression_start_time
write(101010,*) "  field_suppression_trd=",  field_suppression_trd
write(101010,*) "  calculate_forces=",  calculate_forces
write(101010,*) "  offdiag_elem_check_frequency=",  offdiag_elem_check_frequency
write(101010,*) "  num_large_offdiag_elem_reported=",  num_large_offdiag_elem_reported
write(101010,*) "  use_checkpoint=",  use_checkpoint
write(101010,*) "  checkpoint_save_frequency=",  checkpoint_save_frequency
write(101010,*) "  lanczos_update_frequency=",  lanczos_update_frequency
write(101010,*) "  num_lanczos_vec=",  num_lanczos_vec
write(101010,*) "  laser1_start_x=",  laser1_start_x
write(101010,*) "  laser1_end_x=",  laser1_end_x
write(101010,*) "  laser1_start_y=",  laser1_start_y
write(101010,*) "  laser1_end_y=",  laser1_end_y
write(101010,*) "  laser1_start_z=",  laser1_start_z
write(101010,*) "  laser1_end_z=",  laser1_end_z
write(101010,*) "  laser2_start_x=",  laser2_start_x
write(101010,*) "  laser2_end_x=",  laser2_end_x
write(101010,*) "  laser2_start_y=",  laser2_start_y
write(101010,*) "  laser2_end_y=",  laser2_end_y
write(101010,*) "  laser2_start_z=",  laser2_start_z
write(101010,*) "  laser2_end_z=",  laser2_end_z
write(101010,*) "  laser3_start_x=",  laser3_start_x
write(101010,*) "  laser3_end_x=",  laser3_end_x
write(101010,*) "  laser3_start_y=",  laser3_start_y
write(101010,*) "  laser3_end_y=",  laser3_end_y
write(101010,*) "  laser3_start_z=",  laser3_start_z
write(101010,*) "  laser3_end_z=",  laser3_end_z
write(101010,*) "  E_laser1=",  E_laser1
write(101010,*) "  E_laser2=",  E_laser2
write(101010,*) "  E_laser3=",  E_laser3
write(101010,*) "  laser_frequency1=",  laser_frequency1
write(101010,*) "  laser_frequency2=",  laser_frequency2
write(101010,*) "  laser_frequency3=",  laser_frequency3
write(101010,*) "  laser_phase1=",  laser_phase1
write(101010,*) "  laser_phase2=",  laser_phase2
write(101010,*) "  laser_phase3=",  laser_phase3
write(101010,*) "  laser_envelope_type1=",  laser_envelope_type1
write(101010,*) "  laser_envelope_type2=",  laser_envelope_type2
write(101010,*) "  laser_envelope_type3=",  laser_envelope_type3
write(101010,*) "  laser_pulse_width1=",  laser_pulse_width1
write(101010,*) "  laser_pulse_width2=",  laser_pulse_width2
write(101010,*) "  laser_pulse_width3=",  laser_pulse_width3
write(101010,*) "  laser_pulse_shift1=",  laser_pulse_shift1
write(101010,*) "  laser_pulse_shift2=",  laser_pulse_shift2
write(101010,*) "  laser_pulse_shift3=",  laser_pulse_shift3
write(101010,*) "  laser_envelope_up_point1=",  laser_envelope_up_point1
write(101010,*) "  laser_envelope_up_point2=",  laser_envelope_up_point2
write(101010,*) "  laser_envelope_up_point3=",  laser_envelope_up_point3
write(101010,*) "  laser_envelope_down_point1=",  laser_envelope_down_point1
write(101010,*) "  laser_envelope_down_point2=",  laser_envelope_down_point2
write(101010,*) "  laser_envelope_down_point3=",  laser_envelope_down_point3
write(101010,*) "  laser_envelope_up_steepness1=",  laser_envelope_up_steepness1
write(101010,*) "  laser_envelope_up_steepness2=",  laser_envelope_up_steepness2
write(101010,*) "  laser_envelope_up_steepness3=",  laser_envelope_up_steepness3
write(101010,*) "  laser_envelope_down_steepness1=",  laser_envelope_down_steepness1
write(101010,*) "  laser_envelope_down_steepness2=",  laser_envelope_down_steepness2
write(101010,*) "  laser_envelope_down_steepness3=",  laser_envelope_down_steepness3
write(101010,*) "  T_sin_sq1=",  T_sin_sq1
write(101010,*) "  T_sin_sq2=",  T_sin_sq2
write(101010,*) "  T_sin_sq3=",  T_sin_sq3
write(101010,*) "  omega_sin_sq1=",  omega_sin_sq1
write(101010,*) "  omega_sin_sq2=",  omega_sin_sq2
write(101010,*) "  omega_sin_sq3=",  omega_sin_sq3
write(101010,*) "  f_sin_sq1=",  f_sin_sq1
write(101010,*) "  f_sin_sq2=",  f_sin_sq2
write(101010,*) "  f_sin_sq3=",  f_sin_sq3
write(101010,*) "  use_projectile=",  use_projectile
write(101010,*) "  projectile_x0=",  projectile_x0
write(101010,*) "  projectile_y0=",  projectile_y0
write(101010,*) "  projectile_z0=",  projectile_z0
write(101010,*) "  projectile_nx0=",  projectile_nx0
write(101010,*) "  projectile_ny0=",  projectile_ny0
write(101010,*) "  projectile_nz0=",  projectile_nz0
write(101010,*) "  projectile_charge=",  projectile_charge
write(101010,*) "  projectile_mass=",  projectile_mass
write(101010,*) "  projectile_energy=",  projectile_energy
write(101010,*) "  projectile_potential_soft_param=",  projectile_potential_soft_param
write(101010,*) "  output_projectile_trajectory=",  output_projectile_trajectory
write(101010,*) "  output_dipole_moment=",  output_dipole_moment
write(101010,*) "  use_vdw=",  use_vdw
write(101010,*) "  damping_vdw=",  damping_vdw
write(101010,*) "  dipole_direction=",  dipole_direction
write(101010,*) "  exp_kick_strength=",  exp_kick_strength
write(101010,*) "  exp_kick_center_x=",  exp_kick_center_x
write(101010,*) "  exp_kick_center_y=",  exp_kick_center_y
write(101010,*) "  exp_kick_center_z=",  exp_kick_center_z
write(101010,*) "  exp_kick_radius=",  exp_kick_radius
write(101010,*) "  dip_mom_region_inf=",  dip_mom_region_inf
write(101010,*) "  dip_mom_region_radius=",  dip_mom_region_radius
write(101010,*) "  dip_mom_region_center_x=",  dip_mom_region_center_x
write(101010,*) "  dip_mom_region_center_y=",  dip_mom_region_center_y
write(101010,*) "  dip_mom_region_center_z=",  dip_mom_region_center_z
write(101010,*) "  dpm_stretch_x=",  dpm_stretch_x
write(101010,*) "  dpm_stretch_y=",  dpm_stretch_y
write(101010,*) "  dpm_stretch_z=",  dpm_stretch_z
write(101010,*) "  ramp_time=",  ramp_time
write(101010,*) "  rwf_sm=",  rwf_sm
write(101010,*) "  min_basis_size_for_cg=",  min_basis_size_for_cg
write(101010,*) "  N_iteration_cg=",  N_iteration_cg
write(101010,*) "  N_iteration_cg_gen=",  N_iteration_cg_gen
write(101010,*) "  check_convergence=",  check_convergence
write(101010,*) "  excitation_jump=",  excitation_jump
write(101010,*) "  gs_laser_switch=",  gs_laser_switch
write(101010,*) "  psi_output_frequency=",  psi_output_frequency
write(101010,*) "  output_full_td_density=",  output_full_td_density
write(101010,*) "  output_orb_current=",  output_orb_current
write(101010,*) "  output_orb_density=",  output_orb_density
write(101010,*) "  no_scf_density=",  no_scf_density
write(101010,*) "  output_td_psi=",  output_td_psi
write(101010,*) "  output_coordinate_map=",  output_coordinate_map
write(101010,*) "  output_full_td_current_density=",  output_full_td_current_density
write(101010,*) "  output_full_td_sp_energy=",  output_full_td_sp_energy
write(101010,*) "  non_local_current=",  non_local_current
write(101010,*) "  init_random=",  init_random
write(101010,*) "  transport_cap=",  transport_cap
write(101010,*) "  cap_to_edge=",  cap_to_edge
write(101010,*) "  huge_cap_edge=",  huge_cap_edge
write(101010,*) "  output_orbitals=",  output_orbitals
write(101010,*) "  output_orbitals2=",  output_orbitals2
write(101010,*) "  gs_data_output_frequency=",  gs_data_output_frequency
write(101010,*) "  gs_dens_output_frequency=",  gs_dens_output_frequency
write(101010,*) "  td_data_output_frequency=",  td_data_output_frequency
write(101010,*) "  td_density_output_frequency=",  td_density_output_frequency
write(101010,*) "  td_current_density_output_frequency=",  td_current_density_output_frequency
write(101010,*) " td_sp_energy_output_frequency=", td_sp_energy_output_frequency
write(101010,*) " td_orb_current_output_frequency=", td_orb_current_output_frequency
write(101010,*) "  orbital_output_num=",  orbital_output_num
write(101010,*) "  orbital_up_output_num=",  orbital_up_output_num
write(101010,*) "  orbital_down_output_num=",  orbital_down_output_num
write(101010,*) "  td_orbital_output_frequency=",  td_orbital_output_frequency
write(101010,*) "  orb_en_comp_output_frequency=",  orb_en_comp_output_frequency
write(101010,*) "  orb_en_comp_output_level=",  orb_en_comp_output_level
write(101010,*) "  gs_path=",  gs_path
write(101010,*) "  bg_beta=",  bg_beta
write(101010,*) "  N_scf_iter_max=",  N_scf_iter_max
write(101010,*) "  N_non_scf_iter_max=",  N_non_scf_iter_max
write(101010,*) "  N_opt=",  N_opt
write(101010,*) "  time_step=",  time_step
write(101010,*) "  N_time_steps=",  N_time_steps
write(101010,*) "  grid_type=",  grid_type
write(101010,*) "  cap_left=",  cap_left
write(101010,*) "  cap_right=",  cap_right
write(101010,*) "  cap_left1=",  cap_left1
write(101010,*) "  cap_right1=",  cap_right1
write(101010,*) "  cap_left2=",  cap_left2
write(101010,*) "  cap_right2=",  cap_right2
write(101010,*) "  cap_left3=",  cap_left3
write(101010,*) "  cap_right3=",  cap_right3
write(101010,*) "  injection_x1=",  injection_x1
write(101010,*) "  injection_x2=",  injection_x2
write(101010,*) "  injection_y1=",  injection_y1
write(101010,*) "  injection_y2=",  injection_y2
write(101010,*) "  injection_z1=",  injection_z1
write(101010,*) "  injection_z2=",  injection_z2
write(101010,*) "  save_cap=",  save_cap
write(101010,*) "  add_projector_cap=",  add_projector_cap
write(101010,*) "  using_injection=",  using_injection
write(101010,*) "  E_ext=",  E_ext
write(101010,*) "  V_step=",  V_step
write(101010,*) "  V_step_end=",  V_step_end
write(101010,*) "  buffer=",  buffer
write(101010,*) "  source_type=",  source_type
write(101010,*) "  box_type=",  box_type
write(101010,*) "  tddft_type=",  tddft_type
write(101010,*) "  wp_momentum=",  wp_momentum
write(101010,*) "  wp_center=",  wp_center
write(101010,*) "  wp_width=",  wp_width
write(101010,*) "  use_high_energy_wp=",  use_high_energy_wp
write(101010,*) "  mixer_type=",  mixer_type
write(101010,*) "  mixer_hist=",  mixer_hist
write(101010,*) "  mixer_weight=",  mixer_weight
write(101010,*) "  mixer_beta=",  mixer_beta
write(101010,*) "  mixer_ibeta=",  mixer_ibeta
write(101010,*) "  mixer_kbeta=",  mixer_kbeta
write(101010,*) "  mixer_ninit=",  mixer_ninit
write(101010,*) "  mixer_nkick=",  mixer_nkick
write(101010,*) "  mixer_abeta=",  mixer_abeta
write(101010,*) "  mixer_a0=",  mixer_a0
write(101010,*) "  mixer_dynamic =",  mixer_dynamic 
write(101010,*) "  mixer_beta_min=",  mixer_beta_min
write(101010,*) "  mixer_beta_max=",  mixer_beta_max
write(101010,*) "  mixer_dyn_f1 =",  mixer_dyn_f1 
write(101010,*) "  mixer_dyn_f2 =",  mixer_dyn_f2 
write(101010,*) "  ediff=",  ediff
write(101010,*) "  pdiff=",  pdiff
write(101010,*) "  periodic=",  periodic
write(101010,*) "  transport=",  transport
write(101010,*) "  contracted=",  contracted
write(101010,*) "  E_fermi=",  E_fermi
write(101010,*) "  V_bias=",  V_bias
write(101010,*) "  fd_p_full=",  fd_p_full
write(101010,*) "  fermi_energy_search=",  fermi_energy_search
write(101010,*) "  td_density_output_format=",  td_density_output_format
write(101010,*) "  td_current_density_output_format=",  td_current_density_output_format
write(101010,*) "  td_total_3D_potential_output_format=",  td_total_3D_potential_output_format
write(101010,*) "  large_file_format=",  large_file_format
write(101010,*) "  propagator=",  propagator
write(101010,*) "  structure_input_filename=",  structure_input_filename
write(101010,*) "  cap_parameter=",  cap_parameter
write(101010,*) "  cap_buffer=",  cap_buffer
write(101010,*) "  save_lattice_view=",  save_lattice_view
write(101010,*) "  kpoint_type=",  kpoint_type
write(101010,*) "  nkv=",  nkv
write(101010,*) "  n_basis_cache=",  n_basis_cache
write(101010,*) "  cache_basis=",  cache_basis
write(101010,*) "  radial_fine_grid=",  radial_fine_grid
write(101010,*) "  recalc_kpoint =",  recalc_kpoint 
write(101010,*) "  orbital_index=",  orbital_index
write(101010,*) " no_crappy_mapping=",no_crappy_mapping 
write(101010,*) " limit_lattice_near_atoms=",limit_lattice_near_atoms
write(101010,*) " limit_lattice_near_rad=",limit_lattice_near_rad
!write(101010,*) "do_fft_Hpsi=",do_fft_Hpsi
write(101010,*) "split_op_save_imagt_gs=",split_op_save_imagt_gs
write(101010,*) "use_split_op_cpximagtime=",use_split_op_cpximagtime
write(101010,*) "split_op_imag_ts_phase=",split_op_imag_ts_phase
write(101010,*) "split_op_num_imag_ts=",split_op_num_imag_ts
write(101010,*) "split_op_num_ramp_ts=",split_op_num_ramp_ts
write(101010,*) "split_op_inital_imag_ts=",split_op_inital_imag_ts
write(101010,*) "split_op_num_imag_tsdecay=",split_op_num_imag_tsdecay
write(101010,*) "projectile_fine_eom_inum=",projectile_fine_eom_inum
write(101010,*) "projectile_fine_eom=",projectile_fine_eom
write(101010,*) "projectile_ion_full_charge=",projectile_ion_full_charge
write(101010,*) "md_give_inf_mass_specific=",          md_give_inf_mass_specific
write(101010,*) "md_inf_mass_numberofatoms=",  md_inf_mass_numberofatoms
write(101010,*) "md_inf_mass_string=",        md_inf_mass_string
write(101010,*) "calc_dpm_elec_nuc=",calc_dpm_elec_nuc
write(101010,*) "md_subtract_COM_motion=",md_subtract_COM_motion
write(101010,*) "resolve_gs=",resolve_gs
write(101010,*) "save_timings=",save_timings
write(101010,*) "switch_mode=",switch_mode
write(101010,*) "switch_proj_z_min=",switch_proj_z_min
write(101010,*) "switch_proj_z=",switch_proj_z
write(101010,*) "switch_check_ioniz=",switch_check_ioniz
write(101010,*) "switch_ioniz_max=",switch_ioniz_max
write(101010,*) "do_dealloc_psi=",do_dealloc_psi
write(101010,*) "output_td_current_density_slices=",output_td_current_density_slices
write(101010,*) "td_current_density_slice_output_frequency=",td_current_density_slice_output_frequency
write(101010,*) "output_td_line_current_orbital=",output_td_line_current_orbital
write(101010,*) "output_td_line_current_orbital_frequency=",output_td_line_current_orbital_frequency
write(101010,*) "output_td_line_current_orbital_stride=",output_td_line_current_orbital_stride
write(101010,*) "output_td_xyslice_current_orbital_frequency=",output_td_xyslice_current_orbital_frequency
write(101010,*) "output_td_current_atom_sum_frequency=",output_td_current_atom_sum_frequency
write(101010,*) "output_td_current_atom_sum_beta=",output_td_current_atom_sum_beta
write(101010,*) "td_current_plane_cutoff=",td_current_plane_cutoff
write(101010,*) "setup_rad_basis=",setup_rad_basis
write(101010,*) "volkov_save_dens=",volkov_save_dens
write(101010,*) "volkov_save_dens_freq=",volkov_save_dens_freq
write(101010,*) "volkov_save_dslice=",volkov_save_dslice
write(101010,*) "volkov_save_1d_dens_freq=",volkov_save_1d_dens_freq
write(101010,*) "maskV_save_PES=",maskV_save_PES
write(101010,*) "maskV_save_multi_PES=",maskV_save_multi_PES
write(101010,*) "maskV_save_multi_PES_avgs=",maskV_save_multi_PES_avgs
write(101010,*) "maskV_save_multi_PES_full=",maskV_save_multi_PES_full
write(101010,*) "maskV_save_multi_PES_freq=",maskV_save_multi_PES_freq
write(101010,*) "print_enediff=",print_enediff
write(101010,*) "calc_energy_freq=",calc_energy_freq
write(101010,*) "debug_output_level=",debug_output_level
write(101010,*) "boosted_orbital=",boosted_orbital
write(101010,*) "boost_around_atom=",boost_around_atom
write(101010,*) "boost_around_atom_idx=",boost_around_atom_idx
write(101010,*) "boost_around_atom_rad=",boost_around_atom_rad
write(101010,*) "calc_force_gs_psi=",calc_force_gs_psi
write(101010,*) "calc_force_gs_psi_frequency=",calc_force_gs_psi_frequency
write(101010,*) "remove_dens_around_atom",remove_dens_around_atom
write(101010,*) "remove_dens_around_atom_idx",remove_dens_around_atom_idx
write(101010,*) "remove_dens_around_atom_rad",remove_dens_around_atom_rad
write(101010,*) "man_set_N_orbitals=",man_set_N_orbitals
write(101010,*) "man_set_N_orbitals_num=",man_set_N_orbitals_num
write(101010,*) "split_region_mode=",split_region_mode
write(101010,*) "split_region_plane_z=",split_region_plane_z
write(101010,*) "split_region_n_orb_lower=",split_region_n_orb_lower
write(101010,*) "split_region_n_orb_upper=",split_region_n_orb_upper
write(101010,*) "combine_gs=",combine_gs
write(101010,*) "combine_gs_2path=",combine_gs_2path
write(101010,*) "combine_gs_num_orb_1=",combine_gs_num_orb_1
write(101010,*) "combine_gs_num_orb_2=",combine_gs_num_orb_2
write(101010,*) "combine_gs_boost2=",combine_gs_boost2
write(101010,*) "combine_gs_boost_vx=",combine_gs_boost_vx
write(101010,*) "combine_gs_boost_vy=",combine_gs_boost_vy
write(101010,*) "combine_gs_boost_vz=",combine_gs_boost_vz
write(101010,*) "use_adsic=",use_adsic
write(101010,*) "n_orb_prop=",n_orb_prop
write(101010,*) "print_fragment_info=",  print_fragment_info
write(101010,*) "print_fragment_freq=",  print_fragment_freq
write(101010,*) "fragment_dens_rad=",    fragment_dens_rad
write(101010,*) "print_bond_info=",      print_bond_info
write(101010,*) "print_bond_freq=",      print_bond_freq
write(101010,*) "MPI_debug=",MPI_debug
write(101010,*) "read_initial_occupation=",read_initial_occupation
write(101010,*) "nl_pp_mode=",nl_pp_mode
write(101010,*) "xc_functional_mode=",xc_functional_mode
write(101010,*) "xc_v_check_t=",xc_v_check_t
write(101010,*) "split_up_gen_nlpp=",split_up_gen_nlpp
write(101010,*) "read_isotope_mass=",read_isotope_mass
write(101010,*) "xc_lib_ex_num",xc_lib_ex_num
write(101010,*) "xc_lib_cor_num",xc_lib_cor_num
close(101010)
END SUBROUTINE parse

subroutine dendiv
  integer            :: n1,n2,n3,i,m1,m2,m3,i1,i2,i3,k,j
  double precision   :: x

  m1=Nx_box(1)
  m3=Nx_box(1)
  m2=N_Lattice(1)-m1-m3
  n2=N_Lattice(2)
  n3=N_Lattice(3)

  open(transport_density_L_file,file=trim(adjustl(transport_density_L_filename)))
    write(transport_density_L_file,*)m1,n2,n3
    i=0
    do i1=1,m1
      do i2=1,n2
        do i3=1,n3
          i=i+1
          write(transport_density_L_file,*) v_hartree(i),v_exchange(i),density(i)
        end do
      end do
    end do
    do i1=1,m1
      write(transport_density_L_file,*)xgrid(i1)
    end do
    do i2=1,n2
      write(transport_density_L_file,*)ygrid(i2)
    end do
    do i3=1,n3
      write(transport_density_L_file,*)zgrid(i3)
    end do
  close(transport_density_L_file)
  open(transport_density_C_file,file=trim(adjustl(transport_density_C_filename)))
    write(transport_density_C_file,*)m2,n2,n3
    i=m1*n2*n3
    do i1=1,m2
      do i2=1,n2
        do i3=1,n3
          i=i+1
          write(transport_density_C_file,*) v_hartree(i),v_exchange(i),density(i)
        end do
      end do
    end do
  close(transport_density_C_file)
  open(transport_density_R_file,file=trim(adjustl(transport_density_R_filename)))
    write(transport_density_R_file,*)m3,n2,n3
    i=(m1+m2)*n2*n3
    do i1=1,m3
      do i2=1,n2
        do i3=1,n3
          i=i+1
          write(transport_density_R_file,*) v_hartree(i),v_exchange(i),density(i)
        end do
      end do
    end do
    do i1=1,m3
      write(transport_density_R_file,*)xgrid(m1+m2+i1)
    end do
    do i2=1,n2
      write(transport_density_R_file,*)ygrid(i2)
    end do
    do i3=1,n3
      write(transport_density_R_file,*)zgrid(i3)
    end do
  close(transport_density_R_file)

end subroutine dendiv

subroutine dendiv5
  integer            :: n1,n2,n3,i,m1,m2,m3,i1,i2,i3,k,j
  double precision   :: x

  if(n_box/=5) then
    write(log_file,*)'N_box/=5 in dendiv5'
  endif

  m1=Nx_box(2)
  m3=Nx_box(2)
  m2=Nx_box(3)
  n2=N_Lattice(2)
  n3=N_Lattice(3)

  open(transport_density_L_file,file=trim(adjustl(transport_density_L_filename)))
    write(transport_density_L_file,*)m1,n2,n3
    i=Nx_box(1)*n2*n3
    write(300,*)Nx_box
    write(300,*)'??',i,N_Lattice_points
    do i1=1,m1
      do i2=1,n2
        do i3=1,n3
          i=i+1
    write(300,*)'?1',i
          write(transport_density_L_file,*) v_hartree(i),v_exchange(i),density(i)
        end do
      end do
    end do
    do i1=1,m1
      write(transport_density_L_file,*)xgrid(i1)
    end do
    do i2=1,n2
      write(transport_density_L_file,*)ygrid(i2)
    end do
    do i3=1,n3
      write(transport_density_L_file,*)zgrid(i3)
    end do
  close(transport_density_L_file)
  open(transport_density_C_file,file=trim(adjustl(transport_density_C_filename)))
    write(transport_density_C_file,*)m2,n2,n3
    i=(Nx_box(1)+Nx_box(2))*n2*n3
    write(300,*)'??',i
    do i1=1,m2
      do i2=1,n2
        do i3=1,n3
          i=i+1
    write(300,*)'?2',i
          write(transport_density_C_file,*) v_hartree(i),v_exchange(i),density(i)
        end do
      end do
    end do
  close(transport_density_C_file)
  open(transport_density_R_file,file=trim(adjustl(transport_density_R_filename)))
    write(transport_density_R_file,*)m3,n2,n3
    i=(Nx_box(1)+Nx_box(2)+Nx_box(3))*n2*n3
    write(300,*)'??',i
    do i1=1,m3
      do i2=1,n2
        do i3=1,n3
          i=i+1
    write(300,*)'?3',i
          write(transport_density_R_file,*) v_hartree(i),v_exchange(i),density(i)
        end do
      end do
    end do
    do i1=1,m3
      write(transport_density_R_file,*)xgrid(Nx_box(1)+Nx_box(2)+Nx_box(3)+i1)
    end do
    do i2=1,n2
      write(transport_density_R_file,*)ygrid(i2)
    end do
    do i3=1,n3
      write(transport_density_R_file,*)zgrid(i3)
    end do
  close(transport_density_R_file)
end subroutine dendiv5


subroutine save_bov_dat_real(real8grid_array,fname_prefix,quantity_name,findex,ftime)
!This is a general subroutine to save scalar real data defined on a 
!grid (given in linear array real8grid_array) into a file. The data is 
!saved in BOV format, i.e. two files are created: <fname_prefix>.bov and 
!<fname_prefix>.dat. Such data can be then visualized with VisIt software. 
real(8)                     :: real8grid_array(*)
character(len=*)            :: fname_prefix
character(len=*), optional  :: quantity_name
integer, optional           :: findex ! index (may range from 0 to 99999) added
                                      ! between <fname_prefix> and ".bov" and ".dat"
real(8), optional           :: ftime  ! time (in fs) which the BOV file corresponds to
!Local variables
integer          k1,k2,k3,k1min,k1max,k2min,k2max,k3min,k3max,dk1,dk2,dk3,ind,pl,m
character(255)   fname_bov,fname_dat,quantity_to_write
real(8)          time_to_write
character(5)     ch5

k1min=N_Lattice_min(1)
k1max=N_Lattice_max(1)
k2min=N_Lattice_min(2)
k2max=N_Lattice_max(2)
k3min=N_Lattice_min(3)
k3max=N_Lattice_max(3)
dk1=(k1max-k1min+1)
dk2=(k2max-k2min+1)
dk3=(k3max-k3min+1)

if (present(quantity_name)) then
  quantity_to_write=quantity_name
else
  quantity_to_write='myquantity'
endif 
pl=len_trim(fname_prefix)
if (present(findex)) then
  write(ch5,'(i5.5)') findex
  write(fname_bov,'(a,a,a)') fname_prefix(1:pl),ch5,'.bov'
  write(fname_dat,'(a,a,a)') fname_prefix(1:pl),ch5,'.dat'
else
  write(fname_bov,'(a,a)') fname_prefix(1:pl),'.bov'
  write(fname_dat,'(a,a)') fname_prefix(1:pl),'.dat' 
endif 
if (present(ftime)) then
  time_to_write=ftime
else
  time_to_write=0.0d0
endif 

!Store actual data in binary form (3D array needs to have its dimension order changed, 
!linearized, and converted to single precision)
allocate(rearranged_arr_real4(dk1*dk2*dk3))
ind=0
do k3=k3min,k3max
  do k2=k2min,k2max
    do k1=k1min,k1max
      if (output_orb_current) then
       do m=1,3
        ind=ind+1
         if (Lattice_inv_xyz(k1,k2,k3)>0) then
         rearranged_arr_real4(ind)=real8grid_array(Lattice_inv_xyz(k1,k2,k3))
         else
         rearranged_arr_real4(ind)=0.0
         endif
       enddo
      else
	    ind=ind+1 ! cody changed 
        if (Lattice_inv_xyz(k1,k2,k3)>0) then
        rearranged_arr_real4(ind)=real8grid_array(Lattice_inv_xyz(k1,k2,k3))
        else
        rearranged_arr_real4(ind)=0.0
        endif
      endif
    enddo
  enddo
enddo
open(gen_purpose_datfile,file=trim(adjustl(fname_dat)),form='unformatted',status='replace')
write(gen_purpose_datfile) rearranged_arr_real4
close(gen_purpose_datfile)

!Now create a header file corresponding to the above datafile. The header file
!is in ascii text form
open(gen_purpose_bovfile,file=trim(adjustl(fname_bov)),status='replace')
write(gen_purpose_bovfile,'(1x,a,1x,es23.15)') 'TIME:',time_to_write
write(gen_purpose_bovfile,'(1x,a,1x,a)') 'DATA_FILE:',trim(adjustl(fname_dat))
write(gen_purpose_bovfile,'(1x,a,3(1x,i6))') 'DATA_SIZE:',dk1,dk2,dk3
write(gen_purpose_bovfile,'(1x,a)') 'DATA_FORMAT:  FLOAT'
write(gen_purpose_bovfile,'(1x,a,1x,a)') 'VARIABLE:',trim(adjustl(quantity_to_write))
write(gen_purpose_bovfile,'(1x,a)') 'DATA_ENDIAN:  LITTLE'
write(gen_purpose_bovfile,'(1x,a)') 'CENTERING:  zonal'
write(gen_purpose_bovfile,'(1x,a,3(1x,es23.15))') 'BRICK_ORIGIN:',xgrid(k1min),ygrid(k2min),zgrid(k3min)
write(gen_purpose_bovfile,'(1x,a,3(1x,es23.15))') 'BRICK_SIZE:',(dk1-1)*grid_step(1),(dk2-1)*grid_step(2),(dk3-1)*grid_step(3)
write(gen_purpose_bovfile,'(1x,a)') 'BYTE_OFFSET: 4'
close(gen_purpose_bovfile)

deallocate(rearranged_arr_real4)
end subroutine save_bov_dat_real


subroutine save_bov_dat_complex(complex8grid_array,fname_prefix,quantity_name,findex,ftime)
!This is a general subroutine to save scalar complex data defined on a 
!grid (given in linear array complex8grid_array) into a file. The data is 
!saved in BOV format, i.e. two files are created: <fname_prefix>.bov and 
!<fname_prefix>.dat. Such data can be then visualized with VisIt software. 
complex(8)                  :: complex8grid_array(*)
character(len=*)            :: fname_prefix
character(len=*), optional  :: quantity_name
integer, optional           :: findex ! index (may range from 0 to 99999) added
                                      ! between <fname_prefix> and ".bov" and ".dat"
real(8), optional           :: ftime  ! time (in fs) which the BOV file corresponds to
!Local variables
integer          k1,k2,k3,k1min,k1max,k2min,k2max,k3min,k3max,dk1,dk2,dk3,ind,pl
character(255)   fname_bov,fname_dat,quantity_to_write
real(8)          time_to_write
character(5)     ch5

k1min=N_Lattice_min(1)
k1max=N_Lattice_max(1)
k2min=N_Lattice_min(2)
k2max=N_Lattice_max(2)
k3min=N_Lattice_min(3)
k3max=N_Lattice_max(3)
dk1=(k1max-k1min+1)
dk2=(k2max-k2min+1)
dk3=(k3max-k3min+1)

if (present(quantity_name)) then
  quantity_to_write=quantity_name
else
  quantity_to_write='myquantity'
endif 
pl=len_trim(fname_prefix)
if (present(findex)) then
  write(ch5,'(i5.5)') findex
  write(fname_bov,'(a,a,a)') fname_prefix(1:pl),ch5,'.bov'
  write(fname_dat,'(a,a,a)') fname_prefix(1:pl),ch5,'.dat'
else
  write(fname_bov,'(a,a)') fname_prefix(1:pl),'.bov'
  write(fname_dat,'(a,a)') fname_prefix(1:pl),'.dat' 
endif 
if (present(ftime)) then
  time_to_write=ftime
else
  time_to_write=0.0d0
endif 

!Store actual data in binary form (3D array needs to have its dimension order changed, 
!linearized, and converted to single precision)
allocate(rearranged_arr_complex4(dk1*dk2*dk3))
ind=0
do k3=k3min,k3max
  do k2=k2min,k2max
    do k1=k1min,k1max
      ind=ind+1
      if (Lattice_inv_xyz(k1,k2,k3)>0) then
        rearranged_arr_complex4(ind)=complex8grid_array(Lattice_inv_xyz(k1,k2,k3))
      else
        rearranged_arr_complex4(ind)=0.0
      endif
    enddo
  enddo
enddo
open(gen_purpose_datfile,file=trim(adjustl(fname_dat)),form='unformatted',status='replace')
write(gen_purpose_datfile) rearranged_arr_complex4
close(gen_purpose_datfile)

!Now create a header file corresponding to the above datafile. The header file
!is in ascii text form
open(gen_purpose_bovfile,file=trim(adjustl(fname_bov)),status='replace')
write(gen_purpose_bovfile,'(1x,a,1x,es23.15)') 'TIME:',time_to_write
write(gen_purpose_bovfile,'(1x,a,1x,a)') 'DATA_FILE:',trim(adjustl(fname_dat))
write(gen_purpose_bovfile,'(1x,a,3(1x,i6))') 'DATA_SIZE:',dk1,dk2,dk3
write(gen_purpose_bovfile,'(1x,a)') 'DATA_FORMAT:  FLOAT'
write(gen_purpose_bovfile,'(1x,a,1x,a)') 'VARIABLE:',trim(adjustl(quantity_to_write))
write(gen_purpose_bovfile,'(1x,a)') 'DATA_COMPONENTS: 2'
write(gen_purpose_bovfile,'(1x,a)') 'DATA_ENDIAN:  LITTLE'
write(gen_purpose_bovfile,'(1x,a)') 'CENTERING:  zonal'
write(gen_purpose_bovfile,'(1x,a,3(1x,es23.15))') 'BRICK_ORIGIN:',xgrid(k1min),ygrid(k2min),zgrid(k3min)
write(gen_purpose_bovfile,'(1x,a,3(1x,es23.15))') 'BRICK_SIZE:',(dk1-1)*grid_step(1),(dk2-1)*grid_step(2),(dk3-1)*grid_step(3)
write(gen_purpose_bovfile,'(1x,a)') 'BYTE_OFFSET: 4'
close(gen_purpose_bovfile)

deallocate(rearranged_arr_complex4)
end subroutine save_bov_dat_complex


function join_string_and_num(inp_string,inp_int,suffix_string)
!This functions concatenates string (inp_string) and a string obtained by
!converting an integer (inp_int) into a sting. It also adda an optional
!string (suffix_string) in the end.
character(len=*)           :: inp_string
integer                    :: inp_int
character(len=*), optional :: suffix_string
character(255)             :: join_string_and_num
character(20)              :: s
integer                    :: L

write(s,'(i12)') inp_int
if (present(suffix_string)) then
  write(join_string_and_num,'(a,a,a)') trim(adjustl(inp_string)),trim(adjustl(s)),trim(adjustl(suffix_string))
else
  write(join_string_and_num,'(a,a)') trim(adjustl(inp_string)),trim(adjustl(s))
endif 

end function join_string_and_num


subroutine save_complex_orbitals(iter)
!This subroutine saves td orbitals 
integer  iter
!Local variables
integer         findex,k,i,N_out_orb
character(255)  fpref,quantity

findex=iter/td_orbital_output_frequency
if (spin_polarized) then
  N_out_orb=min(orbital_down_output_num,N_orbitals_down)
  do k=N_orbitals_down-N_out_orb+1,N_orbitals_down
    fpref=trim(adjustl(join_string_and_num("homodown",N_orbitals_down-k,"_")))
    quantity=join_string_and_num("homodown",N_orbitals_down-k)
    !$omp parallel do default(shared) private (i)
    do i=1,N_Lattice_points    
      Phi_c(i)=Psi_c(i,k)
    enddo  
    !$omp end parallel do  
    call save_bov_dat_complex(Phi_c,fpref,trim(adjustl(quantity)),findex,iter*time_step)
  enddo 
  N_out_orb=min(orbital_up_output_num,N_orbitals_up)
  do k=N_orbitals_down+N_orbitals_up-N_out_orb+1,N_orbitals_down+N_orbitals_up
    fpref=trim(adjustl(join_string_and_num("homoup",N_orbitals_up+N_orbitals_up-k,"_")))
    quantity=join_string_and_num("homoup",N_orbitals_up+N_orbitals_up-k)
    !$omp parallel do default(shared) private (i)
    do i=1,N_Lattice_points    
      Phi_c(i)=Psi_c(i,k)
    enddo  
    !$omp end parallel do  
    call save_bov_dat_complex(Phi_c,fpref,trim(adjustl(quantity)),findex,iter*time_step)
  enddo    
else
  N_out_orb=min(orbital_output_num,N_orbitals)
  do k=N_orbitals-N_out_orb+1,N_orbitals
    fpref=trim(adjustl(join_string_and_num("homo",N_orbitals-k,"_")))
    quantity=join_string_and_num("homo",N_orbitals-k)
    !$omp parallel do default(shared) private (i)
    do i=1,N_Lattice_points    
      Phi_c(i)=Psi_c(i,k)
    enddo  
    !$omp end parallel do  
    call save_bov_dat_complex(Phi_c,fpref,trim(adjustl(quantity)),findex,iter*time_step)
  enddo  
endif 
end subroutine save_complex_orbitals


subroutine save_real_orbitals
!This subroutine saves ground-state (i.e. real) orbitals 
integer  iter
!Local variables
integer         findex,k,i,N_out_orb
character(255)  fpref,quantity

if (spin_polarized) then
  N_out_orb=min(orbital_down_output_num,N_orbitals_down)
  do k=N_orbitals_down-N_out_orb+1,N_orbitals_down
    fpref=trim(adjustl(join_string_and_num("gs_homodown",N_orbitals_down-k)))
    quantity="psi"
    !$omp parallel do default(shared) private (i)
    do i=1,N_Lattice_points    
      Phi(i)=Psi(i,k)
    enddo  
    !$omp end parallel do  
    call save_bov_dat_real(Phi,fpref,trim(adjustl(quantity)))
  enddo 
  N_out_orb=min(orbital_up_output_num,N_orbitals_up)
  do k=N_orbitals_down+N_orbitals_up-N_out_orb+1,N_orbitals_down+N_orbitals_up
    fpref=trim(adjustl(join_string_and_num("gs_homoup",N_orbitals_up+N_orbitals_up-k)))
    quantity="psi"
    !$omp parallel do default(shared) private (i)
    do i=1,N_Lattice_points    
      Phi(i)=Psi(i,k)
    enddo  
    !$omp end parallel do  
    call save_bov_dat_real(Phi,fpref,trim(adjustl(quantity)))
  enddo    
else
  N_out_orb=min(orbital_output_num,N_orbitals)
  do k=N_orbitals-N_out_orb+1,N_orbitals
    fpref=trim(adjustl(join_string_and_num("gs_homo",N_orbitals-k)))
    quantity="psi"
    !$omp parallel do default(shared) private (i)
    do i=1,N_Lattice_points    
      Phi(i)=Psi(i,k)
    enddo  
    !$omp end parallel do  
    call save_bov_dat_real(Phi,fpref,trim(adjustl(quantity)))
  enddo  
endif 
end subroutine save_real_orbitals


subroutine save_complex_orbitals2(iter)
!This subroutine saves absolute squares of td orbitals 
integer  iter
!Local variables
integer         findex,k,i,N_out_orb
character(255)  fpref,quantity

findex=iter/td_orbital_output_frequency
if (spin_polarized) then
  N_out_orb=min(orbital_down_output_num,N_orbitals_down)
  do k=N_orbitals_down-N_out_orb+1,N_orbitals_down
    fpref=trim(adjustl(join_string_and_num("dens_homodown",N_orbitals_down-k,"_")))
    quantity=join_string_and_num("dens_homodown",N_orbitals_down-k)
    !$omp parallel do default(shared) private (i)
    do i=1,N_Lattice_points    
      Phi(i)=Psi_c(i,k)*conjg(Psi_c(i,k))
    enddo  
    !$omp end parallel do  
    call save_bov_dat_real(Phi,fpref,trim(adjustl(quantity)),findex,iter*time_step)
  enddo 
  N_out_orb=min(orbital_up_output_num,N_orbitals_up)
  do k=N_orbitals_down+N_orbitals_up-N_out_orb+1,N_orbitals_down+N_orbitals_up
    fpref=trim(adjustl(join_string_and_num("dens_homoup",N_orbitals_up+N_orbitals_up-k,"_")))
    quantity=join_string_and_num("dens_homoup",N_orbitals_up+N_orbitals_up-k)
    !$omp parallel do default(shared) private (i)
    do i=1,N_Lattice_points    
      Phi(i)=Psi_c(i,k)*conjg(Psi_c(i,k))
    enddo  
    !$omp end parallel do  
    call save_bov_dat_real(Phi,fpref,trim(adjustl(quantity)),findex,iter*time_step)
  enddo    
else
  N_out_orb=min(orbital_output_num,N_orbitals)
  do k=N_orbitals-N_out_orb+1,N_orbitals
    fpref=trim(adjustl(join_string_and_num("dens_homo",N_orbitals-k,"_")))
    quantity=join_string_and_num("dens_homo",N_orbitals-k)
    !$omp parallel do default(shared) private (i)
    do i=1,N_Lattice_points    
      Phi(i)=Psi_c(i,k)*conjg(Psi_c(i,k))
    enddo  
    !$omp end parallel do  
    call save_bov_dat_real(Phi,fpref,trim(adjustl(quantity)),findex,iter*time_step)
  enddo  
endif 
end subroutine save_complex_orbitals2

SUBROUTINE laser_read_from_file
! cody: read laser from file
  integer          :: i
  open(laser_xyz_file,file=laser_xyz_filename)
  write(log_file,*)"Read xyz comonents of external field from file",laser_xyz_filename
  read(laser_xyz_file,*) laser_xyz_t_number
  write(log_file,*)" * Read ",laser_xyz_t_number
  allocate ( laser_xyz_t(4,0:laser_xyz_t_number) )
  laser_xyz_t(:,0)=0.d0
  do i=1, laser_xyz_t_number
     read ( laser_xyz_file,* ) laser_xyz_t(1:4,i)
  end do
  close (laser_xyz_file)
  laser_xyz_t(1,0)=laser_xyz_t(1,1)-laser_xyz_t(1,2) ! NEGATIVE STARTING POINT FOR INTERPOLATION LATER.
  laser_xyz_t_iteration(1) = 0.0d0
  laser_xyz_t_iteration(2) = 0.0d0
  laser_xyz_t_iteration(3) = 0.0d0
END SUBROUTINE laser_read_from_file

subroutine print_frc_TD_and_GS(time_point)
implicit none
  logical :: file_open
  real*8,intent(in) :: time_point
  real*8  :: rmsd_force,max_diff,fdiff
  integer :: atom,max_diff_atom
  
  if(.NOT.compare_force_file_open) then
    open(compare_force_file_number,file=trim(adjustl(force_compare_file_name)),form='formatted',status='replace',action='write')
	compare_force_file_open=.TRUE.
	write(compare_force_file_number,*) "# XYZ crd  TD_force  GS_FORCE"
  end if

  rmsd_force=0.d0
  max_diff=0.d0; max_diff_atom=0
  write(compare_force_file_number,*) "time=",time_point
  write(compare_force_file_number,*) ""
  do atom=1,N_total_atom
    write(compare_force_file_number,'(i4,3F12.6,6ES16.7E3)') atom,Position(1:3,atom),force(1:3,atom),force_psiREAL(1:3,atom)
	fdiff=sum((force(1:3,atom)-force_psiREAL(1:3,atom))**2)
	rmsd_force=rmsd_force+fdiff
	fdiff=sqrt(fdiff)
	if(fdiff>max_diff) then
	  max_diff=fdiff
	  max_diff_atom=atom
	end if
  end do
  rmsd_force=sqrt(rmsd_force/N_total_atom)
  write(compare_force_file_number,*) "#RMSD_F=",rmsd_force
  write(compare_force_file_number,*) "#max_diff=",max_diff," A=",max_diff_atom
  
  
end subroutine print_frc_TD_and_GS

subroutine open_formatted_file(unit, filename, do_append)
  implicit none
  integer, intent(in)      :: unit
  character(*), intent(in) :: filename
  logical,intent(in)       :: do_append

  if (do_append) then
    open(unit, file=trim(adjustl(filename)), form='formatted', action='write', status='old', position='append')
  else
    open(unit, file=trim(adjustl(filename)), form='formatted', action='write', status='replace')
  end if
end subroutine open_formatted_file

subroutine open_fort_file(unit, do_append)
  implicit none
  integer, intent(in)      :: unit
  logical,intent(in)       :: do_append

  if (do_append) then
    open(unit, form='formatted', action='write', status='old', position='append')
  else
    open(unit, form='formatted', action='write', status='replace')
  end if
end subroutine open_fort_file

END MODULE MOD_IO



