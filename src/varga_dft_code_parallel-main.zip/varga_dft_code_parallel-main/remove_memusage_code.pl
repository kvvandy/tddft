#!/usr/bin/env perl
use strict;
use warnings;

my $parameters_filename="parameters.f90";

##############################
# End of user-defined values #
##############################

# Process command-line arguments
if(scalar(@ARGV)!=0) {
  die "\n  Usage: make_memusage_code.pl\n\n";
}

open(my $INPUT_FILE,"<$parameters_filename") or die "\n\nUnable to open file \"$parameters_filename\"\n";
my $file_contents=join('',<$INPUT_FILE>);
close($INPUT_FILE);

my $file_ID;
if($file_contents=~/memory_log_file\s*=\s*(\S+)[,\s\n]+/i) {
  $file_ID=$1;
} else {
  die "\n  ERROR: Could not set file ID\n\n";
}

go();
chdir("Poisson");
go();
chdir("Poisson_S");
go();
chdir("..");

###############
# Subroutines #
###############

sub go {
  # Get a list of source files in the current directory
  my $directory_list=`ls -1 *.f*`;
  chomp($directory_list);
  my @filenames=split('\n',$directory_list);

  foreach my $filename (@filenames) {
    remove_memory_usage_code($filename,$filename);
  }
}

sub remove_memory_usage_code {
  my ($input_filename,$output_filename)=@_;
  open(my $INPUT_FILE,"<$input_filename") or die "\n\nUnable to open file \"$input_filename\"\n";

  my @output_lines=();
  while(my $file_line=<$INPUT_FILE>) {
    if($file_line!~/write\s*\($file_ID/i) {
      push(@output_lines,$file_line);
    } elsif($file_line=~/\!\s*keep/i) {
      push(@output_lines,$file_line);
    }
  }
  close($INPUT_FILE);

  open(my $OUTPUT_FILE,">$output_filename") or die "\n\nUnable to open file \"$output_filename\"\n";
  foreach my $output_line (@output_lines) {
    print $OUTPUT_FILE $output_line;
  }
  close($OUTPUT_FILE);
}
