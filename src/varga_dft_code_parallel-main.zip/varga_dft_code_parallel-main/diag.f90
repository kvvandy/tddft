subroutine diag3z(hm,om,n,neig,e,v)
USE PARAMETERS
!Arguments(input):
complex(8)   hm(n,n)     !Hamiltonian matrix
complex(8)   om(n,n)     !Overlap matrix
integer   n               !Eigenvalue problem size
integer   neig            !Number of lowest eigenvalues/eigenvectors to compute
!Arguments(output):
real(8)   e(neig)   !Eigenvalues
complex(8)   v(n,neig) !Corresponding eigenvectors

!local variables
integer,allocatable,dimension(:)   :: IWORK
real(8)                            :: ABSTOL
real(8),allocatable,dimension(:)  :: RWORK
complex(8),allocatable,dimension(:)   :: WORK
integer                            :: LDA, LDB, IU, M, LDZ, NB, LWORK,INFO
integer,allocatable,dimension(:)   :: IFAIL
integer                            :: ILAENV
character(1), parameter :: JOBZ='V',RANGE='I',UPLO='U'
real(8), parameter :: VL=0.0d0, VU=0.0d0
integer, parameter :: IL=1
integer, parameter :: ITYPE = 1




      !The problem type is A*x = lambda*B*x
      !'V' means compute both eigenvalues and eigenvectors
      !'I' means only selected eigenvalues/eigenvectors will be found
      !'U' means the upper triangles of A and B are provided.
LDA=N          !Leading dimension of A is N
LDB=N          !Leading dimension of B is N
       !VL can be set to anything because it is not used when RANGE='I'
       !VU can be set to anything because it is not used when RANGE='I'
       !The smallest eigenvalue number
IU=neig        !The largest eigenvalue number.
ABSTOL=2*tiny(ABSTOL) !Set tolerance that yields highest possible accuracy in the
                      !calculations; equivalent to  ABSTOL=2*DLAMCH('S')
LDZ=N          !Leading dimension of Z is N
NB=ILAENV(1,'DSYTRD','VIU',N,N,N,N) !Determine the optimal block size
LWORK=(NB+3)*N !Set the size of array WORK
allocate(WORK(LWORK)) !Allocate array WORK, which is a real(8) work array used by DSYGVX
allocate(IWORK(5*N))  !Allocate array IWORK, which is an integer work array used by DSYGVX
allocate(IFAIL(N)) !Allocate IFAIL, an integer flag array used by DSYGVX
allocate(RWORK(7*N))

call ZHEGVX( ITYPE, JOBZ, RANGE, UPLO, N, hm, LDA, om, LDB, VL, VU, IL, IU, &
     &  ABSTOL, M, e, v, LDZ, WORK, LWORK, RWORK, &
     &  IWORK, IFAIL, INFO )


if (INFO/=0) then
  write(log_file,*) 'Error in diag3z: subroutine DSYGVX failed with INFO=',INFO
  write(log_file,*) ' N=',N
  stop
endif

deallocate(IFAIL)
deallocate(IWORK)
deallocate(WORK)
deallocate(RWORK)

end subroutine diag3z

subroutine diag3(hm,om,n,neig,e,v)
USE PARAMETERS
!Arguments(input):
real(8)   hm(n,n)         !Hamiltonian matrix
real(8)   om(n,n)         !Overlap matrix
integer   n               !Eigenvalue problem size
integer   neig            !Number of lowest eigenvalues/eigenvectors to compute
!Arguments(output):
real(8)   e(neig)   !Eigenvalues
real(8)   v(n,neig) !Corresponding eigenvectors

!local variables
integer,allocatable,dimension(:)   :: IWORK
character(1)                       :: JOBZ, RANGE, UPLO
real(8)                            :: VL, VU, ABSTOL
real(8),allocatable,dimension(:)   :: WORK
integer                            :: ITYPE, LDA, LDB, IL, IU, M, LDZ, NB, LWORK,INFO
integer,allocatable,dimension(:)   :: IFAIL
integer                            :: ILAENV
ITYPE=1        !The problem type is A*x = lambda*B*x
JOBZ='V'       !'V' means compute both eigenvalues and eigenvectors
RANGE='I'      !'I' means only selected eigenvalues/eigenvectors will be found
UPLO='U'       !'U' means the upper triangles of A and B are provided.
LDA=N          !Leading dimension of A is N
LDB=N          !Leading dimension of B is N
VL=0.0D0       !VL can be set to anything because it is not used when RANGE='I'
VU=0.0D0       !VU can be set to anything because it is not used when RANGE='I'
IL=1           !The smallest eigenvalue number
IU=neig        !The largest eigenvalue number.
ABSTOL=2*tiny(ABSTOL) !Set tolerance that yields highest possible accuracy in the
                      !calculations; equivalent to  ABSTOL=2*DLAMCH('S')
LDZ=N          !Leading dimension of Z is N
NB=ILAENV(1,'DSYTRD','VIU',N,N,N,N) !Determine the optimal block size
LWORK=max(8*N,(NB+3)*N) !Set the size of array WORK
allocate(WORK(LWORK)) !Allocate array WORK, which is a real(8) work array used by DSYGVX
allocate(IWORK(5*N))  !Allocate array IWORK, which is an integer work array used by DSYGVX
allocate(IFAIL(N)) !Allocate IFAIL, an integer flag array used by DSYGVX

!Call DSYGVX
call DSYGVX( ITYPE, JOBZ, RANGE, UPLO, N, hm, LDA, om, LDB,    &
             VL, VU, IL, IU, ABSTOL, M, e, v, LDZ, WORK,     &
             LWORK, IWORK, IFAIL, INFO )
if (INFO/=0) then
  write(log_file,*) 'Error in diag3: subroutine DSYGVX failed with INFO=',INFO
  write(log_file,*) ' N=',N
  stop
endif

deallocate(IFAIL)
deallocate(IWORK)
deallocate(WORK)

end subroutine diag3


      subroutine f01aef(n,a,ia,b,ib,dl,ifail)
!     mark 2 release. nag copyright 1972
!     mark 3 revised.
!     mark 4.5 revised

!     reduc1
!     reduction of the general symmetric eigenvalue problem a * x =
!     lambda * b * x, with symmetric matrix a and symmetric
!     positive definite matrix b, to the equivalent standard
!     problem p * z = lambda * z. the upper triangle, including
!     diagonal elements, of a and b are given in the arrays a(n,n)
!     and b(n,n). l(b = l * lt) is formed in the
!     remaining strictly lower triangle of the array b with its
!     diagonal elements in the array dl(n) , and the lower
!     triangle of the symmetric matrix p(p = inv(l) * a * inv( lt))
!     is formed in the lower triangle of the array a, including the
!     diagonal elements. hence the diagonal elements of a are lost.
!     the subroutine will fail if b, perhaps on account of rounding
!     errors, is not positive definite - sets ifail = 0 if
!     successful else ifail = 1.
!     1st december 1971

      integer isave, ifail, i, n, i1, j, kk, k, j1, ia, ib, p01aaf
      double precision srname
      double precision x, y, a(ia,n), b(ib,n), dl(n)
      data srname /8h f01aef /
      isave = ifail
      do 100 i=1,n
         i1 = i - 1
         do 80 j=i,n
            x = b(i,j)
            if (i1.eq.0) go to 40
            do 20 kk=1,i1
               k = i1 - kk + 1
               x = x - b(i,k)*b(j,k)
   20       continue
   40       if (i.ne.j) go to 60
            if (x.le.0.0d0) go to 320
            y = dsqrt(x)
            dl(i) = y
            go to 80
   60       b(j,i) = x/y
   80    continue
  100 continue
!     l has been formed in array b
      do 180 i=1,n
         y = dl(i)
         i1 = i - 1
         do 160 j=i,n
            x = a(i,j)
            if (i1.eq.0) go to 140
            do 120 kk=1,i1
               k = i1 - kk + 1
               x = x - b(i,k)*a(j,k)
  120       continue
  140       a(j,i) = x/y
  160    continue
  180 continue
!     the transpose of the upper triangle of
!     inv(l) * a has been formed in the lower
!     triangle of array a
      do 300 j=1,n
         j1 = j - 1
         do 280 i=j,n
            x = a(i,j)
            i1 = i - 1
            if (i1.lt.j) go to 220
            do 200 kk=j,i1
               k = i1 - kk + j
               x = x - a(k,j)*b(i,k)
  200       continue
  220       if (j1.eq.0) go to 260
            do 240 kk=1,j1
               k = j1 - kk + 1
               x = x - a(j,k)*b(i,k)
  240       continue
  260       a(i,j) = x/dl(i)
  280    continue
  300 continue
      ifail = 0
      return
  320 ifail = p01aaf(isave,1,srname)
      return
      end
      subroutine f01aff(n, im1, im2, b, ib, dl, z, iz)
!     mark 2 release. nag copyright 1972
!     mark 4.5 revised

!     rebaka
!     this subroutine performs, on the matrix of eigenvectors, z,
!     stored
!     in columns im1 to im2 of the array z(n,n), a backward
!     substitution
!     lt* x = z, over- writing x on z. the diagonal elements of l
!     must be stored in the array dl(n), and the remaining
!     triangle in the strictly lower triangle of the array b(n,n).
!     the subroutines f01aef and f01bdf leave l in this
!     desired form. if x denotes any column of the resultant matrix
!     x, then x satisfies xt * b * x = zt * z, where b = l * lt.
!     1st august 1971

      integer j, im1, im2, ii, n, i, i2, k, ib, iz
      double precision x, b(ib,n), dl(n), z(iz,im2)
      do 80 j=im1,im2
         do 60 ii=1,n
            i = n - ii + 1
            x = z(i,j)
            i2 = i + 1
            if (i2.gt.n) go to 40
            do 20 k=i2,n
               x = x - b(k,i)*z(k,j)
   20       continue
   40       z(i,j) = x/dl(i)
   60    continue
   80 continue
      return
      end
      subroutine f01ajf(n, atol, a, ia, d, e, z, iz)
!     mark 2 release. nag copyright 1972
!     mark 4 revised.
!     mark 4.5 revised
!     mark 5c revised

!     tred2
!     this subroutine reduces the given lower triangle of a
!     symmetric matrix, a, stored in the array a(n,n), to
!     tridiagonal form using householders reduction. the diagonal
!     of the result is stored in the array d(n) and the
!     sub-diagonal in the last n - 1 stores of the array e(n)
!     (with the additional element e(1) = 0). the transformation
!     matrices are accumulated in the array z(n,n). the array
!     a is left unaltered unless the actual parameters
!     corresponding to a and z are identical.
!     1st august 1971

      integer i, ia, ii, iz, j1, j, k, l, n
      double precision atol, f, g, h, hh, a(ia,n), d(n), e(n), z(iz,n)
      do 40 i=1,n
         do 20 j=1,i
            z(i,j) = a(i,j)
   20    continue
   40 continue
      if (n.eq.1) go to 280
      do 260 ii=2,n
         i = n - ii + 2
         l = i - 2
         f = z(i,i-1)
         g = 0.0d0
         if (l.eq.0) go to 80
         do 60 k=1,l
            g = g + z(i,k)*z(i,k)
   60    continue
   80    h = g + f*f
!     if g is too small for orthogonality to be
!     guaranteed the transformation is skipped
         if (g.gt.atol) go to 100
         e(i) = f
         h = 0.0d0
         go to 240
  100    l = l + 1
         g = dsqrt(h)
         if (f.ge.0.0d0) g = -g
         e(i) = g
         h = h - f*g
         z(i,i-1) = f - g
         f = 0.0d0
         do 180 j=1,l
            z(j,i) = z(i,j)/h
            g = 0.0d0
!     form element of a*u
            do 120 k=1,j
               g = g + z(j,k)*z(i,k)
  120       continue
            j1 = j + 1
            if (j1.gt.l) go to 160
            do 140 k=j1,l
               g = g + z(k,j)*z(i,k)
  140       continue
!     form element of p
  160       e(j) = g/h
            f = f + g*z(j,i)
  180    continue
!     form k
         hh = f/(h+h)
!     form reduced a
         do 220 j=1,l
            f = z(i,j)
            g = e(j) - hh*f
            e(j) = g
            do 200 k=1,j
               z(j,k) = z(j,k) - f*e(k) - g*z(i,k)
  200       continue
  220    continue
  240    d(i) = h
  260 continue
  280 e(1) = 0.0d0
      d(1) = 0.0d0
!     accumulation of transformation matrices
      do 400 i=1,n
         l = i - 1
         if (d(i).eq.0.0d0) go to 360
         do 340 j=1,l
            g = 0.0d0
            do 300 k=1,l
               g = g + z(i,k)*z(k,j)
  300       continue
            do 320 k=1,l
               z(k,j) = z(k,j) - g*z(k,i)
  320       continue
  340    continue
  360    d(i) = z(i,i)
         z(i,i) = 1.0d0
         if (l.eq.0) go to 400
         do 380 j=1,l
            z(i,j) = 0.0d0
            z(j,i) = 0.0d0
  380    continue
  400 continue
      return
      end

      subroutine f02aef(a,ia,b,ib,n,r,v,iv,dl,e,ifail)
!     mark 2 release. nag copyright 1972
!     mark 3 revised.
!     mark 4.5 revised

!     eigenvalues and eigenvectors of a-lambda*b
!     1st december 1971

      integer p01aaf,isave,ifail,n,ia,ib,iv
      double precision srname
      double precision tol,a(ia,n),b(ib,n),r(n),v(iv,n),dl(n),e(n)
      data srname /8h f02aef /
      isave = ifail
      ifail = 1
      call f01aef(n, a, ia, b, ib, dl, ifail)
      if (ifail.eq.0) go to 20
      ifail = p01aaf(isave,ifail,srname)
      return
   20 tol = 2.0d0**(-50)
      call f01ajf(n, tol, a, ia, r, e, v, iv)
      tol = 2.0d0**(-55)
      ifail = 1
      call f02amf(n, tol, r, e, v, iv, ifail)
      if (ifail.eq.0) go to 40
      ifail = p01aaf(isave,2,srname)
      return
   40 call f01aff(n, 1, n, b, ib, dl, v, iv)
      return
      end
      subroutine f02amf(n,acheps,d,e,z,iz,ifail)
!     mark 2 release. nag copyright 1972
!     mark 3 revised.
!     mark 4 revised.
!     mark 4.5 revised

!     tql2
!     this subroutine finds the eigenvalues and eigenvectors of a
!     tridiagonal matrix, t, given with its diagonal elements in
!     the array d(n) and its sub-diagonal elements in the last n
!     - 1 stores of the array e(n), using ql transformations. the
!     eigenvalues are overwritten on the diagonal elements in the
!     array d in ascending order. the eigenvectors are formed in
!     the array z(n,n), overwriting the accumulated
!     transformations as supplied by the subroutine f01ajf. the
!     subroutine will fail if any one eigenvalue takes more than 30
!     iterations.
!     1st april 1972
!
      integer p01aaf, isave, ifail, n, i, l, j, m, i1, m1, ii, k, iz
      double precision srname
      double precision b, f, h, acheps, g, p, r, c, s, d(n), e(n), z(iz,n)
      data srname /8h f02amf /
      isave = ifail
      if (n.eq.1) go to 40
      do 20 i=2,n
         e(i-1) = e(i)
   20 continue
   40 e(n) = 0.0d0
      b = 0.0d0
      f = 0.0d0
      do 300 l=1,n
         j = 0
         h = acheps*(dabs(d(l))+dabs(e(l)))
         if (b.lt.h) b = h
!     look for small sub-diag element
         do 60 m=l,n
            if (dabs(e(m)).le.b) go to 80
   60    continue
   80    if (m.eq.l) go to 280
  100    if (j.eq.30) go to 400
         j = j + 1
!     form shift
         g = d(l)
         h = d(l+1) - g
         if (dabs(h).ge.dabs(e(l))) go to 120
         p = h*0.5d0/e(l)
         r = dsqrt(p*p+1.0d0)
         h = p + r
         if (p.lt.0.0d0) h = p - r
         d(l) = e(l)/h
         go to 140
  120    p = 2.0d0*e(l)/h
         r = dsqrt(p*p+1.0d0)
         d(l) = e(l)*p/(1.0d0+r)
  140    h = g - d(l)
         i1 = l + 1
         if (i1.gt.n) go to 180
         do 160 i=i1,n
            d(i) = d(i) - h
  160    continue
  180    f = f + h
!     ql transformation
         p = d(m)
         c = 1.0d0
         s = 0.0d0
         m1 = m - 1
         do 260 ii=l,m1
            i = m1 - ii + l
            g = c*e(i)
            h = c*p
            if (dabs(p).lt.dabs(e(i))) go to 200
            c = e(i)/p
            r = dsqrt(c*c+1.0d0)
            e(i+1) = s*p*r
            s = c/r
            c = 1.0d0/r
            go to 220
  200       c = p/e(i)
            r = dsqrt(c*c+1.0d0)
            e(i+1) = s*e(i)*r
            s = 1.0d0/r
            c = c/r
  220       p = c*d(i) - s*g
            d(i+1) = h + s*(c*g+s*d(i))
!     form vector
            do 240 k=1,n
               h = z(k,i+1)
               z(k,i+1) = s*z(k,i) + c*h
               z(k,i) = c*z(k,i) - s*h
  240       continue
  260    continue
         e(l) = s*p
         d(l) = c*p
         if (dabs(e(l)).gt.b) go to 100
  280    d(l) = d(l) + f
  300 continue
!     order eigenvalues and eigenvectors
      do 380 i=1,n
         k = i
         p = d(i)
         i1 = i + 1
         if (i1.gt.n) go to 340
         do 320 j=i1,n
            if (d(j).ge.p) go to 320
            k = j
            p = d(j)
  320    continue
  340    if (k.eq.i) go to 380
         d(k) = d(i)
         d(i) = p
         do 360 j=1,n
            p = z(j,i)
            z(j,i) = z(j,k)
            z(j,k) = p
  360    continue
  380 continue
      ifail = 0
      return
  400 ifail = p01aaf(isave,1,srname)
      return
      end



      subroutine p01aaz
!     routine to stop program
      write(log_file,*)'nag diag stop'
      end




      integer function p01aaf(ifail, error, srname)
!     mark 1 release.  nag copyright 1971
!     mark 3 revised
!     mark 4a revised, ier-45
!     mark 4.5 revised
!     mark 7 revised (dec 1978)
!     returns the value of error or terminates the program.
      integer error, ifail, nout

      double precision srname
!*** for v5 compatability only
!     test if no error detected
      if (error.eq.0) go to 20
      nout = 9
!     test for soft failure
      if (mod(ifail,10).eq.1) go to 10
!     hard failure
      write (nout,99999) srname, error
!     stopping mechanism may also differ
      call p01aaz
!     stop
!     soft fail
!     test if error messages suppressed
   10 if (mod(ifail/10,10).eq.0) go to 20
      write (nout,99999) srname, error
   20 p01aaf = error
      return
99999 format (1h0, 38herror detected by nag library routine , a8,11h - ifail = , i5//)
      end

      SUBROUTINE F02BJF(N,A,IA,B,IB,EPS1,ALFR,ALFI,BETA,MATZ,Z,IZ,ITER,&
     &                  IFAIL)
!     MARK 6 RELEASE. NAG COPYRIGHT 1977
!     MARK 6A REVISED  IER-99
!     MARK 11.5(F77) REVISED. (SEPT 1985.)
!     THIS SUBROUTINE PERFORMS THE QZ ALGORITHM FOR SOLVING THE
!     GENERALIZED MATRIX EIGENVALUE PROBLEM, A*Z = LAMBDA*B*Z
!     WHERE A AND B ARE REAL SQUARE MATRICES.
!     REFERENCE
!     SIAM J.NUMER.ANAL., 10, PP241-256, 1973.
!     C. B. MOLER AND G. W. STEWART.
!
!     THIS SUBROUTINE WAS WRITTEN BY
!     W. PHILLIPS OXFORD UNIVERSITY COMPUTING SERVICE.
!     IT CALLS F02BJW, F02BJX, F02BJY AND F02BJZ WHICH
!     WERE OBTAINED FROM EISPACK.
!
!     .. Parameters ..
      CHARACTER*6       SRNAME
      PARAMETER         (SRNAME='F02BJF')
!     .. Scalar Arguments ..
      DOUBLE PRECISION  EPS1
      INTEGER           IA, IB, IFAIL, IZ, N
      LOGICAL           MATZ
!     .. Array Arguments ..
      DOUBLE PRECISION  A(IA,N), ALFI(N), ALFR(N), B(IB,N), BETA(N),&
     &                  Z(IZ,N)
      INTEGER           ITER(N)
!     .. Local Scalars ..
      INTEGER           ISAVE
!     .. Local Arrays ..
      CHARACTER*1       P01REC(1)
!     .. External Functions ..
      INTEGER           P01ABF
      EXTERNAL          P01ABF
!     .. External Subroutines ..
      EXTERNAL          F02BJW, F02BJX, F02BJY, F02BJZ
!     .. Executable Statements ..
      ISAVE = IFAIL
      IFAIL = 1
      CALL F02BJW(N,A,IA,B,IB,MATZ,Z,IZ)
      CALL F02BJX(N,A,IA,B,IB,EPS1,MATZ,Z,IZ,ITER,IFAIL)
      IF (IFAIL.EQ.0) GO TO 20
      IFAIL = P01ABF(ISAVE,IFAIL,SRNAME,0,P01REC)
   20 CALL F02BJY(N,A,IA,B,IB,ALFR,ALFI,BETA,MATZ,Z,IZ)
      IF (IFAIL.NE.0) RETURN
      IF (MATZ) CALL F02BJZ(N,A,IA,B,IB,ALFR,ALFI,BETA,Z,IZ)
      RETURN
      END

      SUBROUTINE F02BJW(N,A,IA,B,IB,MATZ,Z,IZ)
!     MARK 6 RELEASE  NAG COPYRIGHT 1977
!     MARK 11.5(F77) REVISED. (SEPT 1985.)
!
!     THIS SUBROUTINE IS THE FIRST STEP OF THE QZ ALGORITHM
!     FOR SOLVING GENERALIZED MATRIX EIGENVALUE PROBLEMS,
!     SIAM J. NUMER. ANAL. 10, 241-256(1973) BY MOLER AND STEWART.
!
!     THIS SUBROUTINE ACCEPTS A PAIR OF REAL GENERAL MATRICES AND
!     REDUCES ONE OF THEM TO UPPER HESSENBERG FORM AND THE OTHER
!     TO UPPER TRIANGULAR FORM USING ORTHOGONAL TRANSFORMATIONS.
!     IT IS USUALLY FOLLOWED BY F02BJX, F02BJY AND, POSSIBLY,
!     F02BJZ.
!
!     ON INPUT
!
!     N IS THE ORDER OF THE MATRICES.
!
!     A CONTAINS A REAL GENERAL MATRIX.
!
!     IA MUST SPECIFY THE FIRST DIMENSION OF THE ARRAY A AS
!     DECLARED IN THE CALLING (SUB)PROGRAM.  IA.GE.N
!
!     B CONTAINS A REAL GENERAL MATRIX.
!
!     IB MUST SPECIFY THE FIRST DIMENSION OF THE ARRAY B AS
!     DECLARED IN THE CALLING (SUB)PROGRAM.  IB.GE.N
!
!     MATZ SHOULD BE SET TO .TRUE. IF THE RIGHT HAND
!     TRANSFORMATIONS
!     ARE TO BE ACCUMULATED FOR LATER USE IN COMPUTING
!     EIGENVECTORS, AND TO .FALSE. OTHERWISE.
!
!     IZ MUST SPECIFY THE FIRST DIMENSION OF THE ARRAY Z AS
!     DECLARED IN THE CALLING (SUB)PROGRAM.  IZ.GE.N
!
!     ON OUTPUT
!
!     A HAS BEEN REDUCED TO UPPER HESSENBERG FORM.  THE ELEMENTS
!     BELOW THE FIRST SUBDIAGONAL HAVE BEEN SET TO ZERO.
!
!     B HAS BEEN REDUCED TO UPPER TRIANGULAR FORM.  THE ELEMENTS
!     BELOW THE MAIN DIAGONAL HAVE BEEN SET TO ZERO.
!
!     Z CONTAINS THE PRODUCT OF THE RIGHT HAND TRANSFORMATIONS IF
!     MATZ HAS BEEN SET TO .TRUE.  OTHERWISE, Z IS NOT REFERENCED.
!
!     IMPLEMENTED FROM EISPACK BY
!     W. PHILLIPS OXFORD UNIVERSITY COMPUTING SERVICE.
!
!     INITIALIZE Z
!     .. Scalar Arguments ..
      INTEGER           IA, IB, IZ, N
      LOGICAL           MATZ
!     .. Array Arguments ..
      DOUBLE PRECISION  A(IA,N), B(IB,N), Z(IZ,N)
!     .. Local Scalars ..
      DOUBLE PRECISION  ONE, R, RHO, S, T, U1, U2, V1, V2, ZERO
      INTEGER           I, J, K, L, L1, LB, NK1, NM1, NM2
!     .. Intrinsic Functions ..
      INTRINSIC         ABS, SQRT
!     .. Data statements ..
      DATA              ONE/1.0D0/, ZERO/0.0D0/
!     .. Executable Statements ..
      IF ( .NOT. MATZ) GO TO 60
!
      DO 40 I = 1, N
!
         DO 20 J = 1, N
            Z(I,J) = ZERO
   20    CONTINUE
!
         Z(I,I) = ONE
   40 CONTINUE
!     REDUCE B TO UPPER TRIANGULAR FORM
   60 IF (N.LE.1) GO TO 420
      NM1 = N - 1
!
      DO 260 L = 1, NM1
         L1 = L + 1
         S = ZERO
!
         DO 80 I = L1, N
            S = S + ABS(B(I,L))
   80    CONTINUE
!
         IF (S.EQ.ZERO) GO TO 260
         S = S + ABS(B(L,L))
         R = ZERO
!
         DO 100 I = L, N
            B(I,L) = B(I,L)/S
            R = R + B(I,L)**2
  100    CONTINUE
!
         R = SQRT(R)
         IF (B(L,L).LT.ZERO) R = -R
         B(L,L) = B(L,L) + R
         RHO = R*B(L,L)
!
         DO 160 J = L1, N
            T = ZERO
!
            DO 120 I = L, N
               T = T + B(I,L)*B(I,J)
  120       CONTINUE
!
            T = -T/RHO
!
            DO 140 I = L, N
               B(I,J) = B(I,J) + T*B(I,L)
  140       CONTINUE
!
  160    CONTINUE
!
         DO 220 J = 1, N
            T = ZERO
!
            DO 180 I = L, N
               T = T + B(I,L)*A(I,J)
  180       CONTINUE
!
            T = -T/RHO
!
            DO 200 I = L, N
               A(I,J) = A(I,J) + T*B(I,L)
  200       CONTINUE
!
  220    CONTINUE
!
         B(L,L) = -S*R
!
         DO 240 I = L1, N
            B(I,L) = ZERO
  240    CONTINUE
!
  260 CONTINUE
!     REDUCE A TO UPPER HESSENBERG FORM, WHILE
!     KEEPING B TRIANGULAR
      IF (N.EQ.2) GO TO 420
      NM2 = N - 2
!
      DO 400 K = 1, NM2
         NK1 = NM1 - K
!        FOR L=N-1 STEP -1 UNTIL K+1 DO --
         DO 380 LB = 1, NK1
            L = N - LB
            L1 = L + 1
!           ZERO A(L+1,K)
            S = ABS(A(L,K)) + ABS(A(L1,K))
            IF (S.EQ.ZERO) GO TO 380
            U1 = A(L,K)/S
            U2 = A(L1,K)/S
            R = SQRT(U1*U1+U2*U2)
            IF (U1.LT.ZERO) R = -R
            V1 = -(U1+R)/R
            V2 = -U2/R
            U2 = V2/V1
!
            DO 280 J = K, N
               T = A(L,J) + U2*A(L1,J)
               A(L,J) = A(L,J) + T*V1
               A(L1,J) = A(L1,J) + T*V2
  280       CONTINUE
!
            A(L1,K) = ZERO
!
            DO 300 J = L, N
               T = B(L,J) + U2*B(L1,J)
               B(L,J) = B(L,J) + T*V1
               B(L1,J) = B(L1,J) + T*V2
  300       CONTINUE
!           ZERO B(L+1,L)
            S = ABS(B(L1,L1)) + ABS(B(L1,L))
            IF (S.EQ.ZERO) GO TO 380
            U1 = B(L1,L1)/S
            U2 = B(L1,L)/S
            R = SQRT(U1*U1+U2*U2)
            IF (U1.LT.ZERO) R = -R
            V1 = -(U1+R)/R
            V2 = -U2/R
            U2 = V2/V1
!
            DO 320 I = 1, L1
               T = B(I,L1) + U2*B(I,L)
               B(I,L1) = B(I,L1) + T*V1
               B(I,L) = B(I,L) + T*V2
  320       CONTINUE
!
            B(L1,L) = ZERO
!
            DO 340 I = 1, N
               T = A(I,L1) + U2*A(I,L)
               A(I,L1) = A(I,L1) + T*V1
               A(I,L) = A(I,L) + T*V2
  340       CONTINUE
!
            IF ( .NOT. MATZ) GO TO 380
!
            DO 360 I = 1, N
               T = Z(I,L1) + U2*Z(I,L)
               Z(I,L1) = Z(I,L1) + T*V1
               Z(I,L) = Z(I,L) + T*V2
  360       CONTINUE
!
  380    CONTINUE
!
  400 CONTINUE
!
  420 RETURN
      END

      SUBROUTINE F02BJX(N,A,IA,B,IB,EPS1,MATZ,Z,IZ,ITER,IERR)
!     MARK 6 RELEASE  NAG COPYRIGHT 1977
!     MARK 8 REVISED. IER-226 (MAR 1980).
!     MARK 9 REVISED. IER-326 (SEP 1981).
!     MARK 11.5(F77) REVISED. (SEPT 1985.)
!     MARK 12A REVISED. IER-508 (AUG 1986).
!     MARK 13 REVISED. USE OF MARK 12 X02 FUNCTIONS (APR 1988).
!
!     THIS SUBROUTINE IS THE SECOND STEP OF THE QZ ALGORITHM
!     FOR SOLVING GENERALIZED MATRIX EIGENVALUE PROBLEMS,
!     SIAM J. NUMER. ANAL. 10, 241-256(1973) BY MOLER AND STEWART.
!
!     THIS SUBROUTINE ACCEPTS A PAIR OF REAL MATRICES, ONE OF THEM
!     IN UPPER HESSENBERG FORM AND THE OTHER IN UPPER TRIANGULAR
!     FORM.
!     IT REDUCES THE HESSENBERG MATRIX TO QUASI-TRIANGULAR FORM
!     USING
!     ORTHOGONAL TRANSFORMATIONS WHILE MAINTAINING THE TRIANGULAR
!     FORM
!     OF THE OTHER MATRIX.  IT IS USUALLY PRECEDED BY F02BJW AND
!     FOLLOWED BY F02BJY AND, POSSIBLY, F02BJZ.
!
!     ON INPUT
!
!     N IS THE ORDER OF THE MATRICES.
!
!     A CONTAINS A REAL UPPER HESSENBERG MATRIX.
!
!     IA MUST SPECIFY THE FIRST DIMENSION OF ARRAY A AS
!     DECLARED IN THE CALLING (SUB)PROGRAM.  IA.GE.N
!
!     B CONTAINS A REAL UPPER TRIANGULAR MATRIX.
!
!     IB MUST SPECIFY THE FIRST DIMENSION OF ARRAY B AS
!     DECLARED IN THE CALLING (SUB)PROGRAM.  IB.GE.N
!
!     EPS1 IS A TOLERANCE USED TO DETERMINE NEGLIGIBLE ELEMENTS.
!     EPS1 = 0.0 (OR NEGATIVE) MAY BE INPUT, IN WHICH CASE AN
!     ELEMENT WILL BE NEGLECTED ONLY IF IT IS LESS THAN ROUNDOFF
!     ERROR TIMES THE NORM OF ITS MATRIX.  IF THE INPUT EPS1 IS
!     POSITIVE, THEN AN ELEMENT WILL BE CONSIDERED NEGLIGIBLE
!     IF IT IS LESS THAN EPS1 TIMES THE NORM OF ITS MATRIX.  A
!     POSITIVE VALUE OF EPS1 MAY RESULT IN FASTER EXECUTION,
!     BUT LESS ACCURATE RESULTS.
!
!     MATZ SHOULD BE SET TO .TRUE. IF THE RIGHT HAND
!     TRANSFORMATIONS
!     ARE TO BE ACCUMULATED FOR LATER USE IN COMPUTING
!     EIGENVECTORS, AND TO .FALSE. OTHERWISE.
!
!     Z CONTAINS, IF MATZ HAS BEEN SET TO .TRUE., THE
!     TRANSFORMATION MATRIX PRODUCED IN THE REDUCTION
!     BY F02BJW, IF PERFORMED, OR ELSE THE IDENTITY MATRIX.
!     IF MATZ HAS BEEN SET TO .FALSE., Z IS NOT REFERENCED.
!
!     IZ MUST SPECIFY THE FIRST DIMENSION OF ARRAY Z AS
!     DECLARED IN THE CALLING (SUB)PROGRAM.  IZ.GE.N
!
!     ON OUTPUT
!
!     A HAS BEEN REDUCED TO QUASI-TRIANGULAR FORM.  THE ELEMENTS
!     BELOW THE FIRST SUBDIAGONAL ARE STILL ZERO AND NO TWO
!     CONSECUTIVE SUBDIAGONAL ELEMENTS ARE NONZERO.
!
!     B IS STILL IN UPPER TRIANGULAR FORM, ALTHOUGH ITS ELEMENTS
!     HAVE BEEN ALTERED.  THE LOCATION B(N,1) IS USED TO STORE
!     EPS1 TIMES THE NORM OF B FOR LATER USE BY F02BJY AND F02BJZ.
!
!     Z CONTAINS THE PRODUCT OF THE RIGHT HAND TRANSFORMATIONS
!     (FOR BOTH STEPS) IF MATZ HAS BEEN SET TO .TRUE..
!
!     IERR IS SET TO
!     ZERO       FOR NORMAL RETURN,
!     J          IF MORE THAN 30*N ITERATIONS HAVE BEEN
!                PERFORMED ALTOGETHER.
!
!     IMPLEMENTED FROM EISPACK BY
!     W. PHILLIPS OXFORD UNIVERSITY COMPUTING SERVICE.
!
!     .. Parameters ..
      CHARACTER*6       SRNAME
      PARAMETER         (SRNAME='F02BJX')
!     .. Scalar Arguments ..
      DOUBLE PRECISION  EPS1
      INTEGER           IA, IB, IERR, IZ, N
      LOGICAL           MATZ
!     .. Array Arguments ..
      DOUBLE PRECISION  A(IA,N), B(IB,N), Z(IZ,N)
      INTEGER           ITER(N)
!     .. Local Scalars ..
      DOUBLE PRECISION  A1, A11, A12, A2, A21, A22, A3, A33, A34, A43,&
     &                  A44, ANI, ANORM, B11, B12, B22, B33, B34, B44,&
     &                  BIT, BNI, BNORM, EP, EPSA, EPSB, HALF, ONE, R,&
     &                  S, SH, T, TWO, U1, U2, U3, V1, V2, V3, XXXX,&
     &                  ZERO
      INTEGER           EN, ENM2, ENORN, I, ISAVE, ISH, ITSTOT, J, K,&
     &                  K1, K2, KM1, L, L1, LD, LL, LM1, LOR1, NA
      LOGICAL           NOTLAS
!     .. Local Arrays ..
      CHARACTER*1       P01REC(1)
!     .. External Functions ..
      DOUBLE PRECISION  X02AJF
      INTEGER           P01ABF
      EXTERNAL          X02AJF, P01ABF
!     .. Intrinsic Functions ..
      INTRINSIC         ABS, MAX, MIN, SQRT
!     .. Data statements ..
      DATA              ZERO/0.0D0/, ONE/1.0D0/, TWO/2.0D0/,&
     &                  BIT/1.1605D0/, HALF/0.5D0/
!     .. Executable Statements ..
      ISAVE = IERR
      IERR = 0
!     COMPUTE EPSA,EPSB
      ANORM = ZERO
      BNORM = ZERO
      ITSTOT = 30*N
!
      DO 40 I = 1, N
         ITER(I) = 0
         ANI = ZERO
         IF (I.NE.1) ANI = ABS(A(I,I-1))
         BNI = ZERO
!
         DO 20 J = I, N
            ANI = ANI + ABS(A(I,J))
            BNI = BNI + ABS(B(I,J))
   20    CONTINUE
!
         IF (ANI.GT.ANORM) ANORM = ANI
         IF (BNI.GT.BNORM) BNORM = BNI
   40 CONTINUE
!
      IF (ANORM.EQ.ZERO) ANORM = ONE
      IF (BNORM.EQ.ZERO) BNORM = ONE
      EP = EPS1
      IF (EP.LE.ZERO) EP = X02AJF()
      EPSA = EP*ANORM
      EPSB = EP*BNORM
!     REDUCE A TO QUASI-TRIANGULAR FORM, WHILE
!     KEEPING B TRIANGULAR
      LOR1 = 1
      ENORN = N
      EN = N
!     BEGIN QZ STEP
   60 IF (EN.LE.2) GO TO 580
      IF ( .NOT. MATZ) ENORN = EN
      NA = EN - 1
      ENM2 = NA - 1
   80 ISH = 2
!     CHECK FOR CONVERGENCE OR REDUCIBILITY.
!     FOR L=EN STEP -1 UNTIL 1 DO --
      DO 100 LL = 1, EN
         LM1 = EN - LL
         L = LM1 + 1
         IF (L.EQ.1) GO TO 140
         IF (ABS(A(L,LM1)).LE.EPSA) GO TO 120
  100 CONTINUE
!
  120 A(L,LM1) = ZERO
      IF (L.LT.NA) GO TO 140
!     1-BY-1 OR 2-BY-2 BLOCK ISOLATED
      EN = LM1
      GO TO 60
!     CHECK FOR SMALL TOP OF B
  140 LD = L
  160 L1 = L + 1
      B11 = B(L,L)
      IF (ABS(B11).GT.EPSB) GO TO 200
      B(L,L) = ZERO
      S = ABS(A(L,L)) + ABS(A(L1,L))
      U1 = A(L,L)/S
      U2 = A(L1,L)/S
      R = SQRT(U1*U1+U2*U2)
      IF (U1.LT.ZERO) R = -R
      V1 = -(U1+R)/R
      V2 = -U2/R
      U2 = V2/V1
!
      DO 180 J = L, ENORN
         T = A(L,J) + U2*A(L1,J)
         A(L,J) = A(L,J) + T*V1
         A(L1,J) = A(L1,J) + T*V2
         T = B(L,J) + U2*B(L1,J)
         B(L,J) = B(L,J) + T*V1
         B(L1,J) = B(L1,J) + T*V2
  180 CONTINUE
!
      IF (L.NE.1) A(L,LM1) = -A(L,LM1)
      LM1 = L
      L = L1
      GO TO 120
  200 A11 = A(L,L)/B11
      A21 = A(L1,L)/B11
      IF (ISH.EQ.1) GO TO 240
!     ITERATION STRATEGY
      IF (ITSTOT.LE.0) GO TO 560
      IF (ITER(EN).EQ.10) GO TO 280
!     DETERMINE TYPE OF SHIFT
      B22 = B(L1,L1)
      IF (ABS(B22).LT.EPSB) B22 = EPSB
      B33 = B(NA,NA)
      IF (ABS(B33).LT.EPSB) B33 = EPSB
      B44 = B(EN,EN)
      IF (ABS(B44).LT.EPSB) B44 = EPSB
      A33 = A(NA,NA)
      A34 = A(NA,EN)
      A43 = A(EN,NA)
      A44 = A(EN,EN)
      B34 = B(NA,EN)
      T = HALF*(A43*B34-A33*B44-A44*B33)
      R = T*T + (A34*A43-A33*A44)*B33*B44
      IF (R.LT.ZERO) GO TO 260
!     DETERMINE SINGLE SHIFT ZEROTH COLUMN OF A
      ISH = 1
      R = SQRT(R)
      SH = -T + R
      S = -T - R
      IF (ABS(S-A44*B33).LT.ABS(SH-A44*B44)) SH = S
      SH = (SH/B33)/B44
!     LOOK FOR TWO CONSECUTIVE SMALL
!     SUB-DIAGONAL ELEMENTS OF A.
!     FOR L=EN-2 STEP -1 UNTIL LD DO --
      DO 220 LL = LD, ENM2
         L = ENM2 + LD - LL
         IF (L.EQ.LD) GO TO 240
         LM1 = L - 1
         L1 = L + 1
         T = A(L,L)
         IF (ABS(B(L,L)).GT.EPSB) T = T - SH*B(L,L)
         IF (ABS(A(L,LM1)).LE.ABS(T/A(L1,L))*EPSA) GO TO 160
  220 CONTINUE
!
  240 A1 = A11 - SH
      A2 = A21
      IF (L.NE.LD) A(L,LM1) = -A(L,LM1)
      GO TO 300
!     DETERMINE DOUBLE SHIFT ZEROTH COLUMN OF A
  260 A12 = A(L,L1)/B22
      A22 = A(L1,L1)/B22
      B12 = B(L,L1)/B22
      A33 = A33/B33
      A34 = A34/B44
      A43 = A43/B33
      A44 = A44/B44
      B34 = B34/B44
      A1 = ((A33-A11)*(A44-A11)-A34*A43+A43*B34*A11)/A21 + A12 - A11*B12
      A2 = (A22-A11) - A21*B12 - (A33-A11) - (A44-A11) + A43*B34
      A3 = A(L1+1,L1)/B22
      GO TO 300
!     AD HOC SHIFT
  280 A1 = ZERO
      A2 = ONE
      A3 = BIT
  300 ITER(EN) = ITER(EN) + 1
      ITSTOT = ITSTOT - 1
      IF ( .NOT. MATZ) LOR1 = LD
!     MAIN LOOP
      DO 540 K = L, NA
         NOTLAS = K .NE. NA .AND. ISH .EQ. 2
         K1 = K + 1
         K2 = K + 2
         KM1 = MAX(K-1,L)
         LL = MIN(EN,K1+ISH)
         IF (NOTLAS) GO TO 360
!        ZERO A(K+1,K-1)
         IF (K.EQ.L) GO TO 320
         A1 = A(K,KM1)
         A2 = A(K1,KM1)
  320    S = ABS(A1) + ABS(A2)
         IF (S.EQ.ZERO) GO TO 80
         U1 = A1/S
         U2 = A2/S
         R = SQRT(U1*U1+U2*U2)
         IF (U1.LT.ZERO) R = -R
         V1 = -(U1+R)/R
         V2 = -U2/R
         U2 = V2/V1
!
         DO 340 J = KM1, ENORN
            T = A(K,J) + U2*A(K1,J)
            A(K,J) = A(K,J) + T*V1
            A(K1,J) = A(K1,J) + T*V2
            T = B(K,J) + U2*B(K1,J)
            B(K,J) = B(K,J) + T*V1
            B(K1,J) = B(K1,J) + T*V2
  340    CONTINUE
!
         IF (K.NE.L) A(K1,KM1) = ZERO
         GO TO 480
!        ZERO A(K+1,K-1) AND A(K+2,K-1)
  360    IF (K.EQ.L) GO TO 380
         A1 = A(K,KM1)
         A2 = A(K1,KM1)
         A3 = A(K2,KM1)
  380    S = ABS(A1) + ABS(A2) + ABS(A3)
         IF (S.EQ.ZERO) GO TO 540
         U1 = A1/S
         U2 = A2/S
         U3 = A3/S
         R = SQRT(U1*U1+U2*U2+U3*U3)
         IF (U1.LT.ZERO) R = -R
         V1 = -(U1+R)/R
         V2 = -U2/R
         V3 = -U3/R
         U2 = V2/V1
         U3 = V3/V1
!
         DO 400 J = KM1, ENORN
            T = A(K,J) + U2*A(K1,J) + U3*A(K2,J)
            A(K,J) = A(K,J) + T*V1
            A(K1,J) = A(K1,J) + T*V2
            A(K2,J) = A(K2,J) + T*V3
            T = B(K,J) + U2*B(K1,J) + U3*B(K2,J)
            B(K,J) = B(K,J) + T*V1
            B(K1,J) = B(K1,J) + T*V2
            B(K2,J) = B(K2,J) + T*V3
  400    CONTINUE
!
         IF (K.EQ.L) GO TO 420
         A(K1,KM1) = ZERO
         A(K2,KM1) = ZERO
!        ZERO B(K+2,K+1) AND B(K+2,K)
  420    S = ABS(B(K2,K2)) + ABS(B(K2,K1)) + ABS(B(K2,K))
         IF (S.EQ.ZERO) GO TO 480
         U1 = B(K2,K2)/S
         U2 = B(K2,K1)/S
         U3 = B(K2,K)/S
         R = SQRT(U1*U1+U2*U2+U3*U3)
         IF (U1.LT.ZERO) R = -R
         V1 = -(U1+R)/R
         V2 = -U2/R
         V3 = -U3/R
         U2 = V2/V1
         U3 = V3/V1
!
         DO 440 I = LOR1, LL
            T = A(I,K2) + U2*A(I,K1) + U3*A(I,K)
            A(I,K2) = A(I,K2) + T*V1
            A(I,K1) = A(I,K1) + T*V2
            A(I,K) = A(I,K) + T*V3
            T = B(I,K2) + U2*B(I,K1) + U3*B(I,K)
            B(I,K2) = B(I,K2) + T*V1
            B(I,K1) = B(I,K1) + T*V2
            B(I,K) = B(I,K) + T*V3
  440    CONTINUE
!
         B(K2,K) = ZERO
         B(K2,K1) = ZERO
         IF ( .NOT. MATZ) GO TO 480
!
         DO 460 I = 1, N
            T = Z(I,K2) + U2*Z(I,K1) + U3*Z(I,K)
            Z(I,K2) = Z(I,K2) + T*V1
            Z(I,K1) = Z(I,K1) + T*V2
            Z(I,K) = Z(I,K) + T*V3
  460    CONTINUE
!        ZERO B(K+1,K)
  480    S = ABS(B(K1,K1)) + ABS(B(K1,K))
         IF (S.EQ.ZERO) GO TO 540
         U1 = B(K1,K1)/S
         U2 = B(K1,K)/S
         R = SQRT(U1*U1+U2*U2)
         IF (U1.LT.ZERO) R = -R
         V1 = -(U1+R)/R
         V2 = -U2/R
         U2 = V2/V1
!
         DO 500 I = LOR1, LL
            T = A(I,K1) + U2*A(I,K)
            A(I,K1) = A(I,K1) + T*V1
            A(I,K) = A(I,K) + T*V2
            T = B(I,K1) + U2*B(I,K)
            B(I,K1) = B(I,K1) + T*V1
            B(I,K) = B(I,K) + T*V2
  500    CONTINUE
!
         B(K1,K) = ZERO
         IF ( .NOT. MATZ) GO TO 540
!
         DO 520 I = 1, N
            T = Z(I,K1) + U2*Z(I,K)
            Z(I,K1) = Z(I,K1) + T*V1
            Z(I,K) = Z(I,K) + T*V2
  520    CONTINUE
!
  540 CONTINUE
!     END QZ STEP
      GO TO 80
!     SET ERROR -- NEITHER BOTTOM SUBDIAGONAL ELEMENT
!     HAS BECOME NEGLIGIBLE AFTER 30*N ITERATIONS ALTOGETHER
  560 IERR = P01ABF(ISAVE,EN,SRNAME,0,P01REC)
!     SAVE EPSB FOR USE BY F02BJY AND F02BJZ
  580 IF (N.GT.1) B(N,1) = EPSB
      RETURN
      END

      SUBROUTINE F02BJY(N,A,IA,B,IB,ALFR,ALFI,BETA,MATZ,Z,IZ)
!     MARK 6 RELEASE  NAG COPYRIGHT 1977
!     MARK 8 REVISED. IER-232 (MAR 1980).
!     MARK 11.5(F77) REVISED. (SEPT 1985.)
!
!     THIS SUBROUTINE IS THE THIRD STEP OF THE QZ ALGORITHM
!     FOR SOLVING GENERALIZED MATRIX EIGENVALUE PROBLEMS,
!     SIAM J. NUMER. ANAL. 10, 241-256(1973) BY MOLER AND STEWART.
!
!     THIS SUBROUTINE ACCEPTS A PAIR OF REAL MATRICES, ONE OF THEM
!     IN QUASI-TRIANGULAR FORM AND THE OTHER IN UPPER TRIANGULAR
!     FORM.
!     IT REDUCES THE QUASI-TRIANGULAR MATRIX FURTHER, SO THAT ANY
!     REMAINING 2-BY-2 BLOCKS CORRESPOND TO PAIRS OF COMPLEX
!     EIGENVALUES, AND RETURNS QUANTITIES WHOSE RATIOS GIVE THE
!     GENERALIZED EIGENVALUES.  IT IS USUALLY PRECEDED BY F02BJW
!     AND F02BJX AND MAY BE FOLLOWED BY F02BJZ.
!
!     ON INPUT
!
!     N IS THE ORDER OF THE MATRICES.
!
!     A CONTAINS A REAL UPPER QUASI-TRIANGULAR MATRIX.
!
!     IA MUST SPECIFY THE FIRST DIMENSION OF THE ARRAY A AS
!     DECLARED IN THE CALLING (SUB)PROGRAM.  IA.GE.N
!
!     B CONTAINS A REAL UPPER TRIANGULAR MATRIX.  IN ADDITION,
!     LOCATION B(N,1) CONTAINS THE TOLERANCE QUANTITY (EPSB)
!     COMPUTED AND SAVED IN F02BJX.
!
!     IB MUST SPECIFY THE FIRST DIMENSION OF THE ARRAY B AS
!     DECLARED IN THE CALLING (SUB)PROGRAM.  IB.GE.N
!
!     MATZ SHOULD BE SET TO .TRUE. IF THE RIGHT HAND
!     TRANSFORMATIONS
!     ARE TO BE ACCUMULATED FOR LATER USE IN COMPUTING
!     EIGENVECTORS, AND TO .FALSE. OTHERWISE.
!
!     Z CONTAINS, IF MATZ HAS BEEN SET TO .TRUE., THE
!     TRANSFORMATION MATRIX PRODUCED IN THE REDUCTIONS BY F02BJW
!     AND F02BJX, IF PERFORMED, OR ELSE THE IDENTITY MATRIX.
!     IF MATZ HAS BEEN SET TO .FALSE., Z IS NOT REFERENCED.
!
!     IZ MUST SPECIFY THE FIRST DIMENSION OF THE ARRAY Z AS
!     DECLARED IN THE CALLING (SUB)PROGRAM.  IZ.GE.N
!
!     ON OUTPUT
!
!     A HAS BEEN REDUCED FURTHER TO A QUASI-TRIANGULAR MATRIX
!     IN WHICH ALL NONZERO SUBDIAGONAL ELEMENTS CORRESPOND TO
!     PAIRS OF COMPLEX EIGENVALUES.
!
!     B IS STILL IN UPPER TRIANGULAR FORM, ALTHOUGH ITS ELEMENTS
!     HAVE BEEN ALTERED.  B(N,1) IS UNALTERED.
!
!     ALFR AND ALFI CONTAIN THE REAL AND IMAGINARY PARTS OF THE
!     DIAGONAL ELEMENTS OF THE TRIANGULAR MATRIX THAT WOULD BE
!     OBTAINED IF A WERE REDUCED COMPLETELY TO TRIANGULAR FORM
!     BY UNITARY TRANSFORMATIONS.  NON-ZERO VALUES OF ALFI OCCUR
!     IN PAIRS, THE FIRST MEMBER POSITIVE AND THE SECOND NEGATIVE.
!
!     BETA CONTAINS THE DIAGONAL ELEMENTS OF THE CORRESPONDING B,
!     NORMALIZED TO BE REAL AND NON-NEGATIVE.  THE GENERALIZED
!     EIGENVALUES ARE THEN THE RATIOS ((ALFR+I*ALFI)/BETA).
!
!     Z CONTAINS THE PRODUCT OF THE RIGHT HAND TRANSFORMATIONS
!     (FOR ALL THREE STEPS) IF MATZ HAS BEEN SET TO .TRUE.
!
!     IMPLEMENTED FROM EISPACK BY
!     W. PHILLIPS OXFORD UNIVERSITY COMPUTING SERVICE.
!
!     .. Scalar Arguments ..
      INTEGER           IA, IB, IZ, N
      LOGICAL           MATZ
!     .. Array Arguments ..
      DOUBLE PRECISION  A(IA,N), ALFI(N), ALFR(N), B(IB,N), BETA(N),&
     &                  Z(IZ,N)
!     .. Local Scalars ..
      DOUBLE PRECISION  A1, A11, A11I, A11R, A12, A12I, A12R, A1I, A2,&
     &                  A21, A22, A22I, A22R, A2I, AN, B11, B12, B22,&
     &                  BN, C, CQ, CZ, D, DI, DR, E, EI, EPSB, HALF,&
     &                  ONE, R, S, SQI, SQR, SSI, SSR, SZI, SZR, T, TI,&
     &                  TR, U1, U2, V1, V2, ZERO
      INTEGER           EN, I, ISW, J, NA, NN
!     .. Intrinsic Functions ..
      INTRINSIC         ABS, SQRT
!     .. Data statements ..
      DATA              ZERO/0.0D0/, HALF/0.5D0/, ONE/1.0D0/
!     .. Executable Statements ..
      EPSB = B(N,1)
      ISW = 1
!     FIND EIGENVALUES OF QUASI-TRIANGULAR MATRICES.
!     FOR EN=N STEP -1 UNTIL 1 DO --
      DO 520 NN = 1, N
         EN = N + 1 - NN
         NA = EN - 1
         IF (ISW.EQ.2) GO TO 500
         IF (EN.EQ.1) GO TO 20
         IF (A(EN,NA).NE.ZERO) GO TO 40
!        1-BY-1 BLOCK, ONE REAL ROOT
   20    ALFR(EN) = A(EN,EN)
         IF (B(EN,EN).LT.ZERO) ALFR(EN) = -ALFR(EN)
         BETA(EN) = ABS(B(EN,EN))
         ALFI(EN) = ZERO
         GO TO 520
!        2-BY-2 BLOCK
   40    IF (ABS(B(NA,NA)).LE.EPSB) GO TO 200
         IF (ABS(B(EN,EN)).GT.EPSB) GO TO 60
         A1 = A(EN,EN)
         A2 = A(EN,NA)
         BN = ZERO
         GO TO 120
   60    AN = ABS(A(NA,NA)) + ABS(A(NA,EN)) + ABS(A(EN,NA)) +&
     &        ABS(A(EN,EN))
         BN = ABS(B(NA,NA)) + ABS(B(NA,EN)) + ABS(B(EN,EN))
         A11 = A(NA,NA)/AN
         A12 = A(NA,EN)/AN
         A21 = A(EN,NA)/AN
         A22 = A(EN,EN)/AN
         B11 = B(NA,NA)/BN
         B12 = B(NA,EN)/BN
         B22 = B(EN,EN)/BN
         E = A11/B11
         EI = A22/B22
         S = A21/(B11*B22)
         T = (A22-E*B22)/B22
         IF (ABS(E).LE.ABS(EI)) GO TO 80
         E = EI
         T = (A11-E*B11)/B11
   80    C = HALF*(T-S*B12)
         D = C*C + S*(A12-E*B12)
         IF (D.LT.ZERO) GO TO 280
!        TWO REAL ROOTS.
!        ZERO BOTH A(EN,NA) AND B(EN,NA)
         E = E + C + SQRT(D)
         IF (C.LT.ZERO) E = E - 2.0D0*SQRT(D)
         A11 = A11 - E*B11
         A12 = A12 - E*B12
         A22 = A22 - E*B22
         IF (ABS(A11)+ABS(A12).LT.ABS(A21)+ABS(A22)) GO TO 100
         A1 = A12
         A2 = A11
         GO TO 120
  100    A1 = A22
         A2 = A21
!        CHOOSE AND APPLY REAL Z
  120    S = ABS(A1) + ABS(A2)
         U1 = A1/S
         U2 = A2/S
         R = SQRT(U1*U1+U2*U2)
         IF (U1.LT.ZERO) R = -R
         V1 = -(U1+R)/R
         V2 = -U2/R
         U2 = V2/V1
!
         DO 140 I = 1, EN
            T = A(I,EN) + U2*A(I,NA)
            A(I,EN) = A(I,EN) + T*V1
            A(I,NA) = A(I,NA) + T*V2
            T = B(I,EN) + U2*B(I,NA)
            B(I,EN) = B(I,EN) + T*V1
            B(I,NA) = B(I,NA) + T*V2
  140    CONTINUE
!
         IF ( .NOT. MATZ) GO TO 180
!
         DO 160 I = 1, N
            T = Z(I,EN) + U2*Z(I,NA)
            Z(I,EN) = Z(I,EN) + T*V1
            Z(I,NA) = Z(I,NA) + T*V2
  160    CONTINUE
!
  180    IF (BN.EQ.ZERO) GO TO 260
         IF (AN.LT.ABS(E)*BN) GO TO 200
         A1 = B(NA,NA)
         A2 = B(EN,NA)
         GO TO 220
  200    A1 = A(NA,NA)
         A2 = A(EN,NA)
!        CHOOSE AND APPLY REAL Q
  220    S = ABS(A1) + ABS(A2)
         IF (S.EQ.ZERO) GO TO 260
         U1 = A1/S
         U2 = A2/S
         R = SQRT(U1*U1+U2*U2)
         IF (U1.LT.ZERO) R = -R
         V1 = -(U1+R)/R
         V2 = -U2/R
         U2 = V2/V1
!
         DO 240 J = NA, N
            T = A(NA,J) + U2*A(EN,J)
            A(NA,J) = A(NA,J) + T*V1
            A(EN,J) = A(EN,J) + T*V2
            T = B(NA,J) + U2*B(EN,J)
            B(NA,J) = B(NA,J) + T*V1
            B(EN,J) = B(EN,J) + T*V2
  240    CONTINUE
!
  260    A(EN,NA) = ZERO
         B(EN,NA) = ZERO
         ALFR(NA) = A(NA,NA)
         ALFR(EN) = A(EN,EN)
         IF (B(NA,NA).LT.ZERO) ALFR(NA) = -ALFR(NA)
         IF (B(EN,EN).LT.ZERO) ALFR(EN) = -ALFR(EN)
         BETA(NA) = ABS(B(NA,NA))
         BETA(EN) = ABS(B(EN,EN))
         ALFI(EN) = ZERO
         ALFI(NA) = ZERO
         GO TO 500
!        TWO COMPLEX ROOTS
  280    E = E + C
         EI = SQRT(-D)
         A11R = A11 - E*B11
         A11I = EI*B11
         A12R = A12 - E*B12
         A12I = EI*B12
         A22R = A22 - E*B22
         A22I = EI*B22
         IF (ABS(A11R)+ABS(A11I)+ABS(A12R)+ABS(A12I).LT.ABS(A21)&
     &       +ABS(A22R)+ABS(A22I)) GO TO 300
         A1 = A12R
         A1I = A12I
         A2 = -A11R
         A2I = -A11I
         GO TO 320
  300    A1 = A22R
         A1I = A22I
         A2 = -A21
         A2I = ZERO
!        CHOOSE COMPLEX Z
  320    CZ = SQRT(A1*A1+A1I*A1I)
         IF (CZ.EQ.ZERO) GO TO 340
         SZR = (A1*A2+A1I*A2I)/CZ
         SZI = (A1*A2I-A1I*A2)/CZ
         R = SQRT(CZ*CZ+SZR*SZR+SZI*SZI)
         CZ = CZ/R
         SZR = SZR/R
         SZI = SZI/R
         GO TO 360
  340    SZR = ONE
         SZI = ZERO
  360    IF (AN.LT.(ABS(E)+EI)*BN) GO TO 380
         A1 = CZ*B11 + SZR*B12
         A1I = SZI*B12
         A2 = SZR*B22
         A2I = SZI*B22
         GO TO 400
  380    A1 = CZ*A11 + SZR*A12
         A1I = SZI*A12
         A2 = CZ*A21 + SZR*A22
         A2I = SZI*A22
!        CHOOSE COMPLEX Q
  400    CQ = SQRT(A1*A1+A1I*A1I)
         IF (CQ.EQ.ZERO) GO TO 420
         SQR = (A1*A2+A1I*A2I)/CQ
         SQI = (A1*A2I-A1I*A2)/CQ
         R = SQRT(CQ*CQ+SQR*SQR+SQI*SQI)
         CQ = CQ/R
         SQR = SQR/R
         SQI = SQI/R
         GO TO 440
  420    SQR = ONE
         SQI = ZERO
!        COMPUTE DIAGONAL ELEMENTS THAT WOULD RESULT
!        IF TRANSFORMATIONS WERE APPLIED
  440    SSR = SQR*SZR + SQI*SZI
         SSI = SQR*SZI - SQI*SZR
         I = 1
         TR = CQ*CZ*A11 + CQ*SZR*A12 + SQR*CZ*A21 + SSR*A22
         TI = CQ*SZI*A12 - SQI*CZ*A21 + SSI*A22
         DR = CQ*CZ*B11 + CQ*SZR*B12 + SSR*B22
         DI = CQ*SZI*B12 + SSI*B22
         GO TO 480
  460    I = 2
         TR = SSR*A11 - SQR*CZ*A12 - CQ*SZR*A21 + CQ*CZ*A22
         TI = -SSI*A11 - SQI*CZ*A12 + CQ*SZI*A21
         DR = SSR*B11 - SQR*CZ*B12 + CQ*CZ*B22
         DI = -SSI*B11 - SQI*CZ*B12
  480    T = TI*DR - TR*DI
         J = NA
         IF (T.LT.ZERO) J = EN
         R = SQRT(DR*DR+DI*DI)
         BETA(J) = BN*R
         ALFR(J) = AN*(TR*DR+TI*DI)/R
         ALFI(J) = AN*T/R
         IF (I.EQ.1) GO TO 460
  500    ISW = 3 - ISW
  520 CONTINUE
!
      RETURN
      END

      SUBROUTINE F02BJZ(N,A,IA,B,IB,ALFR,ALFI,BETA,Z,IZ)
!     MARK 6 RELEASE  NAG COPYRIGHT 1977
!     MARK 9A REVISED. IER-359 (NOV 1981)
!     MARK 11.5(F77) REVISED. (SEPT 1985.)
!
!     THIS SUBROUTINE IS THE OPTIONAL FOURTH STEP OF THE QZ
!     ALGORITHM
!     FOR SOLVING GENERALIZED MATRIX EIGENVALUE PROBLEMS,
!     SIAM J. NUMER. ANAL. 10, 241-256(1973) BY MOLER AND STEWART.
!
!     THIS SUBROUTINE ACCEPTS A PAIR OF REAL MATRICES, ONE OF THEM
!     IN
!     QUASI-TRIANGULAR FORM (IN WHICH EACH 2-BY-2 BLOCK CORRESPONDS
!     TO
!     A PAIR OF COMPLEX EIGENVALUES) AND THE OTHER IN UPPER
!     TRIANGULAR
!     FORM.  IT COMPUTES THE EIGENVECTORS OF THE TRIANGULAR PROBLEM
!     AND
!     TRANSFORMS THE RESULTS BACK TO THE ORIGINAL COORDINATE
!     SYSTEM.
!     IT IS USUALLY PRECEDED BY F02BJW, F02BJX AND F02BJY.
!
!     ON INPUT
!
!     N IS THE ORDER OF THE MATRICES.
!
!     A CONTAINS A REAL UPPER QUASI-TRIANGULAR MATRIX.
!
!     IA MUST SPECIFY THE FIRST DIMENSION OF THE ARRAY A AS
!     DECLARED IN THE CALLING (SUB)PROGRAM.  IA.GE.N
!
!     B CONTAINS A REAL UPPER TRIANGULAR MATRIX.  IN ADDITION,
!     LOCATION B(N,1) CONTAINS THE TOLERANCE QUANTITY (EPSB)
!     COMPUTED AND SAVED IN F02BJX.
!
!     IB MUST SPECIFY THE FIRST DIMENSION OF THE ARRAY B AS
!     DECLARED IN THE CALLING (SUB)PROGRAM.  IB.GE.N
!
!     ALFR, ALFI, AND BETA  ARE VECTORS WITH COMPONENTS WHOSE
!     RATIOS ((ALFR+I*ALFI)/BETA) ARE THE GENERALIZED
!     EIGENVALUES.  THEY ARE USUALLY OBTAINED FROM F02BJY.
!
!     Z CONTAINS THE TRANSFORMATION MATRIX PRODUCED IN THE
!     REDUCTIONS BY F02BJW, F02BJX AND F02BJY, IF PERFORMED.
!     IF THE EIGENVECTORS OF THE TRIANGULAR PROBLEM ARE
!     DESIRED, Z MUST CONTAIN THE IDENTITY MATRIX.
!
!     IZ MUST SPECIFY THE FIRST DIMENSION OF THE ARRAY Z AS
!     DECLARED IN THE CALLING (SUB)PROGRAM.  IZ.GE.N
!
!     ON OUTPUT
!
!     A IS UNALTERED.  ITS SUBDIAGONAL ELEMENTS PROVIDE INFORMATION
!     ABOUT THE STORAGE OF THE COMPLEX EIGENVECTORS.
!
!     B HAS BEEN DESTROYED.
!
!     ALFR, ALFI, AND BETA ARE UNALTERED.
!
!     Z CONTAINS THE REAL AND IMAGINARY PARTS OF THE EIGENVECTORS.
!     IF ALFI(I) .EQ. 0.0, THE I-TH EIGENVALUE IS REAL AND
!     THE I-TH COLUMN OF Z CONTAINS ITS EIGENVECTOR.
!     IF ALFI(I) .NE. 0.0, THE I-TH EIGENVALUE IS COMPLEX.
!     IF ALFI(I) .GT. 0.0, THE EIGENVALUE IS THE FIRST OF
!     A COMPLEX PAIR AND THE I-TH AND (I+1)-TH COLUMNS
!     OF Z CONTAIN ITS EIGENVECTOR.
!     IF ALFI(I) .LT. 0.0, THE EIGENVALUE IS THE SECOND OF
!     A COMPLEX PAIR AND THE (I-1)-TH AND I-TH COLUMNS
!     OF Z CONTAIN THE CONJUGATE OF ITS EIGENVECTOR.
!     EACH EIGENVECTOR IS NORMALIZED SO THAT THE COMPONENT WITH
!     LARGEST MODULUS IS REAL AND THE SUM OF SQUARES OF THE
!     MODULI OF THE COMPONENTS IS EQUAL TO 1.0
!
!     IMPLEMENTED FROM EISPACK BY
!     W. PHILLIPS OXFORD UNIVERSITY COMPUTING SERVICE.
!
!     .. Scalar Arguments ..
      INTEGER           IA, IB, IZ, N
!     .. Array Arguments ..
      DOUBLE PRECISION  A(IA,N), ALFI(N), ALFR(N), B(IB,N), BETA(N),&
     &                  Z(IZ,N)
!     .. Local Scalars ..
      DOUBLE PRECISION  ALFM, ALMI, ALMR, BETM, D, DI, DR, EPSB, ONE, Q,&
     &                  R, RA, RR, S, SA, T, T1, T2, TI, TR, W, W1, X,&
     &                  X1, Y, Z1, ZERO, ZZ
      INTEGER           EN, ENM2, I, II, ISW, J, JJ, K, M, NA, NN
!     .. External Functions ..
      DOUBLE PRECISION  A02ABF, F04JGW
      EXTERNAL          A02ABF, F04JGW
!     .. Intrinsic Functions ..
      INTRINSIC         ABS
!     .. Data statements ..
      DATA              ZERO/0.0D0/, ONE/1.0D0/
!     .. Executable Statements ..
      EPSB = B(N,1)
      ISW = 1
!     FOR EN=N STEP -1 UNTIL 1 DO --
      DO 380 NN = 1, N
         EN = N + 1 - NN
         NA = EN - 1
         IF (ISW.EQ.2) GO TO 360
         IF (ALFI(EN).NE.ZERO) GO TO 140
!        REAL VECTOR
         M = EN
         B(EN,EN) = ONE
         IF (NA.EQ.0) GO TO 380
         ALFM = ALFR(M)
         BETM = BETA(M)
!        FOR I=EN-1 STEP -1 UNTIL 1 DO --
         DO 120 II = 1, NA
            I = EN - II
            W = BETM*A(I,I) - ALFM*B(I,I)
            R = ZERO
!
            DO 20 J = M, EN
               R = R + (BETM*A(I,J)-ALFM*B(I,J))*B(J,EN)
   20       CONTINUE
!
            IF (I.EQ.1 .OR. ISW.EQ.2) GO TO 40
            IF (BETM*A(I,I-1).EQ.ZERO) GO TO 40
            ZZ = W
            S = R
            GO TO 100
   40       M = I
            IF (ISW.EQ.2) GO TO 60
!           REAL 1-BY-1 BLOCK
            T = W
            IF (W.EQ.ZERO) T = EPSB
            B(I,EN) = -R/T
            GO TO 120
!           REAL 2-BY-2 BLOCK
   60       X = BETM*A(I,I+1) - ALFM*B(I,I+1)
            Y = BETM*A(I+1,I)
            Q = W*ZZ - X*Y
            T = (X*S-ZZ*R)/Q
            B(I,EN) = T
            IF (ABS(X).LE.ABS(ZZ)) GO TO 80
            B(I+1,EN) = (-R-W*T)/X
            GO TO 100
   80       B(I+1,EN) = (-S-Y*T)/ZZ
  100       ISW = 3 - ISW
  120    CONTINUE
!        END REAL VECTOR
         GO TO 380
!        COMPLEX VECTOR
  140    M = NA
         ALMR = ALFR(M)
         ALMI = ALFI(M)
         BETM = BETA(M)
!        LAST VECTOR COMPONENT CHOSEN IMAGINARY SO THAT
!        EIGENVECTOR MATRIX IS TRIANGULAR
         Y = BETM*A(EN,NA)
         B(NA,NA) = -ALMI*B(EN,EN)/Y
         B(NA,EN) = (ALMR*B(EN,EN)-BETM*A(EN,EN))/Y
         B(EN,NA) = ZERO
         B(EN,EN) = ONE
         ENM2 = NA - 1
         IF (ENM2.EQ.0) GO TO 360
!        FOR I=EN-2 STEP -1 UNTIL 1 DO --
         DO 340 II = 1, ENM2
            I = NA - II
            W = BETM*A(I,I) - ALMR*B(I,I)
            W1 = -ALMI*B(I,I)
            RA = ZERO
            SA = ZERO
!
            DO 160 J = M, EN
               X = BETM*A(I,J) - ALMR*B(I,J)
               X1 = -ALMI*B(I,J)
               RA = RA + X*B(J,NA) - X1*B(J,EN)
               SA = SA + X*B(J,EN) + X1*B(J,NA)
  160       CONTINUE
!
            IF (I.EQ.1 .OR. ISW.EQ.2) GO TO 180
            IF (BETM*A(I,I-1).EQ.ZERO) GO TO 180
            ZZ = W
            Z1 = W1
            R = RA
            S = SA
            ISW = 2
            GO TO 340
  180       M = I
            IF (ISW.EQ.2) GO TO 260
!           COMPLEX 1-BY-1 BLOCK
            TR = -RA
            TI = -SA
  200       DR = W
            DI = W1
!           COMPLEX DIVIDE (T1,T2) = (TR,TI) / (DR,DI)
  220       IF (ABS(DI).GT.ABS(DR)) GO TO 240
            RR = DI/DR
            D = DR + DI*RR
            T1 = (TR+TI*RR)/D
            T2 = (TI-TR*RR)/D
            GO TO (320,280) ISW
  240       RR = DR/DI
            D = DR*RR + DI
            T1 = (TR*RR+TI)/D
            T2 = (TI*RR-TR)/D
            GO TO (320,280) ISW
!           COMPLEX 2-BY-2 BLOCK
  260       X = BETM*A(I,I+1) - ALMR*B(I,I+1)
            X1 = -ALMI*B(I,I+1)
            Y = BETM*A(I+1,I)
            TR = Y*RA - W*R + W1*S
            TI = Y*SA - W*S - W1*R
            DR = W*ZZ - W1*Z1 - X*Y
            DI = W*Z1 + W1*ZZ - X1*Y
            IF (DR.EQ.ZERO .AND. DI.EQ.ZERO) DR = EPSB
            GO TO 220
  280       B(I+1,NA) = T1
            B(I+1,EN) = T2
            ISW = 1
            IF (ABS(Y).GT.ABS(W)+ABS(W1)) GO TO 300
            TR = -RA - X*B(I+1,NA) + X1*B(I+1,EN)
            TI = -SA - X*B(I+1,EN) - X1*B(I+1,NA)
            GO TO 200
  300       T1 = (-R-ZZ*B(I+1,NA)+Z1*B(I+1,EN))/Y
            T2 = (-S-ZZ*B(I+1,EN)-Z1*B(I+1,NA))/Y
  320       B(I,NA) = T1
            B(I,EN) = T2
  340    CONTINUE
!        END COMPLEX VECTOR
  360    ISW = 3 - ISW
  380 CONTINUE
!     END BACK SUBSTITUTION.
!     TRANSFORM TO ORIGINAL COORDINATE SYSTEM.
!     FOR J=N STEP -1 UNTIL 1 DO --
      DO 440 JJ = 1, N
         J = N + 1 - JJ
!
         DO 420 I = 1, N
            ZZ = ZERO
!
            DO 400 K = 1, J
               ZZ = ZZ + Z(I,K)*B(K,J)
  400       CONTINUE
!
            Z(I,J) = ZZ
  420    CONTINUE
  440 CONTINUE
!     NORMALIZE SO THAT, FOR EACH VECTOR, THE COMPONENT
!     WITH LARGEST MODULUS IS REAL AND THE SUM OF SQUARES OF
!     THE MODULI OF THE COMPONENTS IS 1.0
      J = 0
  460 J = J + 1
      IF (ALFI(J).NE.ZERO) GO TO 500
      D = F04JGW(N,Z(1,J))
      DO 480 I = 1, N
         Z(I,J) = Z(I,J)/D
  480 CONTINUE
      GO TO 560
  500 R = ZERO
      DO 520 I = 1, N
         W = A02ABF(Z(I,J),Z(I,J+1))
         IF (W.LE.R) GO TO 520
         R = W
         X = Z(I,J)
         Y = -Z(I,J+1)
  520 CONTINUE
      D = A02ABF(F04JGW(N,Z(1,J)),F04JGW(N,Z(1,J+1)))*A02ABF(X,Y)
      DO 540 I = 1, N
         W = Z(I,J)
         Z(I,J) = (Z(I,J)*X-Z(I,J+1)*Y)/D
         Z(I,J+1) = (Y*W+X*Z(I,J+1))/D
  540 CONTINUE
      J = J + 1
  560 IF (J.LT.N) GO TO 460
!
      RETURN
      END

      DOUBLE PRECISION FUNCTION F04JGW(N,X)
!     MARK 8 RELEASE. NAG COPYRIGHT 1979.
!     MARK 11.5(F77) REVISED. (SEPT 1985.)
!     MARK 13 REVISED. USE OF MARK 12 X02 FUNCTIONS (APR 1988).
!     WRITTEN BY S. HAMMARLING, MIDDLESEX POLYTECHNIC (V2NORM)
!
!     REAL FUNCTION F04JGW RETURNS THE VALUE OF THE EUCLIDEAN
!     LENGTH OF THE N ELEMENT VECTOR X. F04JGW IS DEFINED AS
!
!     F04JGW = SQRT(X(1)**2+X(2)**2+...+X(N)**2).
!
!     .. Scalar Arguments ..
      INTEGER                          N
!     .. Array Arguments ..
      DOUBLE PRECISION                 X(N)
!     .. Local Scalars ..
      DOUBLE PRECISION                 BIG, SMALL, TINY
!     .. External Functions ..
      DOUBLE PRECISION                 F04JGV, X02AMF
      EXTERNAL                         F04JGV, X02AMF
!     .. Intrinsic Functions ..
      INTRINSIC                        SQRT
!     .. Executable Statements ..
      SMALL = X02AMF()
      BIG = 1.0D0/SMALL
      TINY = SQRT(SMALL)
!
      F04JGW = F04JGV(N,X,TINY,BIG)
!
      RETURN
      END

      DOUBLE PRECISION FUNCTION F04JGV(N,X,TINY,BIG)
!     MARK 8 RELEASE. NAG COPYRIGHT 1979.
!     MARK 11.5(F77) REVISED. (SEPT 1985.)
!     MARK 13 REVISED. USE OF MARK 12 X02 FUNCTIONS (APR 1988).
!     WRITTEN BY S. HAMMARLING, MIDDLESEX POLYTECHNIC (VENORM)
!
!     REAL FUNCTION F04JGV RETURNS THE VALUE OF THE EUCLIDEAN
!     LENGTH OF THE N ELEMENT VECTOR X. F04JGV IS DEFINED AS
!
!     F04JGV = SQRT(X(1)**2+X(2)**2+...+X(N)**2).
!
!     TINY AND BIG MUST BE GIVEN BY
!
!     TINY = SQRT(X02AMF)   AND   BIG = 1.0/X02AMF
!
!     WHERE X02AMF IS THE SMALL REAL VALUE RETURNED FROM
!     ROUTINE X02AMF.
!
!     .. Scalar Arguments ..
      DOUBLE PRECISION                 BIG, TINY
      INTEGER                          N
!     .. Array Arguments ..
      DOUBLE PRECISION                 X(N)
!     .. Local Scalars ..
      DOUBLE PRECISION                 SCALE, SUMSQ
!     .. External Functions ..
      DOUBLE PRECISION                 F04JGU
      LOGICAL                          X02DAF
      EXTERNAL                         F04JGU, X02DAF
!     .. External Subroutines ..
      EXTERNAL                         F04JGT
!     .. Executable Statements ..
      SCALE = 0.0D0
      SUMSQ = 1.0D0
!
      CALL F04JGT(N,X,SCALE,SUMSQ,TINY,X02DAF(0.0D0))
!
      F04JGV = F04JGU(SCALE,SUMSQ,BIG)
!
      RETURN
      END

      SUBROUTINE F04JGT(N,X,SCALE,SUMSQ,TINY,UNDFLW)
!     MARK 8 RELEASE. NAG COPYRIGHT 1979.
!     MARK 11.5(F77) REVISED. (SEPT 1985.)
!     MARK 13 REVISED. USE OF MARK 12 X02 FUNCTIONS (APR 1988).
!     WRITTEN BY S. HAMMARLING, MIDDLESEX POLYTECHNIC (SCLSQS)
!
!     F04JGT RETURNS THE VALUES SCL AND SUM SUCH THAT
!
!     (SCL**2)*SUM = X(1)**2+X(2)**2+...+X(N)**2+(SCALE**2)*SUMSQ .
!
!     SCL IS OVERWRITTEN ON SCALE AND SUM IS OVERWRITTEN ON SUMSQ.
!
!     THE SUPPLIED VALUE OF SUMSQ IS ASSUMED TO BE AT LEAST
!     UNITY IN WHICH CASE SUM WILL SATISFY THE BOUNDS
!
!     1.0 .LE. SUM .LE. SUMSQ+N .
!
!     ONLY ONE PASS THROUGH THE VECTOR X IS MADE.
!
!     TINY MUST BE SUCH THAT
!
!     TINY = SQRT(X02AMF) ,
!
!     WHERE X02AMF IS THE SMALL VALUE RETURNED FROM ROUTINE X02AMF.
!
!     UNDFLW MUST BE THE VALUE RETURNED BY X02DAF
!
!     .. Scalar Arguments ..
      DOUBLE PRECISION  SCALE, SUMSQ, TINY
      INTEGER           N
      LOGICAL           UNDFLW
!     .. Array Arguments ..
      DOUBLE PRECISION  X(N)
!     .. Local Scalars ..
      DOUBLE PRECISION  ABSXI, Q
      INTEGER           I
!     .. Intrinsic Functions ..
      INTRINSIC         ABS
!     .. Executable Statements ..
      IF (UNDFLW) GO TO 60
!
      DO 40 I = 1, N
         IF (X(I).EQ.0.0D0) GO TO 40
!
         ABSXI = ABS(X(I))
         IF (SCALE.GE.ABSXI) GO TO 20
!
         SUMSQ = 1.0D0 + SUMSQ*(SCALE/ABSXI)**2
         SCALE = ABSXI
         GO TO 40
!
   20    SUMSQ = SUMSQ + (ABSXI/SCALE)**2
!
   40 CONTINUE
!
      RETURN
!
   60 DO 100 I = 1, N
         IF (X(I).EQ.0.0D0) GO TO 100
!
         ABSXI = ABS(X(I))
         Q = 0.0D0
         IF (SCALE.LT.ABSXI) GO TO 80
!
         IF (SCALE.GT.TINY) Q = SCALE*TINY
         IF (ABSXI.GE.Q) SUMSQ = SUMSQ + (ABSXI/SCALE)**2
         GO TO 100
!
   80    IF (ABSXI.GT.TINY) Q = ABSXI*TINY
         IF (SCALE.GE.Q) SUMSQ = 1.0D0 + SUMSQ*(SCALE/ABSXI)**2
         SCALE = ABSXI
!
  100 CONTINUE
!
      RETURN
      END

      DOUBLE PRECISION FUNCTION F04JGU(SCALE,SUMSQ,BIG)
!     MARK 8 RELEASE. NAG COPYRIGHT 1979.
!     MARK 11.5(F77) REVISED. (SEPT 1985.)
!     MARK 13 REVISED. USE OF MARK 12 X02 FUNCTIONS (APR 1988).
!     WRITTEN BY S. HAMMARLING, MIDDLESEX POLYTECHNIC (TWONRM)
!
!     F04JGU RETURNS THE VALUE
!
!     F04JGU = SCALE*SQRT(SUMSQ) .
!
!     SCALE IS ASSUMED TO BE NON-NEGATIVE AND SUMSQ IS ASSUMED
!     TO BE AT LEAST UNITY.
!
!     BIG MUST BE GIVEN BY
!
!     BIG = 1.0/X02AMF ,
!
!     WHERE X02AMF IS THE SMALL REAL VALUE RETURNED FROM
!     ROUTINE X02AMF.
!
!     F04JGU IS USED IN CONJUNCTION WITH F04JGT BY VARIOUS
!     EUCLIDEAN NORM ROUTINES.
!
!     .. Scalar Arguments ..
      DOUBLE PRECISION                 BIG, SCALE, SUMSQ
!     .. Intrinsic Functions ..
      INTRINSIC                        SQRT
!     .. Executable Statements ..
      IF (SCALE.GE.BIG/SUMSQ) GO TO 20
      F04JGU = SCALE*SQRT(SUMSQ)
      RETURN
!
   20 F04JGU = BIG
      RETURN
      END

      DOUBLE PRECISION FUNCTION X02AJF()
!     MARK 12 RELEASE. NAG COPYRIGHT 1986.
!
!     RETURNS  (1/2)*B**(1-P)  IF ROUNDS IS .TRUE.
!     RETURNS  B**(1-P)  OTHERWISE
!
      DOUBLE PRECISION X02CON
      DATA X02CON /1.11022302462516D-16 /
!     .. Executable Statements ..
      X02AJF = X02CON
      RETURN
      END

      DOUBLE PRECISION FUNCTION X02AMF()
!     MARK 12 RELEASE. NAG COPYRIGHT 1986.
!
!     RETURNS THE 'SAFE RANGE' PARAMETER
!     I.E. THE SMALLEST POSITIVE MODEL NUMBER Z SUCH THAT
!     FOR ANY X WHICH SATISFIES X.GE.Z AND X.LE.1/Z
!     THE FOLLOWING CAN BE COMPUTED WITHOUT OVERFLOW, UNDERFLOW OR OTHER
!     ERROR
!
!        -X
!        1.0/X
!        SQRT(X)
!        LOG(X)
!        EXP(LOG(X))
!        Y**(LOG(X)/LOG(Y)) FOR ANY Y
!
      DOUBLE PRECISION X02CON
      DATA X02CON /2.22507385850721D-308 /
!     .. Executable Statements ..
      X02AMF = X02CON
      RETURN
      END

      LOGICAL FUNCTION X02DAF(X)
!     MARK 8 RELEASE. NAG COPYRIGHT 1980.
!     MARK 11.5(F77) REVISED. (SEPT 1985.)
!
!     RETURNS .FALSE. IF THE SYSTEM SETS UNDERFLOWING QUANTITIES
!     TO ZERO, WITHOUT ANY ERROR INDICATION OR UNDESIRABLE WARNING
!     OR SYSTEM OVERHEAD.
!     RETURNS .TRUE. OTHERWISE, IN WHICH CASE CERTAIN LIBRARY
!     ROUTINES WILL TAKE SPECIAL PRECAUTIONS TO AVOID UNDERFLOW
!     (USUALLY AT SOME COST IN EFFICIENCY).
!
!     X IS A DUMMY ARGUMENT
!
!     .. Scalar Arguments ..
      DOUBLE PRECISION        X
!     .. Executable Statements ..
      X02DAF = .FALSE.
      RETURN
      END

      DOUBLE PRECISION FUNCTION A02ABF(XXR,XXI)
!     NAG COPYRIGHT 1975
!     MARK 4.5 REVISED
!     MARK 5C REVISED
!     MARK 11.5(F77) REVISED. (SEPT 1985.)
!
!     RETURNS THE ABSOLUTE VALUE OF A COMPLEX NUMBER VIA ROUTINE
!     NAME
!
!     .. Scalar Arguments ..
      DOUBLE PRECISION                 XXI, XXR
!     .. Local Scalars ..
      DOUBLE PRECISION                 H, ONE, XI, XR, ZERO
!     .. Intrinsic Functions ..
      INTRINSIC                        ABS, SQRT
!     .. Data statements ..
      DATA                             ZERO/0.0D0/, ONE/1.0D0/
!     .. Executable Statements ..
!
      XR = ABS(XXR)
      XI = ABS(XXI)
      IF (XI.LE.XR) GO TO 20
      H = XR
      XR = XI
      XI = H
   20 IF (XI.NE.ZERO) GO TO 40
      A02ABF = XR
      RETURN
   40 H = XR*SQRT(ONE+(XI/XR)**2)
      A02ABF = H
      RETURN
      END

      INTEGER FUNCTION P01ABF(IFAIL,IERROR,SRNAME,NREC,REC)
!     MARK 11.5(F77) RELEASE. NAG COPYRIGHT 1986.
!     MARK 13 REVISED. IER-621 (APR 1988).
!     MARK 13B REVISED. IER-668 (AUG 1988).
!
!     P01ABF is the error-handling routine for the NAG Library.
!
!     P01ABF either returns the value of IERROR through the routine
!     name (soft failure), or terminates execution of the program
!     (hard failure). Diagnostic messages may be output.
!
!     If IERROR = 0 (successful exit from the calling routine),
!     the value 0 is returned through the routine name, and no
!     message is output
!
!     If IERROR is non-zero (abnormal exit from the calling routine),
!     the action taken depends on the value of IFAIL.
!
!     IFAIL =  1: soft failure, silent exit (i.e. no messages are
!                 output)
!     IFAIL = -1: soft failure, noisy exit (i.e. messages are output)
!     IFAIL =-13: soft failure, noisy exit but standard messages from
!                 P01ABF are suppressed
!     IFAIL =  0: hard failure, noisy exit
!
!     For compatibility with certain routines included before Mark 12
!     P01ABF also allows an alternative specification of IFAIL in which
!     it is regarded as a decimal integer with least significant digits
!     cba. Then
!
!     a = 0: hard failure  a = 1: soft failure
!     b = 0: silent exit   b = 1: noisy exit
!
!     except that hard failure now always implies a noisy exit.
!
!     S.Hammarling, M.P.Hooper and J.J.du Croz, NAG Central Office.
!
!     .. Scalar Arguments ..
      INTEGER                 IERROR, IFAIL, NREC
      CHARACTER*(*)           SRNAME
!     .. Array Arguments ..
      CHARACTER*(*)           REC(*)
!     .. Local Scalars ..
      INTEGER                 I, NERR
      CHARACTER*72            MESS
!     .. External Subroutines ..
      EXTERNAL                P01ABZ, X04AAF, X04BAF
!     .. Intrinsic Functions ..
      INTRINSIC               ABS, MOD
!     .. Executable Statements ..
      IF (IERROR.NE.0) THEN
!        Abnormal exit from calling routine
         IF (IFAIL.EQ.-1 .OR. IFAIL.EQ.0 .OR. IFAIL.EQ.-13 .OR.&
     &       (IFAIL.GT.0 .AND. MOD(IFAIL/10,10).NE.0)) THEN
!           Noisy exit
            CALL X04AAF(0,NERR)
            DO 20 I = 1, NREC
               CALL X04BAF(NERR,REC(I))
   20       CONTINUE
            IF (IFAIL.NE.-13) THEN
               WRITE (MESS,FMT=99999) SRNAME, IERROR
               CALL X04BAF(NERR,MESS)
               IF (ABS(MOD(IFAIL,10)).NE.1) THEN
!                 Hard failure
                  CALL X04BAF(NERR,&
     &                     ' ** NAG hard failure - execution terminated'&
     &                        )
                  CALL P01ABZ
               ELSE
!                 Soft failure
                  CALL X04BAF(NERR,&
     &                        ' ** NAG soft failure - control returned')
               END IF
            END IF
         END IF
      END IF
      P01ABF = IERROR
      RETURN
!
99999 FORMAT (' ** ABNORMAL EXIT from NAG Library routine ',A,': IFAIL',&
     &  ' =',I6)
      END

      SUBROUTINE P01ABZ
!     MARK 11.5(F77) RELEASE. NAG COPYRIGHT 1986.
!
!     Terminates execution when a hard failure occurs.
!
!     ******************** IMPLEMENTATION NOTE ********************
!     The following STOP statement may be replaced by a call to an
!     implementation-dependent routine to display a message and/or
!     to abort the program.
!     *************************************************************
!     .. Executable Statements ..
      STOP
      END


      SUBROUTINE X04AAF(I,NERR)
!     MARK 7 RELEASE. NAG COPYRIGHT 1978
!     MARK 7C REVISED IER-190 (MAY 1979)
!     MARK 11.5(F77) REVISED. (SEPT 1985.)
!     MARK 14 REVISED. IER-829 (DEC 1989).
!     IF I = 0, SETS NERR TO CURRENT ERROR MESSAGE UNIT NUMBER
!     (STORED IN NERR1).
!     IF I = 1, CHANGES CURRENT ERROR MESSAGE UNIT NUMBER TO
!     VALUE SPECIFIED BY NERR.
!
!     .. Scalar Arguments ..
      INTEGER           I, NERR
!     .. Local Scalars ..
      INTEGER           NERR1
!     .. Save statement ..
      SAVE              NERR1
!     .. Data statements ..
      DATA              NERR1/0/
!     .. Executable Statements ..
      IF (I.EQ.0) NERR = NERR1
      IF (I.EQ.1) NERR1 = NERR
      RETURN
      END

      SUBROUTINE X04BAF(NOUT,REC)
!     MARK 11.5(F77) RELEASE. NAG COPYRIGHT 1986.
!
!     X04BAF writes the contents of REC to the unit defined by NOUT.
!
!     Trailing blanks are not output, except that if REC is entirely
!     blank, a single blank character is output.
!     If NOUT.lt.0, i.e. if NOUT is not a valid Fortran unit identifier,
!     then no output occurs.
!
!     .. Scalar Arguments ..
      INTEGER           NOUT
      CHARACTER*(*)     REC
!     .. Local Scalars ..
      INTEGER           I
!     .. Intrinsic Functions ..
      INTRINSIC         LEN
!     .. Executable Statements ..
      IF (NOUT.GE.0) THEN
!        Remove trailing blanks
         DO 20 I = LEN(REC), 2, -1
            IF (REC(I:I).NE.' ') GO TO 40
   20    CONTINUE
!        Write record to external file
   40    WRITE (NOUT,FMT=99999) REC(1:I)
      END IF
      RETURN
!
99999 FORMAT (A)
      END
