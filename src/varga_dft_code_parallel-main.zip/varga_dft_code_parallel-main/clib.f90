MODULE COMMON_LIBRARY
  USE MOD_GLOBAL
  implicit none
  integer,parameter              :: nmax=100,nnmax=301,n2d=100,indm=10000
  real*8                         :: f(0:nmax),df(-1:nnmax),x2n(0:n2d)
  real*8                         :: dfa(0:2*nmax+1)
  real*8,parameter               :: xpi=3.141592653589793d0

CONTAINS

  pure function dnrm2b(v)
    implicit none
    real*8 :: dnrm2b
    real*8, dimension(3), intent(in) :: v
    dnrm2b = sqrt(v(1)*v(1) + v(2)*v(2) + v(3)*v(3))
  end function dnrm2b

!  pure function dnrm2b(v)
!    implicit none
!    real*8 :: dnrm2b
!    real*8, dimension(:), intent(in) :: v
!    dnrm2b = sqrt(dot_product(v,v))
!  end function dnrm2b

function Laguerre(n,alpha,x)
implicit none
real*8   :: Laguerre,alpha,x,bin
integer  :: i,n
  Laguerre=1.d0; bin=1.d0
  do i=n,1,-1
    bin= bin*(alpha+i)/dfloat(n+1-i)
    Laguerre= bin-x*Laguerre/dfloat(i)
  end do
end function Laguerre


function clb(l,lp,ll)
!  cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
!  c     C(l,lp,L) coefficient (see (A2))
!  cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
  implicit none
  real*8      :: clb
  integer     :: l,lp,ll
  real*8      :: xl,xlp,xll,xnul,hl,hlp,hll
  xl=dfloat(l)
  xlp=dfloat(lp)
  xll=dfloat(ll)
  xnul=0.d0
  hl=dsqrt(2.d0*l+1.d0)
  hlp=dsqrt(2.d0*lp+1.d0)
  hll=dsqrt(2.d0*ll+1.d0)
  clb=0.5d0*clebgn(xl,xnul,xlp,xnul,xll,xnul)*hl*hlp/(dsqrt(xpi)*hll)

end function clb

function snj(j11,j12,j13,j21,j22,j23,j31,j32,j33)
! 9j symbol (arguments are 2*j)
!     | j11 j12 j13 |
!     | j21 j22 j23 |
!     | j31 j32 j33 |
  implicit none
  real*8    :: snj
  integer   :: j11,j12,j13,j21,j22,j23,j31,j32,j33
!
  integer   :: i1,i2,i3,jmin,jmax,ifas,j
  real*8    :: a,b,c

      snj=0.d0
      i1=j21-j32
      if(i1.lt.0)i1=-i1
      i2=j33-j11
      if(i2.lt.0)i2=-i2
      i3=j12-j23
      if(i3.lt.0)i3=-i3
      jmin=i1
      if(jmin.lt.i2)jmin=i2
      if(jmin.lt.i3)jmin=i3
      i1=j21+j32
      i2=j33+j11
      i3=j12+j23
      jmax=i1
      if(jmax.gt.i2)jmax=i2
      if(jmax.gt.i3)jmax=i3
      if(jmin.gt.jmax)return
      do j=jmin,jmax,2
        ifas=1
        if(j.ne.2*(j/2))ifas=-1
        a=sjs(j11,j21,j31,j32,j33,j)
        b=sjs(j12,j22,j32,j21,j,j23)
        c=sjs(j13,j23,j33,j,j11,j12)
        snj=snj+ifas*(dfloat(j)+1.d0)*a*b*c
      end do
end function snj

function sjs(j1,j2,j5,j4,j3,j6)
! 6j symbol (arguments are 2*j)
!     | j1 j2 j5 |
!     | j4 j3 j6 |
  implicit none
  real*8      :: sjs
  integer     :: j1,j2,j3,j4,j5,j6
!
  real*8      :: z1,z2,phase,xf,fctor
  integer     :: i1,i2,i3,i4,i5,i6,i7,numin,numax,jy1,jy2,jy3,jy4,jy5,jy6,nu
      sjs=0.d0
      z1=delr(j1,j2,j5)
      if(z1.gt.1.d+19) goto 90
      z1=delr(j3,j4,j5)+z1
      if(z1.gt.1.d+19) goto 90
      z2=delr(j1,j3,j6)
      if(z2.gt.1.d+19) goto 90
      z2=delr(j2,j4,j6)+z2
      if(z2.gt.1.d+19) goto 90
      z1=0.5d0*(z1+z2)
      i1=(j1+j2+j4+j3)/2+1
      i2=(j1+j2-j5)/2
      i3=(j4+j3-j5)/2
      i4=(j1+j3-j6)/2
      i5=(j4+j2-j6)/2
      i6=(j1+j4-j5-j6)/2
      i7=(j2+j3-j5-j6)/2
      numin=max0(i6,i7,0)
      numax=min0(i2,i3,i4,i5)
      if(numax.lt.numin) go to 90
      phase=phasef(numin+(j1+j2+j3+j4)/2)
      do nu=numin,numax
        jy1=i2-nu
        jy2=i3-nu
        jy3=i4-nu
        jy4=i5-nu
        jy5=nu-i6
        jy6=nu-i7
        xf=f(jy1)+f(jy2)+f(jy3)+f(jy4)+f(jy5)+f(jy6)
        fctor=xf-z1+f(nu)-f(i1-nu)
        fctor=dexp(fctor)
        sjs=sjs+phase/fctor
        phase=-phase
      end do
90    return
end function sjs

function delr(j1,j2,j3)
  implicit none
  real*8   :: delr
  integer  :: j1,j2,j3
  integer  :: jz1,jz2,jz3,jz4
      jz1=(j1+j2-j3)/2
      if(jz1.lt.0) go to 130
      jz2=(j1-j2+j3)/2
      if(jz2.lt.0) go to 130
      jz3=(j2+j3-j1)/2
      if(jz3.lt.0) go to 130
      jz4=(j1+j2+j3)/2+1
      if(jz4.gt.1000)go to 200
      delr=f(jz1)+f(jz2)+f(jz3)-f(jz4)
      return
130   delr=1.d+20
      return
200   write(log_file,*)'  too high spins'
      stop
end function delr

function racah(i1,i2,i3,i4,i5,i6)
  implicit none
  real*8    :: racah
  integer   :: i1,i2,i3,i4,i5,i6
  integer   :: ipf
  ipf=(i1+i2+i5+i4)/2
!
! call sjs and calculate racah
!
  racah=sjs(i1,i2,i3,i4,i5,i6)/phasef(ipf)
  return
end function racah


function tjs(j1,j2,j3,m1,m2)
!
!  tjs is the 3-j symbol. The arguments are obvious, e.g.
!  m3=-m1-m2. j's and m's are doubled.
!  Note that max(j1+j2+j3+1)=2000 (i.e. twice the sum of j's),
!  otherwise change f(0:1000))
!
  implicit none
  integer :: j1,j2,j3,m1,m2
  real*8  :: tjs
!
  integer :: m3,i1,i2,i3,i4,i5,i6,i7,kmin,kmax,isj,k,j1m1,j2m2,j3m3m,j3m3p
  real*8  :: sum,fk,fjm,fsj,den,fj,comfac

      tjs=0.d0
      i1=(j1+j2-j3)/2
      if(i1.lt.0)return
      i2=(j1-j2+j3)/2
      if(i2.lt.0)return
      i3=(-j1+j2+j3)/2
      if(i3.lt.0)return
      fj=f(i1)+f(i2)+f(i3)
      m3=-m1-m2
      i4=(j1-m1)/2
      i5=(j2+m2)/2
      j1m1=(j1+m1)/2
      j2m2=(j2-m2)/2
      j3m3p=(j3+m3)/2
      j3m3m=(j3-m3)/2
      fjm=f(j1m1)+f(i4)+f(i5)+f(j2m2)+f(j3m3p)+f(j3m3m)
      isj=(j1+j2+j3+2)/2
      fsj=f(isj)
      comfac=0.5d0*(fj+fjm-fsj)
      sum=0.d0
      kmax=i1
      if(kmax.gt.i4)kmax=i4
      if(kmax.gt.i5)kmax=i5
      kmin=0
      i6=-(j3-j2+m1)/2
      if(kmin.lt.i6)kmin=i6
      i7=(-j3+j1+m2)/2
      if(kmin.lt.i7)kmin=i7
      fk=phasef(kmin-1)
      do k=kmin,kmax
        fk=-fk
        den=-f(k)-f(i1-k)-f(i4-k)-f(i5-k)-f(-i6+k)-f(-i7+k)
        sum=sum+fk*dexp(den+comfac)
      end do
      tjs=sum*phasef((j1-j2-m3)/2)
      return
end function tjs

function phasef(n)
  implicit none
  real*8  :: phasef
  integer :: n
  phasef=1.d0
  if(n.ne.2*(n/2))phasef=-1.d0
end function phasef


function power(x,n)
implicit none
  real*8         :: x,power
  integer        :: n

  if(x.eq.0.d0) then
    if(n.eq.0) then
      power=1.d0
    else
      power=0.d0
    endif
  else
    power=x**n
  endif

end function power



subroutine init_angular
  implicit none
  real*8               :: x
  integer              :: i,j

  dfa(0)=1.d0
  do j=1,nmax
    dfa(j)=(2.d0*j+1.d0)*dfa(j-1)
  end do


  f(0)=0.d0
  df(-1)=0.d0
  df(0)=0.d0
  x2n(0)=0.d0
  f(1)=0.d0
  df(1)=0.d0
  df(2)=dlog(2.d0)
  do i=2,nmax
    x=dble(i)
    f(i)=f(i-1)+dlog(x)
  end do
  do i=3,nnmax
    x=dble(i)
    df(i)=df(i-2)+dlog(x)
  end do
  do i=1,n2d
    x=2.d0
    x2n(i)=x2n(i-1)+dlog(x)
  end do
  write(log_file,*)'init_angular   :  OK'
end subroutine  init_angular

function gaunt(l1,m1,l2,m2,l)
!
  implicit none
  real*8                       :: fc,gaunt
  integer                      :: l1,l2,l,m1,m2

  fc=sqrt((2.d0*l1+1.d0)*(2.d0*l2+1.d0)/(4.d0*xpi*(2.d0*l+1.d0)))

  gaunt=fc*clebgn(1.d0*l1,1.d0*m1,1.d0*l2,-1.d0*m2,1.d0*l,1.d0*(m1-m2))* &
&          clebgn(1.d0*l1,0.d0,1.d0*l2,0.d0,1.d0*l,0.d0)*(-1)**m2



end function gaunt


function clebgn(a,az,b,bz,c,cz)
!
!        determines clebsch-gordan coefficients
!
  implicit none
  real*8              :: az,bz,cz,a,b,c,d(6),r,s,clebgn,p,t
  integer             :: k1,k2,k3,k4,k5,k6,i,j,k,mn,mx,m


  if(dabs(az+bz-cz)-0.1d0)1,4,4
1 r=a+b+c
  s=r-dint(r+1.1d0)+1.0d0
  if(s-0.1)9,9,4
9 if(dabs(az)-0.1)2,5,5
2 if(dabs(bz)-0.1)3,5,5
3 if(dsign(1.d0,2.d0*dint(.5d0*r+.2d0)+.5d0-r))4,5,5
4 clebgn=0.0d0
  return
5 d(1)=0.0d0
  d(2)=b-c-az
  d(3)=a-c+bz
  d(4)=a+b-c
  d(5)=a-az
  d(6)=b+bz
  r=dmax1(d(1),d(2),d(3))
  s=dmin1(d(4),d(5),d(6))
  if(s-r+0.1d0)4,6,6
6 mn=idint(r+0.1d0)
  mx=idint(s+0.1d0)
  k1=idint(a+az+1.1d0)
  k2=idint(d(5)+1.1d0)
  k3=idint(d(6)+1.1d0)
  k4=idint(b-bz+1.1d0)
  k5=idint(c+cz+1.1d0)
  k6=idint(c-cz+1.1d0)
  s=0.5*(f(k1-1)+f(k2-1)+f(k3-1)+f(k4-1)+f(k5-1)+f(k6-1))+delt(a,b,c)
  r=0.0d0
  p=dsign(1.d0,2.d0*dint(.5d0*dble(mn)+.2d0)+.5d0-dble(mn))
  do m=mn,mx
    t=-s
    do i=1,3
      j=idint(dble(m)-d(i)+1.1d0)
      k=idint(d(i+3)-dble(m)+1.1d0)
      t=t+f(j-1)+f(k-1)
    end do
    r=r+p*dexp(-t)
    p=-p
  end do
  clebgn=r*dsqrt(2.d0*c+1.d0)
  return
end function clebgn

function delt(a,b,c)
!
!         computes items used by subroutine clebgn
!
implicit none
  real*8               :: delt,a,b,c
  integer              :: i1,i2,i3,i4

  i1=idint(a+b+c+2.1d0)
  i2=idint(a+b-c+1.1d0)
  i3=idint(a+c-b+1.1d0)
  i4=idint(b+c-a+1.1d0)
  delt=0.5*(f(i2-1)+f(i3-1)+f(i4-1)-f(i1-1))
end function delt


      FUNCTION plgndr(l,m,x)
      INTEGER l,m
      REAL*8 plgndr,x
      INTEGER i,ll
      REAL*8 fact,pll,pmm,pmmp1,somx2

      if(m.lt.0.or.m.gt.l.or.abs(x).gt.1.) then         
         write(*,*)  'bad arguments in plgndr'
         stop
      end if

      pmm=1.d0
      if(m.gt.0) then
        somx2=sqrt((1.d0-x)*(1.d0+x))
        fact=1.d0
        do i=1,m
          pmm=-pmm*fact*somx2
          fact=fact+2.d0
        end do
      endif
      if(l.eq.m) then
        plgndr=pmm
      else
        pmmp1=x*(2*m+1)*pmm
        if(l.eq.m+1) then
          plgndr=pmmp1
        else
          do 12 ll=m+2,l
            pll=(x*(2*ll-1)*pmmp1-(ll+m-1)*pmm)/(ll-m)
            pmm=pmmp1
            pmmp1=pll
12        continue
          plgndr=pll
        endif
      endif
      return
      END function plgndr


function powerc(x,n)
  complex*16     :: x,powerc
  integer        :: n

  if(x.eq.(0.d0,0.d0)) then
    if(n.eq.0) then
      powerc=(1.d0,0.d0)
    else
      powerc=(0.d0,0.d0)
    endif
  else
    powerc=x**n
  endif

end function powerc


function spherical_harmonics(r,l,mm)

  implicit none
  real*8                       :: x,y,z,cost,fc,r(3),r2
  complex*16,parameter         :: zi=(0.d0,1.d0)
  integer                      :: i,l,m,mm
  complex*16                   :: spherical_harmonics,phi
!  complex*16,external          :: powerc
!  real*8,external              :: polgndr
  spherical_harmonics=(0.d0,0.d0)

  m=abs(mm)
  if(abs(m).gt.l) then
    spherical_harmonics=(0.d0,0.d0)
    return
  endif

  x=r(1); y=r(2); z=r(3)
  r2=x**2+y**2+z**2

  fc=(2*l+1)/(4.d0*xpi)
  do i=1,l-m
    fc=fc*i
  end do
  do i=1,l+m
    fc=fc/i
  end do

    phi=(x+zi*y)/sqrt(x**2+y**2+1.d-20)

    cost=z/sqrt(r2+1.d-20)

  spherical_harmonics=sqrt(fc)*powerc(phi,m)*plgndr(l,m,cost)
  if(mm.lt.0) spherical_harmonics=(-1)**m*Conjg(spherical_harmonics)

end function spherical_harmonics

function spherical_harmonics2(r,l,m)
  ! this version assumes 0<=m<=l
  implicit none
  complex*16 :: spherical_harmonics2

  real*8, intent(in) :: r(3)
  integer, intent(in) :: l,m

  complex*16,parameter  :: zi=(0.d0,1.d0)
  real*8, parameter :: ff=1.0d0/(4.0d0*xpi)

  integer :: i
  real*8 :: cost, fc, rr, x2, y2
  complex*16 :: phi
 
  x2=r(1)*r(1)
  y2=r(2)*r(2)
  rr=x2+y2+r(3)*r(3)
  phi=(r(1)+zi*r(2))/sqrt(x2+y2+1.0d-20)
  cost=r(3)/sqrt(rr+1.d-20)

  fc=ff*(2*l+1)
  do i=1,l-m
    fc=fc*i
  end do
  do i=1,l+m
    fc=fc/i
  end do

  spherical_harmonics2=sqrt(fc)*plgndr(l,m,cost)*phi**m

end function spherical_harmonics2

SUBROUTINE gaussj(a,n,np,b,m,mp,ierr)
  integer            :: n,np,i,j,l,ll,icol,irow,mp,ierr,m,k
  real*8             :: a(np,np),b(np,np)
  integer,parameter  :: nmax=500
  integer            :: indxc(NMAX),indxr(NMAX),ipiv(NMAX)
  real*8             :: big,dum,pivinv

      do 11 j=1,n
        ipiv(j)=0
11    continue
      do 22 i=1,n
        big=0.
        do 13 j=1,n
          if(ipiv(j).ne.1)then
            do 12 k=1,n
              if (ipiv(k).eq.0) then
                if (abs(a(j,k)).ge.big)then
                  big=abs(a(j,k))
                  irow=j
                  icol=k
                endif
              else if (ipiv(k).gt.1) then
                ierr=1
                return
              endif
12          continue
          endif
13      continue
        ipiv(icol)=ipiv(icol)+1
        if (irow.ne.icol) then
          do 14 l=1,n
            dum=a(irow,l)
            a(irow,l)=a(icol,l)
            a(icol,l)=dum
14        continue
          do 15 l=1,m
            dum=b(irow,l)
            b(irow,l)=b(icol,l)
            b(icol,l)=dum
15        continue
        endif
        indxr(i)=irow
        indxc(i)=icol
        if (a(icol,icol).eq.0.) then
        ierr=1
        return
        endif
        pivinv=1./a(icol,icol)
        a(icol,icol)=1.
        do 16 l=1,n
          a(icol,l)=a(icol,l)*pivinv
16      continue
        do 17 l=1,m
          b(icol,l)=b(icol,l)*pivinv
17      continue
        do 21 ll=1,n
          if(ll.ne.icol)then
            dum=a(ll,icol)
            a(ll,icol)=0.
            do 18 l=1,n
              a(ll,l)=a(ll,l)-a(icol,l)*dum
18          continue
            do 19 l=1,m
              b(ll,l)=b(ll,l)-b(icol,l)*dum
19          continue
          endif
21      continue
22    continue
      do 24 l=n,1,-1
        if(indxr(l).ne.indxc(l))then
          do 23 k=1,n
            dum=a(k,indxr(l))
            a(k,indxr(l))=a(k,indxc(l))
            a(k,indxc(l))=dum
23        continue
        endif
24    continue
      return
      END  SUBROUTINE gaussj

!***********************************************************************
      function bessj(l,x)
!
!     Calculates bessj(l,x) = x*j(l,x), where j(l,x) is the Spherical
!     Bessel Function of integer order l.
!     l=0,2 : The analytic expressions in sin(x) & cos(x) are used.
!     l>2   : The functional value is obtained by downward recursion,
!             if x<l, by upward recursion if x>l, calling 'besrec()'.
!     x<xmin,l>0: bessj()=x**(l+1)/(2*l-1)!!
!     If the argument is excessively small, 'bestiny' sets the output
!     equal to the lowest order term in the powerseries expansion.
!***********************************************************************
      implicit  none
      real*8,parameter    :: xmin=1.0d-10
      real*8              :: bessj,x
      integer             :: l
!      real*8,external     :: besrec,bestiny

      if(l.eq.0)then
         bessj=sin(x)
      else if(x.lt.xmin)then
         bessj=x*bestiny(l,x)
      else if(l.eq.1)then
         bessj=sin(x)/x-cos(x)
      else if(l.eq.2)then
         bessj=(3.0d0/x/x-1.0d0)*sin(x)-3.0d0*cos(x)/x
      else
         bessj=x*besrec(l,x)
      endif

      return
      end function bessj


!***********************************************************************
      function besrec(l,x)
!
!     Recursion for Bessel functions. 'acclog' is about the negative
!     log of the desired accuracy.
!***********************************************************************
      implicit none
      real*8, parameter       :: acclog=1.0d1
      real*8                  :: besrec,x
      integer                 :: l
      real*8                  :: upj,downj,tempj
      integer                 :: m,mstart

      if(x.gt.dble(l))then
!
! upward recursion
!
         downj=sin(x)/x
         tempj=(downj-cos(x))/x
         do 100 m=2,l
            upj=(2.0*m-1.0)/x*tempj-downj
                 downj=tempj
                 tempj=upj
100      continue
         besrec=upj
      else
!
! downward recursion & renormalization
!
         mstart=2*l+int(acclog*sqrt(dble(l)))
200      upj=0.0d0
         tempj=1.0d0
         do 300 m=mstart-1,0,-1
            downj=(2.0*m+3.0)/x*tempj-upj
            if(m.eq.l)besrec=downj
            upj=tempj
            tempj=downj
300      continue
         besrec=besrec/downj*sin(x)/x
      endif

400   return
      end function besrec


!***********************************************************************
      function bestiny(l,x)
!
!     Lowest order powerseries term for spherical Bessel function.
!***********************************************************************
      implicit none
      real*8                   :: bestiny,x
      integer                  :: l,k
      real*8                   :: kdiv
      kdiv=1.0d0
      do 100 k=1,2*l-1,2
         kdiv=kdiv*k
100   continue
      bestiny=x**l/kdiv

      return
      end function bestiny

subroutine potential_fit(rp,pot,np,nu,ng,cg)
! fit the local potentials with gaussians
  implicit none
  integer              :: ierr,i,j,k,np,ng
  real*8               :: pot(np),rp(np),cg(ng)
  real*8               :: am(ng,ng),bm(ng),bf(ng)
  real*8               :: r2,nu(ng)

  am=0.d0
  bm=0.d0
  do k=1,np
    r2=rp(k)
    do i=1,ng
      bf(i)=exp(-nu(i)*r2**2)
    end do
    do i=1,ng
      do j=1,ng
        am(j,i)=am(j,i)+bf(i)*bf(j)
      end do
      bm(i)=bm(i)+bf(i)*pot(k)
    end do
  end do

  call gaussj(am,ng,ng,bm,1,1,ierr)

  cg=bm

end subroutine potential_fit


function Slm(x,y,z,l,m)
!This function evaluates a real spherical harmonic of order
!up to l=4. These are defined as follows (warning: the definition
!of spherical harmonics might differ in some references)
!  S_{l0} = Y_{l0}                                      for m=0
!  S_{lm} = ( Y_{la} + Y_{la}^{*} ) / sqrt(2)           for m>0
!  S_{lm} = ( Y_{la} - Y_{la}^{*} ) / ( i * sqrt(2) )   for m<0
!or, equivalently,
!  S_{l0} = Y_{l0}                                           for m=0
!  S_{lm} = ( Y_{lm} + (-1)^m Y_{l -m} ) / sqrt(2)           for m>0
!  S_{lm} = ( Y_{l -m} - (-1)^m Y_{lm} ) / ( i * sqrt(2) )   for m<0
!where a=abs(m), Y_{lm} are common complex spherical harmonics, and i=sqrt(-1).
!The user is responsible for making sure that the arguments are
!acceptable, i.e. 0<=l<=4  and x**2+y**2+z**2>0.0
implicit none
real(8)    Slm
!Input parameters:
real(8),intent(in) ::   x,y,z  !The point where the harmonic needs to be computed
integer,intent(in) ::   l,m    !integers which define the harmonic (0<=l<=4, m=[-l,l])
!Work variables:
real(8)                 r2,rl !used to store r^2 and r^{l}
real(8)                 x2,y2,z2 !used to store x**2, y**2, and z**2
!Constants:
real(8),parameter   :: pi=3.141592653589793238462643383279503d0

select case (l)
case(0)
  Slm=1/sqrt(4*pi)
case(1)
  rl=sqrt(x*x+y*y+z*z)
  select case(m)
  case(-1)
    Slm=(-sqrt(3/pi)/2)*y/rl
  case(0)
    Slm=(sqrt(3/pi)/2)*z/rl
  case(1)
    Slm=(-sqrt(3/pi)/2)*x/rl
  endselect
case(2)
  x2=x**2
  y2=y**2
  z2=z**2
  rl=x2+y2+z2
  select case(m)
  case(-2)
    Slm=(sqrt(15/pi)/2)*x*y/rl
  case(-1)
    Slm=(-sqrt(15/pi)/2)*y*z/rl
  case(0)
    Slm=(-sqrt(5/pi)/4)*(rl-3*z2)/rl
  case(1)
    Slm=(-sqrt(15/pi)/2)*x*z/rl
  case(2)
    Slm=(sqrt(15/pi)/4)*(x2-y2)/rl
  endselect
case(3)
  x2=x**2
  y2=y**2
  z2=z**2
  r2=x2+y2+z2
  rl=r2*sqrt(r2)
  select case(m)
  case(-3)
    Slm=(-sqrt(70/pi)/8)*y*(3*x2-y2)/rl
  case(-2)
    Slm=(sqrt(105/pi)/2)*x*y*z/rl
  case(-1)
    Slm=(sqrt(42/pi)/8)*y*(r2-5*z2)/rl
  case(0)
    Slm=(-sqrt(7/pi)/4)*z*(3*r2-5*z2)/rl
  case(1)
    Slm=(sqrt(42/pi)/8)*x*(r2-5*z2)/rl
  case(2)
    Slm=(sqrt(105/pi)/4)*z*(x2-y2)/rl
  case(3)
    Slm=(-sqrt(70/pi)/8)*x*(x2-3*y2)/rl
  endselect
case(4)
  x2=x**2
  y2=y**2
  z2=z**2
  r2=x2+y2+z2
  rl=r2**2
  select case(m)
  case(-4)
    Slm=(3*sqrt(35/pi)/4)*x*y*(x2-y2)/rl
  case(-3)
    Slm=(-(3*sqrt(70/pi))/8)*z*y*(3*x2-y2)/rl
  case(-2)
    Slm=(-(3*sqrt(5/pi))/4)*x*y*(r2-7*z2)/rl
  case(-1)
    Slm=((3*sqrt(10/pi))/8)*y*z*(3*r2-7*z2)/rl
  case(0)
    Slm=((3*sqrt(1/pi))/16)*(3*rl-30*z2*r2+35*z2**2)/rl
  case(1)
    Slm=((3*sqrt(10/pi))/8)*z*x*(3*r2-7*z2)/rl
  case(2)
    Slm=(-(3*sqrt(5/pi))/8)*(r2-7*z2)*(x2-y2)/rl
  case(3)
    Slm=(-(3*sqrt(70/pi))/8)*z*x*(x2-3*y2)/rl
  case(4)
    Slm=((3*sqrt(35/pi))/16)*((r2-z2)**2-8*x2*y2)/rl
  endselect
endselect

end function Slm


function rlSlm(x,y,z,l,m)
!This function evaluates a product of a real spherical harmonic, S_{lm}(r), and r^l.
!Values of l up to order 4 are acceptable. Real spherical harmonics are defined as
!follows (warning: the definition of spherical harmonics might differ in some references)
!  S_{l0} = Y_{l0}                                      for m=0
!  S_{lm} = ( Y_{la} + Y_{la}^{*} ) / sqrt(2)           for m>0
!  S_{lm} = ( Y_{la} - Y_{la}^{*} ) / ( i * sqrt(2) )   for m<0
!or, equivalently,
!  S_{l0} = Y_{l0}                                           for m=0
!  S_{lm} = ( Y_{lm} + (-1)^m Y_{l -m} ) / sqrt(2)           for m>0
!  S_{lm} = ( Y_{l -m} - (-1)^m Y_{lm} ) / ( i * sqrt(2) )   for m<0
!where a=abs(m), Y_{lm} are common complex spherical harmonics, and i=sqrt(-1).
!The user is responsible for making sure that the arguments are
!acceptable, i.e. 0<=l<=4.
implicit none
real(8)    rlSlm
!Input parameters:
real(8),intent(in) ::   x,y,z  !The point where the harmonic needs to be computed
integer,intent(in) ::   l,m    !integers which define the harmonic (0<=l<=4, m=[-l,l])
!Work variables:
real(8)                 r2,x2,y2,z2
!Constants:
real(8),parameter   :: pi=3.141592653589793238462643383279503d0

select case (l)
case(0)
  rlSlm=1/sqrt(4*pi)
case(1)
  select case(m)
  case(-1)
    rlSlm=(-sqrt(3/pi)/2)*y
  case(0)
    rlSlm=(sqrt(3/pi)/2)*z
  case(1)
    rlSlm=(-sqrt(3/pi)/2)*x
  endselect
case(2)
  select case(m)
  case(-2)
    rlSlm=(sqrt(15/pi)/2)*x*y
  case(-1)
    rlSlm=(-sqrt(15/pi)/2)*y*z
  case(0)
    rlSlm=(-sqrt(5/pi)/4)*(x**2+y**2-2*z**2)
  case(1)
    rlSlm=(-sqrt(15/pi)/2)*x*z
  case(2)
    rlSlm=(sqrt(15/pi)/4)*(x**2-y**2)
  endselect
case(3)
  select case(m)
  case(-3)
    rlSlm=(-sqrt(70/pi)/8)*y*(3*x**2-y**2)
  case(-2)
    rlSlm=(sqrt(105/pi)/2)*x*y*z
  case(-1)
    rlSlm=(sqrt(42/pi)/8)*y*(x**2+y**2-4*z**2)
  case(0)
    rlSlm=(-sqrt(7/pi)/4)*z*(3*(x**2+y**2)-2*z**2)
  case(1)
    rlSlm=(sqrt(42/pi)/8)*x*(x**2+y**2-4*z**2)
  case(2)
    rlSlm=(sqrt(105/pi)/4)*z*(x**2-y**2)
  case(3)
    rlSlm=(-sqrt(70/pi)/8)*x*(x**2-3*y**2)
  endselect
case(4)
  select case(m)
  case(-4)
    rlSlm=(3*sqrt(35/pi)/4)*x*y*(x**2-y**2)
  case(-3)
    rlSlm=(-(3*sqrt(70/pi))/8)*z*y*(3*x**2-y**2)
  case(-2)
    rlSlm=(-(3*sqrt(5/pi))/4)*x*y*(x**2+y**2-6*z**2)
  case(-1)
    rlSlm=((3*sqrt(10/pi))/8)*y*z*(3*(x**2+y**2)-4*z**2)
  case(0)
    z2=z**2
    r2=x**2+y**2+z2
    rlSlm=((3*sqrt(1/pi))/16)*(3*r2*(r2-10*z2)+35*z2**2)
  case(1)
    rlSlm=((3*sqrt(10/pi))/8)*z*x*(3*r2-7*z2)
  case(2)
    x2=x**2
    y2=y**2
    rlSlm=(-(3*sqrt(5/pi))/8)*(x2+y2-6*z**2)*(x2-y2)
  case(3)
    rlSlm=(-(3*sqrt(70/pi))/8)*z*x*(x**2-3*y**2)
  case(4)
    x2=x**2
    y2=y**2
    rlSlm=((3*sqrt(35/pi))/16)*((x2+y2)**2-8*x2*y2)
  endselect
endselect

end function rlSlm


subroutine grad_frlSlm(f,fp,x,y,z,l,m,gx,gy,gz)
!This subroutine computes the gradient of the
!following expression: f(r) * r^l * S_{lm}(r), where f(r)
!is some spherically symmetric function, r is a set of
!coordinates (x,y,z), and S_{lm}(r) is a real spherical
!harmonic of order up to l=4. Function value f and its radial
!derivative value, fp=df/dr, must be supplied in f and fp respectively.
!The gradient components are returned in gx, gy, and gz.
!The user is responsible for making sure that the arguments are
!acceptable, i.e. 0<=l<=4 and x**2+y**2+z**2>0.0
!Input parameters:
implicit none
real(8),intent(in)  :: f,fp,x,y,z
integer,intent(in)  :: l,m
!Output data:
real(8),intent(out) :: gx,gy,gz
!Work variables:
real(8)                x2,y2,z2,r2,fpor,t,p,q,w
!Constants:
real(8),parameter   :: pi=3.141592653589793238462643383279503d0

x2=x**2
y2=y**2
z2=z**2
r2=x2+y2+z2
fpor=fp/sqrt(r2)

select case(l)
case(0)
  select case(m)
  case(0)
    t = (1/sqrt(4*pi))*fpor
    gx =  x*t
    gy =  y*t
    gz =  z*t
  endselect
case(1)
  select case(m)
  case(-1)
    t = (-sqrt(3/pi)/2)*y*fpor
    gx =  x*t
    gy =  (-sqrt(3/pi)/2) * (f+y2*fpor)
    gz =  z*t
  case(0)
    t = (sqrt(3/pi)/2)*z*fpor
    gx =  x*t
    gy =  y*t
    gz =  (sqrt(3/pi)/2) * (f+z2*fpor)
  case(1)
    t = (-sqrt(3/pi)/2)*x*fpor
    gx =  (-sqrt(3/pi)/2) * (f+x2*fpor)
    gy =  y*t
    gz =  z*t
  endselect
case(2)
  select case(m)
  case(-2)
    gx =  (sqrt(15/pi)/2) * (y*(f+x2*fpor))
    t = (sqrt(15/pi)/2)*x
    gy =  t*(f+y2*fpor)
    gz =  t*y*z*fpor
  case(-1)
    t = (-sqrt(15/pi)/2)*z
    gx =  t*x*y*fpor
    gy =  t*(f+y2*fpor)
    gz =  (-sqrt(15/pi)/2) * (y*(f+z2*fpor))
  case(0)
    t = (r2-3*z2)*fpor
    p = (-sqrt(5/pi)/4)*(t+f+f)
    gx =  x*p
    gy =  y*p
    gz =  (sqrt(5/pi)/4) * z*(4*f-t)
  case(1)
    t = (-sqrt(15/pi)/2) * z
    gx =  t*(f+x2*fpor)
    gy =  t*x*y*fpor
    gz =  (-sqrt(15/pi)/2) * x*(f+z2*fpor)
  case(2)
    t = (x2-y2)*fpor
    gx =  (sqrt(15/pi)/4) * x*(f+f+t)
    gy =  (-sqrt(15/pi)/4) * y*(f+f-t)
    gz =  (sqrt(15/pi)/4) * z*t
  endselect
case(3)
  select case(m)
  case(-3)
    t = (3*x2-y2)*fpor
    p = (-sqrt(70/pi)/8)*y
    gx =  p*x*(6*f+t)
    gy =  (-sqrt(70/pi)/8) * (3*(x2-y2)*f+t*y2)
    gz =  p*z*t
  case(-2)
    t = (sqrt(105/pi)/2)*z
    gx =  t*y*(f+x2*fpor)
    gy =  t*x*(f+y2*fpor)
    gz =  (sqrt(105/pi)/2) * x*y*(f+z2*fpor)
  case(-1)
    t = r2-5*z2
    p = t*fpor
    q = (sqrt(42/pi)/8)*y
    gx =  q*x*(f+f+p)
    gy =  (sqrt(42/pi)/8) * ((y2+y2+t)*f+p*y2)
    gz =  q*z*(p-8*f)
  case(0)
    t = 3*r2-5*z2
    p = t*fpor
    q = (-sqrt(7/pi)/4)*z*(6*f+(3*r2-5*z2)*fpor)
    gx =  q*x
    gy =  q*y
    gz =  (-sqrt(7/pi)/4) * ((t-4*z2)*f+p*z2)
  case(1)
    t = (r2-5*z2)*fpor
    p = (sqrt(42/pi)/8) * x
    gx =  (sqrt(42/pi)/8) * ((3*x2+y2-4*z2)*f+t*x2)
    gy =  p*y*(f+f+t)
    gz =  p*z*(t-8*f)
  case(2)
    t = x2-y2
    p = t*fpor
    q = f+f
    w = (sqrt(105/pi)/4)*z
    gx =  w*x*(p+q)
    gy =  w*y*(p-q)
    gz =  (sqrt(105/pi)/4) * t*(f+z2*fpor)
  case(3)
    t = (x2-3*y2)*fpor
    p = (-sqrt(70/pi)/8)*x
    gx =  (-sqrt(70/pi)/8) * (3*(x2-y2)*f+x2*t)
    gy =  p*y*(t-6*f)
    gz =  p*z*t
  endselect
case(4)
  select case(m)
  case(-4)
    t = (x2-y2)*fpor
    p = ((3*sqrt(35/pi))/4) * x
    gx =  ((3*sqrt(35/pi))/4) * y*(f*(3*x2-y2)+x2*t)
    gy =  p *((x2-3*y2)*f+y2*t)
    gz =  p*y*z*t
  case(-3)
    t = 3*x2-y2
    p = t * fpor
    q = (-(3*sqrt(70/pi))/8)*y
    gx =  q*x*z*(6*f+p)
    gy =  (-(3*sqrt(70/pi))/8) * z*(3*(x2-y2)*f+p*y2)
    gz =  q*t*(f+z2*fpor)
  case(-2)
    t = r2-7*z2
    p = t*fpor
    q = (-(3*sqrt(5/pi))/4)*y
    gx =  q*((3*x2+y2-6*z2)*f+p*x2)
    gy =  (-(3*sqrt(5/pi))/4) * x*((2*y2+t)*f+p*y2)
    gz =  q*x*z*(p-12*f)
  case(-1)
    t = 3*r2-7*z2
    p = t*fpor
    q = ((3*sqrt(10/pi))/8)*y
    gx =  q*x*z*(6*f+p)
    gy =  ((3*sqrt(10/pi))/8) * z*((6*y2+(3*r2-7*z2))*f+p*y2)
    gz =  q*((t-8*z2)*f+p*z2)
  case(0)
    t = (r2*(3*r2-30*z2)+35*z2**2)*fpor
    p = ((3/sqrt(pi))/16)*(12*(r2-5*z2)*f+t)
    gx =  p*x
    gy =  p*y
    gz =  (-(3/sqrt(pi))/16) * z*((48*r2-80*z2)*f-t)
  case(1)
    t = 3*r2-7*z2
    p = t*fpor
    q = ((3*sqrt(10/pi))/8)*x
    gx =  ((3*sqrt(10/pi))/8) * z*((9*r2-6*y2-13*z2)*f+x2*p)
    gy =  q*y*z*(6*f+p)
    gz =  q*((t-8*z2)*f+z2*p)
  case(2)
    t = x2-y2
    p = t*(r2-7*z2)*fpor
    gx =  (-(3*sqrt(5/pi))/8) * x*(4*(x2-3*z2)*f+p)
    gy =  ((3*sqrt(5/pi))/8) * y*(4*f*(y2-3*z2)-p)
    gz =  ((3*sqrt(5/pi))/8) * z*(12*t*f-p)
  case(3)
    t = x2-3*y2
    p = t*fpor
    q = (-(3*sqrt(70/pi))/8)*z
    gx =  q*(3*(x2-y2)*f+x2*p)
    gy =  q*x*y*(p-6*f)
    gz =  (-(3*sqrt(70/pi))/8) * x*(t*f+z2*p)
  case(4)
    t = ((r2-z2)**2-8*x2*y2)*fpor
    q = 4*f
    gx =  ((3*sqrt(35/pi))/16) * x*((x2-3*y2)*q+t)
    gy =  (-(3*sqrt(35/pi))/16) * y*((3*x2-y2)*q-t)
    gz =  (-(3*sqrt(35/pi))/16) * (z*t)
  endselect
endselect

end subroutine grad_frlSlm


END  MODULE COMMON_LIBRARY

