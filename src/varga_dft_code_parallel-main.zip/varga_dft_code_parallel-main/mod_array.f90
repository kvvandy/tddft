module mod_array
USE parameters
!This module declares data types that correspond to various nonrectangular
!1D, 2D, and 3D arrays  (for example a 2D array that may have a dirrerent
!number of elements in each row). It also provides subroutines to allocate
!and deallocate such arrays

!The type names are made up in such a way that the total number of D and F
!letters defines the total dimensionality and.
!For example suffix "_D_D" is for a array or arrays. "D" itself means nonfixed
!size in particular dimension. "F" means fixed size. "_FD" stands for
!a 2D array whose first dimension (max index) size is fixed. Note that "_F_F"
!and "_FF" are nt the same thing. The first is an array of arrays while the
!second is a 2D array. Essentially "_FF" and "_FD" are the same. However,
!"_DD" does not make sense ("_D_D" does make sense).


!Quick usage examples related to arrays of arrays:
!Allocate an array of k one-dimensional real arrays with lengths arrsize(1:k)
!  call allocate_array_D_D_real8(myarr,k,arrsize(1:k))
!or simply
!  call allocate_array_D_D(myarr,k,arrsize(1:k))
!Deallocate previously allocated array of array
!  call deallocate_array_D_D_real8(myarr)
!Access an element
!  b=myarr%d2(i)%d1(j)
!Determine the number of elements in i-th 1D array
!  j=myarr%d2(i)%nelem
!Determine the number of 1D subarrays in the array of arrays
!  j=myarr%nsubarr
!Determine the total number of elements in the array of arrays
!  j=myarr%nelem

private :: check_error

type :: array_D_integer
  integer          :: nelem
  integer, pointer :: d1(:)
end type array_D_integer

type :: array_D_D_integer
  integer                          :: nsubarr
  integer                          :: nelem
  type(array_D_integer), pointer   :: d2(:)
end type array_D_D_integer

type :: array_D_real8
  integer          :: nelem
  real(8), pointer :: d1(:)
end type array_D_real8

type :: array_D_D_real8
  integer                        :: nsubarr
  integer                        :: nelem
  type(array_D_real8), pointer   :: d2(:)
end type array_D_D_real8

type :: array_D_complex8
  integer             :: nelem
  complex(8), pointer :: d1(:)
end type array_D_complex8

type :: array_D_D_complex8
  integer                           :: nsubarr
  integer                           :: nelem
  type(array_D_complex8), pointer   :: d2(:)
end type array_D_D_complex8

type :: array_D_logical
  integer          :: nelem
  logical, pointer :: d1(:)
end type array_D_logical

type :: array_D_D_logical
  integer                          :: nsubarr
  integer                          :: nelem
  type(array_D_logical), pointer   :: d2(:)
end type array_D_D_logical

type :: array_FD_integer
  integer          :: nelem
  integer          :: d2size
  integer, pointer :: d21(:,:)
end type array_FD_integer

type :: array_D_FD_integer
  integer                         :: nelem
  integer                         :: nsubarr
  type(array_FD_integer), pointer :: d3(:)
end type array_D_FD_integer

type :: array_FD_real8
  integer          :: nelem
  integer          :: d2size
  real(8), pointer :: d21(:,:)
end type array_FD_real8

type :: array_D_FD_real8
  integer                       :: nelem
  integer                       :: nsubarr
  type(array_FD_real8), pointer :: d3(:)
end type array_D_FD_real8

type :: array_FD_complex8
  integer             :: nelem
  integer             :: d2size
  complex(8), pointer :: d21(:,:)
end type array_FD_complex8

type :: array_D_FD_complex8
  integer                          :: nelem
  integer                          :: nsubarr
  type(array_FD_complex8), pointer :: d3(:)
end type array_D_FD_complex8

type :: array_FD_logical
  integer             :: nelem
  integer             :: d2size
  logical, pointer    :: d21(:,:)
end type array_FD_logical

type :: array_D_FD_logical
  integer                          :: nelem
  integer                          :: nsubarr
  type(array_FD_logical), pointer  :: d3(:)
end type array_D_FD_logical

interface allocate_array_D
  module procedure allocate_array_D_integer, allocate_array_D_real8, &
                   allocate_array_D_complex8, allocate_array_D_logical
end interface

interface allocate_array_D_D
  module procedure allocate_array_D_D_integer, allocate_array_D_D_real8, &
                   allocate_array_D_D_complex8, allocate_array_D_D_logical
end interface

interface allocate_array_FD
  module procedure allocate_array_FD_integer, allocate_array_FD_real8, &
                   allocate_array_FD_complex8, allocate_array_FD_logical
end interface

interface allocate_array_D_FD
  module procedure allocate_array_D_FD_integer, allocate_array_D_FD_real8, &
                   allocate_array_D_FD_complex8, allocate_array_D_FD_logical
end interface


contains


subroutine check_error(error_code,str)
integer          :: error_code
character(len=*) :: str
if (error_code/=0) then
  write(log_file,*) str
  write(log_file,*) 'Error code :',error_code
  stop
endif
end subroutine check_error

subroutine allocate_array_D_integer(a, asize)
type(array_D_integer)      :: a
integer                    :: asize
integer                    :: error_code
allocate(a%d1(1:asize),stat=error_code)
call check_error(error_code,'Error in allocate_array_D_integer')
a%nelem=asize
end subroutine allocate_array_D_integer

subroutine deallocate_array_D_integer(a)
type(array_D_integer)      :: a
integer                    :: error_code
deallocate(a%d1,stat=error_code)
call check_error(error_code,'Error in deallocate_array_D_integer')
end subroutine deallocate_array_D_integer

subroutine allocate_array_D_D_integer(a,f2,f1)
type(array_D_D_integer)    :: a
integer                    :: f2
integer                    :: f1(:)
integer                    :: i,tot_elem_count,error_code
allocate(a%d2(1:f2),stat=error_code)
call check_error(error_code,'Error in allocate_array_D_D_integer')
a%nsubarr=f2
tot_elem_count=0
do i=1,f2
  allocate(a%d2(i)%d1(1:f1(i)),stat=error_code)
  call check_error(error_code,'Error in allocate_array_D_D_integer')
  a%d2(i)%nelem=f1(i)
  tot_elem_count=tot_elem_count+f1(i)
enddo
a%nelem=tot_elem_count
end subroutine allocate_array_D_D_integer

subroutine deallocate_array_D_D_integer(a)
type(array_D_D_integer)    :: a
integer                    :: i,error_code
do i=1,a%nsubarr
  deallocate(a%d2(i)%d1,stat=error_code)
  call check_error(error_code,'Error in deallocate_array_D_D_integer')
enddo
deallocate(a%d2,stat=error_code)
call check_error(error_code,'Error in deallocate_array_D_D_integer')
end subroutine deallocate_array_D_D_integer

subroutine allocate_array_D_real8(a, asize)
type(array_D_real8)        :: a
integer                    :: asize
integer                    :: error_code
allocate(a%d1(1:asize),stat=error_code)
call check_error(error_code,'Error in allocate_array_D_real8')
a%nelem=asize
end subroutine allocate_array_D_real8

subroutine deallocate_array_D_real8(a)
type(array_D_real8)        :: a
integer                    :: error_code
deallocate(a%d1,stat=error_code)
call check_error(error_code,'Error in deallocate_array_D_real8')
end subroutine deallocate_array_D_real8

subroutine allocate_array_D_D_real8(a,f2,f1)
type(array_D_D_real8)      :: a
integer                    :: f2
integer                    :: f1(:)
integer                    :: i,tot_elem_count,error_code
allocate(a%d2(1:f2),stat=error_code)
call check_error(error_code,'Error in allocate_array_D_D_real8')
a%nsubarr=f2
tot_elem_count=0
do i=1,f2
  allocate(a%d2(i)%d1(1:f1(i)),stat=error_code)
  call check_error(error_code,'Error in allocate_array_D_D_real8')
  a%d2(i)%nelem=f1(i)
  tot_elem_count=tot_elem_count+f1(i)
enddo
a%nelem=tot_elem_count
end subroutine allocate_array_D_D_real8

subroutine deallocate_array_D_D_real8(a)
type(array_D_D_real8)      :: a
integer                    :: i,error_code
do i=1,a%nsubarr
  deallocate(a%d2(i)%d1,stat=error_code)
  call check_error(error_code,'Error in deallocate_array_D_D_real8')
enddo
deallocate(a%d2,stat=error_code)
call check_error(error_code,'Error in deallocate_array_D_D_real8')
end subroutine deallocate_array_D_D_real8

subroutine allocate_array_D_complex8(a, asize)
type(array_D_complex8)     :: a
integer                    :: asize
integer                    :: error_code
allocate(a%d1(1:asize),stat=error_code)
call check_error(error_code,'Error in allocate_array_D_complex8')
a%nelem=asize
end subroutine allocate_array_D_complex8

subroutine deallocate_array_D_complex8(a)
type(array_D_complex8)     :: a
integer                    :: error_code
deallocate(a%d1,stat=error_code)
call check_error(error_code,'Error in deallocate_array_D_complex8')
end subroutine deallocate_array_D_complex8

subroutine allocate_array_D_D_complex8(a,f2,f1)
type(array_D_D_complex8)   :: a
integer                    :: f2
integer                    :: f1(:)
integer                    :: i,tot_elem_count,error_code
allocate(a%d2(1:f2),stat=error_code)
call check_error(error_code,'Error in allocate_array_D_D_complex8')
a%nsubarr=f2
tot_elem_count=0
do i=1,f2
  allocate(a%d2(i)%d1(1:f1(i)),stat=error_code)
  call check_error(error_code,'Error in allocate_array_D_D_complex8')
  a%d2(i)%nelem=f1(i)
  tot_elem_count=tot_elem_count+f1(i)
enddo
a%nelem=tot_elem_count
end subroutine allocate_array_D_D_complex8

subroutine deallocate_array_D_D_complex8(a)
type(array_D_D_complex8)   :: a
integer                    :: i,error_code
do i=1,a%nsubarr
  deallocate(a%d2(i)%d1,stat=error_code)
  call check_error(error_code,'Error in deallocate_array_D_D_complex8')
enddo
deallocate(a%d2,stat=error_code)
call check_error(error_code,'Error in deallocate_array_D_D_complex8')
end subroutine deallocate_array_D_D_complex8

subroutine allocate_array_D_logical(a, asize)
type(array_D_logical)      :: a
integer                    :: asize
integer                    :: error_code
allocate(a%d1(1:asize),stat=error_code)
call check_error(error_code,'Error in allocate_array_D_logical')
a%nelem=asize
end subroutine allocate_array_D_logical

subroutine deallocate_array_D_logical(a)
type(array_D_logical)     :: a
integer                   :: error_code
deallocate(a%d1,stat=error_code)
call check_error(error_code,'Error in deallocate_array_D_logical')
end subroutine deallocate_array_D_logical

subroutine allocate_array_D_D_logical(a,f2,f1)
type(array_D_D_logical)    :: a
integer                    :: f2
integer                    :: f1(:)
integer                    :: i,tot_elem_count,error_code
allocate(a%d2(1:f2),stat=error_code)
call check_error(error_code,'Error in allocate_array_D_D_logical')
a%nsubarr=f2
tot_elem_count=0
do i=1,f2
  allocate(a%d2(i)%d1(1:f1(i)),stat=error_code)
  call check_error(error_code,'Error in allocate_array_D_D_logical')
  a%d2(i)%nelem=f1(i)
  tot_elem_count=tot_elem_count+f1(i)
enddo
a%nelem=tot_elem_count
end subroutine allocate_array_D_D_logical

subroutine deallocate_array_D_D_logical(a)
type(array_D_D_logical)      :: a
integer                      :: i,error_code
do i=1,a%nsubarr
  deallocate(a%d2(i)%d1,stat=error_code)
  call check_error(error_code,'Error in deallocate_array_D_D_logical')
enddo
deallocate(a%d2,stat=error_code)
call check_error(error_code,'Error in deallocate_array_D_D_logical')
end subroutine deallocate_array_D_D_logical

subroutine allocate_array_FD_integer(a, f2, f1)
type(array_FD_integer)     :: a
integer                    :: f2, f1
integer                    :: error_code
allocate(a%d21(1:f2,1:f1),stat=error_code)
call check_error(error_code,'Error in allocate_array_FD_integer')
a%d2size=f2
a%nelem=f1*f2
end subroutine allocate_array_FD_integer

subroutine deallocate_array_FD_integer(a)
type(array_FD_integer)     :: a
integer                    :: error_code
deallocate(a%d21,stat=error_code)
call check_error(error_code,'Error in deallocate_array_FD_integer')
end subroutine deallocate_array_FD_integer

subroutine allocate_array_FD_real8(a, f2, f1)
type(array_FD_real8)       :: a
integer                    :: f2, f1
integer                    :: error_code
allocate(a%d21(1:f2,1:f1),stat=error_code)
call check_error(error_code,'Error in allocate_array_FD_real8')
a%d2size=f2
a%nelem=f1*f2
end subroutine allocate_array_FD_real8

subroutine deallocate_array_FD_real8(a)
type(array_FD_real8)       :: a
integer                    :: error_code
deallocate(a%d21,stat=error_code)
call check_error(error_code,'Error in deallocate_array_FD_real8')
end subroutine deallocate_array_FD_real8

subroutine allocate_array_FD_complex8(a, f2, f1)
type(array_FD_complex8)    :: a
integer                    :: f2, f1
integer                    :: error_code
allocate(a%d21(1:f2,1:f1),stat=error_code)
call check_error(error_code,'Error in allocate_array_FD_complex8')
a%d2size=f2
a%nelem=f1*f2
end subroutine allocate_array_FD_complex8

subroutine deallocate_array_FD_complex8(a)
type(array_FD_complex8)    :: a
integer                    :: error_code
deallocate(a%d21,stat=error_code)
call check_error(error_code,'Error in deallocate_array_FD_complex8')
end subroutine deallocate_array_FD_complex8

subroutine allocate_array_FD_logical(a, f2, f1)
type(array_FD_logical)     :: a
integer                    :: f2, f1
integer                    :: error_code
allocate(a%d21(1:f2,1:f1),stat=error_code)
call check_error(error_code,'Error in allocate_array_FD_logical')
a%d2size=f2
a%nelem=f1*f2
end subroutine allocate_array_FD_logical

subroutine deallocate_array_FD_logical(a)
type(array_FD_logical)     :: a
integer                    :: error_code
deallocate(a%d21,stat=error_code)
call check_error(error_code,'Error in deallocate_array_FD_logical')
end subroutine deallocate_array_FD_logical

subroutine allocate_array_D_FD_integer(a, f3, f2, f1)
type(array_D_FD_integer)    :: a
integer                     :: f3, f2, f1(f3)
integer                     :: error_code,i,tot_elem_count
allocate(a%d3(1:f3),stat=error_code)
call check_error(error_code,'Error in allocate_array_D_FD_integer')
a%nsubarr=f3
tot_elem_count=0
do i=1,f3
  allocate(a%d3(i)%d21(1:f2,1:f1(i)),stat=error_code)
  call check_error(error_code,'Error in allocate_array_D_FD_integer')
  a%d3(i)%nelem=f2*f1(i)
  a%d3(i)%d2size=f2
  tot_elem_count=tot_elem_count+f2*f1(i)
enddo
a%nelem=tot_elem_count
end subroutine allocate_array_D_FD_integer

subroutine deallocate_array_D_FD_integer(a)
type(array_D_FD_integer)    :: a
integer                     :: error_code,i
do i=1,a%nsubarr
  deallocate(a%d3(i)%d21,stat=error_code)
  call check_error(error_code,'Error in deallocate_array_D_FD_integer')
enddo
deallocate(a%d3,stat=error_code)
call check_error(error_code,'Error in deallocate_array_D_FD_integer')
end subroutine deallocate_array_D_FD_integer

subroutine allocate_array_D_FD_real8(a, f3, f2, f1)
type(array_D_FD_real8)      :: a
integer                     :: f3, f2, f1(f3)
integer                     :: error_code,i,tot_elem_count
allocate(a%d3(1:f3),stat=error_code)
call check_error(error_code,'Error in allocate_array_D_FD_real8')
a%nsubarr=f3
tot_elem_count=0
do i=1,f3
  allocate(a%d3(i)%d21(1:f2,1:f1(i)),stat=error_code)
  call check_error(error_code,'Error in allocate_array_D_FD_real8')
  a%d3(i)%nelem=f2*f1(i)
  a%d3(i)%d2size=f2
  tot_elem_count=tot_elem_count+f2*f1(i)
enddo
a%nelem=tot_elem_count
end subroutine allocate_array_D_FD_real8

subroutine deallocate_array_D_FD_real8(a)
type(array_D_FD_real8)      :: a
integer                     :: error_code,i
do i=1,a%nsubarr
  deallocate(a%d3(i)%d21,stat=error_code)
  call check_error(error_code,'Error in deallocate_array_D_FD_real8')
enddo
deallocate(a%d3,stat=error_code)
call check_error(error_code,'Error in deallocate_array_D_FD_real8')
end subroutine deallocate_array_D_FD_real8

subroutine allocate_array_D_FD_complex8(a, f3, f2, f1)
type(array_D_FD_complex8)      :: a
integer                     :: f3, f2, f1(f3)
integer                     :: error_code,i,tot_elem_count
allocate(a%d3(1:f3),stat=error_code)
call check_error(error_code,'Error in allocate_array_D_FD_complex8')
a%nsubarr=f3
tot_elem_count=0
do i=1,f3
  allocate(a%d3(i)%d21(1:f2,1:f1(i)),stat=error_code)
  call check_error(error_code,'Error in allocate_array_D_FD_complex8')
  a%d3(i)%nelem=f2*f1(i)
  a%d3(i)%d2size=f2
  tot_elem_count=tot_elem_count+f2*f1(i)
enddo
a%nelem=tot_elem_count
end subroutine allocate_array_D_FD_complex8

subroutine deallocate_array_D_FD_complex8(a)
type(array_D_FD_complex8)      :: a
integer                     :: error_code,i
do i=1,a%nsubarr
  deallocate(a%d3(i)%d21,stat=error_code)
  call check_error(error_code,'Error in deallocate_array_D_FD_complex8')
enddo
deallocate(a%d3,stat=error_code)
call check_error(error_code,'Error in deallocate_array_D_FD_complex8')
end subroutine deallocate_array_D_FD_complex8

subroutine allocate_array_D_FD_logical(a, f3, f2, f1)
type(array_D_FD_logical)      :: a
integer                     :: f3, f2, f1(f3)
integer                     :: error_code,i,tot_elem_count
allocate(a%d3(1:f3),stat=error_code)
call check_error(error_code,'Error in allocate_array_D_FD_logical')
a%nsubarr=f3
tot_elem_count=0
do i=1,f3
  allocate(a%d3(i)%d21(1:f2,1:f1(i)),stat=error_code)
  call check_error(error_code,'Error in allocate_array_D_FD_logical')
  a%d3(i)%nelem=f2*f1(i)
  a%d3(i)%d2size=f2
  tot_elem_count=tot_elem_count+f2*f1(i)
enddo
a%nelem=tot_elem_count
end subroutine allocate_array_D_FD_logical

subroutine deallocate_array_D_FD_logical(a)
type(array_D_FD_logical)      :: a
integer                     :: error_code,i
do i=1,a%nsubarr
  deallocate(a%d3(i)%d21,stat=error_code)
  call check_error(error_code,'Error in deallocate_array_D_FD_logical')
enddo
deallocate(a%d3,stat=error_code)
call check_error(error_code,'Error in deallocate_array_D_FD_logical')
end subroutine deallocate_array_D_FD_logical


end module mod_array
