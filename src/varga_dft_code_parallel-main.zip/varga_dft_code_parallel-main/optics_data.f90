!*************************************************************************
!*                                                                       *
!* Real-space, real-time TD/DFT calculation of molecular optical effects *
!* prepared 9 Aug 2001                                                   *
!* by J.-I.Iwata and K.Yabana, University of Tsukuba                     *
!* Modified by V.Goncharov 27 June 2010                                  *
!*                                                                       *
!*************************************************************************
 module optics_data

 	implicit none

!-------------------- Global variables

      integer :: Miter       ! Total number of Iteration for LDA
      integer :: MI,MKI,MST,MST_HOMO
      real(8)	:: Etot,Exc
!      real(8) :: H           ! no more Uniform Grid spacing

! Labels of grid points
      integer :: ML

! Pseudopotential

      real(8),allocatable :: occ(:)      ! Occupation number
      real(8),allocatable :: esp(:)      ! Single particle energy
      real(8),allocatable :: rho(:)      ! Single particle density
      real(8),allocatable :: Vxc(:)      ! Exchange-Correlation potential

! Exchange-Correlation potential (additional local option)
      character(4) :: XC
 ! hyp specific
      integer :: Na,Nb ! directions
!      character(4)  :: dir,fdir        !in mod_global for now
!      character(20) :: file_IN, process, Hyp_Info
      integer :: a,b,n
      real(8) :: dshif(3)
      real  :: ti1,ti2

! Dipole Operator

      real(8),allocatable :: D(:,:)

! Transition Densities

      real(8),allocatable :: dn1(:,:,:)  ,h1(:,:,:)
      real(8),allocatable :: dn2(:,:,:,:),h2(:,:,:,:)

! Hyperpolarizability tensors

      real(8) :: alphaF(3,3,2),alpha(3,3,2)
      real(8) :: betaF(3,3,3,3),beta(3,3,3,3)
      real(8) :: gammaF(3,3,3,3),gamma(3,3,3,3)

! Orientation averaged hyperpolarizabilities

      real(8) :: alphaF_av(2), alpha_av(2)
      real(8) :: betaF_av(3) , beta_av(3)
      real(8) :: gammaF_av   , gamma_av

!      real(8) :: hw(2)
      real(8) :: const
      real(8) :: ep,N_e
      real(8),allocatable :: Fxc(:),Gxc(:),Hxc(:)

! RT specific
! Coefficients of finite-difference
!      integer,parameter :: Nd=4      ! (2*Nd+1)-points finite-difference
      real(8),parameter :: cN0=-205.d0/72.d0                 ! for Laplacian
      real(8),parameter :: cN1=8.d0/5.d0  , cN2=-1.d0/5.d0
      real(8),parameter :: cN3=8.d0/315.d0, cN4=-1.d0/560.d0
      real(8),parameter :: bN1=4.d0/5.d0  , bN2=-1.d0/5.d0   ! for Nabla
      real(8),parameter :: bN3=4.d0/105.d0, bN4=-1.d0/280.d0

    real(8), parameter     :: lambda=0.01d0
    real(8),parameter       :: dE=0.01d0
    integer,parameter       :: Nenergy=3000
    real(8),allocatable :: alpha_R(:),alpha_I(:)
    real(8) :: Ds ! Static dipole moment
    real(8),allocatable    :: R(:),Rf(:,:)
    integer    :: fdir,ipt
    real(8), allocatable :: Pt(:,:,:) ! Time dependent polarizability array
    real(8),allocatable :: Ptot(:,:) ! evolution of polarization vector
    integer ::  orderp ! Order of polarization
!    real(8),allocatable :: Dp(:) ! Dipole moment
    integer, parameter      :: N_energy=3000 !number of energy steps
!    real(8), parameter      :: dE=0.01d0 !energy step

! interface
! subroutine PSolver(geocode,datacode,iproc,nproc,n01,n02,n03,ixc,hx,hy,hz,&
!     rhopot,karray,pot_ion,eh,exc,vxc,offset,sumpion,nspin)
!  implicit none
!  character(len=1), intent(in) :: geocode
!  character(len=1), intent(in) :: datacode
!  logical, intent(in) :: sumpion
!  integer, intent(in) :: iproc,nproc,n01,n02,n03,ixc,nspin
!  real(kind=8), intent(in) :: hx,hy,hz,offset
!  real(kind=8), dimension(*), intent(in) :: karray
!  real(kind=8), intent(out) :: eh,exc,vxc
!  real(kind=8), dimension(*), intent(inout) :: rhopot,pot_ion
!  end subroutine PSolver
!
! subroutine createKernel(geocode,n01,n02,n03,hx,hy,hz,itype_scf,iproc,nproc,kernel)
!  implicit none
!  character(len=1), intent(in) :: geocode
!  integer, intent(in) :: n01,n02,n03,itype_scf,iproc,nproc
!  real(kind=8), intent(in) :: hx,hy,hz
!  real(kind=8), pointer :: kernel(:)
!  end subroutine createKernel
! end interface

 end module optics_data
