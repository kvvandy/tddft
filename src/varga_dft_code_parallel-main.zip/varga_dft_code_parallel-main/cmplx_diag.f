      SUBROUTINE A02AAF(XXR,XXI,YR,YI)
C     MARK 2A RELEASE.  NAG COPYRIGHT 1973
C     MARK 4.5 REVISED
C     MARK 5C REVISED
C     MARK 11C REVISED. IER-467 (MAR 1985)
C     MARK 11.5(F77) REVISED. (SEPT 1985.)
C     COMPUTES THE SQUARE ROOT OF A COMPLEX NUMBER
C
C     .. Scalar Arguments ..
      DOUBLE PRECISION  XXI, XXR, YI, YR
C     .. Local Scalars ..
      DOUBLE PRECISION  H, HALF, ONE, XI, XR, ZERO
C     .. External Functions ..
      DOUBLE PRECISION  A02ABF
      EXTERNAL          A02ABF
C     .. Intrinsic Functions ..
      INTRINSIC         ABS, SQRT
C     .. Data statements ..
      DATA              ZERO/0.0D0/, HALF/0.5D0/, ONE/1.0D0/
C     .. Executable Statements ..
C
      XR = ABS(XXR)
      XI = XXI
      IF (XR.GT.ONE) H = SQRT(XR*HALF+A02ABF(XR*HALF,XI*HALF))
      IF (XR.LE.ONE) H = SQRT(XR+A02ABF(XR,XI))*SQRT(HALF)
      IF (XI.NE.ZERO) XI = XI/(H+H)
      IF (XXR.LT.ZERO) GO TO 20
      YR = H
      YI = XI
      RETURN
   20 IF (XI.LT.ZERO) GO TO 40
      YR = XI
      YI = H
      RETURN
   40 YR = -XI
      YI = -H
      RETURN
      END
      
      
      SUBROUTINE A02ACF(XXR,XXI,YYR,YYI,ZR,ZI)
C     MARK 2A RELEASE.  NAG COPYRIGHT 1973
C     MARK 4.5 REVISED
C     MARK 5C REVISED
C     MARK 11.5(F77) REVISED. (SEPT 1985.)
C
C     DIVIDES ONE COMPLEX NUMBER BY A SECOND
C
C     .. Scalar Arguments ..
      DOUBLE PRECISION  XXI, XXR, YYI, YYR, ZI, ZR
C     .. Local Scalars ..
      DOUBLE PRECISION  A, H, ONE
C     .. Intrinsic Functions ..
      INTRINSIC         ABS
C     .. Data statements ..
      DATA              ONE/1.0D0/
C     .. Executable Statements ..
C
      IF (ABS(YYR).LE.ABS(YYI)) GO TO 20
      H = YYI/YYR
      A = ONE/(H*YYI+YYR)
      ZR = (XXR+H*XXI)*A
      ZI = (XXI-H*XXR)*A
      RETURN
   20 H = YYR/YYI
      A = ONE/(H*YYR+YYI)
      ZR = (H*XXR+XXI)*A
      ZI = (H*XXI-XXR)*A
      RETURN
      END
      
      SUBROUTINE F02GJF(N,AR,IAR,AI,IAI,BR,IBR,BI,IBI,EPS1,ALFR,ALFI,
     *                  BETA,MATZ,ZR,IZR,ZI,IZI,ITER,IFAIL)
C     MARK 8 RELEASE. NAG COPYRIGHT 1979.
C     MARK 11.5(F77) REVISED. (SEPT 1985.)
C
C     THIS ROUTINE IS THE COMPLEX ANALOGUE OF THE QZ ALGORITHM FOR
C     SOLVING THE GENERALIZED MATRIX EIGENVALUE PROBLEM,
C     A*Z = LAMBDA*B*Z
C     WHERE A AND B ARE REAL SQUARE MATRICES.
C     REFERENCE
C     SIAM J. NUMER. ANAL., 10, PP241-256, 1973.
C     C.B. MOLER AND G.W. STEWART.
C
C     THIS BLACK BOX ROUTINE WAS WRITTEN BY
C     W. PHILLIPS OXFORD UNIVERSITY COMPUTING SERVICE
C
C     IT CALLS F02GJX, F02GJY AND F02GJZ WHICH
C     WERE OBTAINED FROM EISPACK.
C
C     .. Parameters ..
      CHARACTER*6       SRNAME
      PARAMETER         (SRNAME='F02GJF')
C     .. Scalar Arguments ..
      DOUBLE PRECISION  EPS1
      INTEGER           IAI, IAR, IBI, IBR, IFAIL, IZI, IZR, N
      LOGICAL           MATZ
C     .. Array Arguments ..
      DOUBLE PRECISION  AI(IAI,N), ALFI(N), ALFR(N), AR(IAR,N), BETA(N),
     *                  BI(IBI,N), BR(IBR,N), ZI(IZI,N), ZR(IZR,N)
      INTEGER           ITER(N)
C     .. Local Scalars ..
      INTEGER           ISAVE
C     .. Local Arrays ..
      CHARACTER*1       P01REC(1)
C     .. External Functions ..
      INTEGER           P01ABF
      EXTERNAL          P01ABF
C     .. External Subroutines ..
      EXTERNAL          F02GJX, F02GJY, F02GJZ
C     .. Executable Statements ..
      ISAVE = IFAIL
      IFAIL = 1
      CALL F02GJX(N,AR,IAR,AI,IAI,BR,IBR,BI,IBI,MATZ,ZR,IZR,ZI,IZI)
      CALL F02GJY(N,AR,IAR,AI,IAI,BR,IBR,BI,IBI,EPS1,ALFR,ALFI,BETA,
     *            MATZ,ZR,IZR,ZI,IZI,ITER,IFAIL)
      IF (IFAIL.EQ.0) GO TO 20
      IFAIL = P01ABF(ISAVE,IFAIL,SRNAME,0,P01REC)
      RETURN
   20 IF (MATZ) CALL F02GJZ(N,AR,IAR,AI,IAI,BR,IBR,BI,IBI,ALFR,ALFI,
     *                      BETA,ZR,IZR,ZI,IZI)
      RETURN
      END
      
      SUBROUTINE F02GJX(N,AR,IAR,AI,IAI,BR,IBR,BI,IBI,MATZ,ZR,IZR,ZI,
     *                  IZI)
C     MARK 8 RELEASE. NAG COPYRIGHT 1979.
C     MARK 11A REVISED. IER-450 (JUN 1984).
C     MARK 11.5(F77) REVISED. (SEPT 1985.)
C     MARK 12 REVISED. IER-516 (AUG 1986).
C
C     THIS ROUTINE IS A COMPLEX ANALOGUE OF THE FIRST STEP OF THE
C     QZ ALGORITHM FOR SOLVING GENERALIZED MATRIX EIGENVALUE
C     PROBLEMS,
C     SIAM J. NUMER. ANAL. 10, 241-256(1973) BY MOLER AND STEWART.
C
C     THIS ROUTINE ACCEPTS A PAIR OF COMPLEX GENERAL MATRICES AND
C     REDUCES ONE OF THEM TO UPPER HESSENBERG FORM WITH REAL (AND
C     NON-NEGATIVE) SUBDIAGONAL ELEMENTS AND THE OTHER TO UPPER
C     TRIANGULAR FORM USING UNITARY TRANSFORMATIONS. IT IS
C     USUALLY FOLLOWED BY F02GJY AND, POSSIBLY, F02GJZ.
C
C     ON INPUT
C
C     N IS THE ORDER OF THE MATRICES.
C
C     A = (AR,AI) CONTAINS A COMPLEX GENERAL MATRIX.
C
C     B = (BR,BI) CONTAINS A COMPLEX GENERAL MATRIX.
C
C     MATZ SHOULD BE SET TO .TRUE. IF THE RIGHT HAND TRANSFORMATIONS
C     ARE TO BE ACCUMULATED FOR LATER USE IN COMPUTING EIGENVECTORS,
C     AND TO .FALSE. OTHERWISE.
C
C     IAR,IAI,IBR,IBI,IZR AND IZI MUST SPECIFY THE FIRST DIMENSIONS
C     OF THE ARRAYS AR,AI,BR,BI,ZR AND ZI AS DECLARED IN THE CALLING
C     (SUB)PROGRAM.  IAR,IAI,IBR,IBI,IZR,IZI.GE.N  .
C
C     ON OUTPUT
C
C     A HAS BEEN REDUCED TO UPPER HESSENBERG FORM. THE ELEMENTS
C     BELOW THE FIRST SUBDIAGONAL HAVE BEEN REDUCED TO ZERO,
C     AND THE SUBDIAGONAL ELEMENTS HAVE BEEN MADE REAL
C     (AND NON-NEGATIVE).
C
C     B HAS BEEN REDUCED TO UPPER TRIANGULAR FORM. THE ELEMENTS
C     BELOW THE MAIN DIAGONAL HAVE BEEN SET TO ZERO.
C
C     Z = (ZR,ZI) CONTAINS THE PRODUCT OF THE RIGHT HAND
C     TRANSFORMATIONS IF MATZ HAS BEEN SET TO .TRUE.
C     OTHERWISE, Z IS NOT REFERENCED.
C
C     IMPLEMENTED FROM EISPACK BY
C     W. PHILLIPS OXFORD UNIVERSITY COMPUTING SERVICE.
C
C     .. Scalar Arguments ..
      INTEGER           IAI, IAR, IBI, IBR, IZI, IZR, N
      LOGICAL           MATZ
C     .. Array Arguments ..
      DOUBLE PRECISION  AI(IAI,N), AR(IAR,N), BI(IBI,N), BR(IBR,N),
     *                  ZI(IZI,N), ZR(IZR,N)
C     .. Local Scalars ..
      DOUBLE PRECISION  ONE, R, RHO, S, T, TI, U1, U1I, U2, XI, XR, YI,
     *                  YR, ZERO
      INTEGER           I, J, K, K1, L, L1, LB, NK1, NM1
C     .. External Functions ..
      DOUBLE PRECISION  A02ABF
      EXTERNAL          A02ABF
C     .. Intrinsic Functions ..
      INTRINSIC         ABS, SQRT
C     .. Data statements ..
      DATA              ZERO/0.0D0/, ONE/1.0D0/
C     .. Executable Statements ..
      IF ( .NOT. MATZ) GO TO 60
C
C     ---------- INITIALIZE Z ----------
      DO 40 I = 1, N
C
         DO 20 J = 1, N
            ZR(I,J) = ZERO
            ZI(I,J) = ZERO
   20    CONTINUE
C
         ZR(I,I) = ONE
   40 CONTINUE
C     ---------- REDUCE B TO UPPER TRIANGULAR FORM WITH
C     TEMPORARILY REAL DIAGONAL ELEMENTS ----------
   60 IF (N.LE.1) GO TO 500
      NM1 = N - 1
C
      DO 300 L = 1, NM1
         L1 = L + 1
         S = ZERO
C
         DO 80 I = L, N
            S = S + ABS(BR(I,L)) + ABS(BI(I,L))
   80    CONTINUE
C
         IF (S.EQ.ZERO) GO TO 300
         RHO = ZERO
C
         DO 100 I = L, N
            BR(I,L) = BR(I,L)/S
            BI(I,L) = BI(I,L)/S
            RHO = RHO + BR(I,L)**2 + BI(I,L)**2
  100    CONTINUE
C
         R = SQRT(RHO)
         XR = A02ABF(BR(L,L),BI(L,L))
         IF (XR.EQ.ZERO) GO TO 120
         RHO = RHO + XR*R
         U1 = -BR(L,L)/XR
         U1I = -BI(L,L)/XR
         YR = R/XR + ONE
         BR(L,L) = YR*BR(L,L)
         BI(L,L) = YR*BI(L,L)
         GO TO 140
C
  120    BR(L,L) = R
         U1 = -ONE
         U1I = ZERO
C
  140    DO 200 J = L1, N
            T = ZERO
            TI = ZERO
C
            DO 160 I = L, N
               T = T + BR(I,L)*BR(I,J) + BI(I,L)*BI(I,J)
               TI = TI + BR(I,L)*BI(I,J) - BI(I,L)*BR(I,J)
  160       CONTINUE
C
            T = T/RHO
            TI = TI/RHO
C
            DO 180 I = L, N
               BR(I,J) = BR(I,J) - T*BR(I,L) + TI*BI(I,L)
               BI(I,J) = BI(I,J) - T*BI(I,L) - TI*BR(I,L)
  180       CONTINUE
C
            XI = U1*BI(L,J) - U1I*BR(L,J)
            BR(L,J) = U1*BR(L,J) + U1I*BI(L,J)
            BI(L,J) = XI
  200    CONTINUE
C
         DO 260 J = 1, N
            T = ZERO
            TI = ZERO
C
            DO 220 I = L, N
               T = T + BR(I,L)*AR(I,J) + BI(I,L)*AI(I,J)
               TI = TI + BR(I,L)*AI(I,J) - BI(I,L)*AR(I,J)
  220       CONTINUE
C
            T = T/RHO
            TI = TI/RHO
C
            DO 240 I = L, N
               AR(I,J) = AR(I,J) - T*BR(I,L) + TI*BI(I,L)
               AI(I,J) = AI(I,J) - T*BI(I,L) - TI*BR(I,L)
  240       CONTINUE
C
            XI = U1*AI(L,J) - U1I*AR(L,J)
            AR(L,J) = U1*AR(L,J) + U1I*AI(L,J)
            AI(L,J) = XI
  260    CONTINUE
C
         BR(L,L) = R*S
         BI(L,L) = ZERO
C
         DO 280 I = L1, N
            BR(I,L) = ZERO
            BI(I,L) = ZERO
  280    CONTINUE
C
  300 CONTINUE
C     REDUCE A TO UPPER HESSENBERG FORM WITH REAL SUBDIAGONAL
C     ELEMENTS, WHILE KEEPING B TRIANGULAR
      DO 480 K = 1, NM1
         K1 = K + 1
C        SET BOTTOM ELEMENT IN K-TH COLUMN OF A REAL
         R = A02ABF(AR(N,K),AI(N,K))
         IF (R.EQ.ZERO) GO TO 340
         U1 = AR(N,K)/R
         U1I = AI(N,K)/R
         AR(N,K) = R
         AI(N,K) = ZERO
C
         DO 320 J = K1, N
            XI = U1*AI(N,J) - U1I*AR(N,J)
            AR(N,J) = U1*AR(N,J) + U1I*AI(N,J)
            AI(N,J) = XI
  320    CONTINUE
C
         XI = U1*BI(N,N) - U1I*BR(N,N)
         BR(N,N) = U1*BR(N,N) + U1I*BI(N,N)
         BI(N,N) = XI
  340    IF (K.EQ.NM1) GO TO 500
         NK1 = NM1 - K
C        ---------- FOR L=N-1 STEP -1 UNTIL K+1 DO -- ----------
         DO 460 LB = 1, NK1
            L = N - LB
            L1 = L + 1
C           ---------- ZERO A(L+1,K) ----------
            S = ABS(AR(L,K)) + ABS(AI(L,K)) + AR(L1,K)
            IF (S.EQ.ZERO) GO TO 460
            U1 = AR(L,K)/S
            U1I = AI(L,K)/S
            U2 = AR(L1,K)/S
            R = SQRT(U1*U1+U1I*U1I+U2*U2)
            U1 = U1/R
            U1I = U1I/R
            U2 = U2/R
            AR(L,K) = R*S
            AI(L,K) = ZERO
            AR(L1,K) = ZERO
C
            DO 360 J = K1, N
               XR = AR(L,J)
               XI = AI(L,J)
               YR = AR(L1,J)
               YI = AI(L1,J)
               AR(L,J) = U1*XR + U1I*XI + U2*YR
               AI(L,J) = U1*XI - U1I*XR + U2*YI
               AR(L1,J) = U1*YR - U1I*YI - U2*XR
               AI(L1,J) = U1*YI + U1I*YR - U2*XI
  360       CONTINUE
C
            XR = BR(L,L)
            BR(L,L) = U1*XR
            BI(L,L) = -U1I*XR
            BR(L1,L) = -U2*XR
C
            DO 380 J = L1, N
               XR = BR(L,J)
               XI = BI(L,J)
               YR = BR(L1,J)
               YI = BI(L1,J)
               BR(L,J) = U1*XR + U1I*XI + U2*YR
               BI(L,J) = U1*XI - U1I*XR + U2*YI
               BR(L1,J) = U1*YR - U1I*YI - U2*XR
               BI(L1,J) = U1*YI + U1I*YR - U2*XI
  380       CONTINUE
C           ---------- ZERO B(L+1,L) ----------
            S = ABS(BR(L1,L1)) + ABS(BI(L1,L1)) + ABS(BR(L1,L))
            IF (S.EQ.ZERO) GO TO 460
            U1 = BR(L1,L1)/S
            U1I = BI(L1,L1)/S
            U2 = BR(L1,L)/S
            R = SQRT(U1*U1+U1I*U1I+U2*U2)
            U1 = U1/R
            U1I = U1I/R
            U2 = U2/R
            BR(L1,L1) = R*S
            BI(L1,L1) = ZERO
            BR(L1,L) = ZERO
C
            DO 400 I = 1, L
               XR = BR(I,L1)
               XI = BI(I,L1)
               YR = BR(I,L)
               YI = BI(I,L)
               BR(I,L1) = U1*XR + U1I*XI + U2*YR
               BI(I,L1) = U1*XI - U1I*XR + U2*YI
               BR(I,L) = U1*YR - U1I*YI - U2*XR
               BI(I,L) = U1*YI + U1I*YR - U2*XI
  400       CONTINUE
C
            DO 420 I = 1, N
               XR = AR(I,L1)
               XI = AI(I,L1)
               YR = AR(I,L)
               YI = AI(I,L)
               AR(I,L1) = U1*XR + U1I*XI + U2*YR
               AI(I,L1) = U1*XI - U1I*XR + U2*YI
               AR(I,L) = U1*YR - U1I*YI - U2*XR
               AI(I,L) = U1*YI + U1I*YR - U2*XI
  420       CONTINUE
C
            IF ( .NOT. MATZ) GO TO 460
C
            DO 440 I = L - K + 1, N
               XR = ZR(I,L1)
               XI = ZI(I,L1)
               YR = ZR(I,L)
               YI = ZI(I,L)
               ZR(I,L1) = U1*XR + U1I*XI + U2*YR
               ZI(I,L1) = U1*XI - U1I*XR + U2*YI
               ZR(I,L) = U1*YR - U1I*YI - U2*XR
               ZI(I,L) = U1*YI + U1I*YR - U2*XI
  440       CONTINUE
C
  460    CONTINUE
C
  480 CONTINUE
C
  500 RETURN
      END
      
      SUBROUTINE F02GJY(N,AR,IAR,AI,IAI,BR,IBR,BI,IBI,EPS1,ALFR,ALFI,
     *                  BETA,MATZ,ZR,IZR,ZI,IZI,ITER,IERR)
C     MARK 8 RELEASE. NAG COPYRIGHT 1979.
C     MARK 9C REVISED. IER-369 (JUN 1982)
C     MARK 11.5(F77) REVISED. (SEPT 1985.)
C     MARK 12 REVISED. IER-517 (AUG 1986).
C     MARK 13 REVISED. USE OF MARK 12 X02 FUNCTIONS (APR 1988).
C     MARK 16A REVISED. IER-1002 (JUN 1993).
C
C     THIS ROUTINE IS A COMPLEX ANALOGUE OF STEPS 2 AND 3 OF THE
C     QZ ALGORITHM FOR SOLVING GENERALIZED MATRIX EIGENVALUE
C     PROBLEMS.
C     SIAM J. NUMER. ANAL. 10, 241-256(1973) BY MOLER AND STEWART,
C     AS MODIFIED IN TECHNICAL NOTE NASA TN D-7305(1973) BY WARD.
C
C     THIS ROUTINE ACCEPTS A PAIR OF COMPLEX MATRICES, ONE OF THEM
C     IN UPPER HESSENBERG FORM AND THE OTHER IN UPPER TRIANGULAR
C     FORM.
C     THE HESSENBERG MATRIX MUST FURTHER HAVE REAL SUBDIAGONAL
C     ELEMENTS.
C     IT REDUCES THE HESSENBERG MATRIX TO TRIANGULAR FORM USING
C     UNITARY TRANSFORMATIONS WHILE MAINTAINING THE TRIANGULAR FORM
C     OF THE OTHER MATRIX AND FURTHER MAKING ITS DIAGONAL ELEMENTS
C     REAL AND NON-NEGATIVE.  IT THEN RETURNS QUANTITIES WHOSE
C     RATIOS GIVE THE GENERALIZED EIGENVALUES. IT IS USUALLY
C     PRECEDED BY F02GJX AND POSSIBLY FOLLOWED BY F02GJZ.
C
C     ON INPUT
C
C     N IS THE ORDER OF THE MATRICES.
C
C     A=(AR,AI) CONTAINS A COMPLEX UPPER HESSENBERG MATRIX
C     WITH REAL SUBDIAGONAL ELEMENTS.
C
C     B=(BR,BI) CONTAINS A COMPLEX UPPER TRIANGULAR MATRIX.
C
C     EPS1 IS A TOLERANCE USED TO DETERMINE NEGLIGIBLE ELEMENTS.
C     EPS1 = 0.0 (OR NEGATIVE) MAY BE INPUT, IN WHICH CASE AN
C     ELEMENT WILL BE NEGLECTED ONLY IF IT IS LESS THAN ROUNDOFF
C     ERROR TIMES THE NORM OF ITS MATRIX.  IF THE INPUT EPS1 IS
C     POSITIVE, THEN AN ELEMENT WILL BE CONSIDERED NEGLIGIBLE
C     IF IT IS LESS THAN EPS1 TIMES THE NORM OF ITS MATRIX.  A
C     POSITIVE VALUE OF EPS1 MAY RESULT IN FASTER EXECUTION,
C     BUT LESS ACCURATE RESULTS.
C
C     MATZ SHOULD BE SET TO .TRUE. IF THE RIGHT HAND TRANSFORMATIONS
C     ARE TO BE ACCUMULATED FOR LATER USE IN COMPUTING
C     EIGENVECTORS, AND TO .FALSE. OTHERWISE.
C
C     Z=(ZR,ZI) CONTAINS, IF MATZ HAS BEEN SET TO .TRUE., THE
C     TRANSFORMATION MATRIX PRODUCED IN THE REDUCTION
C     BY  F02GJX, IF PERFORMED, OR ELSE THE IDENTITY MATRIX.
C     IF MATZ HAS BEEN SET TO .FALSE., Z IS NOT REFERENCED.
C
C     IAR, IAI, IBR, IBI, IZR AND IZI MUST SPECIFY THE FIRST
C     DIMENSIONS OF THE ARRAYS AR, AI, BR, BI, ZR AND ZI AS DECLARED
C     IN THE CALLING (SUB)PROGRAM.
C     IAR,IAI,IBR,IBI,IZR,IZI.GE.N  .
C
C     ON OUTPUT
C
C     A HAS BEEN REDUCED TO UPPER TRIANGULAR FORM.  THE ELEMENTS
C     BELOW THE MAIN DIAGONAL HAVE BEEN SET TO ZERO.
C
C     B IS STILL IN UPPER TRIANGULAR FORM, ALTHOUGH ITS ELEMENTS
C     HAVE BEEN ALTERED.  IN PARTICULAR, ITS DIAGONAL HAS BEEN SET
C     REAL AND NON-NEGATIVE.  THE LOCATION BR(N,1) IS USED TO
C     STORE EPS1 TIMES THE NORM OF B FOR LATER USE BY  F02GJZ.
C
C     ALFR AND ALFI CONTAIN THE REAL AND IMAGINARY PARTS OF THE
C     DIAGONAL ELEMENTS OF THE TRIANGULARIZED A MATRIX.
C
C     BETA CONTAINS THE REAL NON-NEGATIVE DIAGONAL ELEMENTS OF THE
C     CORRESPONDING B.  THE GENERALIZED EIGENVALUES ARE THEN
C     THE RATIOS ((ALFR+I*ALFI)/BETA).
C
C     Z CONTAINS THE PRODUCT OF THE RIGHT HAND TRANSFORMATIONS
C     (FOR BOTH STEPS) IF MATZ HAS BEEN SET TO .TRUE. .
C
C     ITER CONTAINS THE NUMBER OF ITERATIONS REQUIRED TO
C     ISOLATE EACH EIGENVALUE.
C
C     IERR IS SET TO
C     ZERO       FOR NORMAL RETURN,
C     J          MORE THAN 30*N ITERATIONS HAVE
C     BEEN PERFORMED ALTOGETHER
C
C     IMPLEMENTED FROM EISPACK BY
C     W. PHILLIPS OXFORD UNIVERSITY COMPUTING SERVICE.
C
C     .. Scalar Arguments ..
      DOUBLE PRECISION  EPS1
      INTEGER           IAI, IAR, IBI, IBR, IERR, IZI, IZR, N
      LOGICAL           MATZ
C     .. Array Arguments ..
      DOUBLE PRECISION  AI(IAI,N), ALFI(N), ALFR(N), AR(IAR,N), BETA(N),
     *                  BI(IBI,N), BR(IBR,N), ZI(IZI,N), ZR(IZR,N)
      INTEGER           ITER(N)
C     .. Local Scalars ..
      DOUBLE PRECISION  A1, A1I, A2, A33, A33I, A34, A34I, A43, A43I,
     *                  A44, A44I, ANI, ANORM, B11, B33, B3344, B3344I,
     *                  B33I, B44, B44I, BNI, BNORM, EP, EPSA, EPSB,
     *                  ONE, R, S, SH, SHI, TWO, U1, U1I, U2, XI, XR,
     *                  YI, YR, ZERO
      INTEGER           EN, ENM2, ENORN, I, ITSTOT, J, K, K1, K2, KM1,
     *                  L, L1, LL, LM1, LOR1, NA
C     .. External Functions ..
      DOUBLE PRECISION  A02ABF, X02AJF
      EXTERNAL          A02ABF, X02AJF
C     .. External Subroutines ..
      EXTERNAL          A02AAF, A02ACF
C     .. Intrinsic Functions ..
      INTRINSIC         ABS, MAX, SQRT
C     .. Data statements ..
      DATA              ZERO/0.0D0/, ONE/1.0D0/, TWO/2.0D0/
C     .. Executable Statements ..
      IERR = 0
C     ---------- COMPUTE EPSA,EPSB ----------
      ANORM = ZERO
      BNORM = ZERO
      ITSTOT = 0
C
      DO 40 I = 1, N
         ITER(I) = 0
         ANI = ZERO
         IF (I.NE.1) ANI = ABS(AR(I,I-1))
         BNI = ZERO
C
         DO 20 J = I, N
            ANI = ANI + ABS(AR(I,J)) + ABS(AI(I,J))
            BNI = BNI + ABS(BR(I,J)) + ABS(BI(I,J))
   20    CONTINUE
C
         IF (ANI.GT.ANORM) ANORM = ANI
         IF (BNI.GT.BNORM) BNORM = BNI
   40 CONTINUE
C
      IF (ANORM.EQ.ZERO) ANORM = ONE
      IF (BNORM.EQ.ZERO) BNORM = ONE
      EP = EPS1
      IF (EP.LE.ZERO) EP = X02AJF()
      EPSA = EP*ANORM
      EPSB = EP*BNORM
C     REDUCE A TO TRIANGULAR FORM, WHILE KEEPING B TRIANGULAR
      LOR1 = 1
      ENORN = N
      EN = N
C     ---------- BEGIN QZ STEP ----------
   60 IF (EN.EQ.0) GO TO 540
      IF ( .NOT. MATZ) ENORN = EN
      NA = EN - 1
      ENM2 = NA - 1
C     CHECK FOR CONVERGENCE OR REDUCIBILITY.
C     FOR L=EN STEP -1 UNTIL 1 DO
   80 DO 100 LL = 1, EN
         LM1 = EN - LL
         L = LM1 + 1
         IF (L.EQ.1) GO TO 140
         IF (ABS(AR(L,LM1)).LE.EPSA) GO TO 120
  100 CONTINUE
C
  120 AR(L,LM1) = ZERO
C     ---------- SET DIAGONAL ELEMENT AT TOP OF B REAL ----------
  140 B11 = A02ABF(BR(L,L),BI(L,L))
      IF (B11.EQ.ZERO) GO TO 180
      U1 = BR(L,L)/B11
      U1I = BI(L,L)/B11
C
      DO 160 J = L, ENORN
         XI = U1*AI(L,J) - U1I*AR(L,J)
         AR(L,J) = U1*AR(L,J) + U1I*AI(L,J)
         AI(L,J) = XI
         XI = U1*BI(L,J) - U1I*BR(L,J)
         BR(L,J) = U1*BR(L,J) + U1I*BI(L,J)
         BI(L,J) = XI
  160 CONTINUE
C
      BI(L,L) = ZERO
  180 IF (L.NE.EN) GO TO 200
C     ---------- 1-BY-1 BLOCK ISOLATED ----------
      ALFR(EN) = AR(EN,EN)
      ALFI(EN) = AI(EN,EN)
      BETA(EN) = B11
      EN = NA
      GO TO 60
C     ---------- CHECK FOR SMALL TOP OF B ----------
  200 L1 = L + 1
      IF (B11.GT.EPSB) GO TO 240
      BR(L,L) = ZERO
      S = ABS(AR(L,L)) + ABS(AI(L,L)) + ABS(AR(L1,L))
      U1 = AR(L,L)/S
      U1I = AI(L,L)/S
      U2 = AR(L1,L)/S
      R = SQRT(U1*U1+U1I*U1I+U2*U2)
      U1 = U1/R
      U1I = U1I/R
      U2 = U2/R
      AR(L,L) = R*S
      AI(L,L) = ZERO
C
      DO 220 J = L1, ENORN
         XR = AR(L,J)
         XI = AI(L,J)
         YR = AR(L1,J)
         YI = AI(L1,J)
         AR(L,J) = U1*XR + U1I*XI + U2*YR
         AI(L,J) = U1*XI - U1I*XR + U2*YI
         AR(L1,J) = U1*YR - U1I*YI - U2*XR
         AI(L1,J) = U1*YI + U1I*YR - U2*XI
         XR = BR(L,J)
         XI = BI(L,J)
         YR = BR(L1,J)
         YI = BI(L1,J)
         BR(L,J) = U1*XR + U1I*XI + U2*YR
         BI(L,J) = U1*XI - U1I*XR + U2*YI
         BR(L1,J) = U1*YR - U1I*YI - U2*XR
         BI(L1,J) = U1*YI + U1I*YR - U2*XI
  220 CONTINUE
C
      LM1 = L
      L = L1
      GO TO 120
C     ---------- ITERATION STRATEGY ----------
  240 IF (ITSTOT.GE.30*N) GO TO 520
      IF (ITER(EN).EQ.10) GO TO 320
C     ---------- DETERMINE SHIFT ----------
      B33 = BR(NA,NA)
      B33I = BI(NA,NA)
      IF (A02ABF(B33,B33I).GE.EPSB) GO TO 260
      B33 = EPSB
      B33I = ZERO
  260 B44 = BR(EN,EN)
      B44I = BI(EN,EN)
      IF (A02ABF(B44,B44I).GE.EPSB) GO TO 280
      B44 = EPSB
      B44I = ZERO
  280 B3344 = B33*B44 - B33I*B44I
      B3344I = B33*B44I + B33I*B44
      A33 = AR(NA,NA)*B44 - AI(NA,NA)*B44I
      A33I = AR(NA,NA)*B44I + AI(NA,NA)*B44
      A34 = AR(NA,EN)*B33 - AI(NA,EN)*B33I - AR(NA,NA)*BR(NA,EN) +
     *      AI(NA,NA)*BI(NA,EN)
      A34I = AR(NA,EN)*B33I + AI(NA,EN)*B33 - AR(NA,NA)*BI(NA,EN) -
     *       AI(NA,NA)*BR(NA,EN)
      A43 = AR(EN,NA)*B44
      A43I = AR(EN,NA)*B44I
      A44 = AR(EN,EN)*B33 - AI(EN,EN)*B33I - AR(EN,NA)*BR(NA,EN)
      A44I = AR(EN,EN)*B33I + AI(EN,EN)*B33 - AR(EN,NA)*BI(NA,EN)
      SH = A44
      SHI = A44I
      XR = A34*A43 - A34I*A43I
      XI = A34*A43I + A34I*A43
      IF (XR.EQ.ZERO .AND. XI.EQ.ZERO) GO TO 310
      YR = (A33-SH)/TWO
      YI = (A33I-SHI)/TWO
      CALL A02AAF(YR**2-YI**2+XR,TWO*YR*YI+XI,U1,U1I)
      IF (YR*U1+YI*U1I.GE.ZERO) GO TO 300
      U1 = -U1
      U1I = -U1I
  300 CALL A02ACF(XR,XI,YR+U1,YI+U1I,YR,YI)
      SH = SH - YR
      SHI = SHI - YI
  310 CALL A02ACF(SH,SHI,B3344,B3344I,YR,YI)
      SH = YR
      SHI = YI
C     ---------- DETERMINE ZEROTH COLUMN OF A ----------
      A1 = AR(L,L)/B11 - SH
      A1I = AI(L,L)/B11 - SHI
      A2 = AR(L1,L)/B11
      GO TO 340
C     ---------- AD HOC SHIFT ----------
  320 A1 = 1.0D0
      A1I = ZERO
      A2 = 1.1605D0
  340 CONTINUE
      ITER(EN) = ITER(EN) + 1
      ITSTOT = ITSTOT + 1
      IF ( .NOT. MATZ) LOR1 = L
C     ---------- MAIN LOOP ----------
      DO 480 K = L, NA
         K1 = K + 1
         K2 = K + 2
         KM1 = MAX(K-1,L)
C        ---------- ZERO A(K+1,K-1) ----------
         IF (K.EQ.L) GO TO 360
         A1 = AR(K,KM1)
         A1I = AI(K,KM1)
         A2 = AR(K1,KM1)
  360    S = ABS(A1) + ABS(A1I) + ABS(A2)
         U1 = A1/S
         U1I = A1I/S
         U2 = A2/S
         R = SQRT(U1*U1+U1I*U1I+U2*U2)
         U1 = U1/R
         U1I = U1I/R
         U2 = U2/R
C
         DO 380 J = KM1, ENORN
            XR = AR(K,J)
            XI = AI(K,J)
            YR = AR(K1,J)
            YI = AI(K1,J)
            AR(K,J) = U1*XR + U1I*XI + U2*YR
            AI(K,J) = U1*XI - U1I*XR + U2*YI
            AR(K1,J) = U1*YR - U1I*YI - U2*XR
            AI(K1,J) = U1*YI + U1I*YR - U2*XI
            XR = BR(K,J)
            XI = BI(K,J)
            YR = BR(K1,J)
            YI = BI(K1,J)
            BR(K,J) = U1*XR + U1I*XI + U2*YR
            BI(K,J) = U1*XI - U1I*XR + U2*YI
            BR(K1,J) = U1*YR - U1I*YI - U2*XR
            BI(K1,J) = U1*YI + U1I*YR - U2*XI
  380    CONTINUE
C
         IF (K.EQ.L) GO TO 400
         AI(K,KM1) = ZERO
         AR(K1,KM1) = ZERO
         AI(K1,KM1) = ZERO
C        ---------- ZERO B(K+1,K) ----------
  400    S = ABS(BR(K1,K1)) + ABS(BI(K1,K1)) + ABS(BR(K1,K))
         U1 = BR(K1,K1)/S
         U1I = BI(K1,K1)/S
         U2 = BR(K1,K)/S
         R = SQRT(U1*U1+U1I*U1I+U2*U2)
         U1 = U1/R
         U1I = U1I/R
         U2 = U2/R
         IF (K.EQ.NA) GO TO 420
         XR = AR(K2,K1)
         AR(K2,K1) = U1*XR
         AI(K2,K1) = -U1I*XR
         AR(K2,K) = -U2*XR
C
  420    DO 440 I = LOR1, K1
            XR = AR(I,K1)
            XI = AI(I,K1)
            YR = AR(I,K)
            YI = AI(I,K)
            AR(I,K1) = U1*XR + U1I*XI + U2*YR
            AI(I,K1) = U1*XI - U1I*XR + U2*YI
            AR(I,K) = U1*YR - U1I*YI - U2*XR
            AI(I,K) = U1*YI + U1I*YR - U2*XI
            XR = BR(I,K1)
            XI = BI(I,K1)
            YR = BR(I,K)
            YI = BI(I,K)
            BR(I,K1) = U1*XR + U1I*XI + U2*YR
            BI(I,K1) = U1*XI - U1I*XR + U2*YI
            BR(I,K) = U1*YR - U1I*YI - U2*XR
            BI(I,K) = U1*YI + U1I*YR - U2*XI
  440    CONTINUE
C
         BI(K1,K1) = ZERO
         BR(K1,K) = ZERO
         BI(K1,K) = ZERO
         IF ( .NOT. MATZ) GO TO 480
C
         DO 460 I = 1, N
            XR = ZR(I,K1)
            XI = ZI(I,K1)
            YR = ZR(I,K)
            YI = ZI(I,K)
            ZR(I,K1) = U1*XR + U1I*XI + U2*YR
            ZI(I,K1) = U1*XI - U1I*XR + U2*YI
            ZR(I,K) = U1*YR - U1I*YI - U2*XR
            ZI(I,K) = U1*YI + U1I*YR - U2*XI
  460    CONTINUE
C
  480 CONTINUE
C     SET LAST A SUBDIAGONAL REAL AND END QZ STEP
      IF (AI(EN,NA).EQ.ZERO) GO TO 80
      R = A02ABF(AR(EN,NA),AI(EN,NA))
      U1 = AR(EN,NA)/R
      U1I = AI(EN,NA)/R
      AR(EN,NA) = R
      AI(EN,NA) = ZERO
C
      DO 500 J = EN, ENORN
         XI = U1*AI(EN,J) - U1I*AR(EN,J)
         AR(EN,J) = U1*AR(EN,J) + U1I*AI(EN,J)
         AI(EN,J) = XI
         XI = U1*BI(EN,J) - U1I*BR(EN,J)
         BR(EN,J) = U1*BR(EN,J) + U1I*BI(EN,J)
         BI(EN,J) = XI
  500 CONTINUE
C
      GO TO 80
C     ---------- SET ERROR -- BOTTOM SUBDIAGONAL ELEMENT HAS NOT
C     BECOME NEGLIGIBLE AFTER 50 ITERATIONS ----------
  520 IERR = EN
C     ---------- SAVE EPSB FOR USE BY F02GJZ ----------
  540 IF (N.GT.1) BR(N,1) = EPSB
      RETURN
      END
      
      SUBROUTINE F02GJZ(N,AR,IAR,AI,IAI,BR,IBR,BI,IBI,ALFR,ALFI,BETA,ZR,
     *                  IZR,ZI,IZI)
C     MARK 8 RELEASE. NAG COPYRIGHT 1979.
C     MARK 11.5(F77) REVISED. (SEPT 1985.)
C
C     THIS ROUTINE IS A COMPLEX ANALOGUE OF THE FOURTH STEP OF THE
C     QZ ALGORITHM FOR SOLVING GENERALIZED MATRIX EIGENVALUE
C     PROBLEMS
C     SIAM J. NUMER. ANAL. 10, 241-256(1973) BY MOLER AND STEWART.
C
C     THIS ROUTINE ACCEPTS A PAIR OF COMPLEX MATRICES IN UPPER
C     TRIANGULAR FORM, WHERE ONE OF THEM FURTHER MUST HAVE REAL
C     DIAGONAL ELEMENTS. IT COMPUTES THE EIGENVECTORS OF THE
C     TRIANGULAR PROBLEM AND TRANSFORMS THE RESULTS BACK TO THE
C     ORIGINAL COORDINATE SYSTEM. IT IS USUALLY PRECEDED BY
C     F02GJX AND F02GJY.
C
C     ON INPUT
C
C     N IS THE ORDER OF THE MATRICES.
C
C     A=(AR,AI) CONTAINS A COMPLEX UPPER TRIANGULAR MATRIX.
C
C     B=(BR,BI) CONTAINS A COMPLEX UPPER TRIANGULAR MATRIX WITH REAL
C     DIAGONAL ELEMENTS.  IN ADDITION, LOCATION BR(N,1) CONTAINS
C     THE TOLERANCE QUANTITY (EPSB) COMPUTED AND SAVED IN  F02GJY.
C
C     ALFR, ALFI, AND BETA ARE VECTORS WITH COMPONENTS WHOSE
C     RATIOS ((ALFR+I*ALFI)/BETA) ARE THE GENERALIZED
C     EIGENVALUES.  THEY ARE USUALLY OBTAINED FROM F02GJY.
C
C     Z=(ZR,ZI) CONTAINS THE TRANSFORMATION MATRIX PRODUCED IN THE
C     REDUCTIONS BY  F02GJX  AND  F02GJY, IF PERFORMED.
C     IF THE EIGENVECTORS OF THE TRIANGULAR PROBLEM ARE
C     DESIRED, Z MUST CONTAIN THE IDENTITY MATRIX.
C
C     IAR, IAI, IBR, IBI, IZR AND IZI MUST SPECIFY THE FIRST
C     DIMENSIONS OF THE ARRAYS AR, AI, BR, BI, ZR AND ZI AS DECLARED
C     IN THE CALLING (SUB)PROGRAM.
C     IAR,IAI,IBR,IBI,IZR,IZI.GE.N  .
C
C     ON OUTPUT
C
C     A IS UNALTERED.
C
C     B HAS BEEN DESTROYED.
C
C     ALFR, ALFI, AND BETA ARE UNALTERED.
C
C     Z CONTAINS THE EIGENVECTORS.  EACH EIGENVECTOR IS NORMALIZED
C     SO THAT THE SUM OF SQUARES OF THE MODULI OF THE COMPONENTS IS
C     EQUAL TO 1.0 AND THE COMPONENT OF LARGEST MODULUS IS REAL.
C
C     IMPLEMENTED FROM EISPACK BY
C     W. PHILLIPS OXFORD UNIVERSITY COMPUTING SERVICE.
C
C     .. Scalar Arguments ..
      INTEGER           IAI, IAR, IBI, IBR, IZI, IZR, N
C     .. Array Arguments ..
      DOUBLE PRECISION  AI(IAI,N), ALFI(N), ALFR(N), AR(IAR,N), BETA(N),
     *                  BI(IBI,N), BR(IBR,N), ZI(IZI,N), ZR(IZR,N)
C     .. Local Scalars ..
      DOUBLE PRECISION  ALMI, ALMR, BETM, C, D, EPSB, MAX, R, RI, SUM,
     *                  T, TERM, TI, XI, ZERO
      INTEGER           EN, I, II, J, JJ, K, M, NA, NN
C     .. External Subroutines ..
      EXTERNAL          A02ACF
C     .. Intrinsic Functions ..
      INTRINSIC         ABS, SQRT
C     .. Data statements ..
      DATA              ZERO/0.0D0/
C     .. Executable Statements ..
      IF (N.LE.1) GO TO 300
      EPSB = BR(N,1)
C     ---------- FOR EN=N STEP -1 UNTIL 2 DO -- ----------
      DO 80 NN = 2, N
         EN = N + 2 - NN
         NA = EN - 1
         ALMR = ALFR(EN)
         ALMI = ALFI(EN)
         BETM = BETA(EN)
C        ---------- FOR I=EN-1 STEP -1 UNTIL 1 DO -- ----------
         DO 60 II = 1, NA
            I = EN - II
            R = ZERO
            RI = ZERO
            M = I + 1
C
            DO 40 J = M, EN
               T = BETM*AR(I,J) - ALMR*BR(I,J) + ALMI*BI(I,J)
               TI = BETM*AI(I,J) - ALMR*BI(I,J) - ALMI*BR(I,J)
               IF (J.EQ.EN) GO TO 20
               XI = T*BI(J,EN) + TI*BR(J,EN)
               T = T*BR(J,EN) - TI*BI(J,EN)
               TI = XI
   20          R = R + T
               RI = RI + TI
   40       CONTINUE
C
            T = ALMR*BETA(I) - BETM*ALFR(I)
            TI = ALMI*BETA(I) - BETM*ALFI(I)
            IF (T.EQ.ZERO .AND. TI.EQ.ZERO) T = EPSB
            CALL A02ACF(R,RI,T,TI,BR(I,EN),BI(I,EN))
   60    CONTINUE
C
   80 CONTINUE
C     END BACK SUBSTITUTION.
C     TRANSFORM THE ORIGINAL COORDINATE SYSTEM.
C     FOR J=N STEP -1 UNTIL 2 DO
      DO 140 JJ = 2, N
         J = N + 2 - JJ
         M = J - 1
C
         DO 120 I = 1, N
C
            DO 100 K = 1, M
               ZR(I,J) = ZR(I,J) + ZR(I,K)*BR(K,J) - ZI(I,K)*BI(K,J)
               ZI(I,J) = ZI(I,J) + ZR(I,K)*BI(K,J) + ZI(I,K)*BR(K,J)
  100       CONTINUE
C
  120    CONTINUE
  140 CONTINUE
C     NORMALIZE SO THAT THE SUM OF SQUARES OF THE MODULI OF THE
C     COMPONENTS IS EQUAL TO 1.0 AND THE COMPONENT OF LARGEST
C     MODULUS IS REAL.
      DO 280 I = 1, N
         SUM = ZERO
         MAX = ZERO
         DO 180 J = 1, N
            IF (ABS(ZR(J,I)).LE.MAX) GO TO 160
            MAX = ABS(ZR(J,I))
  160       IF (ABS(ZI(J,I)).LE.MAX) GO TO 180
            MAX = ABS(ZI(J,I))
  180    CONTINUE
         DO 200 J = 1, N
            ZR(J,I) = ZR(J,I)/MAX
            ZI(J,I) = ZI(J,I)/MAX
  200    CONTINUE
         MAX = ZERO
         DO 240 J = 1, N
            TERM = ZR(J,I)**2 + ZI(J,I)**2
            SUM = SUM + TERM
            IF (TERM.LE.MAX) GO TO 220
            MAX = TERM
            C = ZR(J,I)
            D = -ZI(J,I)
  220       CONTINUE
  240    CONTINUE
         SUM = SUM*(C**2+D**2)
         SUM = SQRT(SUM)
         DO 260 J = 1, N
            TERM = ZR(J,I)
            ZR(J,I) = (ZR(J,I)*C-ZI(J,I)*D)/SUM
            ZI(J,I) = (D*TERM+C*ZI(J,I))/SUM
  260    CONTINUE
  280 CONTINUE
C
  300 RETURN
      END
      
      
      
