#!/usr/bin/env perl
use strict;
use warnings;

my $mode=0; # 0=add, 1=remove
my $parameters_filename="parameters.f90";

##############################
# End of user-defined values #
##############################

if(scalar(@ARGV)!=0) {
  die "\n  Usage: make_memusage_code.pl\n\n";
}

# The file ID to be used for memory usage write statements is set in parameters.f90.
# The parameter name is "memory_log_file".
open(my $INPUT_FILE,"<$parameters_filename") or die "\n\nUnable to open file \"$parameters_filename\"\n";
my $file_contents=join('',<$INPUT_FILE>);
close($INPUT_FILE);

my $file_ID;
if($file_contents=~/memory_log_file\s*=\s*(\S+)[,\s\n]+/i) {
  $file_ID=$1;
} else {
  die "\n  ERROR: Could not set file ID\n\n";
}

go();

chdir("Poisson");
go();

chdir("Poisson_S");
go();

chdir("..");

###############
# Subroutines #
###############

sub go {
  # Get a list of source files in the current directory
  my $directory_list=`ls -1 *.f*`;
  chomp($directory_list);
  my @filenames=split('\n',$directory_list);

  if($mode==0) {
    foreach my $filename (@filenames) {
      add_memory_usage_code($filename,$filename);
    }
  } elsif($mode==1) {
    foreach my $filename (@filenames) {
      remove_memory_usage_code($filename,$filename);
    }
  } else {
    die "\n  ERROR: invalid mode\n\n";
  }
}

sub remove_memory_usage_code {
  my ($input_filename,$output_filename)=@_;
  open(my $INPUT_FILE,"<$input_filename") or die "\n\nUnable to open file \"$input_filename\"\n";

  my @output_lines=();
  while(my $file_line=<$INPUT_FILE>) {
    if($file_line!~/write\s*\($file_ID/i) {
      push(@output_lines,$file_line);
    } elsif($file_line=~/\!\s*keep/i) {
      push(@output_lines,$file_line);
    }
  }
  close($INPUT_FILE);

  open(my $OUTPUT_FILE,">$output_filename") or die "\n\nUnable to open file \"$output_filename\"\n";
  foreach my $output_line (@output_lines) {
    print $OUTPUT_FILE $output_line;
  }
  close($OUTPUT_FILE);
}

sub parse_declaration {
#integer
#real
#complex
#logical
#character
#user-defined
  
  my ($type,$line_continued)=(-1,0);
  my @lines=split(/\n/,chomp_plus($_[0]));
  foreach my $line (@lines) {
    if(($line=~/^\s*$/)||($line=~/^\s*\!/)) {
      next;
    }
    
    if($line=~/^\s*integer[\s\*\(]+/) {
      $type=0;
    } elsif($line=~/^\s*real[\s\*\(]+/) {
      $type=1;
    } elsif($line=~/^\s*complex[\s\*\(]+/) {
      $type=2;
    } elsif($line=~/^\s*logical[\s\*\(]+/) {
      $type=3;
    } elsif($line=~/^\s*type[\s\*\(]+/) {
      $type=4;
    } else {
      last;
    }            
    
    if($line=~/\&\s*$/) {
      $line_continued=1;
    }
  }  
}

sub add_memory_usage_code {
  my ($input_filename,$output_filename)=@_;
  open(my $INPUT_FILE,"<$input_filename") or die "\n\nUnable to open file \"$input_filename\"\n";

  my (@subroutine_parts,@output_lines)=(())x2;
  my ($in_subroutine,$in_allocation,$allocation_paren_counter,$deallocation_paren_counter)=(0)x4;
  my $in_deallocation=0;
  my ($subroutine_contents,$subroutine_name,$allocation_contents,$deallocation_contents)=("")x4;
  while(my $file_line=<$INPUT_FILE>) {
    if($file_line=~/write\s*\($file_ID/i) {
      if($file_line=~/\!\s*keep/i) {
        push(@output_lines,$file_line);
      }
      next;
    }

    if($file_line=~/^\s*$/) {
      push(@output_lines,$file_line);
      next;
    } elsif($file_line=~/^\s*subroutine\s+(\S+)\s*/i) {
      $in_subroutine=1;
      $subroutine_name=$1;
      if($subroutine_name=~/^\s*(\S+)\s*\(/) {
        $subroutine_name=$1;
      }
    } elsif($file_line=~/^\s*end\s+subroutine/i) {
      $in_subroutine=0;
      push(@subroutine_parts,[($subroutine_name,$subroutine_contents)]);
      ($subroutine_contents,$subroutine_name)=("")x2;
    } elsif($in_subroutine==1) {
      $subroutine_contents.=$file_line;
    }

    if($file_line=~/^\s*allocate\s*\(/) {
      $in_allocation=1;
    }

    if($file_line=~/^\s*deallocate\s*\(/) {
      $in_deallocation=1;
    }

    if(($in_allocation==0)&&($in_deallocation==0)) {
      push(@output_lines,$file_line);
    }

    if($in_allocation==1) {
      $allocation_contents.=$file_line;
      my $temp=$file_line;
      while($temp=~s/\(//) {
        $allocation_paren_counter++;
      }

      $temp=$file_line;
      while($temp=~s/\)//) {
        $allocation_paren_counter--;
      }

      if($allocation_paren_counter==0) {
        $in_allocation=0;
        my @variables=@{parse_allocation($allocation_contents)};
        push(@output_lines,$allocation_contents);
        $allocation_contents="";

        if(scalar(@variables)>0) {
          foreach my $var_name (@variables) {          
            push(@output_lines,"  write($file_ID,'(3a)',advance=\"no\")\"A:\",char(9),\"$input_filename\"");
            push(@output_lines,"  write($file_ID,'(3a)',advance=\"no\")char(9),\"$subroutine_name\",char(9)");
            push(@output_lines,"  write($file_ID,'(2a,i20)')\"$var_name\",char(9),size($var_name)\n";            
          }
        }
      }
    }

    if($in_deallocation==1) {
      $deallocation_contents.=$file_line;
      my $temp=$file_line;
      while($temp=~s/\(//) {
        $deallocation_paren_counter++;
      }

      $temp=$file_line;
      while($temp=~s/\)//) {
        $deallocation_paren_counter--;
      }

      if($deallocation_paren_counter==0) {
        $in_deallocation=0;
        my @variables=@{parse_deallocation($deallocation_contents)};

        if(scalar(@variables)>0) {
          foreach my $var_name (@variables) {
            push(@output_lines,"  write($file_ID,'(3a)',advance=\"no\")\"D:\",char(9),\"$input_filename\"");
            push(@output_lines,"  write($file_ID,'(3a)',advance=\"no\")char(9),\"$subroutine_name\",char(9)");
            push(@output_lines,"  write($file_ID,'(2a,i20)')\"$var_name\",char(9),size($var_name)\n";     
          }
        }
        push(@output_lines,$deallocation_contents);
        $deallocation_contents="";
      }
    }
  }
  close($INPUT_FILE);

  open(my $OUTPUT_FILE,">$output_filename") or die "\n\nUnable to open file \"$output_filename\"\n";
  foreach my $output_line (@output_lines) {
    print $OUTPUT_FILE $output_line;
  }
  close($OUTPUT_FILE);
}

sub chomp_plus {
  my $string=$_[0];
  $string=~s/^\s+//;
  chomp($string);
  return $string;
}

sub parse_allocation {
  my $allocation_contents=chomp_plus($_[0]);

  $allocation_contents=~s/[&\n\s]//g;
  $allocation_contents=~s/allocate\s*\(//ig;

  my $paren_counter=1;
  my $var_name="";
  my @variables=();
  for(my $i=0; $i<length($allocation_contents); $i++) {
    my $character=substr($allocation_contents,$i,1);
    if($character=~/^\s*$/) {
      next;
    }

    if($character=~/\(/) {
      $paren_counter++;
      if((length($var_name)>0)&&($var_name!~/=/)) {
        push(@variables,$var_name);
      }
      $var_name="";
    } elsif($character=~/\)/) {
      $paren_counter--;
      if((length($var_name)>0)&&($var_name!~/=/)) {
        push(@variables,$var_name);
      }
      $var_name="";
    } elsif(($character!~/,/)&&($paren_counter==1)) {
      $var_name.=$character;
    }
  }
  return \@variables;
}

sub parse_deallocation {
  my $deallocation_contents=chomp_plus($_[0]);
  $deallocation_contents=~s/[&\n\s]//g;
  $deallocation_contents=~/deallocate\s*\(\s*(\S+)\s*\)/i;
  my @variables=split(/,/,$1);
  return \@variables;
}
