#!/usr/bin/env perl
use strict;
use warnings;

##############################
# End of user-defined values #
##############################

# Process command-line arguments
if(scalar(@ARGV)!=2) {
  die "\n  Usage: parse_memusage_data.pl <input_filename> <output_filename>\n\n";
}
my ($input_filename,$output_filename)=@ARGV;
chomp($output_filename);

my ($memory_allocated,$counter)=(0)x2;
open(my $INPUT_FILE,"<$input_filename") or die "\n\nUnable to open file \"$input_filename\"\n";
open(my $OUTPUT_FILE,">$output_filename") or die "\n\nUnable to open file \"$output_filename\"\n";
while(my $file_line=<$INPUT_FILE>) {
  if($file_line=~/^\s*(\S+)\s+(\S+)\s+(\S+)\s+(\S+)\s+(\S+)\s*$/) {
    my ($type,$amount)=($1,$5);

    if($type=~/a/i) {
      $memory_allocated+=$amount;
    } elsif($type=~/d/i) {
      $memory_allocated-=$amount;
    }
    print $OUTPUT_FILE "$counter\t$memory_allocated\t".($memory_allocated/1024.0)."\t"
      .($memory_allocated/(1024.0*1024.0))."\t".($memory_allocated/(1024.0*1024.0*1024.0))."\n";
    $counter++;
  }
}
close($INPUT_FILE);
close($OUTPUT_FILE);
