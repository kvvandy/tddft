Module EXCPOT
  implicit none
  double precision, parameter ::  thrd=.333333333333333333d0,pi=3.14159265358979312d0, &
& pisq3=.296088132032680740d2,thrd2=.666666666666666666d0,eps= 1.d-15,crs=1.91915829267751281d0
  
contains
  
subroutine ggax(mode,rh,grad_rh,grad_abs_grad_rh,lap_rh,xpot,xen)
! exchange potential & energy density
! LSDA - GGA
! Hartree a.u.
!
! input
!    mode = 1           LSDA
!    mode = 2           GGA-X Becke
!    mode = 3           GGA-X Perdew
!    mode = 5           GGA-X Burke-Perdew-Ernzerhof
!    rh:                density
!    grad_rh            gradient of density
!    abs_grad_rh        abs value of gradient of density
!    grad_abs_grad_rh   abs value of gradient of density
!    grad_zeta          gradient of zeta
!    lap_rh             laplace of density
!    xpot()             up/down exchange potential
!    xen                exchange energy density, i.e. per electron
!
  implicit none
  double precision :: rh(2),xpot(2),xen,grad_rh(3),grad_abs_grad_rh(3),lap_rh
  double precision :: d,ex,vx,ux,uy,uz,u,v,s,k_f
  integer          :: mode,i
                      
  xen=0.d0
  do i=1,2
    if(rh(i) .le. eps) then
      xpot(i)=0.d0
    else
      d=2.d0*rh(i)
      if(mode .eq. 1) then
        call xlda(d,vx,ex)
      else if(mode .eq. 2 .or. mode .eq. 3 .or. mode .eq. 5) then
        k_f =(pisq3*d)**thrd
        ux=grad_rh(1)**2
        uy=grad_rh(2)**2
        uz=grad_rh(3)**2
        s=0.5d0*sqrt(ux+uy+uz)/(k_f*d)
        ux=grad_rh(1)*grad_abs_grad_rh(1)
        uy=grad_rh(2)*grad_abs_grad_rh(2)
        uz=grad_rh(3)*grad_abs_grad_rh(3)
        u=(ux+uy+uz)/(d**2*(2.d0*k_f)**3)
        v=lap_rh/(d*(2.d0*k_f)**2)                                                       
        if(mode .eq. 2) then
          call xbecke(d,s,u,v,ex,vx)
        else if(mode .eq. 3) then
          call exch(d,s,u,v,ex,vx)
        else if(mode .eq. 5) then
          call exchpbe(d,s,u,v,1,1,ex,vx)
        endif
      else
        stop 'ggax mode improper'
      endif
      xpot(i) = vx
      xen=xen+rh(i)*ex
    endif
  end do
  xen = xen/max(rh(1)+rh(2),eps)
    
end subroutine ggax



subroutine ggac(mode,rh,grad_rh,grad_abs_grad_rh,grad_zeta,lap_rh,grad_up,grad_dw,cpot,cen)
! correlation potential & energy density
! spherical symmetry
! LSDA - GGA
! Hartree a.u.
!
! input
!    mode = 1           LSDA
!    mode = 2           GGA-C Perdew 91
!    mode = 3           GGA-C Perdew 86
!    mode = 4           GGA-C Lee-Yang-Parr 1988
!    mode = 5           GGA-C Burke-Perdew-Ernzerhof
!    rh()               spin up/down density
!    grad_rh            gradient of density
!    grad_up            gradient of density  spin up
!    grad_dw            gradient of density  spin_down
!    grad_abs_grad_rh   abs value of gradient of density
!    grad_zeta          gradient of zeta
!    lap_rh             laplace of density
!   
! output
!    zet                spin polarization
!    cpot()             correlation potential
!    cen                correlation energy density
implicit none
  integer           ::  mode
  double precision  ::  rh(2),grad_rh(3),grad_abs_grad_rh(3),grad_zeta(3),lap_rh,cpot(2),cen
  double precision  ::  grad_up(3),grad_dw(3)
  double precision  ::  sk,fk,ux,uy,uz,d,zet,g,gks2,gks2sq,dp11,dp22,dp12
  double precision  ::  t,uu,ww,vv,rs,ec,h,vcup,vcdn,ecrs,eczet,alfc,dvcup,dvcdn


! LSDA
  d = rh(1)+rh(2)
  cen=0.d0
  if(d .le. eps) then
    cen=0.d0
    cpot(1)=0.d0
    cpot(2)=0.d0
  else
    if(mode .ne. 4) then
      zet=(rh(1)-rh(2))/d
      fk=(pisq3*d)**thrd
      rs=crs/fk
! GGA correction to LSDA
      if(mode .eq. 1) then
        call corlsd(rs,zet,ec,vcup,vcdn,ecrs,eczet,alfc)
        dvcup=0.d0
        dvcdn=0.d0
        h=0.d0
      else if(mode .eq. 2) then
        call corlsd(rs,zet,ec,vcup,vcdn,ecrs,eczet,alfc)
        sk=2.d0*dsqrt(fk/pi)
        g=((1.d0+zet)**thrd2 + (1.d0-zet)**thrd2) /2.d0
        gks2=2.d0*sk*g
        gks2sq=gks2*gks2
!   t: abs(grad d)/(d*2.*ks*g)
!   uu: (grad d)*grad(abs(grad d))/(d**2 * (2*ks*g)**3)
!   vv: (laplacian d)/(d * (2*ks*g)**2)
!   ww: (grad d)*(grad zet)/(d * (2*ks*g)**2 )
        t=sqrt(grad_rh(1)**2+grad_rh(2)**2+grad_rh(3)**2)/(d*gks2)                              
        ux=grad_rh(1)*grad_abs_grad_rh(1)
        uy=grad_rh(2)*grad_abs_grad_rh(2)
        uz=grad_rh(3)*grad_abs_grad_rh(3)
        uu=(ux+uy+uz)/(d*d*gks2sq*gks2)
        vv=lap_rh/(d*gks2sq)
        ux=grad_rh(1)*grad_zeta(1)
        uy=grad_rh(2)*grad_zeta(2)
        uz=grad_rh(3)*grad_zeta(3)
        ww=(ux+uy+uz)/(d*gks2sq)
        call corgga(rs,fk,sk,g,ec,ecrs,eczet,zet,t,uu,vv,ww,h,dvcup,dvcdn)
      else if(mode .eq. 3) then
        call corlsd(rs,zet,ec,vcup,vcdn,ecrs,eczet,alfc)
!  dp11..: grad(d1)*grad(d1) 
!  dp22..: grad(d2)*grad(d2) 
!  dp12..: grad(d1)*grad(d2) {* == vector product}, MUST NOT == 0
!  uu    : (grad d)*grad(abs(grad d)) , d = d1 + d2
!  vv    : laplacian d
        ux=grad_rh(1)*grad_abs_grad_rh(1)
        uy=grad_rh(2)*grad_abs_grad_rh(2)
        uz=grad_rh(3)*grad_abs_grad_rh(3)
        uu=(ux+uy+uz)
        vv=lap_rh
        ux=grad_up(1)*grad_up(1)
        uy=grad_up(2)*grad_up(2)
        uz=grad_up(3)*grad_up(3)
        dp11=ux+uy+uz
        ux=grad_dw(1)*grad_dw(1)
        uy=grad_dw(2)*grad_dw(2)
        uz=grad_dw(3)*grad_dw(3)
        dp22=ux+uy+uz
        ux=grad_up(1)*grad_dw(1)
        uy=grad_up(2)*grad_dw(2)
        uz=grad_up(3)*grad_dw(3)
        dp12=ux+uy+uz
        if(abs(dp12)>1.d-20) call corga86(rh(1),rh(2),dp11,dp22,dp12,uu,vv,h,dvcup,dvcdn)
      else if(mode .eq. 5) then
        sk=2.d0*dsqrt(fk/pi)
        g=((1.d0+zet)**thrd2 + (1.d0-zet)**thrd2) /2.d0
        gks2=2.d0*sk*g
        gks2sq=gks2*gks2
!   t=ABS(GRAD rho)/(rho*2.*KS*G)  
!   UU=(GRAD rho)*GRAD(ABS(GRAD rho))/(rho**2 * (2*KS*G)**3)
!   VV=(LAPLACIAN rho)/(rho * (2*KS*G)**2)
!   WW=(GRAD rho)*(GRAD ZET)/(rho * (2*KS*G)**2 )
        t=sqrt(grad_rh(1)**2+grad_rh(2)**2+grad_rh(3)**2)/(d*gks2)                              
        ux=grad_rh(1)*grad_abs_grad_rh(1)
        uy=grad_rh(2)*grad_abs_grad_rh(2)
        uz=grad_rh(3)*grad_abs_grad_rh(3)
        uu=(ux+uy+uz)/(d*d*gks2sq*gks2)
        vv=lap_rh/(d*gks2sq)
        ux=grad_rh(1)*grad_zeta(1)
        uy=grad_rh(2)*grad_zeta(2)
        uz=grad_rh(3)*grad_zeta(3)
        ww=(ux+uy+uz)/(d*gks2sq)                                  
        call CORPBE(rs,zet,t,uu,vv,ww,1,1,ec,vcup,vcdn,h,dvcup,dvcdn)
      else
        stop 'ggac : mode improper'
      endif
    endif
  cpot(1)=vcup+dvcup
  cpot(2)=vcdn+dvcdn
  cen=ec+h
  endif
                   
end subroutine ggac


end Module EXCPOT


!  Becke exchange for a spin-unpolarized electronic system 
!
!  Gradient-corrected exchange energy based on
!     [A.D. Becke, J.Chem.Phys.96, 2155, 1992].
!  The LSDA energy functional, obtained as E{n+,n-}=(E{2n+}+E{2n-})/2,
!     and the functional derivative formula are given by 
!     [J.P. Perdew , PRB 33, 8800, 1986].
!     [J.P. Perdew , PRB 34, 7406, 1986].
!  see also [G.Ortiz ...,PRB 43, 6376 (1991)] eq. (A2)
!  
!  Hartree a.u.
!
!  input
!  d            density
!  s            abs(grad d)/(2kf*d)
!  u            (grad d)*grad(abs(grad d))/(d**2 * (2*kf)**3)
!           >>  grad(abs(grad d) has mixed derivatives ! <<
!  v            (laplacian d)/(d*(2*kf)**2)
!
!  output
!  ex           exchange energy per electron
!  vx           exchange potential
!

      subroutine xbecke(d,s,u,v,ex,vx)

      implicit real*8 (a-h,o-z)
      data c / .779555417944150792d1/
      data b / .42d-2/
      data bb/-.451357747124625192d-2/
      data ax/-.738558766382022406d0/
      data thrd,thrd4/.333333333333333333d0,.1333333333333333333d1/
      intrinsic dlog, dsqrt
!
! exchange enhancement factor f
      x  = c*s
      y1 = 1.d0/dsqrt(1.d0+x*x)
      y0 = dlog(x+1.d0/y1)
      y2 = -x*y1*y1*y1
      ddi= 1.d0/(1.d0 + 6.d0*b*x*y0)
      dd1= 6.d0*b*(y0+x*y1)
      g  = 1.d0 - 0.5d0*x*dd1*ddi
      fs = -2.d0*bb*c*c*ddi
      g1 = -3.d0*b*(y0+x*(3.d0*y1+x*y2-dd1*dd1*ddi/(6.d0*b)))
      fss= fs*c*(g1 - g*dd1)*ddi
      fs = fs*g
      f  = 1.d0 - bb*x*x*ddi
!
! LDA only
      fac= ax*d**thrd
!
! energy
      ex = fac*f
!
! potential
      vx = fac*(thrd4*f-(u-thrd4*s*s*s)*fss-v*fs)
!
      return
      end


!
!  gradient-correction to correlation energy from
!  
!  [J.P.Perdew, PRB 33, 8822 (1986) and PRB 34, 7406 (1986)]
!
!  to correlation part of the Becke-Perdew gradient-corrected 
!  xc-functional
!
!  input
!  d1,d2 : up/down spindensity
!  dp12..: grad(d1)*grad(d2) {* == vector product}, MUST NOT == 0
!  uu    : (grad d)*grad(abs(grad d)) , d = d1 + d2
!  vv    : laplacian d
!
!  output
!  dec  : correction to correlation energy per electron      
!  dvcup :         - "" -            potential maj. spin
!  dvcdn :         - "" -            potential min. spin
!
!  Hartree a.u.
!

      subroutine corga86(d1,d2,dp11,dp22,dp12,uu,vv,dec,dvcup,dvcdn)

      implicit real*8 (a-h,o-z)

      data a1,a2,a3,a4,a5,a6,a7/ 2.568d-3,1.443307452d-2,2.843543831d-6,5.411317331d0, &
        1.816419933d-1,1.763993811d-2,8.12908d-4/
      data t13,t23,t43,t53,t76/	.33333333333333333d0,.66666666666666667d0,.13333333333333333d1, &
        .16666666666666667d1,.11666666666666667d1/
      data crt2/.1587401052d1/
!
      d    = d1+d2
      dm13 = 1.d0/d**t13
      d43  = d**t43
!
! gradient expansion coefficient
      c1 = a1 + dm13*(a2+dm13*a3)
      c2 = 1.d0 + dm13*(a4+dm13*(a5+dm13*a6))
      c  = 1.667d-3 + c1/c2
!
      dpnorm = sqrt(dp11+dp22+2.d0*dp12)
      dpnorm2= dpnorm*dpnorm
!
      fi = a7*dpnorm/(c*d**t76)
!
! spin interpolation
      zet= (d1-d2)/d
      dd = sqrt(.5d0*((1.d0+zet)**t53 + (1.d0-zet)**t53))
!
! dC(n)/dn
      cp = -t13/(d43*c2*c2)*(c2*(a2+2.d0*a3*dm13)-c1*(a4+dm13*(2.d0*a5+dm13*3.d0*a6)))
!
! spin-independent terms
      www=( (fi-1.d0)*(cp/c-t43/d)+(fi-2.d0)*fi*(cp/c+t76/d) )*dpnorm2
      uuu=(3.d0-fi)*fi*uu/dpnorm
      vvv=(fi-2.d0)*vv
!
! spin dependent term     
      zzz=crt2*.5d0*t53/(dd*d43)**2*(d1**t23-d2**t23)
      zz1= zzz*((1.d0-fi)*d2*dpnorm2-(2.d0-fi)*d*(dp12+dp22))
      zz2=-zzz*((1.d0-fi)*d1*dpnorm2-(2.d0-fi)*d*(dp12+dp11))

      if(abs(fi)<200) then
        dec=c/(dd*exp(fi)*d43)
	  else
	    dec=0
	  end if
!
      dvcup=dec*(www+uuu+vvv+zz1)
      dvcdn=dec*(www+uuu+vvv+zz2)
      dec=dec*dpnorm2/d
!
      return
      end

!-----------------------------------------------------------------------
!  Perdew - Wang GGA91 exchange-correlation functional
!
!  J.P. Perdew et.al., Phys.Rev.B 46, 6671 (1992)
!
!  w/out gradients it's the new parametrization of the Ceperley-Alder
!  xc-energy data from
!
!  J.P. Perdew et.al., Phys.Rev.B 45, 13244 (1992)
!
!  pure spin singularity numerically removed
!
! original version by J P Perdew
!-----------------------------------------------------------------------
!
!  gga91 exchange for a spin-unpolarized electronic system
!  input d : density
!  input s:  abs(grad d)/(2*kf*d)
!  input u:  (grad d)*grad(abs(grad d))/(d**2 * (2*kf)**3)
!  input v: (laplacian d)/(d*(2*kf)**2)
!  output:  exchange energy per electron (ex) and potential (vx)
!
      subroutine exch(d,s,u,v,ex,vx)
!
      implicit real*8 (a-h,o-z)
      data a1,a2,a3,a4/0.19645d0,0.27430d0,0.15084d0,100.d0/
      data ax,a,b1/-0.7385588d0,7.7956d0,0.004d0/
      data thrd,thrd4/0.333333333333d0,1.33333333333d0/
      fac = ax*d**thrd
      s2 = s*s
      s3 = s2*s
      s4 = s2*s2
      p0 = 1.d0/dsqrt(1.d0+a*a*s2)
      p1 = dlog(a*s+1.d0/p0)
      p2 = dexp(-a4*s2)
      p3 = 1.d0/(1.d0+a1*s*p1+b1*s4)
      p4 = 1.d0+a1*s*p1+(a2-a3*p2)*s2
      f = p3*p4
      ex = fac*f
!  local exchange option
!     ex = fac
!  energy done. now the potential:
      p5 = b1*s2-(a2-a3*p2)
      p6 = a1*s*(p1+a*s*p0)
      p7 = 2.d0*(a2-a3*p2)+2.d0*a3*a4*s2*p2-4.d0*b1*s2*f
      fs = p3*(p3*p5*p6+p7)
      p8 = 2.d0*s*(b1-a3*a4*p2)
      p9 = a1*p1+a*a1*s*p0*(3.d0-a*a*s2*p0*p0)
      p10 = 4.d0*a3*a4*s*p2*(2.d0-a4*s2)-8.d0*b1*s*f-4.d0*b1*s3*fs
      p11 = -p3*p3*(a1*p1+a*a1*s*p0+4.d0*b1*s3)
      fss = p3*p3*(p5*p9+p6*p8)+2.d0*p3*p5*p6*p11+p3*p10+p7*p11
      vx = fac*(thrd4*f-(u-thrd4*s3)*fss-v*fs)
!
!  local exchange option:
!     vx = fac*thrd4
      return
      end

      subroutine corlsd(rs,zet,ec,vcup,vcdn,ecrs,eczet,alfc)
!  uniform-gas correlation of perdew and wang 1991
!  input: seitz radius (rs), relative spin polarization (zet)
!  output: correlation energy per electron (ec), up- and down-spin
!     potentials (vcup,vcdn), derivatives of ec wrt rs (ecrs) & zet (eczet)
!  output: correlation contribution (alfc) to the spin stiffness
      implicit real*8 (a-h,o-z)
      data gam,fzz/0.5198421d0,1.709921d0/
      data thrd,thrd4/0.333333333333d0,1.333333333333d0/
      f = ((1.d0+zet)**thrd4+(1.d0-zet)**thrd4-2.d0)/gam
      call gcor(0.0310907d0,0.21370d0,7.5957d0,3.5876d0,1.6382d0,0.49294d0,1.00d0,rs,eu,eurs)
      call gcor(0.01554535d0,0.20548d0,14.1189d0,6.1977d0,3.3662d0,0.62517d0,1.00d0,rs,ep,eprs)
      call gcor(0.0168869d0,0.11125d0,10.357d0,3.6231d0,0.88026d0,0.49671d0,1.00d0,rs,alfm,alfrsm)
!  alfm is minus the spin stiffness alfc
      alfc = -alfm
      z4 = zet**4
      ec = eu*(1.d0-f*z4)+ep*f*z4-alfm*f*(1.d0-z4)/fzz
!  energy done. now the potential:
      ecrs = eurs*(1.d0-f*z4)+eprs*f*z4-alfrsm*f*(1.d0-z4)/fzz
      fz = thrd4*((1.d0+zet)**thrd-(1.d0-zet)**thrd)/gam
      eczet = 4.d0*(zet**3)*f*(ep-eu+alfm/fzz)+fz*(z4*ep-z4*eu-(1.d0-z4)*alfm/fzz)
      comm = ec -rs*ecrs/3.d0-zet*eczet
      vcup = comm + eczet
      vcdn = comm - eczet
      return
      end

      subroutine gcor(a,a1,b1,b2,b3,b4,p,rs,gg,ggrs)

!  called by subroutine corlsd
      implicit real*8 (a-h,o-z)
      p1 = p + 1.d0
      q0 = -2.d0*a*(1.d0+a1*rs)
      rs12 = dsqrt(rs)
      rs32 = rs12**3
      rsp = rs**p
      q1 = 2.d0*a*(b1*rs12+b2*rs+b3*rs32+b4*rs*rsp)
      q2 = dlog(1.d0+1.d0/q1)
      gg = q0*q2
      q3 = a*(b1/rs12+2.d0*b2+3.d0*b3*rs12+2.d0*b4*p1*rsp)
      ggrs = -2.d0*a*a1*q2-q0*q3/(q1**2+q1)
      return
      end

!  gga91 correlation
!  input rs: seitz radius
!  input zet: relative spin polarization
!  input t: abs(grad d)/(d*2.*ks*g)
!  input uu: (grad d)*grad(abs(grad d))/(d**2 * (2*ks*g)**3)
!  input vv: (laplacian d)/(d * (2*ks*g)**2)
!  input ww: (grad d)*(grad zet)/(d * (2*ks*g)**2
!  output h: nonlocal part of correlation energy per electron
!  output dvcup,dvcdn:  nonlocal parts of correlation potentials


      subroutine corgga(rs, fk,sk,g,ec,ecrs,eczet,zet,t,uu,vv,ww,h,dvcup,dvcdn)

      implicit real*8 (a-h,o-z)
      logical flag 
      data xnu,cc0,cx,alf/15.75592d0,0.004235d0,-0.001667212d0,0.09d0/
      data c1,c2,c3,c4/0.002568d0,0.023266d0,7.389d-6,8.723d0/
      data c5,c6,a4/0.472d0,7.389d-2,100.d0/
      data thrdm,thrd2/-0.333333333333d0,0.666666666667d0/
      data flag/.true./
      bet = xnu*cc0
      delt = 2.d0*alf/bet
      g3 = g**3
      g4 = g3*g
      pon = -delt*ec/(g3*bet)
      b = delt/(dexp(pon)-1.d0)
      b2 = b*b
      t2 = t*t
      t4 = t2*t2
      t6 = t4*t2
      rs2 = rs*rs
      rs3 = rs2*rs
      q4 = 1.d0+b*t2
      q5 = 1.d0+b*t2+b2*t4
      q6 = c1+c2*rs+c3*rs2
      q7 = 1.d0+c4*rs+c5*rs2+c6*rs3
      cc = -cx + q6/q7
      r0 = (sk/fk)**2
      r1 = a4*r0*g4
      coeff = cc-cc0-3.d0*cx/7.d0
      r2 = xnu*coeff*g3
      r3 = dexp(-r1*t2)
      h0 = g3*(bet/delt)*dlog(1.d0+delt*q4*t2/q5)
      h1 = r3*r2*t2
      h = h0+h1
!  local correlation option:
!     h = 0.0d0
!  energy done. now the potential:
      ccrs = (c2+2.*c3*rs)/q7 - q6*(c4+2.*c5*rs+3.*c6*rs2)/q7**2
      rsthrd = rs/3.d0
      r4 = rsthrd*ccrs/coeff
!
!mf (orginal version bad for fully polarized systems) 
      if(abs(zet) .ge. 1.d0) then
        if(zet .lt. 0.d0) zet=-1.d0+1.d-15
        if(zet .gt. 0.d0) zet=1.d0-1.d-15
      endif
      gz = ((1.d0+zet)**thrdm - (1.d0-zet)**thrdm)/3.d0
      fac = delt/b+1.d0
      bg = -3.d0*b2*ec*fac/(bet*g4)
      bec = b2*fac/(bet*g3)
      q8 = q5*q5+delt*q4*q5*t2
      q9 = 1.d0+2.d0*b*t2
      h0b = -bet*g3*b*t6*(2.d0+b*t2)/q8
      h0rs = -rsthrd*h0b*bec*ecrs
      fact0 = 2.d0*delt-6.d0*b
      fact1 = q5*q9+q4*q9*q9
      h0bt = 2.d0*bet*g3*t4*((q4*q5*fact0-delt*fact1)/q8)/q8
      h0rst = rsthrd*t2*h0bt*bec*ecrs
      h0z = 3.d0*gz*h0/g + h0b*(bg*gz+bec*eczet)
      h0t = 2.*bet*g3*q9/q8
      h0zt = 3.d0*gz*h0t/g+h0bt*(bg*gz+bec*eczet)
      fact2 = q4*q5+b*t2*(q4*q9+q5)
      fact3 = 2.d0*b*q5*q9+delt*fact2
      h0tt = 4.d0*bet*g3*t*(2.d0*b/q8-(q9*fact3/q8)/q8)
      h1rs = r3*r2*t2*(-r4+r1*t2/3.d0)
      fact4 = 2.d0-r1*t2
      h1rst = r3*r2*t2*(2.d0*r4*(1.d0-r1*t2)-thrd2*r1*t2*fact4)
      h1z = gz*r3*r2*t2*(3.d0-4.d0*r1*t2)/g
      h1t = 2.d0*r3*r2*(1.d0-r1*t2)
      h1zt = 2.d0*gz*r3*r2*(3.d0-11.d0*r1*t2+4.d0*r1*r1*t4)/g
      h1tt = 4.d0*r3*r2*r1*t*(-2.d0+r1*t2)
      hrs = h0rs+h1rs
      hrst = h0rst+h1rst
      ht = h0t+h1t
      htt = h0tt+h1tt
      hz = h0z+h1z
      hzt = h0zt+h1zt
      comm = h+hrs+hrst+t2*ht/6.d0+7.d0*t2*t*htt/6.d0
      pref = hz-gz*t2*ht/g
      fact5 = gz*(2.d0*ht+t*htt)/g
      comm = comm-pref*zet-uu*htt-vv*ht-ww*(hzt-fact5)
      dvcup = comm + pref
      dvcdn = comm - pref
!  local correlation option:
!     dvcup = 0.0d0
!     dvcdn = 0.0d0
      return
      end

!==========================================================================
! c original version by K Burke
! Perdew-Burke-Ernzerhof GGA 
! see: J.P. Perdew, K. Burke, M. Ernzerhof, Phys Rev Lett 77, 3865 (1996).
! this collection contains the older PW91 and Becke exchange as well, 
! everything not needed for the PBE GGA is commented out w/ "c--"
      SUBROUTINE EXCHPBE(rho,S,U,V,lgga,lpot,EX,VX)
!  PBE EXCHANGE FOR A SPIN-UNPOLARIZED ELECTRONIC SYSTEM
!  K Burke's modification of PW91 codes, May 14, 1996
!  Modified again by K. Burke, June 29, 1996, with simpler Fx(s)


!  INPUT rho : DENSITY
!  INPUT S:  ABS(GRAD rho)/(2*KF*rho), where kf=(3 pi^2 rho)^(1/3)
!  INPUT U:  (GRAD rho)*GRAD(ABS(GRAD rho))/(rho**2 * (2*KF)**3)
!  INPUT V: (LAPLACIAN rho)/(rho*(2*KF)**2)
!   (for U,V, see PW86(24))
!  input lgga:  (=0=>don't put in gradient corrections, just LDA)
!  input lpot:  (=0=>don't get potential and don't need U and V)
!  OUTPUT:  EXCHANGE ENERGY PER ELECTRON (EX) AND POTENTIAL (VX)

! References:
! [a]J.P.~Perdew, K.~Burke, and M.~Ernzerhof, submiited to PRL, May96
! [b]J.P. Perdew and Y. Wang, Phys. Rev.  B {\bf 33},  8800  (1986);
!     {\bf 40},  3399  (1989) (E).

! Formulas:
!   	e_x[unif]=ax*rho^(4/3)  [LDA]
!       ax = -0.75*(3/pi)^(1/3)
!	e_x[PBE]=e_x[unif]*FxPBE(s)
!	FxPBE(s)=1+uk-uk/(1+ul*s*s)                 [a](13)
! uk, ul defined after [a](13) 
      IMPLICIT REAL*8 (A-H,O-Z)
      parameter(thrd=1.d0/3.d0,thrd4=4.d0/3.d0)
      parameter(pi=3.14159265358979323846264338327950d0)
      parameter(ax=-0.738558766382022405884230032680836d0)
      parameter(um=0.2195149727645171d0,uk=0.8040d0,ul=um/uk)

! construct LDA exchange energy density
      exunif = AX*rho**THRD
      if(lgga.eq.0)then
	ex=exunif
        vx=ex*thrd4
	return
      endif
! construct PBE enhancement factor
      S2 = S*S
      P0=1.d0+ul*S2
      FxPBE = 1d0+uk-uk/P0
      EX = exunif*FxPBE
      if(lpot.eq.0)return
!  ENERGY DONE. NOW THE POTENTIAL:
!  find first and second derivatives of Fx w.r.t s.
!  Fs=(1/s)*d FxPBE/ ds
!  Fss=d Fs/ds
      Fs=2.d0*uk*ul/(P0*P0)
      Fss=-4.d0*ul*S*Fs/P0
! calculate potential from [b](24) 
      VX = exunif*(THRD4*FxPBE-(U-THRD4*S2*s)*FSS-V*FS)
      RETURN
      END
      SUBROUTINE CORPBE(RS,ZET,T,UU,VV,WW,lgga,lpot,ec,vcup,vcdn,H,DVCUP,DVCDN)
!  Official PBE correlation code. K. Burke, May 14, 1996.
!  INPUT: RS=SEITZ RADIUS=(3/4pi rho)^(1/3)
!       : ZET=RELATIVE SPIN POLARIZATION = (rhoup-rhodn)/rho
!       : t=ABS(GRAD rho)/(rho*2.*KS*G)  -- only needed for PBE
!       : UU=(GRAD rho)*GRAD(ABS(GRAD rho))/(rho**2 * (2*KS*G)**3)
!       : VV=(LAPLACIAN rho)/(rho * (2*KS*G)**2)
!       : WW=(GRAD rho)*(GRAD ZET)/(rho * (2*KS*G)**2
!       :  UU,VV,WW, only needed for PBE potential
!       : lgga=flag to do gga (0=>LSD only)
!       : lpot=flag to do potential (0=>energy only)
!  output: ec=lsd correlation energy from [a]
!        : vcup=lsd up correlation potential
!        : vcdn=lsd dn correlation potential
!        : h=NONLOCAL PART OF CORRELATION ENERGY PER ELECTRON
!        : dvcup=nonlocal correction to vcup
!        : dvcdn=nonlocal correction to vcdn
! References:
! [a] J.P.~Perdew, K.~Burke, and M.~Ernzerhof, 
!     {\sl Generalized gradient approximation made simple}, sub.
!     to Phys. Rev.Lett. May 1996.
! [b] J. P. Perdew, K. Burke, and Y. Wang, {\sl Real-space cutoff
!     construction of a generalized gradient approximation:  The PW91
!     density functional}, submitted to Phys. Rev. B, Feb. 1996.
! [c] J. P. Perdew and Y. Wang, Phys. Rev. B {\bf 45}, 13244 (1992).
      IMPLICIT REAL*8 (A-H,O-Z)
! thrd*=various multiples of 1/3
! numbers for use in LSD energy spin-interpolation formula, [c](9).
!      GAM= 2^(4/3)-2
!      FZZ=f''(0)= 8/(9*GAM)
! numbers for construction of PBE
!      gamma=(1-log(2))/pi^2
!      bet=coefficient in gradient expansion for correlation, [a](4).
!      eta=small number to stop d phi/ dzeta from blowing up at 
!          |zeta|=1.
      parameter(thrd=1.d0/3.d0,thrdm=-thrd,thrd2=2.d0*thrd)
      parameter(sixthm=thrdm/2.d0)
      parameter(thrd4=4.d0*thrd)
      parameter(GAM=0.5198420997897463295344212145565d0)
      parameter(fzz=8.d0/(9.d0*GAM))
      parameter(gamma=0.03109069086965489503494086371273d0)
      parameter(bet=0.06672455060314922d0,delt=bet/gamma)
      parameter(eta=1.d-12)
! find LSD energy contributions, using [c](10) and Table I[c].
! EU=unpolarized LSD correlation energy
! EURS=dEU/drs
! EP=fully polarized LSD correlation energy
! EPRS=dEP/drs
! ALFM=-spin stiffness, [c](3).
! ALFRSM=-dalpha/drs
! F=spin-scaling factor from [c](9).
! construct ec, using [c](8)
      rtrs=dsqrt(rs)
      CALL gcor2(0.0310907D0,0.21370D0,7.5957D0,3.5876D0,1.6382D0,0.49294D0,rtrs,EU,EURS)
      CALL gcor2(0.01554535D0,0.20548D0,14.1189D0,6.1977D0,3.3662D0,0.62517D0,rtRS,EP,EPRS)
      CALL gcor2(0.0168869D0,0.11125D0,10.357D0,3.6231D0,0.88026D0,0.49671D0,rtRS,ALFM,ALFRSM)
      ALFC = -ALFM
      Z4 = ZET**4
      F=((1.D0+ZET)**THRD4+(1.D0-ZET)**THRD4-2.D0)/GAM
      EC = EU*(1.D0-F*Z4)+EP*F*Z4-ALFM*F*(1.D0-Z4)/FZZ
! LSD potential from [c](A1)
! ECRS = dEc/drs [c](A2)
! ECZET=dEc/dzeta [c](A3)
! FZ = dF/dzeta [c](A4)
      ECRS = EURS*(1.D0-F*Z4)+EPRS*F*Z4-ALFRSM*F*(1.D0-Z4)/FZZ
      FZ = THRD4*((1.D0+ZET)**THRD-(1.D0-ZET)**THRD)/GAM
      ECZET = 4.D0*(ZET**3)*F*(EP-EU+ALFM/FZZ)+FZ*(Z4*EP-Z4*EU-(1.D0-Z4)*ALFM/FZZ)
      COMM = EC -RS*ECRS/3.D0-ZET*ECZET
      VCUP = COMM + ECZET
      VCDN = COMM - ECZET
      if(lgga.eq.0)return
! PBE correlation energy
! G=phi(zeta), given after [a](3)
! DELT=bet/gamma
! B=A of [a](8)
      G=((1.d0+ZET)**thrd2+(1.d0-ZET)**thrd2)/2.d0
      G3 = G**3
      PON=-EC/(G3*gamma)
      B = DELT/(DEXP(PON)-1.D0)
      B2 = B*B
      T2 = T*T
      T4 = T2*T2
      RS2 = RS*RS
      RS3 = RS2*RS
      Q4 = 1.D0+B*T2
      Q5 = 1.D0+B*T2+B2*T4
      H = G3*(BET/DELT)*DLOG(1.D0+DELT*Q4*T2/Q5)
      if(lpot.eq.0)return
! ENERGY DONE. NOW THE POTENTIAL, using appendix E of [b].
      G4 = G3*G
      T6 = T4*T2
      RSTHRD = RS/3.D0
      GZ=(((1.d0+zet)**2+eta)**sixthm-((1.d0-zet)**2+eta)**sixthm)/3.d0
      FAC = DELT/B+1.D0
      BG = -3.D0*B2*EC*FAC/(BET*G4)
      BEC = B2*FAC/(BET*G3)
      Q8 = Q5*Q5+DELT*Q4*Q5*T2
      Q9 = 1.D0+2.D0*B*T2
      hB = -BET*G3*B*T6*(2.D0+B*T2)/Q8
      hRS = -RSTHRD*hB*BEC*ECRS
      FACT0 = 2.D0*DELT-6.D0*B
      FACT1 = Q5*Q9+Q4*Q9*Q9
      hBT = 2.D0*BET*G3*T4*((Q4*Q5*FACT0-DELT*FACT1)/Q8)/Q8
      hRST = RSTHRD*T2*hBT*BEC*ECRS
      hZ = 3.D0*GZ*h/G + hB*(BG*GZ+BEC*ECZET)
      hT = 2.d0*BET*G3*Q9/Q8
      hZT = 3.D0*GZ*hT/G+hBT*(BG*GZ+BEC*ECZET)
      FACT2 = Q4*Q5+B*T2*(Q4*Q9+Q5)
      FACT3 = 2.D0*B*Q5*Q9+DELT*FACT2
      hTT = 4.D0*BET*G3*T*(2.D0*B/Q8-(Q9*FACT3/Q8)/Q8)
      COMM = H+HRS+HRST+T2*HT/6.D0+7.D0*T2*T*HTT/6.D0
      PREF = HZ-GZ*T2*HT/G
      FACT5 = GZ*(2.D0*HT+T*HTT)/G
      COMM = COMM-PREF*ZET-UU*HTT-VV*HT-WW*(HZT-FACT5)
      DVCUP = COMM + PREF
      DVCDN = COMM - PREF
      RETURN
      END

      SUBROUTINE GCOR2(A,A1,B1,B2,B3,B4,rtrs,GG,GGRS)
! slimmed down version of GCOR used in PW91 routines, to interpolate
! LSD correlation energy, as given by (10) of
! J. P. Perdew and Y. Wang, Phys. Rev. B {\bf 45}, 13244 (1992).
! K. Burke, May 11, 1996.
      IMPLICIT REAL*8 (A-H,O-Z)
      Q0 = -2.D0*A*(1.D0+A1*rtrs*rtrs)
      Q1 = 2.D0*A*rtrs*(B1+rtrs*(B2+rtrs*(B3+B4*rtrs)))
      Q2 = DLOG(1.D0+1.D0/Q1)
      GG = Q0*Q2
      Q3 = A*(B1/rtrs+2.D0*B2+rtrs*(3.D0*B3+4.D0*B4*rtrs))
      GGRS = -2.D0*A*A1*Q2-Q0*Q3/(Q1*(1.d0+Q1))
      RETURN
      END

!  LDA exchange
!  Hartree a.u.
      subroutine xlda(d,vx,ex)
      implicit real *8 (a-h,o-z)
      data ax,thd,thd4,eps/-.738558766382022406d0,.333333333333333333d0, &
        .133333333333333333d1,1.d-100/

      if(d .le. eps) then
        vx=0.d0
        ex=0.d0
      else
        ex=ax*d**thd
        vx=thd4*ex
      endif
      return
      end
! Wigner interpolation formula, E. Wigner, Phys. Rev. 46, 1002 (1934).
! Hartree a.u.
! see W.E. Pickett, Comp.Phys.Rep. 9, 115 (1989), pg. 187 : w2 = 7.79
      subroutine wigner(rh,ex,fx,exc,fxc)
      implicit real*8 (a-h,o-z)
      data thrd,w1,w2,ax,pif,eps/.333333333333333333d0,-.44d0,.779d1, &
        -.738558766382022447d0,.620350490899400087d0,1.d-100/


      if(rh .lt. eps) then
        ex = 0.d0
        fx = 0.d0
        exc= 0.d0
        fxc= 0.d0
      else

        x  = rh**thrd
        ex = ax * x
        fx = 4.d0*thrd*ex
        rs = pif/x
        y  = 1.d0/(rs + w2)
        exc= ex + w1*y
        fxc= fx + w1*(4.d0*thrd*rs + w2)*y*y
      endif

      return
      end
! LDA - Ceperley - Alder exchange-correlation potential and energy
! as parameterized by Perdew and Zunger, Phys. Rev. B23, 5048 (1981)
! Hartree a.u.
! original version by D.R. Hamann, gncpp

      subroutine cepal(rh,ex,fx,exc,fxc)
      implicit real *8 (a-h,o-z)
      data eps/1.d-100/

      if(rh .lt. 0.23873241d0) then

        if(rh .le. eps) then
          fxc=0.d0
          exc=0.d0
          ex=0.d0
          fx=0.d0
          goto 100
        endif

        rs=0.62035049d0*rh**(-0.3333333333333333d0)
        sqrs=dsqrt(rs)
        den=1.0d0 + 1.0529d0*sqrs + 0.3334d0*rs
        exc=-0.4582d0/rs - 0.1423d0/den
        fxc=exc - rs*(0.15273333d0/rs**2+ (0.02497128d0/sqrs + 0.01581427d0)/den**2)
      else
        rs=0.62035049d0*rh**(-0.3333333333333333d0)
        rsl=dlog(rs)
        exc=-0.4582d0/rs - 0.0480d0 + 0.0311d0*rsl - 0.0116d0*rs+ 0.002d0*rs*rsl
        fxc=exc - rs*(0.15273333d0/rs**2+ 0.01036667d0/rs - 0.003866667d0 &
                      + 0.00066667d0*(1.0d0 + rsl))
      end if

! exchange-only energy and potential
      ex=-0.7385587664d0*rh**(.3333333333333333d0) 
      fx=4.d0/3.d0*ex

  100 return
      end
! LDA - scaled Wigner exchange-correlation
! from [Q. Zhao, R.G. Parr, PRA 46, R5320 (1992)] eqs. (5) and (7)
! Input   
! rh        density
!
! Output
! ex        exchange energy per electron
! fx           ""    potential
!           ... based on continuum-LDA (electron-gas like)
!
! exc       exchange-correlation energy per electron
! fxc          ""        ""      potential
!
! Hartree a.u.
      subroutine wigscaled(rh,ex,fx,exc,fxc)
      implicit real *8 (a-h,o-z)
      intrinsic log
      data thrd,aa,bb,ax,eps/.333333333333333333d0,.93222d0,.947362d-2, &
        .738558766382022406d0,1.d-100/

      if(rh .le. 0.d0) then
        rh = 0.d0
        ex = 0.d0
        fx = 0.d0
        exc= 0.d0
        fxc= 0.d0
      else

        x = bb*rh**thrd
        y = x/(x + 1.d0)
        z = -aa*x/bb
        xyln = x*log(y)

        exc = z * (1.d0 + xyln)
        fxc = thrd*z *(4.d0 + 5.d0*xyln + y)

! electron-gas based LDA exchange

        ex = ax*z/aa
        fx = 4.d0*thrd*ex
      endif
      return
      end

