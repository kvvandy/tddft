MODULE HAMILTON
  USE MOD_GLOBAL
  USE PSEUDOPOTENTIAL
  USE MIXING
  USE MOD_IO
  USE FFT_POISSON
  use mod_converged
  use xc
  implicit none


  complex(8), dimension(:,:,:), allocatable :: nab
  
  
CONTAINS

function dipole_moment(direc)
!This function computes dipole moment in direction direc=1,2,3 (i.e. x,y,z). The
!returned value is in units of eV*Angstrom/Volt. It is assumed that the density is
!normalized by the number of electrons and the lattice points are in Angstroms.
!If the dipole moment in units of Debye is needed, the returned value should be
!multiplied by the factor 1.60217646 * 2.99792458 = 4.803204191
real(8) dipole_moment
integer direc
real(8) dm,bm,x,y,z,r2,dpmrr2
integer j,ai
if(dip_mom_region_inf) then
  bm=0.0d0
  !Dipole moment is evaluated by integrating density everywhere
  !$omp parallel do &
  !$omp default(shared) &
  !$omp private (j)  &
  !$omp reduction(+: bm)
  do j=1,N_lattice_points
    bm=bm+density(j)*Grid_Point(direc,j)
  enddo
  !$omp end parallel do
  dm=-bm
else
  !Dipole_moment is evaluated by integrating density only within
  !a sphere of radius dip_mom_region_radius and centered
  !at (dip_mom_region_center_x,dip_mom_region_center_y,dip_mom_region_center_z)
  dpmrr2=dip_mom_region_radius*dip_mom_region_radius
  bm=0.0d0
  !$omp parallel do &
  !$omp default(shared) &
  !$omp private (j, x, y, z, r2)  &
  !$omp reduction(+: bm)
  do j=1,N_lattice_points
    x=Grid_Point(1,j)
    y=Grid_Point(2,j)
    z=Grid_Point(3,j)
    r2=((x-dip_mom_region_center_x)/dpm_stretch_x)**2+((y-dip_mom_region_center_y)/dpm_stretch_y)**2+ &
        ((z-dip_mom_region_center_z)/dpm_stretch_z)**2
    if (r2<dpmrr2) bm=bm+density(j)*Grid_Point(direc,j)
  enddo
  !$omp end parallel do
  dm=-bm
endif
dm=dm*grid_volume
!Now add the contribution due to ionic charges. These contributions do
!not change with time if ions are not allowed to move.
bm=0.0d0
!$omp parallel do if(N_total_atom > 400) &
!$omp default(shared) &
!$omp private (j, ai) &
!$omp reduction(+: bm)
do j=1,N_total_atom
 ai=atom_index(j)
 if (z_atom(ai)/=0) then
   bm=bm+Charge_pp(ai)*Position(direc,j)
 endif
enddo
!$omp end parallel do
dipole_moment=dm+bm
end function dipole_moment

subroutine update_dipole_moment
implicit none
real(8) dm,bm(3),x,y,z,r2,dpmrr2
integer j,ai

  bm=0.0d0
  do j=1,N_lattice_points
    bm(:)=bm(:)+density(j)*Grid_Point(:,j)
  enddo
  dipole_mom_vec(:)=-bm(:)*grid_volume
!Now add the contribution due to ionic charges. These contributions do
!not change with time if ions are not allowed to move.
do j=1,N_total_atom
 ai=atom_index(j)
 if (z_atom(ai)/=0) then
   dipole_mom_vec(:)=dipole_mom_vec(:)+Charge_pp(ai)*Position(:,j)
 endif
enddo

end subroutine update_dipole_moment

subroutine dipole_moment_opt(dpmelec,dpmnuc,dpm)
!This function computes dipole moment in direction . The
!returned value is in units of eV*Angstrom/Volt. It is assumed that the density is
!normalized by the number of electrons and the lattice points are in Angstroms.
!If the dipole moment in units of Debye is needed, the returned value should be
!multiplied by the factor 1.60217646 * 2.99792458 = 4.803204191
real(8),intent(out) :: dpmelec(3),dpmnuc(3),dpm(3)
!integer direc
real(8) x,y,z,r2,dpmrr2
integer j,ai
dpmelec=0.d0
dpmnuc=0.d0
dpm=0.d0

if(dip_mom_region_inf) then
  !Dipole moment is evaluated by integrating density everywhere
  do j=1,N_lattice_points
    dpmelec=dpmelec+density(j)*Grid_Point(:,j)
  enddo
  dpmelec=-dpmelec
else
  !Dipole_moment is evaluated by integrating density only within
  !a sphere of radius dip_mom_region_radius and centered
  !at (dip_mom_region_center_x,dip_mom_region_center_y,dip_mom_region_center_z)
  dpmrr2=dip_mom_region_radius*dip_mom_region_radius

  do j=1,N_lattice_points
    x=Grid_Point(1,j)
    y=Grid_Point(2,j)
    z=Grid_Point(3,j)
    r2=((x-dip_mom_region_center_x)/dpm_stretch_x)**2+((y-dip_mom_region_center_y)/dpm_stretch_y)**2+ &
        ((z-dip_mom_region_center_z)/dpm_stretch_z)**2
    if (r2<dpmrr2) dpmelec=dpmelec+density(j)*Grid_Point(:,j)
  enddo

  dpmelec=-dpmelec
endif
dpmelec=dpmelec*grid_volume

  !Now add the contribution due to ionic charges. These contributions do
  !not change with time if ions are not allowed to move.
  do j=1,N_total_atom
   ai=atom_index(j)
   if (z_atom(ai)/=0) then
     dpmnuc=dpmnuc+Charge_pp(ai)*Position(:,j)
   endif
  enddo

dpm=dpmelec+dpmnuc
end subroutine dipole_moment_opt

SUBROUTINE local_force_bg(force)
  implicit none
  integer                               :: atom,i,j,it,l,intr
  real*8                                :: r(3),r2,vloc,ratio1,ratio2,f
  real*8 :: force(3,n_total_atom)


  force=0.d0
  do atom=1,N_total_atom
    it=atom_index(atom)
    L=L_ref(it)
    f=1.d0/step_pp(it)
    do i=1,N_Lattice_points
      r(:)=Grid_point(:,i)-Position(:,atom)
      r2=sqrt(r(1)**2+r(2)**2+r(3)**2)+1.d-50

      vloc=2.d0*sqrt(bg_beta)/(r2*sqrt(pi))*E2*charge_pp(it)*exp(-bg_beta*r2**2)- &
&              derf(sqrt(bg_beta)*r2)/r2**2*E2*charge_pp(it)
      force(:,atom)=force(:,atom)+vloc*density(i)*grid_volume*r(:)/r2

    end do
  end do

end subroutine local_force_bg
 
 
 
 
 
SUBROUTINE calculate_force
 implicit none
 integer       :: j,it,grid,lm,atom,i1,i2,i3,orbital,i,l,ai
 real*8        :: f,su,w,r,force_temp(3),two_occ,Rc,Rh,R0,d,C,F_mag
 complex*16    :: uV_Psi,uV_grad_Psi(3)
 double precision :: ratio1,ratio2,Vloc,r2,x(3)
 integer          :: intr
 real*8,parameter :: fc=a_b*a_b/e2
 real*8 :: force_bg(3,n_total_atom)

 call local_force_bg(force_bg)

 force=-force_bg

 if(debug_force_output) call print_forces_to_monitor(force,"F_BG")
 ! 
! do i1=1,N_total_atom
!   write(44444101,'(a,i4,3ES20.10E3)') "fbg ",i1,force(1:3,i1)
! end do

!force=0.d0
 
grad_density=0.d0
! force from nonlocal_pseudo_potential
do orbital=1,N_orbitals

  !$omp parallel do &
  !$omp default(shared) &
  !$omp private (grid, i1, i2, i3)
  do grid=1,N_lattice_points
    i1=Lattice(1,grid)
    i2=Lattice(2,grid)
    i3=Lattice(3,grid)
    wphi_c(i1,i2,i3)=Psi_c(grid,orbital)
  end do
  !$omp end parallel do

  call nabla

  two_occ=2*occupation(orbital)
  !$omp parallel do &
  !$omp default(shared) &
  !$omp private (i)
  do i=1,N_lattice_points
    grad_density(:,i)=grad_density(:,i)+two_occ*Conjg(Psi_c(i,orbital))*wlap_p(:,i)
  end do
  !$omp end parallel do


  do i=1,N_nl
    atom=nl_ind(i)
    uV_Psi=(0.d0,0.d0)
    uV_grad_Psi=(0.d0,0.d0)
    !$omp parallel do &
    !$omp default(shared) &
    !$omp private (j, grid, lm) &
    !$omp reduction(+: uV_Psi, uV_grad_Psi)
    do j=1,num_ps_points(atom)
      grid=ps_grid(j,atom)
      uV_Psi=uV_Psi+uV_nl(j,i)*Psi_c(grid,orbital)
      uV_grad_Psi(:)=uV_grad_Psi(:)+uV_nl(j,i)*wlap_p(:,grid)
    end do
    !$omp end parallel do
    f=-two_occ*Grid_Volume**2*s_uVu_nl(i)
    force(:,atom)=force(:,atom)+uV_grad_Psi(:)*Conjg(uv_Psi)*f
  end do
end do

if(debug_force_output) call print_forces_to_monitor(force,"F_nL")

! do i1=1,N_total_atom
!   write(44444101,'(a,i4,3ES20.10E3)') "fps1 ",i1,force(1:3,i1)
! end do

! force from other ions

!$omp parallel do if(N_total_atom > 20) &
!$omp default(shared) &
!$omp private (i1, i2, r, w)
do i1=1,N_total_atom
  if (z_atom(atom_index(i1))/=0) then
    do i2=1,N_total_atom
      if((i1/=i2).and.(z_atom(atom_index(i2))/=0)) then
        r=sqrt((Position(1,i1)-Position(1,i2))**2+ &
               (Position(2,i1)-Position(2,i2))**2+ &
               (Position(3,i1)-Position(3,i2))**2)
        w=Charge_pp(atom_index(i1))*Charge_pp(atom_index(i2))/r**3*E2
        force(:,i1)=force(:,i1)+w*(Position(:,i1)-Position(:,i2))
      endif
    enddo
  endif
enddo
!$omp end parallel do

if(debug_force_output) call print_forces_to_monitor(force,"F_ii")

! do i1=1,N_total_atom
!   write(44444101,'(a,i4,3ES20.10E3)') "fion ",i1,force(1:3,i1)
! end do

! force from projectile
if (use_projectile) then
  !$omp parallel do if(N_total_atom > 400) &
  !$omp default(shared) &
  !$omp private (i, r, w, ai)
  do i=1,N_total_atom
    ai=atom_index(i)
    if (z_atom(ai)/=0) then
	  ! removed projectile_potential_soft_param for direct collisions
      r=sqrt((Position(1,i)-projectile_x)**2+ &
           (Position(2,i)-projectile_y)**2+ &
           (Position(3,i)-projectile_z)**2 )
            ! projectile_potential_soft_param**2 )
	  if(projectile_ion_full_charge) then
		if(r<Core_radius(atom_index(i))) then
		  w=z_atom(ai)*projectile_charge/r**3*E2
		else
		  w=Charge_pp(ai)*projectile_charge/r**3*E2
		end if
	  else
        w=Charge_pp(ai)*projectile_charge/r**3*E2
      end if
      force(1,i)=force(1,i)+w*(Position(1,i)-projectile_x)
      force(2,i)=force(2,i)+w*(Position(2,i)-projectile_y)
      force(3,i)=force(3,i)+w*(Position(3,i)-projectile_z)
    endif
  enddo
  !$omp end parallel do
endif

! do i1=1,N_total_atom
!   write(44444101,'(a,i4,3ES20.10E3)') "fp ",i1,force(1:3,i1)
! end do

! force from local potential

do atom=1,N_total_atom
  it=atom_index(atom)
  if(z_atom(it).ne.0) then
    L=L_ref(it)
    f=1/step_pp(it)
    force_temp=0.0d0
    !$omp parallel do &
    !$omp default(shared) &
    !$omp private (i, x, r2, intr, ratio1, ratio2, Vloc) &
    !$omp reduction(+: force_temp)
    do i=1,N_Lattice_points
      x(:)=Grid_Point(:,i)-Position(:,atom)
      r2=sqrt(x(1)**2+x(2)**2+x(3)**2)+1.d-50
      intr=int(r2*f)
      ratio1=(r2*f-intr)
      ratio2=1.d0-ratio1
      if(intr+1.gt.N_points_max) then
        Vloc=-Charge_pp(atom)*E2/r2+derf(sqrt(bg_beta)*r2)/r2*E2*charge_pp(it)
	  else
	    Vloc=ratio1*v_pp(intr+1,L,it)+ratio2*v_pp(intr,L,it)+derf(sqrt(bg_beta)*r2)/r2*E2*charge_pp(it)
      endif
      force_temp(:)=force_temp(:)+Vloc*grad_density(:,i)
    end do
    !$omp end parallel do
    force(:,atom)=force(:,atom)-grid_volume*force_temp(:)  
  endif
enddo

if(debug_force_output) call print_forces_to_monitor(force,"F_lc")

! do i1=1,N_total_atom
!   write(44444101,'(a,i4,3ES20.10E3)') "flp ",i1,force(1:3,i1)
! end do

! force due to DC field (along x-axis) and due to laser fields
if (using_v_laser1.or.using_v_laser2.or.using_v_laser3.or.using_v_ext.or.using_v_fromfile) then
 do atom=1,N_total_atom
   it=atom_index(atom)
   if(z_atom(it)/=0) then
     w=Charge_pp(it)
     if (using_v_ext) force(1,atom)=force(1,atom)+w*E_ext*factor_static_ef
     if (using_v_laser1) force(1,atom)=force(1,atom)+w*E_laser1*factor_laser1
     if (using_v_laser2) force(2,atom)=force(2,atom)+w*E_laser2*factor_laser2
     if (using_v_laser3) force(3,atom)=force(3,atom)+w*E_laser3*factor_laser3
	 if (using_v_fromfile) then
        force(1,atom)=force(1,atom)+w*laser_xyz_t_iteration(1)
        force(2,atom)=force(2,atom)+w*laser_xyz_t_iteration(2)
        force(3,atom)=force(3,atom)+w*laser_xyz_t_iteration(3)
	 endif
   endif
 enddo
endif

if(debug_force_output) call print_forces_to_monitor(force,"F_zr")


!  van der Waals force for the case of a hydrogen hitting graphene
if (use_vdw) then
  Rc=1.11 
  Rh=1.61
  R0=Rc+Rh
  d=23
  C=sqrt(0.16*1.65)*(6.242e+18)*10**6/(6.02214129e+23)
  do atom=2,N_total_atom
      it= z_atom(atom_index(atom))
         !print *,atom
      if (abs(it-6)<1) then
         !print *, 'go vdw!'
         r=sqrt((position(1,atom)-position(1,1))**2+(position(2,atom)-position(2,1))**2+(position(3,atom)-position(3,1))**2)
        if (damping_vdw) then
         F_mag=d*exp(-d*(r/R0-1))/(R0*(1+exp(-d*(r/R0-1)))**2)*C/r**6-6*C/(r**7*(1+exp(-d*(r/R0-1))))
        else  
         F_mag=-6*C/r**7
        endif
        ! print *, r,F_mag
         force(1,1)=force(1,1)+F_mag*(position(1,1)-position(1,atom))/r
         force(2,1)=force(2,1)+F_mag*(position(2,1)-position(2,atom))/r
         force(3,1)=force(3,1)+F_mag*(position(3,1)-position(3,atom))/r
      endif
  enddo
endif


!write(999,*)'force_wf'
!do i=1,N_total_atom
!  write(999,*)i
!  write(999,*)force(:,i)
!end do
!write(999,*)


end subroutine calculate_force


SUBROUTINE calculate_force_MPI
 implicit none
 integer       :: j,it,grid,lm,atom,i1,i2,i3,orbital,i,l,ai
 real*8        :: f,su,w,r,force_temp(3),two_occ,Rc,Rh,R0,d,C,F_mag
 complex*16    :: uV_Psi,uV_grad_Psi(3)
 double precision :: ratio1,ratio2,Vloc,r2,x(3)
 integer          :: intr
 real*8,parameter :: fc=a_b*a_b/e2
 real*8 :: force_bg(3,n_total_atom)
   real*8  :: s1,s2,s3
   real*8  :: buf_grad_density(3,N_Lattice_points)
   real*8  :: buf_force(3,N_total_atom)

force=0.d0

if(MPI_master) then
 call local_force_bg(force_bg)
 force=-force_bg
endif

 
grad_density=0.d0
! force from nonlocal_pseudo_potential
do orbital=1,N_orbitals
 if(MPItask_orbital_map(orbital)==MPI_proc_rank) then
  !$omp parallel do &
  !$omp default(shared) &
  !$omp private (grid, i1, i2, i3)
  do grid=1,N_lattice_points
    i1=Lattice(1,grid)
    i2=Lattice(2,grid)
    i3=Lattice(3,grid)
    wphi_c(i1,i2,i3)=Psi_c(grid,orbital)
  end do
  !$omp end parallel do

  call nabla

  two_occ=2*occupation(orbital)
  !$omp parallel do &
  !$omp default(shared) &
  !$omp private (i)
  do i=1,N_lattice_points
    grad_density(:,i)=grad_density(:,i)+two_occ*Conjg(Psi_c(i,orbital))*wlap_p(:,i)
  end do
  !$omp end parallel do


  do i=1,N_nl
    atom=nl_ind(i)
    uV_Psi=(0.d0,0.d0)
    uV_grad_Psi=(0.d0,0.d0)
    !$omp parallel do &
    !$omp default(shared) &
    !$omp private (j, grid, lm) &
    !$omp reduction(+: uV_Psi, uV_grad_Psi)
    do j=1,num_ps_points(atom)
      grid=ps_grid(j,atom)
      uV_Psi=uV_Psi+uV_nl(j,i)*Psi_c(grid,orbital)
      uV_grad_Psi(:)=uV_grad_Psi(:)+uV_nl(j,i)*wlap_p(:,grid)
    end do
    !$omp end parallel do
    f=-two_occ*Grid_Volume**2*s_uVu_nl(i)
    force(:,atom)=force(:,atom)+uV_grad_Psi(:)*Conjg(uv_Psi)*f
  end do
 endif
end do

buf_grad_density=grad_density
buf_force=force
call MPI_Reduce(buf_force,force,3*N_total_atom,MPI_DOUBLE_PRECISION,MPI_SUM,0,taylor_time_communicator,MPI_ierror)
if(MPI_ierror/=0) write(log_file,*) "MPI_ierror",MPI_ierror," at Location ID: ham700"
call MPI_Reduce(buf_grad_density,grad_density,3*N_Lattice_points,MPI_DOUBLE_PRECISION,MPI_SUM,0,taylor_time_communicator,MPI_ierror)
if(MPI_ierror/=0) write(log_file,*) "MPI_ierror",MPI_ierror," at Location ID: ham800"

! force from other ions
if(MPI_master) then

!$omp parallel do if(N_total_atom > 20) &
!$omp default(shared) &
!$omp private (i1, i2, r, w)
do i1=1,N_total_atom
  if (z_atom(atom_index(i1))/=0) then
    do i2=1,N_total_atom
      if((i1/=i2).and.(z_atom(atom_index(i2))/=0)) then
        r=sqrt((Position(1,i1)-Position(1,i2))**2+ &
               (Position(2,i1)-Position(2,i2))**2+ &
               (Position(3,i1)-Position(3,i2))**2)
        w=Charge_pp(atom_index(i1))*Charge_pp(atom_index(i2))/r**3*E2
        force(:,i1)=force(:,i1)+w*(Position(:,i1)-Position(:,i2))
      endif
    enddo
  endif
enddo
!$omp end parallel do

! do i1=1,N_total_atom
!   write(44444101,'(a,i4,3ES20.10E3)') "fion ",i1,force(1:3,i1)
! end do

! force from projectile
if (use_projectile) then
  !$omp parallel do if(N_total_atom > 400) &
  !$omp default(shared) &
  !$omp private (i, r, w, ai)
  do i=1,N_total_atom
    ai=atom_index(i)
    if (z_atom(ai)/=0) then
	  ! removed projectile_potential_soft_param for direct collisions
      r=sqrt((Position(1,i)-projectile_x)**2+ &
           (Position(2,i)-projectile_y)**2+ &
           (Position(3,i)-projectile_z)**2 )
            ! projectile_potential_soft_param**2 )
	  if(projectile_ion_full_charge) then
		if(r<Core_radius(atom_index(i))) then
		  w=z_atom(ai)*projectile_charge/r**3*E2
		else
		  w=Charge_pp(ai)*projectile_charge/r**3*E2
		end if
	  else
        w=Charge_pp(ai)*projectile_charge/r**3*E2
      end if
      force(1,i)=force(1,i)+w*(Position(1,i)-projectile_x)
      force(2,i)=force(2,i)+w*(Position(2,i)-projectile_y)
      force(3,i)=force(3,i)+w*(Position(3,i)-projectile_z)
    endif
  enddo
  !$omp end parallel do
endif

! do i1=1,N_total_atom
!   write(44444101,'(a,i4,3ES20.10E3)') "fp ",i1,force(1:3,i1)
! end do

! force from local potential

do atom=1,N_total_atom
  it=atom_index(atom)
  if(z_atom(it).ne.0) then
    L=L_ref(it)
    f=1/step_pp(it)
    force_temp=0.0d0
    !$omp parallel do &
    !$omp default(shared) &
    !$omp private (i, x, r2, intr, ratio1, ratio2, Vloc) &
    !$omp reduction(+: force_temp)
    do i=1,N_Lattice_points
      x(:)=Grid_Point(:,i)-Position(:,atom)
      r2=sqrt(x(1)**2+x(2)**2+x(3)**2)+1.d-50
      intr=int(r2*f)
      ratio1=(r2*f-intr)
      ratio2=1.d0-ratio1
      if(intr+1.gt.N_points_max) then
        Vloc=-Charge_pp(atom)*E2/r2+derf(sqrt(bg_beta)*r2)/r2*E2*charge_pp(it)
	  else
	    Vloc=ratio1*v_pp(intr+1,L,it)+ratio2*v_pp(intr,L,it)+derf(sqrt(bg_beta)*r2)/r2*E2*charge_pp(it)
      endif
      force_temp(:)=force_temp(:)+Vloc*grad_density(:,i)
    end do
    !$omp end parallel do
    force(:,atom)=force(:,atom)-grid_volume*force_temp(:)  
  endif
enddo

! do i1=1,N_total_atom
!   write(44444101,'(a,i4,3ES20.10E3)') "flp ",i1,force(1:3,i1)
! end do

! force due to DC field (along x-axis) and due to laser fields
if (using_v_laser1.or.using_v_laser2.or.using_v_laser3.or.using_v_ext.or.using_v_fromfile) then
 do atom=1,N_total_atom
   it=atom_index(atom)
   if(z_atom(it)/=0) then
     w=Charge_pp(it)
     if (using_v_ext) force(1,atom)=force(1,atom)+w*E_ext*factor_static_ef
     if (using_v_laser1) force(1,atom)=force(1,atom)+w*E_laser1*factor_laser1
     if (using_v_laser2) force(2,atom)=force(2,atom)+w*E_laser2*factor_laser2
     if (using_v_laser3) force(3,atom)=force(3,atom)+w*E_laser3*factor_laser3
	 if (using_v_fromfile) then
        force(1,atom)=force(1,atom)+w*laser_xyz_t_iteration(1)
        force(2,atom)=force(2,atom)+w*laser_xyz_t_iteration(2)
        force(3,atom)=force(3,atom)+w*laser_xyz_t_iteration(3)
	 endif
   endif
 enddo
endif

!  van der Waals force for the case of a hydrogen hitting graphene
if (use_vdw) then
  Rc=1.11 
  Rh=1.61
  R0=Rc+Rh
  d=23
  C=sqrt(0.16*1.65)*(6.242e+18)*10**6/(6.02214129e+23)
  do atom=2,N_total_atom
      it= z_atom(atom_index(atom))
         !print *,atom
      if (abs(it-6)<1) then
         !print *, 'go vdw!'
         r=sqrt((position(1,atom)-position(1,1))**2+(position(2,atom)-position(2,1))**2+(position(3,atom)-position(3,1))**2)
        if (damping_vdw) then
         F_mag=d*exp(-d*(r/R0-1))/(R0*(1+exp(-d*(r/R0-1)))**2)*C/r**6-6*C/(r**7*(1+exp(-d*(r/R0-1))))
        else  
         F_mag=-6*C/r**7
        endif
        ! print *, r,F_mag
         force(1,1)=force(1,1)+F_mag*(position(1,1)-position(1,atom))/r
         force(2,1)=force(2,1)+F_mag*(position(2,1)-position(2,atom))/r
         force(3,1)=force(3,1)+F_mag*(position(3,1)-position(3,atom))/r
      endif
  enddo
endif

endif 

end subroutine calculate_force_MPI


! cody
SUBROUTINE calculate_force_PsiREAL
 implicit none
 integer       :: j,it,grid,lm,atom,i1,i2,i3,orbital,i,l,ai
 real*8        :: f,su,w,r,force_temp(3),two_occ,Rc,Rh,R0,d,C,F_mag
 complex*16    :: uV_Psi,uV_grad_Psi(3)
 double precision :: ratio1,ratio2,Vloc,r2,x(3)
 integer          :: intr
 real*8,parameter :: fc=a_b*a_b/e2
 real*8 :: force_bg(3,n_total_atom)

 call local_force_bg(force_bg)

if(.not.allocated(force_psiREAL)) allocate(force_psiREAL(3,N_total_atom))
 
 force_psiREAL=-force_bg

! do i1=1,N_total_atom
!   write(44444102,'(a,i4,3ES20.10E3)') "fbg ",i1,force_psiREAL(1:3,i1)
! end do

!force=0.d0
 
grad_density=0.d0
! force from nonlocal_pseudo_potential
do orbital=1,N_orbitals

  !$omp parallel do &
  !$omp default(shared) &
  !$omp private (grid, i1, i2, i3)
  do grid=1,N_lattice_points
    i1=Lattice(1,grid)
    i2=Lattice(2,grid)
    i3=Lattice(3,grid)
    wphi_c(i1,i2,i3)=Psi(grid,orbital)
  end do
  !$omp end parallel do

  call nabla

  two_occ=2*occupation(orbital)
  !$omp parallel do &
  !$omp default(shared) &
  !$omp private (i)
  do i=1,N_lattice_points
    grad_density(:,i)=grad_density(:,i)+two_occ*Psi(i,orbital)*wlap_p(:,i)
  end do
  !$omp end parallel do


  do i=1,N_nl
    atom=nl_ind(i)
    uV_Psi=(0.d0,0.d0)
    uV_grad_Psi=(0.d0,0.d0)
    !$omp parallel do &
    !$omp default(shared) &
    !$omp private (j, grid, lm) &
    !$omp reduction(+: uV_Psi, uV_grad_Psi)
    do j=1,num_ps_points(atom)
      grid=ps_grid(j,atom)
      uV_Psi=uV_Psi+uV_nl(j,i)*Psi(grid,orbital)
      uV_grad_Psi(:)=uV_grad_Psi(:)+uV_nl(j,i)*wlap_p(:,grid)
    end do
    !$omp end parallel do
    f=-two_occ*Grid_Volume**2*s_uVu_nl(i)
    force_psiREAL(:,atom)=force_psiREAL(:,atom)+uV_grad_Psi(:)*Conjg(uv_Psi)*f
  end do
end do

! do i1=1,N_total_atom
!   write(44444102,'(a,i4,3ES20.10E3)') "fps1 ",i1,force_psiREAL(1:3,i1)
! end do

! force from other ions

!$omp parallel do if(N_total_atom > 20) &
!$omp default(shared) &
!$omp private (i1, i2, r, w)
do i1=1,N_total_atom
  if (z_atom(atom_index(i1))/=0) then
    do i2=1,N_total_atom
      if((i1/=i2).and.(z_atom(atom_index(i2))/=0)) then
        r=sqrt((Position(1,i1)-Position(1,i2))**2+ &
               (Position(2,i1)-Position(2,i2))**2+ &
               (Position(3,i1)-Position(3,i2))**2)
        w=Charge_pp(atom_index(i1))*Charge_pp(atom_index(i2))/r**3*E2
        force_psiREAL(:,i1)=force_psiREAL(:,i1)+w*(Position(:,i1)-Position(:,i2))
      endif
    enddo
  endif
enddo
!$omp end parallel do

! do i1=1,N_total_atom
!   write(44444102,'(a,i4,3ES20.10E3)') "fion ",i1,force_psiREAL(1:3,i1)
! end do

! force from projectile
if (use_projectile) then
  !$omp parallel do if(N_total_atom > 400) &
  !$omp default(shared) &
  !$omp private (i, r, w, ai)
  do i=1,N_total_atom
    ai=atom_index(i)
    if (z_atom(ai)/=0) then
	  ! removed projectile_potential_soft_param for direct collisions
      r=sqrt((Position(1,i)-projectile_x)**2+ &
           (Position(2,i)-projectile_y)**2+ &
           (Position(3,i)-projectile_z)**2 )
            ! projectile_potential_soft_param**2 )
	  if(projectile_ion_full_charge) then
	    w=z_atom(ai)*projectile_charge/r**3*E2
	  else
        w=Charge_pp(ai)*projectile_charge/r**3*E2
      end if
      force_psiREAL(1,i)=force_psiREAL(1,i)+w*(Position(1,i)-projectile_x)
      force_psiREAL(2,i)=force_psiREAL(2,i)+w*(Position(2,i)-projectile_y)
      force_psiREAL(3,i)=force_psiREAL(3,i)+w*(Position(3,i)-projectile_z)
    endif
  enddo
  !$omp end parallel do
endif

! do i1=1,N_total_atom
!   write(44444102,'(a,i4,3ES20.10E3)') "fp ",i1,force_psiREAL(1:3,i1)
! end do

! force from local potential

do atom=1,N_total_atom
  it=atom_index(atom)
  if(z_atom(it).ne.0) then
    L=L_ref(it)
    f=1/step_pp(it)
    force_temp=0.0d0
    !$omp parallel do &
    !$omp default(shared) &
    !$omp private (i, x, r2, intr, ratio1, ratio2, Vloc) &
    !$omp reduction(+: force_temp)
    do i=1,N_Lattice_points
      x(:)=Grid_Point(:,i)-Position(:,atom)
      r2=sqrt(x(1)**2+x(2)**2+x(3)**2)+1.d-50
      intr=int(r2*f)
      ratio1=(r2*f-intr)
      ratio2=1.d0-ratio1
      if(intr+1.gt.N_points_max) then
        Vloc=-Charge_pp(atom)*E2/r2+derf(sqrt(bg_beta)*r2)/r2*E2*charge_pp(it)
	  else
	    Vloc=ratio1*v_pp(intr+1,L,it)+ratio2*v_pp(intr,L,it)+derf(sqrt(bg_beta)*r2)/r2*E2*charge_pp(it)
      endif
      force_temp(:)=force_temp(:)+Vloc*grad_density(:,i)
    end do
    !$omp end parallel do
    force_psiREAL(:,atom)=force_psiREAL(:,atom)-grid_volume*force_temp(:)  
  endif
enddo

! do i1=1,N_total_atom
!   write(44444102,'(a,i4,3ES20.10E3)') "flp ",i1,force_psiREAL(1:3,i1)
! end do

! force due to DC field (along x-axis) and due to laser fields
if (using_v_laser1.or.using_v_laser2.or.using_v_laser3.or.using_v_ext.or.using_v_fromfile) then
 do atom=1,N_total_atom
   it=atom_index(atom)
   if(z_atom(it)/=0) then
     w=Charge_pp(it)
     if (using_v_ext) force_psiREAL(1,atom)=force_psiREAL(1,atom)+w*E_ext*factor_static_ef
     if (using_v_laser1) force_psiREAL(1,atom)=force_psiREAL(1,atom)+w*E_laser1*factor_laser1
     if (using_v_laser2) force_psiREAL(2,atom)=force_psiREAL(2,atom)+w*E_laser2*factor_laser2
     if (using_v_laser3) force_psiREAL(3,atom)=force_psiREAL(3,atom)+w*E_laser3*factor_laser3
	 if (using_v_fromfile) then
        force_psiREAL(1,atom)=force_psiREAL(1,atom)+w*laser_xyz_t_iteration(1)
        force_psiREAL(2,atom)=force_psiREAL(2,atom)+w*laser_xyz_t_iteration(2)
        force_psiREAL(3,atom)=force_psiREAL(3,atom)+w*laser_xyz_t_iteration(3)
	 endif
   endif
 enddo
endif

!  van der Waals force for the case of a hydrogen hitting graphene
if (use_vdw) then
  Rc=1.11 
  Rh=1.61
  R0=Rc+Rh
  d=23
  C=sqrt(0.16*1.65)*(6.242e+18)*10**6/(6.02214129e+23)
  do atom=2,N_total_atom
      it= z_atom(atom_index(atom))
         !print *,atom
      if (abs(it-6)<1) then
         !print *, 'go vdw!'
         r=sqrt((position(1,atom)-position(1,1))**2+(position(2,atom)-position(2,1))**2+(position(3,atom)-position(3,1))**2)
        if (damping_vdw) then
         F_mag=d*exp(-d*(r/R0-1))/(R0*(1+exp(-d*(r/R0-1)))**2)*C/r**6-6*C/(r**7*(1+exp(-d*(r/R0-1))))
        else  
         F_mag=-6*C/r**7
        endif
        ! print *, r,F_mag
         force_psiREAL(1,1)=force_psiREAL(1,1)+F_mag*(position(1,1)-position(1,atom))/r
         force_psiREAL(2,1)=force_psiREAL(2,1)+F_mag*(position(2,1)-position(2,atom))/r
         force_psiREAL(3,1)=force_psiREAL(3,1)+F_mag*(position(3,1)-position(3,atom))/r
      endif
  enddo
endif


!write(999,*)'force_wf' ! force
!do i=1,N_total_atom
!  write(999,*)i
!  write(999,*)force(:,i)
!end do
!write(999,*)


end subroutine calculate_force_PsiREAL

! cody
SUBROUTINE calculate_force_ion_proj(force_ponly,natomst)
 implicit none
 integer       :: j,it,grid,lm,atom,i1,i2,i3,orbital,i,l,ai
 real*8        :: f,su,w,r,force_temp(3),two_occ,Rc,Rh,R0,d,C,F_mag
 complex*16    :: uV_Psi((L_max+1)**2),uV_grad_Psi(3,(L_max+1)**2)
 double precision :: ratio1,ratio2,Vloc,r2,x(3)
 integer          :: intr,natomst
 real*8,parameter :: fc=a_b*a_b/e2
 real*8           :: force_ponly(3,natomst)

 force_ponly=0.d0
  !$omp parallel do if(N_total_atom > 400) &
  !$omp default(shared) &
  !$omp private (i, r, w, ai)
  do i=1,N_total_atom
    ai=atom_index(i)
    if (z_atom(ai)/=0) then
	  ! removed projectile_potential_soft_param for direct collisions
      r=sqrt((Position(1,i)-projectile_x)**2+ &
           (Position(2,i)-projectile_y)**2+ &
           (Position(3,i)-projectile_z)**2 )
            ! projectile_potential_soft_param**2 )
	  if(projectile_ion_full_charge) then
		if(r<Core_radius(atom_index(i))) then
		  w=z_atom(ai)*projectile_charge/r**3*E2
		else
		  w=Charge_pp(ai)*projectile_charge/r**3*E2
		end if
	  else
        w=Charge_pp(ai)*projectile_charge/r**3*E2
      end if
	  force_ponly(1,i)=force_ponly(1,i)+w*(Position(1,i)-projectile_x)
      force_ponly(2,i)=force_ponly(2,i)+w*(Position(2,i)-projectile_y)
      force_ponly(3,i)=force_ponly(3,i)+w*(Position(3,i)-projectile_z)
    endif
  enddo
  !$omp end parallel do
 
end SUBROUTINE calculate_force_ion_proj
 
! cody
SUBROUTINE calculate_force_noProj(force_nop,natomst)
 implicit none
 integer       :: j,it,grid,lm,atom,i1,i2,i3,orbital,i,l,ai
 real*8        :: f,su,w,r,force_temp(3),two_occ,Rc,Rh,R0,d,C,F_mag
 !complex*16    :: uV_Psi((L_max+1)**2),uV_grad_Psi(3,(L_max+1)**2)
 complex*16    :: uV_Psi,uV_grad_Psi(3)
 double precision :: ratio1,ratio2,Vloc,r2,x(3)
 integer          :: intr,natomst
 real*8,parameter :: fc=a_b*a_b/e2
 real*8           :: force_nop(3,natomst)
 real*8 :: force_bg(3,n_total_atom)

 call local_force_bg(force_bg)


force_nop=-force_bg
grad_density=0.d0
! force from nonlocal_pseudo_potential
do orbital=1,N_orbitals

  !$omp parallel do &
  !$omp default(shared) &
  !$omp private (grid, i1, i2, i3)
  do grid=1,N_lattice_points
    i1=Lattice(1,grid)
    i2=Lattice(2,grid)
    i3=Lattice(3,grid)
    wphi_c(i1,i2,i3)=Psi_c(grid,orbital)
  end do
  !$omp end parallel do

  call nabla

  two_occ=2*occupation(orbital)
  !$omp parallel do &
  !$omp default(shared) &
  !$omp private (i)
  do i=1,N_lattice_points
    grad_density(:,i)=grad_density(:,i)+two_occ*Conjg(Psi_c(i,orbital))*wlap_p(:,i)
  end do
  !$omp end parallel do

  do i=1,N_nl
    atom=nl_ind(i)
    uV_Psi=(0.d0,0.d0)
    uV_grad_Psi=(0.d0,0.d0)
    !$omp parallel do &
    !$omp default(shared) &
    !$omp private (j, grid, lm) &
    !$omp reduction(+: uV_Psi, uV_grad_Psi)
    do j=1,num_ps_points(atom)
      grid=ps_grid(j,atom)
      uV_Psi=uV_Psi+uV_nl(j,i)*Psi_c(grid,orbital)
      uV_grad_Psi(:)=uV_grad_Psi(:)+uV_nl(j,i)*wlap_p(:,grid)
    end do
    !$omp end parallel do
    f=-two_occ*Grid_Volume**2*s_uVu_nl(i)
    force_nop(:,atom)=force_nop(:,atom)+uV_grad_Psi(:)*Conjg(uv_Psi)*f
  end do
end do

! force from other ions

!$omp parallel do if(N_total_atom > 20) &
!$omp default(shared) &
!$omp private (i1, i2, r, w)
do i1=1,N_total_atom
  if (z_atom(atom_index(i1))/=0) then
    do i2=1,N_total_atom
      if((i1/=i2).and.(z_atom(atom_index(i2))/=0)) then
        r=sqrt((Position(1,i1)-Position(1,i2))**2+ &
               (Position(2,i1)-Position(2,i2))**2+ &
               (Position(3,i1)-Position(3,i2))**2)
        w=Charge_pp(atom_index(i1))*Charge_pp(atom_index(i2))/r**3*E2
        force_nop(:,i1)=force_nop(:,i1)+w*(Position(:,i1)-Position(:,i2))
      endif
    enddo
  endif
enddo
!$omp end parallel do


! force from local potential

do atom=1,N_total_atom
  it=atom_index(atom)
  if(z_atom(it).ne.0) then
    L=L_ref(it)
    f=1/step_pp(it)
    force_temp=0.0d0
    !$omp parallel do &
    !$omp default(shared) &
    !$omp private (i, x, r2, intr, ratio1, ratio2, Vloc) &
    !$omp reduction(+: force_temp)
    do i=1,N_Lattice_points
      x(:)=Grid_Point(:,i)-Position(:,atom)
      r2=sqrt(x(1)**2+x(2)**2+x(3)**2)+1.d-50
      intr=int(r2*f)
      ratio1=(r2*f-intr)
      ratio2=1.d0-ratio1
      if(intr+1.gt.N_points_max) then
        Vloc=-Charge_pp(atom)*E2/r2+derf(sqrt(bg_beta)*r2)/r2*E2*charge_pp(it)
	  else
	    Vloc=ratio1*v_pp(intr+1,L,it)+ratio2*v_pp(intr,L,it)+derf(sqrt(bg_beta)*r2)/r2*E2*charge_pp(it)
      endif
      force_temp(:)=force_temp(:)+Vloc*grad_density(:,i)
    end do
    !$omp end parallel do
    force_nop(:,atom)=force_nop(:,atom)-grid_volume*force_temp(:)  
  endif
enddo

! force due to DC field (along x-axis) and due to laser fields
if (using_v_laser1.or.using_v_laser2.or.using_v_laser3.or.using_v_ext.or.using_v_fromfile) then
 do atom=1,N_total_atom
   it=atom_index(atom)
   if(z_atom(it)/=0) then
     w=Charge_pp(it)
     if (using_v_ext) force_nop(1,atom)=force_nop(1,atom)+w*E_ext*factor_static_ef
     if (using_v_laser1) force_nop(1,atom)=force_nop(1,atom)+w*E_laser1*factor_laser1
     if (using_v_laser2) force_nop(2,atom)=force_nop(2,atom)+w*E_laser2*factor_laser2
     if (using_v_laser3) force_nop(3,atom)=force_nop(3,atom)+w*E_laser3*factor_laser3
	 if (using_v_fromfile) then
        force_nop(1,atom)=force_nop(1,atom)+w*laser_xyz_t_iteration(1)
        force_nop(2,atom)=force_nop(2,atom)+w*laser_xyz_t_iteration(2)
        force_nop(3,atom)=force_nop(3,atom)+w*laser_xyz_t_iteration(3)
	 endif
   endif
 enddo
endif

!  van der Waals force for the case of a hydrogen hitting graphene
if (use_vdw) then
  Rc=1.11 
  Rh=1.61
  R0=Rc+Rh
  d=23
  C=sqrt(0.16*1.65)*(6.242e+18)*10**6/(6.02214129e+23)
  do atom=2,N_total_atom
      it= z_atom(atom_index(atom))
         !print *,atom
      if (abs(it-6)<1) then
         !print *, 'go vdw!'
         r=sqrt((position(1,atom)-position(1,1))**2+(position(2,atom)-position(2,1))**2+(position(3,atom)-position(3,1))**2)
        if (damping_vdw) then
         F_mag=d*exp(-d*(r/R0-1))/(R0*(1+exp(-d*(r/R0-1)))**2)*C/r**6-6*C/(r**7*(1+exp(-d*(r/R0-1))))
        else  
         F_mag=-6*C/r**7
        endif
        ! print *, r,F_mag
         force_nop(1,1)=force_nop(1,1)+F_mag*(position(1,1)-position(1,atom))/r
         force_nop(2,1)=force_nop(2,1)+F_mag*(position(2,1)-position(2,atom))/r
         force_nop(3,1)=force_nop(3,1)+F_mag*(position(3,1)-position(3,atom))/r
      endif
  enddo
endif

end subroutine calculate_force_noProj


subroutine compute_force_on_projectile(f)
!This subroutine computes force on projectile. The force is the sum of two
!terms. One comes from ion charges, the other comes from the electron density.
!It is assumed that array density contains freshly calculated electron density
!when the this subroutine is called.
real(8)  :: f(3)
real(8)  :: dx,dy,dz,r,s,w
integer  :: i,ai
real(8)  :: f_debug(3)

f(1:3)=0.0d0

s=projectile_charge*E2
!force due to ions
!$omp parallel do if(N_total_atom > 400) &
!$omp default(shared) &
!$omp private (i, dx, dy, dz, r, w, ai) &
!$omp reduction(+: f)
do i=1,N_total_atom
  ai=atom_index(i)
  if (z_atom(ai)/=0) then
    dx=projectile_x-Position(1,i)
    dy=projectile_y-Position(2,i)
    dz=projectile_z-Position(3,i)
	! cody removed soft parameter for direct collisions
    ! r=sqrt(dx**2+dy**2+dz**2+projectile_potential_soft_param**2)
	r=sqrt(dx**2+dy**2+dz**2)
	if(projectile_ion_full_charge) then
	  w=z_atom(ai)*s/r**3
	else
      w=Charge_pp(ai)*s/r**3
    end if
    f(1)=f(1)+w*dx
    f(2)=f(2)+w*dy
    f(3)=f(3)+w*dz
  endif
enddo
!$omp end parallel do

!write(*,*) 'force on projectile due to ions, x :',f(1)
!write(*,*) 'force on projectile due to ions, y :',f(2)
!write(*,*) 'force on projectile due to ions, z :',f(3)

f_debug=0.0
s=-projectile_charge*grid_volume*E2
!force due to electron density
!$omp parallel do &
!$omp default(shared) &
!$omp private (i, dx, dy, dz, r, w) &
!$omp reduction(+: f, f_debug)
do i=1,N_lattice_points
  dx=projectile_x-Grid_Point(1,i)
  dy=projectile_y-Grid_Point(2,i)
  dz=projectile_z-Grid_Point(3,i)
  r=sqrt(dx**2+dy**2+dz**2+projectile_potential_soft_param**2)
  w=s*density(i)/r**3
  f(1)=f(1)+w*dx
  f(2)=f(2)+w*dy
  f(3)=f(3)+w*dz
  f_debug(1)=f_debug(1)+w*dx
  f_debug(2)=f_debug(2)+w*dy
  f_debug(3)=f_debug(3)+w*dz
enddo
!$omp end parallel do
!write(*,*) 'force on projectile due to electrons, x :',f_debug(1)
!write(*,*) 'force on projectile due to electrons, y :',f_debug(2)
!write(*,*) 'force on projectile due to electrons, z :',f_debug(3)

end subroutine compute_force_on_projectile

subroutine compute_force_on_projectile_nuc(f)
!This subroutine computes force on projectile. The force  comes from ion charges
real(8)  :: f(3)
real(8)  :: dx,dy,dz,r,s,w
integer  :: i,ai
real(8)  :: f_debug(3)

f(1:3)=0.0d0

s=projectile_charge*E2
!force due to ions
!$omp parallel do if(N_total_atom > 400) &
!$omp default(shared) &
!$omp private (i, dx, dy, dz, r, w, ai) &
!$omp reduction(+: f)
do i=1,N_total_atom
  ai=atom_index(i)
  if (z_atom(ai)/=0) then
    dx=projectile_x-Position(1,i)
    dy=projectile_y-Position(2,i)
    dz=projectile_z-Position(3,i)
	! cody removed soft parameter for direct collisions
    ! r=sqrt(dx**2+dy**2+dz**2+projectile_potential_soft_param**2)
	r=sqrt(dx**2+dy**2+dz**2)
	if(projectile_ion_full_charge) then
	  w=z_atom(ai)*s/r**3
	else
      w=Charge_pp(ai)*s/r**3
    end if
	f(1)=f(1)+w*dx
    f(2)=f(2)+w*dy
    f(3)=f(3)+w*dz
  endif
enddo
!$omp end parallel do


end subroutine compute_force_on_projectile_nuc

subroutine compute_force_on_projectile_elec(f)
!This subroutine computes force on projectile. The force is the sum of two
!terms. One comes from ion charges, the other comes from the electron density.
!It is assumed that array density contains freshly calculated electron density
!when the this subroutine is called.
real(8)  :: f(3)
real(8)  :: dx,dy,dz,r,s,w
integer  :: i,ai
real(8)  :: f_debug(3)

f(1:3)=0.0d0

f_debug=0.0
s=-projectile_charge*grid_volume*E2
!force due to electron density
!$omp parallel do &
!$omp default(shared) &
!$omp private (i, dx, dy, dz, r, w) &
!$omp reduction(+: f, f_debug)
do i=1,N_lattice_points
  dx=projectile_x-Grid_Point(1,i)
  dy=projectile_y-Grid_Point(2,i)
  dz=projectile_z-Grid_Point(3,i)
  r=sqrt(dx**2+dy**2+dz**2+projectile_potential_soft_param**2)
  w=s*density(i)/r**3
  f(1)=f(1)+w*dx
  f(2)=f(2)+w*dy
  f(3)=f(3)+w*dz
  f_debug(1)=f_debug(1)+w*dx
  f_debug(2)=f_debug(2)+w*dy
  f_debug(3)=f_debug(3)+w*dz
enddo
!$omp end parallel do

end subroutine compute_force_on_projectile_elec

SUBROUTINE calculate_force_r
!Same as calculate_force but for the case of real (not complex) orbitals
 implicit none
 integer       :: j,it,grid,lm,atom,i1,i2,i3,orbital,i,l,ai
 real*8        :: f,su,w,r,force_temp(3),two_occ
 !real*8        :: uV_Psi((L_max+1)**2),uV_grad_Psi(3,(L_max+1)**2)
 real*8    :: uV_Psi,uV_grad_Psi(3)
 real*8        :: ratio1,ratio2,Vloc,r2,x(3)
 integer          :: intr
 real*8,parameter :: fc=a_b*a_b/e2

 real*8 :: force_bg(3,n_total_atom)

 call local_force_bg(force_bg)

 force=-force_bg
!vk force=0.d0

 grad_density=0.d0
! force from nonlocal_pseudo_potential
do orbital=1,N_orbitals

  !$omp parallel do &
  !$omp default(shared) &
  !$omp private (grid, i1, i2, i3)
  do grid=1,N_lattice_points
    i1=Lattice(1,grid)
    i2=Lattice(2,grid)
    i3=Lattice(3,grid)
    wphi(i1,i2,i3)=Psi(grid,orbital)
  end do
  !$omp end parallel do

  call nabla_r

  two_occ=2*occupation(orbital)
  !$omp parallel do &
  !$omp default(shared) &
  !$omp private (i)
  do i=1,N_lattice_points
    grad_density(:,i)=grad_density(:,i)+two_occ*Psi(i,orbital)*wlap_r(:,i)
  end do
  !$omp end parallel do

  do i=1,N_nl
    atom=nl_ind(i)
    uV_Psi=(0.d0,0.d0)
    uV_grad_Psi=(0.d0,0.d0)
    !$omp parallel do &
    !$omp default(shared) &
    !$omp private (j, grid, lm) &
    !$omp reduction(+: uV_Psi, uV_grad_Psi)
    do j=1,num_ps_points(atom)
      grid=ps_grid(j,atom)
      uV_Psi=uV_Psi+uV_nl(j,i)*Psi(grid,orbital)
      uV_grad_Psi(:)=uV_grad_Psi(:)+uV_nl(j,i)*wlap_r(:,grid)
    end do
    !$omp end parallel do
    f=-two_occ*Grid_Volume**2*s_uVu_nl(i)
    force(:,atom)=force(:,atom)+uV_grad_Psi(:)*(uv_Psi)*f
  end do
end do

 ! force from other ions

!$omp parallel do if(N_total_atom > 20) &
!$omp default(shared) &
!$omp private (i1, i2, r, w)
do i1=1,N_total_atom
  if (z_atom(atom_index(i1))/=0) then
    do i2=1,N_total_atom
      if((i1/=i2).and.(z_atom(atom_index(i2))/=0)) then
        r=sqrt((Position(1,i1)-Position(1,i2))**2+ &
               (Position(2,i1)-Position(2,i2))**2+ &
               (Position(3,i1)-Position(3,i2))**2)
        w=Charge_pp(atom_index(i1))*Charge_pp(atom_index(i2))/r**3*E2
        force(:,i1)=force(:,i1)+w*(Position(:,i1)-Position(:,i2))
      endif
    enddo
  endif
enddo
!$omp end parallel do

! force from projectile
if (use_projectile) then
  !$omp parallel do if(N_total_atom > 400) &
  !$omp default(shared) &
  !$omp private (i, r, w, ai)
  do i=1,N_total_atom
    ai=atom_index(i)
    if (z_atom(ai)/=0) then
	  ! removed projectile_potential_soft_param for direct collisions
      r=sqrt((Position(1,i)-projectile_x)**2+ &
           (Position(2,i)-projectile_y)**2+ &
           (Position(3,i)-projectile_z)**2)
            ! projectile_potential_soft_param**2 )
      w=Charge_pp(ai)*projectile_charge/r**3*E2
      force(1,i)=force(1,i)+w*(Position(1,i)-projectile_x)
      force(2,i)=force(2,i)+w*(Position(2,i)-projectile_y)
      force(3,i)=force(3,i)+w*(Position(3,i)-projectile_z)
    endif
  enddo
  !$omp end parallel do
endif

! force from local potential

do atom=1,N_total_atom
  it=atom_index(atom)
  if(z_atom(it).ne.0) then
    L=L_ref(it)
    f=1/step_pp(it)
    force_temp=0.0d0
    !$omp parallel do &
    !$omp default(shared) &
    !$omp private (i, x, r2, intr, ratio1, ratio2, Vloc) &
    !$omp reduction(+: force_temp)
    do i=1,N_Lattice_points
      x(:)=Grid_Point(:,i)-Position(:,atom)
      r2=sqrt(x(1)**2+x(2)**2+x(3)**2)+1.d-50
      intr=int(r2*f)
      ratio1=(r2*f-intr)
      ratio2=1.d0-ratio1
      if(intr+1.gt.N_points_max) then
        Vloc=-Charge_pp(atom)*E2/r2+derf(sqrt(bg_beta)*r2)/r2*E2*charge_pp(it)
	  else
	    Vloc=ratio1*v_pp(intr+1,L,it)+ratio2*v_pp(intr,L,it)+derf(sqrt(bg_beta)*r2)/r2*E2*charge_pp(it)
      endif
      force_temp(:)=force_temp(:)+Vloc*grad_density(:,i)
    end do
    !$omp end parallel do
    force(:,atom)=force(:,atom)-grid_volume*force_temp(:)  
  endif
enddo

! force due to DC field (along x-axis) and due to laser fields
if (using_v_laser1.or.using_v_laser2.or.using_v_laser3.or.using_v_ext.or.using_v_fromfile) then
 do atom=1,N_total_atom
   it=atom_index(atom)
   if(z_atom(it)/=0) then
     w=Charge_pp(it)
     if (using_v_ext) force(1,atom)=force(1,atom)+w*E_ext
     if (using_v_laser1) force(1,atom)=force(1,atom)+w*E_laser1*time_factor(1)
     if (using_v_laser2) force(2,atom)=force(2,atom)+w*E_laser2*time_factor(2)
     if (using_v_laser3) force(3,atom)=force(3,atom)+w*E_laser3*time_factor(3)
	 if (using_v_fromfile) then
        force(1,atom)=force(1,atom)+w*laser_xyz_t_iteration(1)
        force(2,atom)=force(2,atom)+w*laser_xyz_t_iteration(2)
        force(3,atom)=force(3,atom)+w*laser_xyz_t_iteration(3)
	 endif
   endif
 enddo
endif

end subroutine calculate_force_r

subroutine save_forces_r()
!This subroutine saves forces on ions into file forces_filename.
!Normally this subroutine should be called after the ground state
!calculations are completed. The knowledge of forces provides an
!estimate how far the ionic geometry is from the equilibrium one.
!Warning: the computed forces also include the forces due to
!electric fields (if specified) and/or projectile (if used)
logical :: force_allocated,wlap_r_allocated,Psi_allocated,wphi_allocated
integer :: atom,ai,elem,realatomcount,j,j1,j2,k,ii,orbital
integer :: k1min,k1max,k2min,k2max,k3min,k3max
real(8) :: fxmax,fymax,fzmax,fx2,fy2,fz2

force_allocated=allocated(force)
wlap_r_allocated=allocated(wlap_r)
Psi_allocated=allocated(Psi)
wphi_allocated=allocated(wphi)
if(.not.force_allocated) allocate(force(3,N_total_atom))
if(.not.wlap_r_allocated) allocate(wlap_r(3,N_lattice_points))
!In case of atomic orbitals we convert them into numeric orbitals
if (run_type==12) then
  if (.not.Psi_allocated) allocate(Psi(N_lattice_points,N_orbitals))
  if (.not.wphi_allocated) then
    k1min=N_Lattice_min(1)
    k1max=N_Lattice_max(1)
    k2min=N_Lattice_min(2)
    k2max=N_Lattice_max(2)
    k3min=N_Lattice_min(3)
    k3max=N_Lattice_max(3)
    allocate(wphi(k1min-Nd-1:k1max+Nd,k2min-Nd-1:k2max+Nd,k3min-Nd-1:k3max+Nd))
  endif
  !This maps atomic orbitals into numeric orbitals (i.e. grid).
  !The points with numerical values of atomic orbitals are assumed to be in psi_basis_r,
  !while array c_basis is assumed to contain the linear coefficients.
  Psi=0.0d0
  do orbital=1,N_orbitals
    do j=1,N_diag
      j1=basis_atom(1,j)
      j2=basis_atom(2,j)
      do k=1,int_points(j2)
        ii=Ind_basis(k,j2)
        Psi(ii,orbital)=Psi(ii,orbital)+c_basis(j,orbital)*psi_basis_r(k,j)
      enddo
    enddo
  enddo
endif
call calculate_force_r()
fxmax=0.0d0
fymax=0.0d0
fzmax=0.0d0
fx2=0.0d0
fy2=0.0d0
fz2=0.0d0
realatomcount=0
open(forces_file,file=trim(adjustl(forces_filename)),status='replace')
write(forces_file,'(4x,a,2x,a,3(7x,a,3x),3(6x,a))') '#','Ion','X[A]','Y[A]','Z[A]','Fx[eV/A]','Fy[eV/A]','Fz[eV/A]'
do atom=1,N_total_atom
  ai=atom_index(atom)
  elem=z_atom(ai)
  if (elem/=0) then
    realatomcount=realatomcount+1
    write(forces_file,'(i5,2x,a,6(1x,f13.6))') atom,element_symbols(elem), &
      Position(1,atom),Position(2,atom),Position(3,atom), &
      force(1,atom),force(2,atom),force(3,atom)
  else
    write(forces_file,'(i5,2x,a,3(1x,f13.6))') atom,' Xx', &
      Position(1,atom),Position(2,atom),Position(3,atom)
  endif
  fx2=fx2+force(1,atom)**2
  fy2=fy2+force(2,atom)**2
  fz2=fz2+force(3,atom)**2
  if (abs(force(1,atom))>fxmax) fxmax=abs(force(1,atom))
  if (abs(force(2,atom))>fymax) fymax=abs(force(2,atom))
  if (abs(force(3,atom))>fzmax) fzmax=abs(force(3,atom))
enddo
write(forces_file,*)
fx2=sqrt(fx2/realatomcount)
fy2=sqrt(fy2/realatomcount)
fz2=sqrt(fz2/realatomcount)
write(forces_file,'(1x,a,39x,3(1x,f13.6))') 'Abs. maximum',fxmax,fymax,fzmax
write(forces_file,'(1x,a,35x,3(1x,f13.6))') 'Root mean square',fx2,fy2,fz2
close(forces_file)
if(.not.force_allocated) deallocate(force)
if(.not.wlap_r_allocated) deallocate(wlap_r)
if(.not.Psi_allocated) deallocate(Psi)
if(.not.wphi_allocated) deallocate(wphi)

end subroutine save_forces_r


subroutine save_dipole_moment
!This subroutine saves dipole moment value in file dipole_moment_filename.
!Note that this is not to save the time-evolution of the dipole moment.
!Normally this subroutine should be called after the ground state
!calculations are completed to provide the user with the information about
!the system.
real(8)  dpx,dpy,dpz,absdp
open(dipole_moment_file,file=trim(adjustl(dipole_moment_filename)),status='replace')
dpx=dipole_moment(1)
dpy=dipole_moment(2)
dpz=dipole_moment(3)
absdp=sqrt(dpx**2+dpy**2+dpz**2)
write(dipole_moment_file,'(1x,a,5x,a,7x,a)') 'Direction','[eV*Angstrom/Volt]','[Debye]'
write(dipole_moment_file,*)
write(dipole_moment_file,'(1x,a,10x,f18.9,1x,f18.9)') 'X',dpx,dpx*4.803204191d0
write(dipole_moment_file,'(1x,a,10x,f18.9,1x,f18.9)') 'Y',dpy,dpy*4.803204191d0
write(dipole_moment_file,'(1x,a,10x,f18.9,1x,f18.9)') 'Z',dpz,dpz*4.803204191d0
write(dipole_moment_file,'(1x,a,2x,f18.9,1x,f18.9)')  'Magnitude',absdp,absdp*4.803204191d0
close(dipole_moment_file)
end subroutine save_dipole_moment

! see Hamiltonian_density_split for split parallel version
SUBROUTINE Hamiltonian_density
use libxc_stuff
  
  if(debug_output_level >= 2) write(log_file,*) "Call Hamiltonian_density"
  ! Update the Hartree and exchange-correlation potentials, using the density
  if(use_adsic) then
    if(.NOT.allocated(full_density_save)) allocate(full_density_save(N_lattice_points))
    full_density_save=density
    density=density*(num_electrons_sys_init-1)/num_electrons_sys_init
  end if

  call Poisson_Solver
  V_hartree=E2*VH

  if(use_adsic) then
    density=full_density_save
  end if  

  if(xc_functional_mode==0) then ! legacy mode
    call Exchange_correlation_potential
	call exchange_correlation_energy
  else if(xc_functional_mode==7) then
    call gen_exc_cor_libxc
  else
    call exc_cor(xc_functional_mode)
  end if

END SUBROUTINE Hamiltonian_density

! for doing XC calc on a different process See Hamiltonian_density for non split version
SUBROUTINE Hamiltonian_density_split
use libxc_stuff
 INTEGER :: MPI_TAG ! arbitrary INTEGER to match
 integer :: status(MPI_STATUS_SIZE)
  
if(MPI_master) then
  if(debug_output_level >= 2) write(log_file,*) "Call Hamiltonian_density"
  ! Update the Hartree and exchange-correlation potentials, using the density
  if(use_adsic) then
    if(.NOT.allocated(full_density_save)) allocate(full_density_save(N_lattice_points))
    full_density_save=density
    density=density*(num_electrons_sys_init-1)/num_electrons_sys_init
  end if

  call Poisson_Solver
  V_hartree=E2*VH

  if(use_adsic) then
    density=full_density_save
  end if  
end if

if(MPI_xc_slave) then
  if(xc_functional_mode==0) then ! legacy mode
    call Exchange_correlation_potential
	call exchange_correlation_energy
  else if(xc_functional_mode==7) then
    call gen_exc_cor_libxc
  else
    call exc_cor(xc_functional_mode)
  end if
end if

if(MPI_xc_process/=0) then ! must move E_exchange & V_exchange from slave process
  if(MPI_master) then
    MPI_TAG=601
    call MPI_Recv(V_exchange,N_Lattice_points,MPI_DOUBLE_PRECISION,MPI_xc_process,MPI_TAG,MPI_COMM_WORLD,status,MPI_ierror)
    if(MPI_ierror/=0) write(log_file,*) "MPI_ierror",MPI_ierror," at Location ID: ham100"
	MPI_TAG=602
    call MPI_Recv(E_exchange,1,MPI_DOUBLE_PRECISION,MPI_xc_process,MPI_TAG,MPI_COMM_WORLD,status,MPI_ierror)
	if(MPI_ierror/=0) write(log_file,*) "MPI_ierror",MPI_ierror," at Location ID: ham200"
  end if
  if(MPI_xc_slave) then
    MPI_TAG=601
    call MPI_Send(V_exchange,N_Lattice_points,MPI_DOUBLE_PRECISION,0,MPI_TAG,MPI_COMM_WORLD,MPI_ierror)
	if(MPI_ierror/=0) write(log_file,*) "MPI_ierror",MPI_ierror," at Location ID: ham300"
	MPI_TAG=602
	call MPI_Send(E_exchange,1,MPI_DOUBLE_PRECISION,0,MPI_TAG,MPI_COMM_WORLD,MPI_ierror)
	if(MPI_ierror/=0) write(log_file,*) "MPI_ierror",MPI_ierror," at Location ID: ham400"
  end if
  
end if

END SUBROUTINE Hamiltonian_density_split


subroutine exc_cor(iexc)
! Hartree a.u.
!
!    V_xc()      xc potential
!    evxc        xc potential energy
!    ex          exchange energy
!    ec          correlation energy    

  use excpot
  implicit none
  integer          :: iexc
  double precision :: evxc,ec,ex,v_check
  double precision :: dens_AU(N_lattice_points) ! density in atomic units
  double precision :: grad_d(3,N_lattice_points)
  double precision :: grad_abs_grad_d(3,N_lattice_points)
  double precision :: abs_grad_d(N_lattice_points)
  double precision :: lap_d(N_lattice_points)
  double precision :: grad_up(3,N_lattice_points)
  double precision :: grad_dw(3,N_lattice_points)
  double precision :: zeta(N_lattice_points)
  double precision :: grad_zeta(3,N_lattice_points)
  integer          :: i,i1,i2,i3,j
  double precision :: exc,fxc,rs,x,aln,ecp,d(2),xpot(2),cpot(2),rh,fx
  double precision :: dex(N_lattice_points),dec(N_lattice_points)
  real*8  :: the_sum,eps_xc,rssq,rho,rsln,v_xc,rat_d_gAg
  real*8, parameter :: tol=1.0d-10
  real*8, parameter :: inv_a_B=1.0d0/a_B
  real*8, parameter :: c1=3.d0/(4.d0*pi)
  real*8, parameter :: c2=4.d0/3.d0*0.4582d0
  real*8, parameter :: DoubleRy=2.d0*Ry
  real*8, parameter :: tol_gga_grad=1d-11
  real*8, parameter :: tol_gga_dens=1d-11
  real*8, parameter :: tol_gga_pot=1d-11
  real*8, parameter :: tol_gga_rat_gAg=10.d0
  real*8            :: grid_volume_AU,grid_step_AU(3)
  
  xc_debug_switch=.TRUE.
  
  grid_step_AU=grid_step/a_B
  grid_volume_AU=grid_volume/(a_B**3)
  dens_AU=density*a_B**3 ! convert from e/Angstrom^3 to e/Bohr^3
  if( (iexc .EQ. 4) .OR. (iexc .EQ. 5)) then ! need gradients and stuff
    !call gradient_real(dens_AU,grad_d)
	!call laplace_real(dens_AU,lap_d)
	call gradient_AND_laplace_real(dens_AU,grad_d,lap_d,grid_step_AU)
	do i=1,N_Lattice_points
        if(abs(grad_d(1,i))<tol_gga_grad) grad_d(1,i)=tol_gga_grad
	    if(abs(grad_d(2,i))<tol_gga_grad) grad_d(2,i)=tol_gga_grad
	    if(abs(grad_d(3,i))<tol_gga_grad) grad_d(3,i)=tol_gga_grad
	end do
    if(spin_polarized) then
      call gradient_real(density_up*a_B**3,grad_up,grid_step_AU)
	  call gradient_real(density_down*a_B**3,grad_dw,grid_step_AU)
      do i=1,N_lattice_points
        zeta(i)=(0.5d0*density_up(i)-0.5d0*density_down(i))/density(i) ! no need to convert as it is unitless
      end do
      call gradient_real(zeta,grad_zeta,grid_step_AU)
    else
      grad_up=0.5d0*grad_d
      grad_dw=0.5d0*grad_d
	  zeta=0.d0
	  grad_zeta=0.d0
    end if
    do i=1,N_lattice_points
      abs_grad_d(i)=sqrt(grad_d(1,i)**2+grad_d(2,i)**2+grad_d(3,i)**2)
    end do
    call gradient_real(abs_grad_d,grad_abs_grad_d,grid_step_AU)
	
    !do i=1,N_lattice_points
    !  do j=1,3
    !    rat_d_gAg=dens_AU(i)/(grad_abs_grad_d(j,i)+1.0D-12)
    !    if(abs(rat_d_gAg)> tol_gga_rat_gAg) then
    !      grad_abs_grad_d(j,i)= SIGN(1.0,grad_abs_grad_d(j,i))*tol_gga_rat_gAg*dens_AU(i)
    !    end if
    !  end do
    !end do
  end if

   ex=0.d0
   ec=0.d0
   V_Exchange=0.d0
   evxc=0.d0
   
   !  6=Perdew Zunger, use as error checking for 4 & 5
   if((iexc .eq. 6).OR.(iexc .eq. 4).OR.(iexc .eq. 5)) then

     do i=1,N_lattice_points
       rho=dens_AU(i)
       if (rho < tol) rho = tol
	   ! took out a_B here since it is already in AU
       rs=((c1/rho)**(1.d0/3.d0))  
       V_xc=-c2/rs
       if(rs>1.d0) then
         rssq=sqrt(rs)
         V_xc=V_xc+gammaU*(1.d0+7.d0/6.d0*beta1U*rssq+4.d0/3.d0*beta2U*rs)/(1.d0+beta1U*rssq+beta2U*rs)**2
       else
         rsln=log(rs)
         V_xc=V_xc+AU*rsln+(BU-AU/3.d0)+2.d0/3.d0*CU*rs*rsln+(2.d0*DU-CU)/3.d0*rs
       endif
       V_Exchange(i)=V_xc
	   !write(1937816,'(2ES26.16E3)') density(i),V_exchange(i)
     enddo
	 !close(1937816)
     the_sum=0.d0
     do i=1,N_lattice_points
       rho=dens_AU(i)
       if (rho < tol) rho = tol
       rs=((c1/rho)**(1.d0/3.d0))
       eps_xc=-.4582d0/rs
       if(rs>1.d0) then
         rssq=sqrt(rs)
         eps_xc=eps_xc+gammaU/(1.d0+beta1U*rssq+beta2U*rs)
       else
         rsln=log(rs)
         eps_xc=eps_xc+AU*rsln+BU+CU*rs*rsln+DU*rs
       endif
       !eps_xc=DoubleRy*eps_xc
       the_sum=the_sum+dens_AU(i)*(eps_xc-V_Exchange(i))
     enddo
     ex=the_sum*grid_volume_AU     
   endif
   
!  Wigner
   if(iexc .eq. 1) then
     do i=1,N_lattice_points
       call wigner(dens_AU(i),ex,fx,exc,fxc)
       V_Exchange(i)=fxc
       dex(i)=ex
       dec(i)=exc-ex
     enddo

! Hedin-Lundqvist
   else if(iexc .eq. 2) then
     do i=1,N_lattice_points
       rh=dens_AU(i)
       if(rh .ne. 0.0d0) then
         rs=0.62035049d0*rh**(-0.3333333333333333d0)
         x=rs/21.0d0
         aln=dlog(1.0d0 + 1.0d0/x)
         ecp = aln+(x**3*aln-x*x)+x/2-1.0d0/3.0d0
         dex(i)=-0.458175d0/rs - 0.0225d0*ecp
         V_Exchange(i)=-0.6109d0/rs - 0.0225d0*aln
       else
         dex(i)=0.d0
         V_Exchange(i)=0.d0
       endif
     enddo
                                                                                                                                                                                                                                                  
! XC Ceperley - Alder
! as parameterized by Perdew and Zunger, Phys. Rev. B23, 5048 (1981)
   else if(iexc .eq. 3) then
     do i=1,N_lattice_points
       rh=dens_AU(i)
       call cepal(rh,ex,fx,exc,fxc)
       V_Exchange(i)=fxc
       dex(i)=ex
       dec(i)=exc-ex
     end do
! X Perdew, C Perdew, generalized gradient approximation 1992
   else if(iexc .eq. 4) then
     do i=1,N_lattice_points
       d=0.5d0*dens_AU(i)
       call ggax(3,d,grad_d(:,i),grad_abs_grad_d(:,i),lap_d(i),xpot,dex(i))
       call ggac(2,d,grad_d(:,i),grad_abs_grad_d(:,i),grad_zeta(:,i),lap_d(i), &
                 grad_up(:,i),grad_dw(:,i),cpot,dec(i))
       v_check=xpot(1)+cpot(1)
	   if(abs(V_Exchange(i)-v_check)<xc_v_check_t) then
	     V_Exchange(i)=v_check ! only update exchange potential to GGA if not crazy
	   end if
!	   if(abs(V_Exchange(i))>xc_v_error_t) then
!	     write(27382004,'(21ES26.16E3)') d,grad_d(:,i),grad_abs_grad_d(:,i),grad_zeta(:,i),lap_d(i),grad_up(:,i),grad_dw(:,i),xpot(1),cpot(1),abs_grad_d(i)
!		 if(xc_debug_switch) then
!		   call write_xc_debug(dens_AU)
!		   xc_debug_switch=.FALSE.
!	     end if
!	   end if
     end do
! X Becke, C Perdew, generalized gradient approximation
   else if(iexc .eq. 5) then
     do i=1,N_lattice_points
       d=0.5d0*dens_AU(i)
       call ggax(2,d,grad_d(:,i),grad_abs_grad_d(:,i),lap_d(i),xpot,dex(i))
       call ggac(3,d,grad_d(:,i),grad_abs_grad_d(:,i),grad_zeta(:,i),lap_d(i), &
                 grad_up(:,i),grad_dw(:,i),cpot,dec(i))
       v_check=xpot(1)+cpot(1)
	   if(abs(V_Exchange(i)-v_check)<xc_v_check_t) then
	     V_Exchange(i)=v_check ! only update exchange potential to GGA if not crazy
	   end if
!	   if(abs(V_Exchange(i))>xc_v_error_t) then
!	     write(27382005,'(21ES26.16E3)') d,grad_d(:,i),grad_abs_grad_d(:,i),grad_zeta(:,i),lap_d(i),grad_up(:,i),grad_dw(:,i),xpot(1),cpot(1),abs_grad_d(i)
!		 call write_xc_debug(dens_AU)
!	   end if
     end do
   endif
   ex=sum(dens_AU*dex)*grid_volume_AU
   ec=sum(dens_AU*dec)*grid_volume_AU
   evxc=sum(dens_AU*V_Exchange)*grid_volume_AU



   ! convert back to eV
   E_exchange=(ex+ec-evxc)*DoubleRy
   ! convert back to V/Angstrom
   V_Exchange=V_Exchange*DoubleRy
   
   

end subroutine exc_cor

SUBROUTINE Total_Energy(ic)
  integer :: i,orbital,p1,p2,p5,p,ic,ik,io
  logical, save :: first_call = .true.

  if (complexbasis .and. .not. first_call) then
     energy = sum(occupation_periodic(1:n_orbitals, 1:n_k_points) &
          * sp_energy_periodic(1:n_orbitals, 1:n_k_points))
     ! Done by exc_cor ?? call exchange_correlation_energy
     call hartree_energy
     if (ic==1) then
        do p5=1,(N_orbitals+4)/5
           p1=5*(p5-1)+1
           p2=5*p5 ; if ( p2 > N_orbitals ) p2=N_orbitals
           write(log_file,'(1x,5(i3,f9.4,2x))') &
                (p,Sp_energy_periodic(p,ik),p=p1,p2)
        enddo
        write(log_file,*)'sp',Energy
        write(log_file,*)'Ha',E_Hartree
        write(log_file,*)'ii',E_Ion_ion
        write(log_file,*)'xc',E_Exchange
        write(log_file,*) 'TOTEN', energy+e_hartree+e_ion_ion+e_exchange
        energy = energy + e_hartree + e_ion_ion + e_exchange
     end if
  else
     energy = sum(occupation(1:n_orbitals)*sp_energy(1:n_orbitals))

     if(spin_polarized) then
        call Exchange_correlation_lsda
     else
        ! Done by exc_cor ?? call Exchange_Correlation_energy
     endif
     call Hartree_Energy

     if(ic==1) then
        do p5=1,(N_orbitals+4)/5
           p1=5*(p5-1)+1
           p2=5*p5 ; if ( p2 > N_orbitals ) p2=N_orbitals
           write(log_file,'(1x,5(i3,f9.4,2x))') (p,Sp_energy(p),p=p1,p2)
        enddo
        write(log_file,*)'sp',Energy
        write(log_file,*)'Ha',E_Hartree
        write(log_file,*)'ii',E_Ion_ion
        write(log_file,*)'xc',E_Exchange
     endif
     Energy=Energy+E_Exchange+E_Hartree+E_Ion_Ion
  end if

  first_call = .false.

END SUBROUTINE Total_Energy

SUBROUTINE Calculate_Density(c1,c2)
  real*8 :: cc1,cc2
  real*8, intent(in), optional :: c1,c2
  !! if two mixing parameters are supplied then this will revert to
  !! the old behavior of linear mixing, otherwise use the new code

  if(present(c1).AND.present(c2)) then
    if(spin_polarized) then
      Density_up=c1*Density_up+c2*Density_up_new
      Density_down=c1*Density_down+c2*Density_down_new
      Density=Density_up+Density_down
    else
      old_density=density
      density=c1*density+c2*new_density
    endif
    call hamiltonian_density
  else
     old_density=density
     call mixer
     call hamiltonian_density
  endif
  if(spin_polarized) then
     write(log_file,*)'Density down',sum(density_down)*grid_volume
     write(log_file,*)'Density   up',sum(density_up)*grid_volume
  endif

END SUBROUTINE Calculate_Density

SUBROUTINE Exchange_Correlation_potential
  integer :: i
  real*8  :: rho,rs,rssq,rsln,V_xc
  real*8, parameter :: tol = 1.0d-10
  real*8, parameter :: inv_a_B=1.0d0/a_B
  real*8, parameter :: c1=3.d0/(4.d0*pi)
  real*8, parameter :: c2=4.d0/3.d0*0.4582d0
  real*8, parameter :: DoubleRy=2.d0*Ry

  !$omp parallel do &
  !$omp default(shared) &
  !$omp private (i, rho, rs, rssq, rsln, V_xc)
  do i=1,N_Lattice_points
    rho=Density(i)
    if (rho < tol) rho = tol
    rs=((c1/rho)**(1.d0/3.d0))*inv_a_B
    V_xc=-c2/rs
    if(rs>1.d0) then
      rssq=sqrt(rs)
      V_xc=V_xc+gammaU*(1.d0+7.d0/6.d0*beta1U*rssq+4.d0/3.d0*beta2U*rs)/(1.d0+beta1U*rssq+beta2U*rs)**2
    else
      rsln=log(rs)
      V_xc=V_xc+AU*rsln+(BU-AU/3.d0)+2.d0/3.d0*CU*rs*rsln+(2.d0*DU-CU)/3.d0*rs
    endif
    V_Exchange(i)=DoubleRy*V_xc
  enddo
  !$omp end parallel do
  
END SUBROUTINE Exchange_correlation_potential

SUBROUTINE Exchange_Correlation_Energy
  integer :: i
  real*8  :: the_sum,eps_xc,rssq,rho,rsln,rs
  real*8, parameter :: tol=1.0d-10
  real*8, parameter :: inv_a_B=1.0d0/a_B
  real*8, parameter :: c1=3.d0/(4.d0*pi)
  real*8, parameter :: c2=4.d0/3.d0*0.4582d0
  real*8, parameter :: DoubleRy=2.d0*Ry

  the_sum=0.d0
  !$omp parallel do &
  !$omp default(shared) &
  !$omp private (i, rho, rs, eps_xc, rssq, rsln) &
  !$omp reduction(+: the_sum)
  do i=1,N_Lattice_points
    rho=Density(i)
    if (rho < tol) rho = tol
    rs=((c1/rho)**(1.d0/3.d0))*inv_a_B
    eps_xc=-.4582d0/rs
    if(rs>1.d0) then
      rssq=sqrt(rs)
      eps_xc=eps_xc+gammaU/(1.d0+beta1U*rssq+beta2U*rs)
    else
      rsln=log(rs)
      eps_xc=eps_xc+AU*rsln+BU+CU*rs*rsln+DU*rs
    endif
    eps_xc=DoubleRy*eps_xc
    the_sum=the_sum+density(i)*(eps_xc-V_exchange(i))
  enddo
  !$omp end parallel do
  E_exchange=the_sum*grid_volume
END SUBROUTINE Exchange_correlation_Energy


SUBROUTINE Hartree_Energy
  integer :: i
  real*8  :: the_sum

  the_sum=0.d0
  if(periodic) then
    !$omp parallel do &
    !$omp default(shared) &
    !$omp private (i) &
    !$omp reduction(+: the_sum)
    do i=1,N_Lattice_points
      the_sum=the_sum+density(i)*(-0.5d0*V_Hartree(i))
    enddo
    !$omp end parallel do
  else
    !$omp parallel do &
    !$omp default(shared) &
    !$omp private (i) &
    !$omp reduction(+: the_sum)
    do i=1,N_Lattice_points
      the_sum=the_sum+density(i)*(-0.5d0*(V_Hartree(i)+VH_bg(i)))
    enddo
    !$omp end parallel do
  endif
  E_Hartree=the_sum*grid_volume
END SUBROUTINE Hartree_Energy

SUBROUTINE Ion_Ion_Energy
  integer :: i1,i2
  real*8  :: r,the_sum

  the_sum=0.d0
  !$omp parallel do if(N_total_atom > 20) &
  !$omp default(shared) &
  !$omp private (i1, i2, r) &
  !$omp reduction(+: the_sum)
  do i1=1,N_total_atom
     if(z_atom(atom_index(i1))<1) cycle
     do i2=1,i1-1
       if(z_atom(atom_index(i2))<1) cycle
	   r=sqrt((Position(1,i1)-Position(1,i2))**2 + (Position(2,i1)-Position(2,i2))**2 &
	           + (Position(3,i1)-Position(3,i2))**2)
	   if(r<(1.d-10)) then
	     write(log_file,*)"ERROR: r=0 in ion_ion_energy"
	     stop
	   endif
	   the_sum=the_sum+Charge_pp(atom_index(i1))*Charge_pp(atom_index(i2))/r
     enddo
  enddo
  !$omp end parallel do
  E_Ion_Ion=the_sum*E2
  !write(log_file,*)"Ion-ion energy: ",E_Ion_Ion
  !write(log_file,*)'ion_ion_energy   :  OK'
END SUBROUTINE Ion_Ion_Energy

subroutine ion_projectile_energy
integer  i,ai
real(8)  r,ipe
ipe=0.0d0
!$omp parallel do if(N_total_atom > 400) &
!$omp default(shared) &
!$omp private (i, r, ai) &
!$omp reduction(+: ipe)
do i=1,N_total_atom
  ai=atom_index(i)
  if (z_atom(ai)>0) then
    ! removed projectile_potential_soft_param for direct collisions
    r=sqrt( (Position(1,i)-projectile_x)**2 + &
            (Position(2,i)-projectile_y)**2 + &
            (Position(3,i)-projectile_z)**2 )
            ! projectile_potential_soft_param**2 )
    ipe=ipe+Charge_pp(ai)/r
  endif
enddo
!$omp end parallel do
E_Ion_Projectile=ipe*projectile_charge*E2
end subroutine ion_projectile_energy

! Moved to mod_global subroutine gradient_real

SUBROUTINE write_grad_info(phi_in,p0)
  implicit none
  real*8                    :: phi_in(N_Lattice_points)
  integer :: i,p0
    integer                    :: i1,i2,i3
  
  wphi=0.d0
  do i=1,N_Lattice_points
    i1=Lattice(1,i); i2=Lattice(2,i); i3=Lattice(3,i)
    wphi(i1,i2,i3)=phi_in(i)
  end do
  
  i=p0
  i1=Lattice(1,i); i2=Lattice(2,i); i3=Lattice(3,i)
  write(27382004,'(25ES26.16E3)') phi_in(p0),wphi(i1+1,i2,i3),wphi(i1-1,i2,i3),wphi(i1+2,i2,i3),wphi(i1-2,i2,i3)&
                                           &,wphi(i1+3,i2,i3),wphi(i1-3,i2,i3),wphi(i1+4,i2,i3),wphi(i1-4,i2,i3) &
                                           &,wphi(i1,i2+1,i3),wphi(i1,i2-1,i3),wphi(i1,i2+2,i3),wphi(i1,i2-2,i3)&
										   &,wphi(i1,i2+3,i3),wphi(i1,i2-3,i3),wphi(i1,i2+4,i3),wphi(i1,i2-4,i3) &
										   &,wphi(i1,i2,i3+1),wphi(i1,i2,i3-1),wphi(i1,i2,i3+2),wphi(i1,i2,i3-2)&
										   &,wphi(i1,i2,i3+3),wphi(i1,i2,i3-3),wphi(i1,i2,i3+4),wphi(i1,i2,i3-4)
  
end SUBROUTINE write_grad_info

SUBROUTINE write_xc_debug(phi_in)
implicit none
  real*8                    :: phi_in(N_Lattice_points)
  character*255  :: fname1
  character*7    :: ch7
  
  write(log_file,*) "output xc debug ",xc_debug_counter
  if(xc_debug_counter==1) then
    open(7418154, file='xc_debug_grid.dat', form='unformatted')
	write(7418154) N_lattice(1:3)
	write(7418154) Lattice
	write(7418154) Grid_Point
	write(7418154) Lattice_inv_xyz
	close(7418154)
  end if
  write(ch7,'(i7.7)') xc_debug_counter
  write(fname1,'(a,a,a)') 'xc_dens_debug',ch7,'.dat'
  open(7418155, file=trim(adjustl(fname1)), form='unformatted')
  write(7418155) phi_in
  close(7418155)
  
  call output_td_density_named(phi_in,xc_debug_counter,'xcDn')
  
  xc_debug_counter=xc_debug_counter+1
  
  if(xc_debug_counter>xc_debug_c_max) then
    write(log_file,*) "max number of xc dens outputs reached."
	STOP
  end if

end SUBROUTINE write_xc_debug

subroutine laplacian(phi,lapl_phi)
!This subroutine evaluates the action of the Hamiltonian on
!a real-valued orbital phi (a 3-dimensional array). The result is returned 
!in lapl_phi (a linear array).
real*8 :: phi(N_Lattice_min(1)-Nd-1:N_Lattice_max(1)+Nd, &
   N_Lattice_min(2)-Nd-1:N_Lattice_max(2)+Nd,N_Lattice_min(3)-Nd-1:N_Lattice_max(3)+Nd)
real*8 :: lapl_phi(N_Lattice_points)
integer    :: i,i1,i2,i3
real*8     :: K_x,K_y,K_z
real*8     :: s1,s2,s3,g,hs

s1=1/Grid_Step(1)**2
s2=1/Grid_Step(2)**2
s3=1/Grid_Step(3)**2
if ((s1==s2).and.(s2==s3)) then
  hs=-h2m*s1
  !$omp parallel do &
  !$omp default(shared) &
  !$omp private (i, i1, i2, i3)
  do i=1,N_Lattice_points
  i1=Lattice(1,i); i2=Lattice(2,i); i3=Lattice(3,i)
  lapl_phi(i)=(3*fd_coeff_second_derivative(0)*phi(i1,i2,i3)+ &
    fd_coeff_second_derivative(1)*(phi(i1+1,i2,i3)+phi(i1-1,i2,i3)+phi(i1,i2+1,i3)+ &
                                   phi(i1,i2-1,i3)+phi(i1,i2,i3+1)+phi(i1,i2,i3-1))+ &
    fd_coeff_second_derivative(2)*(phi(i1+2,i2,i3)+phi(i1-2,i2,i3)+phi(i1,i2+2,i3)+ &
                                   phi(i1,i2-2,i3)+phi(i1,i2,i3+2)+phi(i1,i2,i3-2))+ &
    fd_coeff_second_derivative(3)*(phi(i1+3,i2,i3)+phi(i1-3,i2,i3)+phi(i1,i2+3,i3)+ &
                                   phi(i1,i2-3,i3)+phi(i1,i2,i3+3)+phi(i1,i2,i3-3))+ &
    fd_coeff_second_derivative(4)*(phi(i1+4,i2,i3)+phi(i1-4,i2,i3)+phi(i1,i2+4,i3)+ &
                                   phi(i1,i2-4,i3)+phi(i1,i2,i3+4)+phi(i1,i2,i3-4)))*hs
  enddo
  !$omp end parallel do
else
  !$omp parallel do &
  !$omp default(shared) &
  !$omp private (i, i1, i2, i3, K_x, K_y, K_z, g)
  do i=1,N_Lattice_points
  i1=Lattice(1,i); i2=Lattice(2,i); i3=Lattice(3,i)
  g=fd_coeff_second_derivative(0)*phi(i1,i2,i3)
  K_x=(g+ &
       fd_coeff_second_derivative(1)*(phi(i1+1,i2,i3)+phi(i1-1,i2,i3))+ &
       fd_coeff_second_derivative(2)*(phi(i1+2,i2,i3)+phi(i1-2,i2,i3))+ &
       fd_coeff_second_derivative(3)*(phi(i1+3,i2,i3)+phi(i1-3,i2,i3))+ &
       fd_coeff_second_derivative(4)*(phi(i1+4,i2,i3)+phi(i1-4,i2,i3)))*s1
  K_y=(g+ &
       fd_coeff_second_derivative(1)*(phi(i1,i2+1,i3)+phi(i1,i2-1,i3))+ &
       fd_coeff_second_derivative(2)*(phi(i1,i2+2,i3)+phi(i1,i2-2,i3))+ &
       fd_coeff_second_derivative(3)*(phi(i1,i2+3,i3)+phi(i1,i2-3,i3))+ &
       fd_coeff_second_derivative(4)*(phi(i1,i2+4,i3)+phi(i1,i2-4,i3)))*s2
  K_z=(g+ &
       fd_coeff_second_derivative(1)*(phi(i1,i2,i3+1)+phi(i1,i2,i3-1))+ &
       fd_coeff_second_derivative(2)*(phi(i1,i2,i3+2)+phi(i1,i2,i3-2))+ &
       fd_coeff_second_derivative(3)*(phi(i1,i2,i3+3)+phi(i1,i2,i3-3))+ &
       fd_coeff_second_derivative(4)*(phi(i1,i2,i3+4)+phi(i1,i2,i3-4)))*s3
   lapl_phi(i)=-h2m*(K_x+K_y+K_z)
  enddo
  !$omp end parallel do
endif

end subroutine laplacian


subroutine kinetic(phi,Tphi)
!Evaluates the action of the kinetic energy operator on a real
!orbital phi. The result is returned in Tphi. 
real*8 :: phi(N_lattice_points),Tphi(N_lattice_points) 
integer :: i1,i2,i3,grid

!$omp parallel do &
!$omp default(shared) &
!$omp private (grid, i1, i2, i3)
do grid=1,N_lattice_points
   i1=Lattice(1,grid)
   i2=Lattice(2,grid)
   i3=Lattice(3,grid)
   wphi(i1,i2,i3)=phi(grid)
enddo
!$omp end parallel do
call laplacian(wphi,Tphi)
end subroutine kinetic


subroutine Hamiltonian_wavefn(phi,Hphi)
!Calculates the action of the Hamiltonian on a real-valued orbital phi
!Input variables:     
!  phi - A linear array containing the orbital |phi>
!Output variables:
! Hphi - A linear array containing H|phi>
real*8  :: phi(N_lattice_points),Hphi(N_lattice_points)

call Nonlocal_pseudo_potential(phi,V_nl_pp)
call kinetic(phi,T_Phi)
if(spin_polarized) then
  if(spin_down) then
    !$omp parallel workshare
    Hphi=(V_l_pp+V_Hartree+V_Exchange_down)*phi+V_nl_pp+T_Phi
    !$omp end parallel workshare
  endif
  if(spin_up) then
    !$omp parallel workshare
    Hphi=(V_l_pp+V_Hartree+V_Exchange_up)*phi+V_nl_pp+T_Phi
    !$omp end parallel workshare
endif
else
  !$omp parallel workshare
  Hphi=(V_l_pp+V_Hartree+V_Exchange)*phi+V_nl_pp+T_Phi
  !$omp end parallel workshare
endif
end subroutine Hamiltonian_wavefn

SUBROUTINE Total_Energy_grid
  integer :: i,orbital,nor,p1,p2,p5,p
  real*8  :: su1,su2,su,over,orbital_energy_components(6)

  Energy=0.d0
  Nor=N_total_orbitals
  do orbital=1,N_total_orbitals
    Phi=Psi(:,orbital)
    if(spin_polarized) then
      if(orbital<N_orbitals_down+1) then
        spin_down=.TRUE.
        spin_up=.FALSE.
      else
        spin_up=.TRUE.
        spin_down=.FALSE.
      endif
    endif
    call Hamiltonian_wavefn(Phi,H_Phi)
    Sp_Energy(orbital)=sum(Phi*H_Phi)*Grid_Volume
    Energy=Energy+Occupation(orbital)*Sp_energy(orbital)

    over=sum(phi**2)
    orbital_energy_components(2)=sum(V_l_pp*phi**2)/over
    orbital_energy_components(3)=sum(V_hartree*phi**2)/over
    orbital_energy_components(4)=sum(V_exchange*phi**2)/over
    orbital_energy_components(5)=sum(V_nl_pp*phi)/over
    orbital_energy_components(6)=sum(T_phi*phi)/over
    orbital_energy_components(1)=sum(orbital_energy_components(2:6))

    write(orbital_energy_components_file,'(i10,a,ES16.8,a)',advance='no')orbital, &
    	tab_char,over*grid_volume,tab_char
    do i=1,6
      write(orbital_energy_components_file,'(ES16.8,a)',advance='no')orbital_energy_components(i),tab_char
    enddo
    write(orbital_energy_components_file,*)
  enddo
  write(orbital_energy_components_file,*)
  do p5=1,(Nor+4)/5
     p1=5*(p5-1)+1
     p2=5*p5 ; if ( p2 > Nor ) p2=Nor
     write(log_file,'(1x,5(i3,f9.4,2x))') (p,Sp_energy(p),p=p1,p2)
  enddo
  ! now done by Hamiltonian_density if(.NOT.spin_polarized) call Exchange_Correlation_Energy
  call Hartree_Energy
  write(log_file,*)'sp',Energy
  write(log_file,*)'Ha',E_Hartree
  write(log_file,*)'ii',E_Ion_ion
  write(log_file,*)'xc',E_Exchange
  write(log_file,*)'Ha+xc',E_Hartree+E_Exchange
  Energy=Energy+E_Exchange+E_Hartree+E_Ion_Ion
  if (add_projectile_to_gs) then
     call ion_projectile_energy
     write(log_file,*)'Total_Energy + projectile_ion ',Energy+E_Ion_Projectile
  endif
END SUBROUTINE Total_Energy_grid

SUBROUTINE Total_Energy_grid_quiet
  integer :: i,orbital,nor,p1,p2,p5,p
  real*8  :: su1,su2,su,over,orbital_energy_components(6)

  Energy=0.d0
  Nor=N_total_orbitals
  do orbital=1,N_total_orbitals
    Phi=Psi(:,orbital)
    if(spin_polarized) then
      if(orbital<N_orbitals_down+1) then
        spin_down=.TRUE.
        spin_up=.FALSE.
      else
        spin_up=.TRUE.
        spin_down=.FALSE.
      endif
    endif
    call Hamiltonian_wavefn(Phi,H_Phi)
    Sp_Energy(orbital)=sum(Phi*H_Phi)*Grid_Volume
    Energy=Energy+Occupation(orbital)*Sp_energy(orbital)

  enddo

  ! if(.NOT.spin_polarized) call Exchange_Correlation_Energy
  call Hartree_Energy
  Energy=Energy+E_Exchange+E_Hartree+E_Ion_Ion
  Energy_GS_current_iteration=Energy
  if (add_projectile_to_gs) then
     call ion_projectile_energy
  endif
END SUBROUTINE Total_Energy_grid_quiet

SUBROUTINE conjugate_gradient(N_o_min,N_o_max)
  ! Conjugate gradient minimization to diagonalize the Hamiltonian
  integer :: orbital,iteration,i,N_o_min,N_o_max
  real*8  :: Phi_H_Phi,gamma,beta_Phi,beta_beta,beta_H_Phi,Phi0_Phi0,Phi0_H_Phi0,delta,A,B,C,omega,overlap
  real*8,dimension(:),allocatable :: alpha,beta,Phi0,H_Phi0

  i=N_lattice_points
  allocate(alpha(i),beta(i),Phi0(i),H_Phi0(i))

  do orbital=N_o_min,N_o_max
    Phi=Psi(:,orbital)
    Phi0=Phi
    call Hamiltonian_wavefn(Phi,H_Phi)
    H_Phi0=H_Phi
    Phi0_H_Phi0=sum(Phi*H_Phi)*Grid_Volume
    Phi0_Phi0=1
    delta=Phi0_H_Phi0

    do iteration=1,N_iteration_cg
      alpha=2*(H_Phi0-delta*Phi0)
!      if(orbital>N_o_min) then
        do i=N_o_min,orbital-1
          alpha=alpha-Psi(:,i)*sum(Psi(:,i)*alpha)*Grid_Volume
        enddo
!      endif
      gamma=sum(alpha*alpha)*Grid_Volume
      if(iteration.eq.1) beta=-alpha
      if(iteration.gt.1) beta=-alpha+gamma/overlap*beta
      overlap=gamma
      beta_Phi=sum(Phi0*beta)*Grid_Volume
      beta_beta=sum(beta*beta)*Grid_Volume
      beta_H_Phi=sum(H_Phi0*beta)*Grid_Volume

      Phi=beta
      call Hamiltonian_wavefn(Phi,H_Phi)
      alpha=H_Phi
      Phi_H_Phi=sum(Phi*H_Phi)*Grid_Volume
      A = Phi_H_Phi*beta_Phi  - beta_H_Phi*beta_beta
      B = Phi_H_Phi*Phi0_Phi0   - Phi0_H_Phi0*beta_beta
      C = beta_H_Phi*Phi0_Phi0 - Phi0_H_Phi0*beta_Phi
!      write(*,*)
!      write(*,*) 'beta_Phi=',beta_Phi
!      write(*,*) 'Phi_H_Phi=',Phi_H_Phi
!      write(*,*) 'beta_Phi*Phi_H_Phi=',beta_Phi*Phi_H_Phi
!      write(*,*) 'beta_H_Phi=',beta_H_Phi
!      write(*,*) 'beta_beta=',beta_beta
!      write(*,*) 'beta_H_Phi*beta_beta=',beta_H_Phi*beta_beta
!      write(*,*) 'A=',A
!      write(*,*) 'B=',B
!      write(*,*) 'C=',C
      omega=(-B+sqrt(B*B-4*A*C))/(2*A)
      Phi0   = Phi0   +omega*Phi
      H_Phi0 = H_Phi0 +omega*H_Phi
      Phi0_Phi0   =sum(Phi0*Phi0)*Grid_Volume
      Phi0_H_Phi0 =sum(Phi0*H_Phi0)*Grid_Volume
      delta=Phi0_H_Phi0/Phi0_Phi0
    enddo
    Phi0_Phi0=sum(Phi0*Phi0)*Grid_Volume
    Psi(:,orbital)=Phi0/sqrt(Phi0_Phi0)
  enddo
  deallocate(alpha,beta,Phi0,H_Phi0)
END SUBROUTINE conjugate_gradient

SUBROUTINE Orthogonalization(N_o_min,N_o_max)
  ! Gram-Schmidt orthogonalization
  integer :: orbital,i,N_o_min,N_o_max
  real*8  :: s,overlap

  do orbital=N_o_min,N_o_max
!    if(orbital>N_o_min) then
      do i=N_o_min,orbital-1
        overlap=sum(Psi(:,i)*Psi(:,orbital))*Grid_Volume
        Psi(:,orbital)=Psi(:,orbital)-overlap*Psi(:,i)
      enddo
!    endif
    s=sum(abs(Psi(:,orbital))**2)*Grid_Volume
    Psi(:,orbital)=Psi(:,orbital)/sqrt(s)
  enddo
END SUBROUTINE Orthogonalization

  subroutine solve_grid(iter)
    integer :: iter,i,k,orbital,N_o_min,N_o_max
    real*8  :: mix
    real*4  :: t1,t2
    mix=mixer_beta

	
    old_density=density
    call hamiltonian_density
    call Total_Energy_grid
    write(log_file,*)'starting Energy',Energy

    call set_monitor_iteration(1)

    scf : do i=1,iter
       write(log_file,*)'iteration',i
       N_o_min=1
       N_o_max=N_total_orbitals
!       call CPU_TIME(t1)
       call conjugate_gradient(N_o_min,N_o_max)
!       call CPU_TIME(t2)
         if(remove_dens_around_atom) call do_remove_dens_around_atom
		 if(split_region_mode) call do_split_region_mode
       call Orthogonalization(N_o_min,N_o_max)
!       write(6,*)t2-t1
       new_density=0.d0
       do orbital=1,N_orbitals
          Phi(:)=Psi(:,orbital)
          do k=1,N_Lattice_points
             new_Density(k)=new_Density(k)+Occupation(orbital)*Phi(k)**2
          enddo
       enddo
       
       call update_monitor(i,Energy,density,new_density)
	   
!       call Calculate_Density(1.d0-mix,mix)
       call calculate_density()
	   if (mod(i,gs_dens_output_frequency)==0) then
	     call save_real_array(density,'gs_dens',i,1,0)
	   end if
       call Total_Energy_grid
       write(log_file,*)i,sum(density)*grid_volume,Energy
       if((mod(i,gs_data_output_frequency)==0).and.(i/=iter)) then
         call plot(i)
       	 call output_psi
         call output_scf
       endif

       if(converged()) then
         exit scf
       endif
  enddo scf
  
  
  !Jorge output coordinate map 
  
  call save_real_array(density,'gs_dens',iter,1,-2)
  !this will print out the map for the lattice points
  if (output_coordinate_map) then
      open(UNIT=coordinate_map_file,FILE= trim(adjustl(coordinate_map_filename)),STATUS='replace',ACTION='write')
        write(coordinate_map_file,*)N_lattice
                do k=1,N_Lattice_points
                   write(coordinate_map_file,*) k, Lattice(1,k),Lattice(2,k),Lattice(3,k) !Density(k)
                enddo
        close(coordinate_map_file)  
  end if
  !end of the coordinate map output
  
  
  call output_3D_total_potential(iter)
end subroutine solve_grid

subroutine solve_grid_td(iter)
    integer :: iter,i,k,orbital,N_o_min,N_o_max,j
    real*8  :: mix,prev_scf_energy,energy_diff_prev
    real*4  :: t1,t2
    mix=mixer_beta
    prev_scf_energy=Energy
    !call calculate_density()
	call calculate_rho_grid_PSIreal
    old_density=density
    call hamiltonian_density
    call Total_Energy_grid_quiet
    !write(log_file,*)'starting Energy',Energy
    !call set_monitor_iteration(1)

    scf : do i=1,iter
       !write(log_file,*)'iteration',i
       N_o_min=1
       N_o_max=N_total_orbitals
!       call CPU_TIME(t1)
       call conjugate_gradient(N_o_min,N_o_max)
!       call CPU_TIME(t2)
       call Orthogonalization(N_o_min,N_o_max)
!       write(6,*)t2-t1
       new_density=0.d0
!       do orbital=1,N_orbitals
!          Phi(:)=Psi(:,orbital)
!          do k=1,N_Lattice_points
!             new_Density(k)=new_Density(k)+Occupation(orbital)*Phi(k)**2
!          enddo
!       enddo
       old_density=density
       call calculate_rho_grid_PSIreal
	   new_density=density
	   density=old_density
       prev_scf_energy=Energy
       call update_monitor(i,Energy,density,new_density)
!       call Calculate_Density(1.d0-mix,mix)
       call calculate_density() ! mix old and new density
       call Total_Energy_grid_quiet
	   
       !write(log_file,*)i,sum(density)*grid_volume,Energy
       energy_diff_prev=abs(prev_scf_energy-Energy)
       if((i>resolve_gs_min_iter).AND.(energy_diff_prev<ediff)) then
         exit scf
       endif
  enddo scf
  write(log_file,'(a,i4,2es20.10e3,a,es20.10e3)') "resolve_gs performed N_iter=",i, &
    sum(density)*grid_volume,Energy,' dE= ',energy_diff_prev
  
end subroutine solve_grid_td

subroutine init_grid
 integer :: i
 integer :: k1min,k1max,k2min,k2max,k3min,k3max
 if(.not.periodic) then

   k1min=N_Lattice_min(1)
   k1max=N_Lattice_max(1)
   k2min=N_Lattice_min(2)
   k2max=N_Lattice_max(2)
   k3min=N_Lattice_min(3)
   k3max=N_Lattice_max(3)
   allocate(wphi(k1min-Nd-1:k1max+Nd,k2min-Nd-1:k2max+Nd,k3min-Nd-1:k3max+Nd))
   wphi=0.0d0
   allocate(T_Phi(N_Lattice_points))
   T_Phi=0.0d0
   allocate(Psi(N_lattice_points,N_total_orbitals))
 endif
end subroutine init_grid

subroutine solve_grid_no_scf(iter)
  integer    :: iter,i,k,orbital,j,idum,N_o_min,N_o_max
  real*4     :: t1,t2
  double precision,external :: ran2
  idum=91231
  do i=1,N_orbitals
    do j=1,N_Lattice_points
      Psi(j,i)=ran2(idum)
    end do
  end do
  N_o_min=1
  N_o_max=N_orbitals
  call orthogonalization(N_o_min,N_o_max)

  do i=1,iter
     write(log_file,*)'iteration',i
     N_o_min=1
     N_o_max=N_orbitals
     call conjugate_gradient(N_o_min,N_o_max)
     call Orthogonalization(N_o_min,N_o_max)
     call Total_Energy_grid
     write(log_file,*)i,sum(density)*grid_volume,Energy
     if((mod(i,gs_data_output_frequency)==0).and.(i/=iter)) then
       call plot(i)
       call output_psi
       call output_scf
     endif
  end do
  call output_3D_total_potential(iter)
end subroutine solve_grid_no_scf

SUBROUTINE kinetic1
  integer :: i,j,i1,i2,i3,j1,j2,j3

  T_Phi=0.d0
  do i=1,N_Lattice_points
     i1=Lattice(1,i)+1; i2=Lattice(2,i)+1; i3=Lattice(3,i)+1
     do j1=max(1,i1-Nd),min(N_Lattice(1),i1+Nd)
	   T_Phi(i)=T_Phi(i)+tm1(j1,i1)*Phi(Lattice_inv_xyz(j1,i2,i3))
     enddo
     do j2=max(1,i2-Nd),min(N_Lattice(2),i2+Nd)
	   T_Phi(i)=T_Phi(i)+tm2(j2,i2)*Phi(Lattice_inv_yzx(j2,i3,i1))
     enddo
     do j3=max(1,i3-Nd),min(N_Lattice(3),i3+Nd)
	   T_Phi(i)=T_Phi(i)+tm3(j3,i3)*Phi(Lattice_inv_zxy(j3,i1,i2))
     enddo
  enddo
END SUBROUTINE kinetic1

SUBROUTINE output_psi
  integer       :: i,j,k
  character*255 :: full_filename

  if(periodic) then
    if (large_file_format(1:5)=='ascii') then
      open(psi_data_file,file=trim(adjustl(psi_data_filename)))
      do k=1,N_k_points
        do j=1,N_orbitals
          do i=1,N_Lattice_points
            write(psi_data_file,*)Psi_p(i,j,k)
          end do
        end do
      end do
      close(psi_data_file)
    else
      open(psi_data_file,file=trim(adjustl(psi_data_filename)),form='unformatted',status='replace')
      write(psi_data_file) Psi_p
      close(psi_data_file)
    endif
  else
    if (large_file_format(1:5)=='ascii') then
      open(psi_data_file,file=trim(adjustl(psi_data_filename)))
      do j=1,N_orbitals+N_empty     !added N_empty (Jorge)
        do i=1,N_Lattice_points
          write(psi_data_file,*)Psi(i,j)
        end do
      end do
      close(psi_data_file)
    else
      open(psi_data_file,file=trim(adjustl(psi_data_filename)),form='unformatted',status='replace')
      write(psi_data_file) Psi(:,1:(N_orbitals+N_empty))  !added N_empty (Jorge)
      close(psi_data_file)
    endif
  endif
END SUBROUTINE output_psi

SUBROUTINE input_psi
  integer       :: i,j,k
  character*255 :: full_filename
  logical       :: file_exists

!  inquire(file=trim(adjustl(psi_data_filename)), exist=file_exists)
!  if(file_exists) then
!    full_filename=psi_data_filename
!  else
    if (use_checkpoint) then
      write(full_filename,'(a)')trim(adjustl(psi_data_filename))
    else
      write(full_filename,'(2a)')trim(adjustl(gs_path)),trim(adjustl(psi_data_filename))
    endif
!  endif
  write(log_file,*)"psi data full filename: ",trim(adjustl(full_filename))

  ! cody check for read in virtual orbitals (unoccupied) 
  ! not tested for other features. so stop program
  if(load_virtual_orbitals) then
     if((periodic).OR.(large_file_format(1:5)=='ascii')) then
	    write(log_file,*) 'loading virtual orbitals not tested for given features'
		stop
	 endif
  endif

  if(periodic) then
    if (large_file_format(1:5)=='ascii') then
      open(psi_data_file,file=trim(adjustl(full_filename)))
      do k=1,N_k_points
        do j=1,N_orbitals
          do i=1,N_Lattice_points
            read(psi_data_file,*)Psi_p(i,j,k)
          enddo
        enddo
      enddo
      close(psi_data_file)
    else
      open(psi_data_file,file=trim(adjustl(full_filename)),form='unformatted')
      read(psi_data_file) Psi_p
      close(psi_data_file)
    endif
  else
    if (large_file_format(1:5)=='ascii') then
      open(psi_data_file,file=trim(adjustl(full_filename)))
      do j=1,N_orbitals
        do i=1,N_Lattice_points
          read(psi_data_file,*)Psi(i,j)
        enddo
      enddo
      close(psi_data_file)
    else
      open(psi_data_file,file=trim(adjustl(full_filename)),form='unformatted')
	  if(load_virtual_orbitals) then
	     write(log_file,*) 'read in Psi with ',N_total_orbitals,' orbitals'
	     read(psi_data_file) Psi(:,1:N_total_orbitals)
	  else
         read(psi_data_file) Psi(:,1:N_orbitals)
      endif
	  close(psi_data_file)
    endif
  endif 
END SUBROUTINE input_psi

SUBROUTINE input_psi_combined
  integer       :: i,j,k,psi_data_file2=2842621
  character*255 :: full_filename,full_filename2
  logical       :: file_exists
  real*8,allocatable :: Psi_gs1(:,:),Psi_gs2(:,:)
  

  allocate(Psi_gs1(N_Lattice_points,combine_gs_num_orb_1))
  allocate(Psi_gs2(N_Lattice_points,combine_gs_num_orb_2))
  
  write(full_filename,'(2a)')trim(adjustl(gs_path)),trim(adjustl(psi_data_filename))
  write(log_file,*)"psi1 data full filename: ",trim(adjustl(full_filename))
  write(full_filename2,'(2a)')trim(adjustl(combine_gs_2path)),trim(adjustl(psi_data_filename))
  write(log_file,*)"psi2 data full filename: ",trim(adjustl(full_filename2))

    if (large_file_format(1:5)=='ascii') then
      write(log_file,*) "must use binary format for merged GS"
    else
      open(psi_data_file,file=trim(adjustl(full_filename)),form='unformatted')
      open(psi_data_file2,file=trim(adjustl(full_filename2)),form='unformatted')
	  write(log_file,*) 'read in Psi 1 with ',combine_gs_num_orb_1,' orbitals'
      read(psi_data_file)  Psi_gs1(:,1:combine_gs_num_orb_1)
	  write(log_file,*) 'read in Psi 2 with ',combine_gs_num_orb_2,' orbitals'
      read(psi_data_file2) Psi_gs2(:,1:combine_gs_num_orb_2)
	  do j=1,combine_gs_num_orb_1
	    Psi(:,j)=Psi_gs1(:,j)
	  end do
	  do j=1,combine_gs_num_orb_2
	    Psi(:,j+combine_gs_num_orb_1)=Psi_gs2(:,j)
	  end do	  
	  close(psi_data_file)
	  close(psi_data_file2)
    endif

	deallocate(Psi_gs1,Psi_gs2)
END SUBROUTINE input_psi_combined

subroutine boost_wavefunction !shenglai
! the boosted wavefunction velocity equals to that of the first atom in the velocity file
integer :: i,i1,i2,i3,grid
complex :: phase
  
   do i=1,N_Lattice_points
      phase =exp(sum((ElectronMass/hbar*atom_velocity(:,1)*grid_point(:,i))*(0.d0,1.d0)))
      psi_c(i,boosted_orbital)=psi_c(i,boosted_orbital)*phase
   enddo
 if (.not.allocated(wlap_p)) allocate(wlap_p(3,N_Lattice_points))
  wlap_p= (0.D0, 0.D0)
! if (.not.allocated(wphi_c)) allocate(wphi_c(3,N_Lattice_points))
   do grid=1,N_lattice_points
    i1=Lattice(1,grid)
    i2=Lattice(2,grid)
    i3=Lattice(3,grid)
    wphi_c(i1,i2,i3)=Psi_c(grid,boosted_orbital)
  end do  
  call nabla
   print *, sum(conjg(psi_c(:,boosted_orbital))*wlap_p(1,:))*Grid_volume*hbar/electronmass
   print *, sum(conjg(psi_c(:,boosted_orbital))*wlap_p(2,:))*Grid_volume*hbar/electronmass
   print *, sum(conjg(psi_c(:,boosted_orbital))*wlap_p(3,:))*Grid_volume*hbar/electronmass

END subroutine boost_wavefunction

subroutine boost_wf_around_atom(aidx1,bst_rad) !cody
integer :: i,j,i1,i2,i3,grid,aidx1,n_orb_in_psi
complex :: phase
real*8  :: R,bst_rad

 write(log_file,*) "boost around atom ",aidx1
 write(log_file,*) "   Radius ",bst_rad
 
 n_orb_in_psi=size(psi_c,2)
   do i=1,N_Lattice_points
      R=sqrt((Position(1,aidx1)-grid_point(1,i))**2+(Position(2,aidx1)-grid_point(2,i))**2+(Position(3,aidx1)-grid_point(3,i))**2)
	  if(R<bst_rad) then
        phase =exp(sum((ElectronMass/hbar*atom_velocity(:,aidx1)*grid_point(:,i))*(0.d0,1.d0)))
	    do j=1,n_orb_in_psi 
	      psi_c(i,j)=psi_c(i,j)*phase
	    end do
	  end if
   enddo
 if (.not.allocated(wlap_p)) allocate(wlap_p(3,N_Lattice_points))

do j=1,n_orb_in_psi 
  wlap_p= (0.D0, 0.D0)
   do grid=1,N_lattice_points
    i1=Lattice(1,grid)
    i2=Lattice(2,grid)
    i3=Lattice(3,grid)
    wphi_c(i1,i2,i3)=Psi_c(grid,j)
  end do  
  call nabla
   write(log_file,*) "Boost orb ",j
   write(log_file,*) sum(conjg(psi_c(:,j))*wlap_p(1,:))*Grid_volume*hbar/electronmass
   write(log_file,*) sum(conjg(psi_c(:,j))*wlap_p(2,:))*Grid_volume*hbar/electronmass
   write(log_file,*) sum(conjg(psi_c(:,j))*wlap_p(3,:))*Grid_volume*hbar/electronmass
end do
   
END subroutine boost_wf_around_atom

subroutine boost_wf2_combined
integer :: i,j,i1,i2,i3,grid,aidx1
complex :: phase
real    :: velb(3)

 velb(1)=combine_gs_boost_vx
 velb(2)=combine_gs_boost_vy
 velb(3)=combine_gs_boost_vz
 write(log_file,*) "boost wf loaded from Ground State 2 "
 write(log_file,*) "boost orb ",1+combine_gs_num_orb_1," to ",N_total_orbitals
 write(log_file,*) "V=",velb(1:3)
 
   do i=1,N_Lattice_points
        phase =exp(sum((ElectronMass/hbar*velb(:)*grid_point(:,i))*(0.d0,1.d0)))
	    do j=1+combine_gs_num_orb_1,N_total_orbitals 
	      psi_c(i,j)=psi_c(i,j)*phase
	    end do
   enddo
 if (.not.allocated(wlap_p)) allocate(wlap_p(3,N_Lattice_points))

do j=1,N_total_orbitals 
  wlap_p= (0.D0, 0.D0)
   do grid=1,N_lattice_points
    i1=Lattice(1,grid)
    i2=Lattice(2,grid)
    i3=Lattice(3,grid)
    wphi_c(i1,i2,i3)=Psi_c(grid,j)
  end do  
  call nabla
   write(log_file,*) "Boost orb ",j
   write(log_file,*) sum(conjg(psi_c(:,j))*wlap_p(1,:))*Grid_volume*hbar/electronmass
   write(log_file,*) sum(conjg(psi_c(:,j))*wlap_p(2,:))*Grid_volume*hbar/electronmass
   write(log_file,*) sum(conjg(psi_c(:,j))*wlap_p(3,:))*Grid_volume*hbar/electronmass
end do
   
END subroutine boost_wf2_combined

subroutine laplacian_c(phi,lapl_phi)
!This subroutine evaluates the action of the Hamiltonian on
!a complex-valued orbital phi (a 3-dimensional array). The result is returned 
!in lapl_phi (a linear array).
complex*16 :: phi(N_Lattice_min(1)-Nd-1:N_Lattice_max(1)+Nd, &
   N_Lattice_min(2)-Nd-1:N_Lattice_max(2)+Nd,N_Lattice_min(3)-Nd-1:N_Lattice_max(3)+Nd)
complex*16 :: lapl_phi(N_Lattice_points)
!Local variables
integer    :: i,i1,i2,i3
real*8     :: ss1,ss2,ss3,s1,hs1,hss1,hss2,hss3
complex*16 :: g,kvec_x,h2m_kvec_x_2,h2m_kvec_x_two_zi,w_x

!Precompute some constants
ss1=1/Grid_Step(1)**2
ss2=1/Grid_Step(2)**2
ss3=1/Grid_Step(3)**2
s1=1/Grid_Step(1)
hss1=-h2m*ss1
hss2=-h2m*ss2
hss3=-h2m*ss3
hs1=s1
if (use_high_energy_wp) then
  kvec_x=wp_momentum(1)/hbar
  h2m_kvec_x_2=h2m*kvec_x**2
  h2m_kvec_x_two_zi=2*h2m*zi*kvec_x
endif

!Compute Hpsi
if ((ss1==ss2).and.(ss2==ss3)) then
  !$omp parallel do &
  !$omp default(shared) &
  !$omp private (i, i1, i2, i3)
  do i=1,N_Lattice_points
    i1=Lattice(1,i); i2=Lattice(2,i); i3=Lattice(3,i)
    lapl_phi(i)=(3*fd_coeff_second_derivative(0)*phi(i1,i2,i3)+ &
    fd_coeff_second_derivative(1)*(phi(i1+1,i2,i3)+phi(i1-1,i2,i3)+phi(i1,i2+1,i3)+ &
                                   phi(i1,i2-1,i3)+phi(i1,i2,i3+1)+phi(i1,i2,i3-1))+ &
    fd_coeff_second_derivative(2)*(phi(i1+2,i2,i3)+phi(i1-2,i2,i3)+phi(i1,i2+2,i3)+ &
                                   phi(i1,i2-2,i3)+phi(i1,i2,i3+2)+phi(i1,i2,i3-2))+ &
    fd_coeff_second_derivative(3)*(phi(i1+3,i2,i3)+phi(i1-3,i2,i3)+phi(i1,i2+3,i3)+ &
                                   phi(i1,i2-3,i3)+phi(i1,i2,i3+3)+phi(i1,i2,i3-3))+ &
    fd_coeff_second_derivative(4)*(phi(i1+4,i2,i3)+phi(i1-4,i2,i3)+phi(i1,i2+4,i3)+ &
                                   phi(i1,i2-4,i3)+phi(i1,i2,i3+4)+phi(i1,i2,i3-4)))*hss1

  enddo
  !$omp end parallel do
else
  !$omp parallel do &
  !$omp default(shared) &
  !$omp private (i, i1, i2, i3, g)
  do i=1,N_Lattice_points
    i1=Lattice(1,i); i2=Lattice(2,i); i3=Lattice(3,i)
    g=fd_coeff_second_derivative(0)*phi(i1,i2,i3)
    lapl_phi(i)= &
         (g+ &
         fd_coeff_second_derivative(1)*(phi(i1+1,i2,i3)+phi(i1-1,i2,i3))+ &
         fd_coeff_second_derivative(2)*(phi(i1+2,i2,i3)+phi(i1-2,i2,i3))+ &
         fd_coeff_second_derivative(3)*(phi(i1+3,i2,i3)+phi(i1-3,i2,i3))+ &
         fd_coeff_second_derivative(4)*(phi(i1+4,i2,i3)+phi(i1-4,i2,i3)))*hss1 + &
         (g+ &
         fd_coeff_second_derivative(1)*(phi(i1,i2+1,i3)+phi(i1,i2-1,i3))+ &
         fd_coeff_second_derivative(2)*(phi(i1,i2+2,i3)+phi(i1,i2-2,i3))+ &
         fd_coeff_second_derivative(3)*(phi(i1,i2+3,i3)+phi(i1,i2-3,i3))+ &
         fd_coeff_second_derivative(4)*(phi(i1,i2+4,i3)+phi(i1,i2-4,i3)))*hss2 + &
         (g+ &
         fd_coeff_second_derivative(1)*(phi(i1,i2,i3+1)+phi(i1,i2,i3-1))+ &
         fd_coeff_second_derivative(2)*(phi(i1,i2,i3+2)+phi(i1,i2,i3-2))+ &
         fd_coeff_second_derivative(3)*(phi(i1,i2,i3+3)+phi(i1,i2,i3-3))+ &
         fd_coeff_second_derivative(4)*(phi(i1,i2,i3+4)+phi(i1,i2,i3-4)))*hss3

  enddo
  !$omp end parallel do
endif

end subroutine laplacian_c

SUBROUTINE nabla
  ! Impose periodic boundary condition
  integer :: i,i1,i2,i3
  real*8  :: s1,s2,s3

  s1=1/Grid_Step(1)
  s2=1/Grid_Step(2)
  s3=1/Grid_Step(3)
  !$omp parallel do &
  !$omp default(shared) &
  !$omp private (i, i1, i2, i3)
  do i=1,N_Lattice_points
    i1=Lattice(1,i); i2=Lattice(2,i); i3=Lattice(3,i)

    wlap_p(1,i)=s1* &
      (fd_coeff_first_derivative(1)*(wphi_c(i1+1,i2,i3)-wphi_c(i1-1,i2,i3)) &
      +fd_coeff_first_derivative(2)*(wphi_c(i1+2,i2,i3)-wphi_c(i1-2,i2,i3)) &
      +fd_coeff_first_derivative(3)*(wphi_c(i1+3,i2,i3)-wphi_c(i1-3,i2,i3)) &
      +fd_coeff_first_derivative(4)*(wphi_c(i1+4,i2,i3)-wphi_c(i1-4,i2,i3)))

    wlap_p(2,i)=s2* &
      (fd_coeff_first_derivative(1)*(wphi_c(i1,i2+1,i3)-wphi_c(i1,i2-1,i3)) &
      +fd_coeff_first_derivative(2)*(wphi_c(i1,i2+2,i3)-wphi_c(i1,i2-2,i3)) &
      +fd_coeff_first_derivative(3)*(wphi_c(i1,i2+3,i3)-wphi_c(i1,i2-3,i3)) &
      +fd_coeff_first_derivative(4)*(wphi_c(i1,i2+4,i3)-wphi_c(i1,i2-4,i3)))

    wlap_p(3,i)=s3* &
      (fd_coeff_first_derivative(1)*(wphi_c(i1,i2,i3+1)-wphi_c(i1,i2,i3-1)) &
      +fd_coeff_first_derivative(2)*(wphi_c(i1,i2,i3+2)-wphi_c(i1,i2,i3-2)) &
      +fd_coeff_first_derivative(3)*(wphi_c(i1,i2,i3+3)-wphi_c(i1,i2,i3-3)) &
      +fd_coeff_first_derivative(4)*(wphi_c(i1,i2,i3+4)-wphi_c(i1,i2,i3-4)))
  enddo
  !$omp end parallel do
END SUBROUTINE nabla

SUBROUTINE nabla_r
  ! Impose periodic boundary condition
  integer :: i,i1,i2,i3
  real*8  :: s1,s2,s3

  s1=1/Grid_Step(1)
  s2=1/Grid_Step(2)
  s3=1/Grid_Step(3)
  !$omp parallel do &
  !$omp default(shared) &
  !$omp private (i, i1, i2, i3)
  do i=1,N_Lattice_points
    i1=Lattice(1,i); i2=Lattice(2,i); i3=Lattice(3,i)

    wlap_r(1,i)=s1* &
      (fd_coeff_first_derivative(1)*(wphi(i1+1,i2,i3)-wphi(i1-1,i2,i3)) &
      +fd_coeff_first_derivative(2)*(wphi(i1+2,i2,i3)-wphi(i1-2,i2,i3)) &
      +fd_coeff_first_derivative(3)*(wphi(i1+3,i2,i3)-wphi(i1-3,i2,i3)) &
      +fd_coeff_first_derivative(4)*(wphi(i1+4,i2,i3)-wphi(i1-4,i2,i3)))

    wlap_r(2,i)=s2* &
      (fd_coeff_first_derivative(1)*(wphi(i1,i2+1,i3)-wphi(i1,i2-1,i3)) &
      +fd_coeff_first_derivative(2)*(wphi(i1,i2+2,i3)-wphi(i1,i2-2,i3)) &
      +fd_coeff_first_derivative(3)*(wphi(i1,i2+3,i3)-wphi(i1,i2-3,i3)) &
      +fd_coeff_first_derivative(4)*(wphi(i1,i2+4,i3)-wphi(i1,i2-4,i3)))

    wlap_r(3,i)=s3* &
      (fd_coeff_first_derivative(1)*(wphi(i1,i2,i3+1)-wphi(i1,i2,i3-1)) &
      +fd_coeff_first_derivative(2)*(wphi(i1,i2,i3+2)-wphi(i1,i2,i3-2)) &
      +fd_coeff_first_derivative(3)*(wphi(i1,i2,i3+3)-wphi(i1,i2,i3-3)) &
      +fd_coeff_first_derivative(4)*(wphi(i1,i2,i3+4)-wphi(i1,i2,i3-4)))
  enddo
  !$omp end parallel do
END SUBROUTINE nabla_r

SUBROUTINE Exchange_Correlation_lsda
  ! Calculate the EXC potential
  integer :: i
  real*8  :: V_xc,su,eps_c,eps_x,v_x,v_c,rho_up,rho_down,v_x_up,v_x_down,v_c_up,v_c_down

  su=0.d0
  do i=1,N_Lattice_points
    rho_up=density_up(i)+1.d-20
    rho_down=density_down(i)+1.d-20
    call xc_pot(rho_up,rho_down,v_x_up,v_x_down,v_c_up,v_c_down,eps_x,eps_c)
    V_Exchange_up(i)=(v_x_up+v_c_up)
    V_Exchange_down(i)=(v_x_down+v_c_down)
    su=su+Density(i)*(eps_x+eps_c)-Density_up(i)*V_exchange_up(i)-Density_down(i)*V_exchange_down(i)
  enddo
  E_exchange=su*Grid_Volume
END SUBROUTINE Exchange_correlation_lsda

  subroutine solve_grid_spin_polarized(iter)
    integer :: iter,i,k,orbital
    real*8  :: mix
    real*4  :: t1,t2

    mix=mixer_beta

    old_density=density
    call hamiltonian_density
    call Total_Energy_grid
    write(log_file,*)'starting Energy',Energy

    call set_monitor_iteration(1)

    scf : do i=1,iter
       write(log_file,*)'iteration',i
       if(N_orbitals_down>0) then
         spin_down=.TRUE.
         spin_up=.FALSE.
         call conjugate_gradient(1,N_orbitals_down)
		   if(remove_dens_around_atom) call do_remove_dens_around_atom
         call Orthogonalization(1,N_orbitals_down)
       endif
       if(N_orbitals_up>0) then
         spin_up=.TRUE.
         spin_down=.FALSE.
         call conjugate_gradient(N_orbitals_down+1,N_orbitals_down+N_orbitals_up)
		   if(remove_dens_around_atom) call do_remove_dens_around_atom
         call Orthogonalization(N_orbitals_down+1,N_orbitals_down+N_orbitals_up)
       endif
	   
       density_up_new=0.d0
       density_down_new=0.d0
       do orbital=1,N_orbitals
          Phi(:)=Psi(:,orbital)
          do k=1,N_Lattice_points
             if(orbital.le.N_orbitals_down) Density_down_new(k)=Density_down_new(k)+Phi(k)**2
             if(orbital>N_orbitals_down) Density_up_new(k)=Density_up_new(k)+Phi(k)**2
          enddo
       enddo

!       call update_monitor(i,Energy,density_up+density_down, &
!            density_up_new+density_down_new)
       density=density_up+density_down
       new_density=density_up_new+density_down_new
       call update_monitor(i,Energy,density,new_density)
       !       call Calculate_Density(1.d0-mix,mix)
       call calculate_density
       call Total_Energy_grid
       write(log_file,*)i,sum(density)*grid_volume,Energy
       if((mod(i,gs_data_output_frequency)==0).and.(i/=iter)) then
         call plot(i)
       	 call output_psi
         call output_scf
       endif

       if(converged()) then
          exit scf
       endif
  enddo scf
  call output_3D_total_potential(iter)
end subroutine solve_grid_spin_polarized

subroutine save_real_array(Asave,idstring,iter,stride,dtype)
implicit none ! ID STRING IS EXACTLY 7 characters
  ! dtype 0 or negative, output bov
  integer :: stride
  integer :: i1,i2,i3,dtype
  character(7)      :: ch7
  character(7)      :: idstring
  real*8            :: r1
  real*8,intent(in)            ::  Asave(:)
  real*4,allocatable           :: sing_prec_rearranged_array(:)
  integer :: iter,n
  integer :: i,j,k,ind,pl,fnl,dk1,dk2,dk3,k1min,k2min,k3min,k1max,k2max,k3max
  character(255) :: fname1,fname2
  character(5)   :: ch5
  character(16)  :: str1,str2,str3
  integer        :: file_number_tmp
  
  n=size(Asave)
  
  file_number_tmp=1991991
  
  write(ch7,'(i7.7)') iter
  if(dtype<1) then
    
    allocate(sing_prec_rearranged_array(n))
    k1min=N_Lattice_min(1)
	k1max=N_Lattice_max(1)
	k2min=N_Lattice_min(2)
	k2max=N_Lattice_max(2)
	k3min=N_Lattice_min(3)
	k3max=N_Lattice_max(3)
	dk1=(k1max-k1min+1)
	dk2=(k2max-k2min+1)
	dk3=(k3max-k3min+1)
	write(fname1,'(a,a,a,a)') idstring,'_full_',ch7,'.dat'
	write(fname2,'(a,a,a,a)') idstring,'_full_',ch7,'.bov'
	fnl=len_trim(fname1)
	ind=0
	do k=N_Lattice_min(3),N_Lattice_max(3)
	  do j=N_Lattice_min(2),N_Lattice_max(2)
	    do i=N_Lattice_min(1),N_Lattice_max(1)
	      ind=ind+1
	      if (Lattice_inv_xyz(i,j,k)>0) then
	        sing_prec_rearranged_array(ind)=Asave(Lattice_inv_xyz(i,j,k))
	      else
	        sing_prec_rearranged_array(ind)=0.0d0
	      endif
	    enddo
	  enddo
	enddo
	open(file_number_tmp,file=fname1,form='unformatted',status='replace')
	write(file_number_tmp) sing_prec_rearranged_array
	close(file_number_tmp)
	open(file_number_tmp,file=fname2,status='replace')
	write(file_number_tmp,'(1x,a,1x,es23.15)') 'TIME:',iter*time_step
	write(file_number_tmp,'(1x,a,1x,a)') 'DATA_FILE:',fname1(1:fnl)
	write(file_number_tmp,'(1x,a,3(1x,i6))') 'DATA_SIZE:',dk1,dk2,dk3
	write(file_number_tmp,'(1x,a)') 'DATA_FORMAT:  FLOAT'
	write(file_number_tmp,'(1x,a)') 'VARIABLE:  density'
	write(file_number_tmp,'(1x,a)') 'DATA_ENDIAN:  LITTLE'
	write(file_number_tmp,'(1x,a)') 'CENTERING:  zonal'
	write(file_number_tmp,'(1x,a,3(1x,es23.15))') 'BRICK_ORIGIN:',xgrid(k1min),ygrid(k2min),zgrid(k3min)
	write(file_number_tmp,'(1x,a,3(1x,es23.15))') 'BRICK_SIZE:', &
	    xgrid(k1max)-xgrid(k1min),ygrid(k2max)-ygrid(k2min),zgrid(k3max)-zgrid(k3min)
	write(file_number_tmp,'(1x,a)') 'BYTE_OFFSET: 4'
	close(file_number_tmp)
	deallocate(sing_prec_rearranged_array)
  end if
  if ((dtype==1).or.(dtype==-1)) then ! slices
	  write(fname1,'(a,a,a)') idstring,'_sliceX0_',ch7
      open(file_number_tmp,file=trim(adjustl(fname1)),form='formatted',status='replace',action='write')
	  i1=N_Lattice(1)/2
	    do i2=1,N_Lattice(2),stride
		  do i3=1,N_Lattice(3),stride
		    i=Lattice_inv_xyz(i1,i2,i3)
			write(file_number_tmp,'(2es11.3e2,es12.2e3)')  grid_point(2,i),grid_point(3,i),Asave(i)
	     end do
	    end do
      close(file_number_tmp)
	  write(fname1,'(a,a,a)') idstring,'_sliceY0_',ch7
      open(file_number_tmp,file=trim(adjustl(fname1)),form='formatted',status='replace',action='write')
	  do i1=1,N_Lattice(1),stride
	    i2=N_Lattice(2)/2
		  do i3=1,N_Lattice(3),stride
		    i=Lattice_inv_xyz(i1,i2,i3)
			write(file_number_tmp,'(2es11.3e2,es12.2e3)')  grid_point(1,i),grid_point(3,i),Asave(i)
	     end do
	    end do
      close(file_number_tmp)
	  write(fname1,'(a,a,a)') idstring,'_sliceZ0_',ch7
      open(file_number_tmp,file=trim(adjustl(fname1)),form='formatted',status='replace',action='write')
	  do i1=1,N_Lattice(1),stride
	    do i2=1,N_Lattice(2),stride
		  i3=N_Lattice(3)/2
		    i=Lattice_inv_xyz(i1,i2,i3)
			write(file_number_tmp,'(2es11.3e2,es12.2e3)')  grid_point(1,i),grid_point(2,i),Asave(i)
	     end do
	    end do
      close(file_number_tmp)
   end if
   if ((dtype==2).or.(dtype==-2)) then ! averages
	  write(fname1,'(a,a,a)') idstring,'_avgX_',ch7
	  write(log_file,*)"write files ",trim(adjustl(fname1))
      open(file_number_tmp,file=trim(adjustl(fname1)),form='formatted',status='replace',action='write')
	    do i2=1,N_Lattice(2)
		  do i3=1,N_Lattice(3)
		    r1=0.d0
		    do i1=1,N_Lattice(1)
		      i=Lattice_inv_xyz(i1,i2,i3)
			  r1=r1+Asave(i)
			end do
			r1=r1/N_Lattice(1)
			write(file_number_tmp,'(2es11.3e2,es12.2e3)')  grid_point(2,i),grid_point(3,i),r1
	     end do
	    end do
      close(file_number_tmp)
	  write(fname1,'(a,a,a)') idstring,'_avgY_',ch7
      open(file_number_tmp,file=trim(adjustl(fname1)),form='formatted',status='replace',action='write')
	  do i1=1,N_Lattice(1)
		  do i3=1,N_Lattice(3)
		    r1=0.d0
			do i2=1,N_Lattice(2)
			  i=Lattice_inv_xyz(i1,i2,i3)
			  r1=r1+Asave(i)
			end do
			r1=r1/N_Lattice(2)
			write(file_number_tmp,'(2es11.3e2,es12.2e3)')  grid_point(1,i),grid_point(3,i),r1
	     end do
	    end do
      close(file_number_tmp)
	  write(fname1,'(a,a,a)') idstring,'_avgZ_',ch7
      open(file_number_tmp,file=trim(adjustl(fname1)),form='formatted',status='replace',action='write')
	  do i1=1,N_Lattice(1)
	    do i2=1,N_Lattice(2)
		    r1=0.d0  
			do i3=1,N_Lattice(3)
			  i=Lattice_inv_xyz(i1,i2,i3)
			  r1=r1+Asave(i)
			end do
			r1=r1/N_Lattice(3)
			write(file_number_tmp,'(2es11.3e2,es12.2e3)')  grid_point(1,i),grid_point(2,i),r1
	     end do
	    end do
      close(file_number_tmp)

  end if  

end subroutine save_real_array

SUBROUTINE output_td_density(iter)
!This subroutine saves electron density (as a 3D array of data)
!at iteration iter in a file(s) whose format is specified by global
!variable td_density_output_format. If the value of this variable
!is "default" then everything will be written in a single ascii file.
!Otherwise, each instant of density is saved in a separate file whose
!prefix is defined by td_total_density_filename_prefix
integer :: iter
integer :: i,j,k,ind,pl,fnl,dk1,dk2,dk3,k1min,k2min,k3min,k1max,k2max,k3max
character(255) :: fname1,fname2
character(5)   :: ch5
character(16)  :: str1,str2,str3
k1min=N_Lattice_min(1)
k1max=N_Lattice_max(1)
k2min=N_Lattice_min(2)
k2max=N_Lattice_max(2)
k3min=N_Lattice_min(3)
k3max=N_Lattice_max(3)
dk1=(k1max-k1min+1)
dk2=(k2max-k2min+1)
dk3=(k3max-k3min+1)
!Default format -- single ascii file for densities at any instant.
!This is inefficient in terms of storage and write speed.
if (trim(adjustl(td_density_output_format))=="default") then
  do i=1,N_Lattice_points
    if(spin_polarized) then
      write(td_total_density_file,'(2ES16.8)')density_up(i),density_down(i)
    else
      write(td_total_density_file,'(ES16.8)')density(i)
    endif
  enddo
endif

!Bov format (bricks of data) which can easily be read by VisIt software.
!It is fast and reasonable in terms of disk space. Works only in the
!case of rectangular box
if ((trim(adjustl(td_density_output_format))=="bov")) then
  if (.not.spin_polarized) then
    write(ch5,'(i5.5)') td_density_counter
    pl=len_trim(td_total_density_filename_prefix)
    write(fname1,'(a,a,a)') td_total_density_filename_prefix(1:pl),ch5(1:5),'.dat'
    write(fname2,'(a,a,a)') td_total_density_filename_prefix(1:pl),ch5(1:5),'.bov'
    fnl=len_trim(fname1)
    !First write the density into a data file, which is of binary form.
    !Note that the density data is rearranged as z,y,x --> x,y,z (C-like
    !storage of array elements)  and converted to single precision before
    !saving it to disk (single precision is used to reduce disk usage).
    !Rearrangement must be done using an auxiliary array
    !(called sing_prec_rearranged_density) because the data cannot be
    !simply written into the binary file by making an appropriate do-loop
    !(writing an entire array at once and writing it step-by-step gives
    !different result in fortran when it is a binary file).
    ind=0
    do k=N_Lattice_min(3),N_Lattice_max(3)
      do j=N_Lattice_min(2),N_Lattice_max(2)
        do i=N_Lattice_min(1),N_Lattice_max(1)
          ind=ind+1
          if (Lattice_inv_xyz(i,j,k)>0) then
            sing_prec_rearranged_density(ind)=density(Lattice_inv_xyz(i,j,k))
          else
            sing_prec_rearranged_density(ind)=0.0d0
          endif
        enddo
      enddo
    enddo
    open(td_total_density_file,file=fname1,form='unformatted',status='replace')
    write(td_total_density_file) sing_prec_rearranged_density
    close(td_total_density_file)
    !Now create a header file corresponding to the above datafile. The header file
    !is in ascii text form
    open(td_total_density_file,file=fname2,status='replace')
    write(td_total_density_file,'(1x,a,1x,es23.15)') 'TIME:',iter*time_step
    write(td_total_density_file,'(1x,a,1x,a)') 'DATA_FILE:',fname1(1:fnl)
    write(td_total_density_file,'(1x,a,3(1x,i6))') 'DATA_SIZE:',dk1,dk2,dk3
    write(td_total_density_file,'(1x,a)') 'DATA_FORMAT:  FLOAT'
    write(td_total_density_file,'(1x,a)') 'VARIABLE:  density'
    write(td_total_density_file,'(1x,a)') 'DATA_ENDIAN:  LITTLE'
    write(td_total_density_file,'(1x,a)') 'CENTERING:  zonal'
    write(td_total_density_file,'(1x,a,3(1x,es23.15))') 'BRICK_ORIGIN:',xgrid(k1min),ygrid(k2min),zgrid(k3min)
    write(td_total_density_file,'(1x,a,3(1x,es23.15))') 'BRICK_SIZE:', &
        xgrid(k1max)-xgrid(k1min),ygrid(k2max)-ygrid(k2min),zgrid(k3max)-zgrid(k3min)
    write(td_total_density_file,'(1x,a)') 'BYTE_OFFSET: 4'
    close(td_total_density_file)
  else
    !If spin_polarized=.true. then we basically perform the same actions as above
    !but do it for spin-up and spin-down density separately
    write(ch5,'(i5.5)') td_density_counter
    pl=len_trim(td_total_density_filename_prefix)
    !spin-up
    write(fname1,'(a,a,a,a)') td_total_density_filename_prefix(1:pl),'U',ch5(1:5),'.dat'
    write(fname2,'(a,a,a,a)') td_total_density_filename_prefix(1:pl),'U',ch5(1:5),'.bov'
    fnl=len_trim(fname1)
    ind=0
    do k=N_Lattice_min(3),N_Lattice_max(3)
      do j=N_Lattice_min(2),N_Lattice_max(2)
        do i=N_Lattice_min(1),N_Lattice_max(1)
          ind=ind+1
          if (Lattice_inv_xyz(i,j,k)>0) then
            sing_prec_rearranged_density(ind)=density_up(Lattice_inv_xyz(i,j,k))
          else
            sing_prec_rearranged_density(ind)=0.0d0
          endif
        enddo
      enddo
    enddo
    open(td_total_density_file,file=fname1,form='unformatted',status='replace')
    write(td_total_density_file) sing_prec_rearranged_density
    close(td_total_density_file)
    open(td_total_density_file,file=fname2,status='replace')
    write(td_total_density_file,'(1x,a,1x,es23.15)') 'TIME:',iter*time_step
    write(td_total_density_file,'(1x,a,1x,a)') 'DATA_FILE:',fname1(1:fnl)
    write(td_total_density_file,'(1x,a,3(1x,i6))') 'DATA_SIZE:',dk1,dk2,dk3
    write(td_total_density_file,'(1x,a)') 'DATA_FORMAT:  FLOAT'
    write(td_total_density_file,'(1x,a)') 'VARIABLE:  density_up'
    write(td_total_density_file,'(1x,a)') 'DATA_ENDIAN:  LITTLE'
    write(td_total_density_file,'(1x,a)') 'CENTERING:  zonal'
    write(td_total_density_file,'(1x,a,3(1x,es23.15))') 'BRICK_ORIGIN:',xgrid(k1min),ygrid(k2min),zgrid(k3min)
    write(td_total_density_file,'(1x,a,3(1x,es23.15))') 'BRICK_SIZE:', &
        xgrid(k1max)-xgrid(k1min),ygrid(k2max)-ygrid(k2min),zgrid(k3max)-zgrid(k3min)
    write(td_total_density_file,'(1x,a)') 'BYTE_OFFSET: 4'
    close(td_total_density_file)
    !spin-down
    write(fname1,'(a,a,a,a)') td_total_density_filename_prefix(1:pl),'D',ch5(1:5),'.dat'
    write(fname2,'(a,a,a,a)') td_total_density_filename_prefix(1:pl),'D',ch5(1:5),'.bov'
    fnl=len_trim(fname1)
    ind=0
    do k=N_Lattice_min(3),N_Lattice_max(3)
      do j=N_Lattice_min(2),N_Lattice_max(2)
        do i=N_Lattice_min(1),N_Lattice_max(1)
          ind=ind+1
          if (Lattice_inv_xyz(i,j,k)>0) then
            sing_prec_rearranged_density(ind)=density_down(Lattice_inv_xyz(i,j,k))
          else
            sing_prec_rearranged_density(ind)=0.0d0
          endif
        enddo
      enddo
    enddo
    open(td_total_density_file,file=fname1,form='unformatted',status='replace')
    write(td_total_density_file) sing_prec_rearranged_density
    close(td_total_density_file)
    open(td_total_density_file,file=fname2,status='replace')
    write(td_total_density_file,'(1x,a,1x,es23.15)') 'TIME:',iter*time_step
    write(td_total_density_file,'(1x,a,1x,a)') 'DATA_FILE:',fname1(1:fnl)
    write(td_total_density_file,'(1x,a,3(1x,i6))') 'DATA_SIZE:',dk1,dk2,dk3
    write(td_total_density_file,'(1x,a)') 'DATA_FORMAT:  FLOAT'
    write(td_total_density_file,'(1x,a)') 'VARIABLE:  density_down'
    write(td_total_density_file,'(1x,a)') 'DATA_ENDIAN:  LITTLE'
    write(td_total_density_file,'(1x,a)') 'CENTERING:  zonal'
    write(td_total_density_file,'(1x,a,3(1x,es23.15))') 'BRICK_ORIGIN:',xgrid(k1min),ygrid(k2min),zgrid(k3min)
    write(td_total_density_file,'(1x,a,3(1x,es23.15))') 'BRICK_SIZE:', &
        xgrid(k1max)-xgrid(k1min),ygrid(k2max)-ygrid(k2min),zgrid(k3max)-zgrid(k3min)
    write(td_total_density_file,'(1x,a)') 'BYTE_OFFSET: 4'
    close(td_total_density_file)
  endif
endif

!Ascii data files for OpenDX
if ((trim(adjustl(td_density_output_format))=="opendx").and.(box_type==1)) then
  write(ch5,'(i5.5)') td_density_counter
  pl=len_trim(td_total_density_filename_prefix)
  write(fname1,'(a,a)') td_total_density_filename_prefix(1:pl),ch5(1:5)
  write(fname2,'(a,a,a)') td_total_density_filename_prefix(1:pl),ch5(1:5),'.general'
  fnl=len_trim(fname1)
  !First write the density into a data file (in ascii format)
  open(td_total_density_file,file=fname1,status='replace')
  do k=N_Lattice_min(3),N_Lattice_max(3)
    do j=N_Lattice_min(2),N_Lattice_max(2)
      do i=N_Lattice_min(1),N_Lattice_max(1)
        if(spin_polarized) then
          if (Lattice_inv_xyz(i,j,k)>0) then
            write(td_total_density_file,'(2ES14.6)')density_up(lattice_inv_xyz(i,j,k)),density_down(lattice_inv_xyz(i,j,k))
          else
            write(td_total_density_file,'(2ES14.6)')0.d0,0.d0
          endif
        else
          if (Lattice_inv_xyz(i,j,k)>0) then
            write(td_total_density_file,'(2ES14.6)')density(lattice_inv_xyz(i,j,k))
          else
            write(td_total_density_file,'(2ES14.6)')0.d0
          endif
        endif
      enddo
    enddo
  enddo
  close(td_total_density_file)
  !Now create a header file
  open(td_total_density_file,file=fname2,status='replace')
  write(td_total_density_file,'(1x,a,a)') 'file = ',fname1(1:fnl)
  write(str1,*) dk1
  str1=adjustl(str1)
  write(str2,*) dk2
  str2=adjustl(str2)
  write(str3,*) dk3
  str3=adjustl(str3)
  write(td_total_density_file,'(1x,a,a,a,a,a,a)') 'grid = ',trim(str1),' x ',trim(str2),' x ',trim(str3)
  write(td_total_density_file,'(1x,a)') 'format = ascii'
  write(td_total_density_file,'(1x,a)') 'interleaving = record'
  write(td_total_density_file,'(1x,a)') 'majority = row'
  write(td_total_density_file,'(1x,a)') 'field = field0'
  write(td_total_density_file,'(1x,a)') 'structure = scalar'
  write(td_total_density_file,'(1x,a)') 'type = double'
  write(td_total_density_file,'(1x,a)') 'dependency = positions'
  write(td_total_density_file,'(1x,a,6(1x,f12.6,a1))') 'positions = regular, regular, regular,', &
    k1min*grid_step(1),',',Grid_step(1),',',k2min*grid_step(2),',',Grid_step(2),',',k3min*grid_step(3),',',Grid_step(3)
  write(td_total_density_file,'(1x,a)') 'end'
  close(td_total_density_file)
endif
td_density_counter=td_density_counter+1

END SUBROUTINE output_td_density


SUBROUTINE output_td_density_named(phi_in,iter,namestr)
implicit none
integer :: iter
integer :: i,j,k,ind,pl,fnl,dk1,dk2,dk3,k1min,k2min,k3min,k1max,k2max,k3max
character(255) :: fname1,fname2
character(5)   :: ch5
character(4)   :: namestr
character(16)  :: str1,str2,str3
  real*8                    :: phi_in(N_Lattice_points)
  
k1min=N_Lattice_min(1)
k1max=N_Lattice_max(1)
k2min=N_Lattice_min(2)
k2max=N_Lattice_max(2)
k3min=N_Lattice_min(3)
k3max=N_Lattice_max(3)
dk1=(k1max-k1min+1)
dk2=(k2max-k2min+1)
dk3=(k3max-k3min+1)

    write(ch5,'(i5.5)') iter
    write(fname1,'(a,a,a)') namestr(1:4),ch5(1:5),'.dat'
    write(fname2,'(a,a,a)') namestr(1:4),ch5(1:5),'.bov'
    fnl=len_trim(fname1)

    ind=0
    do k=N_Lattice_min(3),N_Lattice_max(3)
      do j=N_Lattice_min(2),N_Lattice_max(2)
        do i=N_Lattice_min(1),N_Lattice_max(1)
          ind=ind+1
          if (Lattice_inv_xyz(i,j,k)>0) then
            sing_prec_rearranged_density(ind)=density(Lattice_inv_xyz(i,j,k))
          else
            sing_prec_rearranged_density(ind)=0.0d0
          endif
        enddo
      enddo
    enddo
    open(td_total_density_file,file=fname1,form='unformatted',status='replace')
    write(td_total_density_file) sing_prec_rearranged_density
    close(td_total_density_file)
    !Now create a header file corresponding to the above datafile. The header file
    !is in ascii text form
    open(td_total_density_file,file=fname2,status='replace')
    write(td_total_density_file,'(1x,a,1x,es23.15)') 'TIME:',iter*time_step
    write(td_total_density_file,'(1x,a,1x,a)') 'DATA_FILE:',fname1(1:fnl)
    write(td_total_density_file,'(1x,a,3(1x,i6))') 'DATA_SIZE:',dk1,dk2,dk3
    write(td_total_density_file,'(1x,a)') 'DATA_FORMAT:  FLOAT'
    write(td_total_density_file,'(1x,a)') 'VARIABLE:  density'
    write(td_total_density_file,'(1x,a)') 'DATA_ENDIAN:  LITTLE'
    write(td_total_density_file,'(1x,a)') 'CENTERING:  zonal'
    write(td_total_density_file,'(1x,a,3(1x,es23.15))') 'BRICK_ORIGIN:',xgrid(k1min),ygrid(k2min),zgrid(k3min)
    write(td_total_density_file,'(1x,a,3(1x,es23.15))') 'BRICK_SIZE:', &
        xgrid(k1max)-xgrid(k1min),ygrid(k2max)-ygrid(k2min),zgrid(k3max)-zgrid(k3min)
    write(td_total_density_file,'(1x,a)') 'BYTE_OFFSET: 4'
    close(td_total_density_file)


td_density_counter=td_density_counter+1

END SUBROUTINE output_td_density_named

subroutine GetCurrentDensity(Psi1, r, KVec) !shenglai 
! this subroutine calculated the current that includes the non-local part
    complex*16,intent(in)                 :: Psi1(:, :) ! , intent(in)
    real(8), intent(in)                     :: r(:,:), KVec(:)
   ! real(8),optional,intent(in)             :: VecPotential(:,:)
   ! real(8), intent(out)                   :: CurrentDensity(:,:)
    real(8)                                 :: f,kr, OneOverHBarClight = 1.D0/hbar/c_light
    integer                                 :: NOrb, n, Nr, j, grid, i1, i2, i3,a,ik,i,lm,m,k,N_out_orb
    complex(16), allocatable                 :: Vpsi(:), PsiGrad(:,:), Vvec(:,:), rPsi(:,:), PsiPhase(:), rPsiPhase(:,:),Int1(:,:)
    complex(16)                              :: ekr(max_ps_points,N_total_atom),Jpsi1(1:3),Jpsi2(1:3)
    double precision,dimension(:,:),allocatable :: orb_current  
    character(255)  fpref,quantity
    Nr = size(Psi1, 1)
    NOrb = size(Psi1, 2)

   if(spin_polarized) then
  !$omp parallel workshare
  current_density_up=0.d0
  !$omp end parallel workshare
  !$omp parallel workshare
  current_density_down=0.d0
  !$omp end parallel workshare
  else
  !$omp parallel workshare
  current_density=0.d0
  !$omp end parallel workshare
  endif
  if (output_orb_current) then  
     allocate(orb_current(3,Nr))
     N_out_orb=min(orbital_output_num,N_orbitals)
   endif
    allocate(PsiGrad(3, Nr)); PsiGrad = (0.D0, 0.D0)
    allocate(Int1(Nr,3));Int1=0.d0
       do a=1,N_total_atom
           do j=1,num_ps_points(a)
              i=ps_grid(j,a)
            !if(present(VecPotential))      kr = dot_product(KVec + OneOverHBarClight*VecPotential(:,i), r(:, i))
            !if(.not. present(VecPotential)) 
             kr = dot_product(KVec, r(:,i))
             ekr(j,a) = exp((0.D0, 1.D0)*kr)
            !if(kr > 10e-10) then
            !print *, "--------------------------"
            !print *, "phase is abnormal."
            !else
           ! print *, "pahse is good."
           !endif
          enddo
       enddo

    do n = 1, NOrb
        if(abs(occupation(n))<1.d-10) cycle
       ! call AddPhase(Psi1(:,n), r, (/0.D0, 0.D0, 0.D0/), , VecPotential)
        f=-occupation(n)
       ! do j = 1, Nr
           ! rPsiPhase(:,j)  = PsiPhase(j)*r(:,j)
       ! enddo
        !call Nonlocal_pseudo_potential_vector(rPsiPhase, Vvec)
        !call Nonlocal_pseudo_potential_cplx(PsiPhase, Vpsi)
        do grid=1,N_lattice_points
            i1=Lattice(1,grid)
            i2=Lattice(2,grid)
            i3=Lattice(3,grid)
            wphi_c(i1,i2,i3)=Psi1(grid,n)
        end do
        call nabla
        PsiGrad = wlap_p 
        Int1=(0.d0,0.d0)
          do a=1,N_total_atom
              ik=atom_index(a)
                  do lm=1,(Max_L_pp(ik)+1)**2
                   if(abs(uVu(lm,ik)).gt.1d-5) then
                      Jpsi1=0.d0; Jpsi2=0.d0
                   do j=1,num_ps_points(a)
                     i=ps_grid(j,a)
                     Jpsi1(:)=Jpsi1(:)+ekr(j,a)*Psi1(i,n)*uV(lm,j,a)

                     Jpsi2(1)=Jpsi2(1)+ekr(j,a)*Psi1(i,n)*uV(lm,j,a)*r(1,i)
                     Jpsi2(2)=Jpsi2(2)+ekr(j,a)*Psi1(i,n)*uV(lm,j,a)*r(2,i)
                     Jpsi2(3)=Jpsi2(3)+ekr(j,a)*Psi1(i,n)*uV(lm,j,a)*r(3,i)

                   enddo
                   Jpsi1=Jpsi1*Grid_Volume/uVu(lm,ik)
                   Jpsi2=Jpsi2*Grid_Volume/uVu(lm,ik)
                   do j=1,num_ps_points(a)
                      i=ps_grid(j,a)
                      !if(Jxx(j,a).eq.0.and.Jyy(j,a).eq.0.and.Jzz(j,a).eq.0) then

                     Int1(i,1)= Int1(i,1)-Jpsi1(1)*conjg(Psi1(i,n)*ekr(j,a))*uV(lm,j,a)*r(1,i)&
                     &+conjg(Psi1(i,n)*ekr(j,a))*uV(lm,j,a)*Jpsi2(1)
                     Int1(i,2)= Int1(i,2)-Jpsi1(2)*conjg(Psi1(i,n)*ekr(j,a))*uV(lm,j,a)*r(2,i)&
                     & +conjg(Psi1(i,n)*ekr(j,a))*uV(lm,j,a)*Jpsi2(2)
                     Int1(i,3)= Int1(i,3)-Jpsi1(3)*conjg(Psi1(i,n)*ekr(j,a))*uV(lm,j,a)*r(3,i)&
                     & +conjg(Psi1(i,n)*ekr(j,a))*uV(lm,j,a)*Jpsi2(3)
                   ! endif
                  enddo
                 endif
           enddo
         enddo
          if(spin_polarized) then
                if(n<=N_orbitals_down) then
                    do j=1,Nr
                       do m=1,3
                             current_density_down(m, j) = current_density_down(m, j)+f*imag(Int1(j,m)/hbar)&
                                   +f*imag(hbar/ElectronMass*PsiGrad(m,j)*conjg(Psi1(j,n)))
                       enddo
                    enddo
                else
                    do j=1,Nr
                       do m=1,3
                             current_density_up(m, j) = current_density_up(m, j)+f*imag(Int1(j,m)/hbar)&
                                   +f*imag(hbar/ElectronMass*PsiGrad(m,j)*conjg(Psi1(j,n)))
                       enddo
                    enddo
               endif
           else
               do j=1,Nr
                       do m=1,3
                             current_density(m, j) = current_density(m, j)+f*imag(Int1(j,m)/hbar)&
                                   +f*imag(hbar/ElectronMass*PsiGrad(m,j)*conjg(Psi1(j,n)))
                       enddo 
              enddo
           endif   
      if (output_orb_current.AND.(mod(time1,td_orb_current_output_frequency)==0).AND.(n>(N_orbitals-N_out_orb))) then
     orb_current=0.d0
        do j=1,Nr
               do m=1,3
                orb_current(m, j) = f*imag(Int1(j,m)/hbar)+f*imag(hbar/ElectronMass*PsiGrad(m,j)*conjg(Psi1(j,n)))
               enddo 
        enddo
    fpref=trim(adjustl(join_string_and_num("current_orb",N_orbitals-n,"_")))
    quantity=join_string_and_num("dens_homo",N_orbitals-n)
     call save_bov_dat_real(Phi,fpref,trim(adjustl(quantity)))
      endif
    enddo
    !do j = 1, Nr
        !current_Density(:,j) = current_density(:,j) - N_orbitals/c_light/ElectronMass*VecPotential(:,j)
   ! enddo
   !deallocate(Vpsi)
    deallocate(PsiGrad)
    deallocate(Int1)
endsubroutine GetCurrentDensity

SUBROUTINE output_td_current_density(iter)
!This subroutine saves electron current density (as a 3D array of data)
!at iteration iter in a file(s) whose format is specified by global
!variable td_current_density_output_format. If the value of this variable
!is "default" then everything will be written in a single ascii file.
!Otherwise, each instant of current density is saved in a separate file whose
!prefix is defined by td_total_current_density_filename_prefix
integer :: iter
integer :: i,j,k,ind,pl,fnl,m,dk1,dk2,dk3,k1min,k2min,k3min,k1max,k2max,k3max
character(255) :: fname1,fname2
character(5)   :: ch5
character(16)  :: str1,str2,str3
complex*16, allocatable :: Psi2(:,:)
!First we compute the current density

if (non_local_current) then
  if (using_injection) then
     allocate(psi2(N_lattice_points,1))
     do j=1,N_lattice_points
      psi2(j,1)=phi_source(j)
     enddo
    call GetCurrentDensity(psi2, Grid_point, (/0.D0,0.D0,0.D0/))
     deallocate(psi2)
  else
    call GetCurrentDensity(Psi_c, Grid_point, (/0.D0,0.D0,0.D0/))
  endif
else
call compute_td_current_density()
endif


k1min=N_Lattice_min(1)
k1max=N_Lattice_max(1)
k2min=N_Lattice_min(2)
k2max=N_Lattice_max(2)
k3min=N_Lattice_min(3)
k3max=N_Lattice_max(3)
dk1=(k1max-k1min+1)
dk2=(k2max-k2min+1)
dk3=(k3max-k3min+1)

!Default format -- single ascii file for current densities at any instant.
!This is inefficient in terms of storage and write speed.
if (trim(adjustl(td_current_density_output_format))=="default") then
  do i=1,N_Lattice_points
    if(spin_polarized) then
      write(td_total_current_density_file,'(6ES16.8)')current_density_up(1,i),current_density_up(2,i), &
      	current_density_up(3,i),current_density_down(1,i),current_density_down(2,i),current_density_down(3,i)
    else
      write(td_total_current_density_file,'(3ES16.8)')current_density(1,i),current_density(2,i),current_density(3,i)
    endif
  enddo
endif

!Bov format (bricks of data) which can easily be read by VisIt software.
!It is fast and reasonable in terms of disk space. Works only in the
!case of rectangular box
if ((trim(adjustl(td_current_density_output_format))=="bov").and.(box_type==1)) then
  if (.not.spin_polarized) then
    write(ch5,'(i5.5)') td_current_density_counter
    pl=len_trim(td_total_current_density_filename_prefix)
    write(fname1,'(a,a,a)') td_total_current_density_filename_prefix(1:pl),ch5(1:5),'.dat'
    write(fname2,'(a,a,a)') td_total_current_density_filename_prefix(1:pl),ch5(1:5),'.bov'
    fnl=len_trim(fname1)
    !First write the current density into a data file, which is of binary form.
    !Note that the current density data is rearranged as z,y,x --> x,y,z (C-like
    !storage of array elements)  and converted to single precision before
    !saving it to disk (single precision is used to reduce disk usage).
    !Rearrangement must be done using an auxiliary array
    !(called sing_prec_rearranged_current_density) because the data cannot be
    !simply written into the binary file by making an appropriate do-loop
    !(writing an entire array at once and writing it step-by-step gives
    !different result in fortran when it is a binary file).
    ind=0
    do k=N_Lattice_min(3),N_Lattice_max(3)
      do j=N_Lattice_min(2),N_Lattice_max(2)
        do i=N_Lattice_min(1),N_Lattice_max(1)
          if (Lattice_inv_xyz(i,j,k)>0) then
            do m=1,3
              ind=ind+1
              sing_prec_rearranged_current_density(ind)=current_density(m,Lattice_inv_xyz(i,j,k))
            enddo
          else
            do m=1,3
              ind=ind+1
              sing_prec_rearranged_current_density(ind)=0.0d0
            enddo
          endif
        enddo
      enddo
    enddo
    open(td_total_current_density_file,file=fname1,form='unformatted',status='replace')
    write(td_total_current_density_file) sing_prec_rearranged_current_density
    close(td_total_current_density_file)
    !Now create a header file corresponding to the above datafile. The header file
    !is in ascii text form
    open(td_total_current_density_file,file=fname2,status='replace')
    write(td_total_current_density_file,'(1x,a,1x,es23.15)') 'TIME:',iter*time_step
    write(td_total_current_density_file,'(1x,a,1x,a)') 'DATA_FILE:',fname1(1:fnl)
    write(td_total_current_density_file,'(1x,a,3(1x,i6))') 'DATA_SIZE:',dk1,dk2,dk3
    write(td_total_current_density_file,'(1x,a)') 'DATA_FORMAT:  FLOAT'
    write(td_total_current_density_file,'(1x,a)') 'VARIABLE:  current_density'
    write(td_total_current_density_file,'(1x,a)') 'DATA_COMPONENTS: 3'
    write(td_total_current_density_file,'(1x,a)') 'DATA_ENDIAN:  LITTLE'
    write(td_total_current_density_file,'(1x,a)') 'CENTERING:  zonal'
    write(td_total_current_density_file,'(1x,a,3(1x,es23.15))') 'BRICK_ORIGIN:',xgrid(k1min),ygrid(k2min),zgrid(k3min)
    write(td_total_current_density_file,'(1x,a,3(1x,es23.15))') 'BRICK_SIZE:', &
            xgrid(k1max)-xgrid(k1min),ygrid(k2max)-ygrid(k2min),zgrid(k3max)-zgrid(k3min)
    write(td_total_current_density_file,'(1x,a)') 'BYTE_OFFSET: 4'
    close(td_total_current_density_file)
  else
    !If spin_polarized=.true. then we basically perform the same actions as above
    !but do it for spin-up and spin-down density separately
    write(ch5,'(i5.5)') td_current_density_counter
    pl=len_trim(td_total_current_density_filename_prefix)
    !spin-up
    write(fname1,'(a,a,a,a)') td_total_current_density_filename_prefix(1:pl),'U',ch5(1:5),'.dat'
    write(fname2,'(a,a,a,a)') td_total_current_density_filename_prefix(1:pl),'U',ch5(1:5),'.bov'
    fnl=len_trim(fname1)
    ind=0
    do k=N_Lattice_min(3),N_Lattice_max(3)
      do j=N_Lattice_min(2),N_Lattice_max(2)
        do i=N_Lattice_min(1),N_Lattice_max(1)
          if (Lattice_inv_xyz(i,j,k)>0) then
            do m=1,3
              ind=ind+1
              sing_prec_rearranged_current_density(ind)=current_density_up(m,Lattice_inv_xyz(i,j,k))
            enddo
          else
            do m=1,3
              ind=ind+1
              sing_prec_rearranged_current_density(ind)=0.0d0
            enddo
          endif
        enddo
      enddo
    enddo
    open(td_total_current_density_file,file=fname1,form='unformatted',status='replace')
    write(td_total_current_density_file) sing_prec_rearranged_current_density
    close(td_total_current_density_file)
    open(td_total_current_density_file,file=fname2,status='replace')
    write(td_total_current_density_file,'(1x,a,1x,es23.15)') 'TIME:',iter*time_step
    write(td_total_current_density_file,'(1x,a,1x,a)') 'DATA_FILE:',fname1(1:fnl)
    write(td_total_current_density_file,'(1x,a,3(1x,i6))') 'DATA_SIZE:',dk1,dk2,dk3
    write(td_total_current_density_file,'(1x,a)') 'DATA_FORMAT:  FLOAT'
    write(td_total_current_density_file,'(1x,a)') 'VARIABLE:  current_density_up'
    write(td_total_current_density_file,'(1x,a)') 'DATA_COMPONENTS: 3'
    write(td_total_current_density_file,'(1x,a)') 'DATA_ENDIAN:  LITTLE'
    write(td_total_current_density_file,'(1x,a)') 'CENTERING:  zonal'
    write(td_total_current_density_file,'(1x,a,3(1x,es23.15))') 'BRICK_ORIGIN:',xgrid(k1min),ygrid(k2min),zgrid(k3min)
    write(td_total_current_density_file,'(1x,a,3(1x,es23.15))') 'BRICK_SIZE:', &
            xgrid(k1max)-xgrid(k1min),ygrid(k2max)-ygrid(k2min),zgrid(k3max)-zgrid(k3min)
    write(td_total_current_density_file,'(1x,a)') 'BYTE_OFFSET: 4'
    close(td_total_current_density_file)
    !spin-down
    write(fname1,'(a,a,a,a)') td_total_current_density_filename_prefix(1:pl),'D',ch5(1:5),'.dat'
    write(fname2,'(a,a,a,a)') td_total_current_density_filename_prefix(1:pl),'D',ch5(1:5),'.bov'
    fnl=len_trim(fname1)
    ind=0
    do k=N_Lattice_min(3),N_Lattice_max(3)
      do j=N_Lattice_min(2),N_Lattice_max(2)
        do i=N_Lattice_min(1),N_Lattice_max(1)
          if (Lattice_inv_xyz(i,j,k)>0) then
            do m=1,3
              ind=ind+1
              sing_prec_rearranged_current_density(ind)=current_density_down(m,Lattice_inv_xyz(i,j,k))
            enddo
          else
            do m=1,3
              ind=ind+1
              sing_prec_rearranged_current_density(ind)=0.0d0
            enddo
          endif
        enddo
      enddo
    enddo
    open(td_total_current_density_file,file=fname1,form='unformatted',status='replace')
    write(td_total_current_density_file) sing_prec_rearranged_current_density
    close(td_total_current_density_file)
    open(td_total_current_density_file,file=fname2,status='replace')
    write(td_total_current_density_file,'(1x,a,1x,es23.15)') 'TIME:',iter*time_step
    write(td_total_current_density_file,'(1x,a,1x,a)') 'DATA_FILE:',fname1(1:fnl)
    write(td_total_current_density_file,'(1x,a,3(1x,i6))') 'DATA_SIZE:',dk1,dk2,dk3
    write(td_total_current_density_file,'(1x,a)') 'DATA_FORMAT:  FLOAT'
    write(td_total_current_density_file,'(1x,a)') 'VARIABLE:  current_density_down'
    write(td_total_current_density_file,'(1x,a)') 'DATA_COMPONENTS: 3'
    write(td_total_current_density_file,'(1x,a)') 'DATA_ENDIAN:  LITTLE'
    write(td_total_current_density_file,'(1x,a)') 'CENTERING:  zonal'
    write(td_total_current_density_file,'(1x,a,3(1x,es23.15))') 'BRICK_ORIGIN:',xgrid(k1min),ygrid(k2min),zgrid(k3min)
    write(td_total_current_density_file,'(1x,a,3(1x,es23.15))') 'BRICK_SIZE:', &
            xgrid(k1max)-xgrid(k1min),ygrid(k2max)-ygrid(k2min),zgrid(k3max)-zgrid(k3min)
    write(td_total_current_density_file,'(1x,a)') 'BYTE_OFFSET: 4'
    close(td_total_current_density_file)
  endif
endif

!Ascii data files for OpenDX
! NOTE: only outputting x component for now
if ((trim(adjustl(td_current_density_output_format))=="opendx").and.(box_type==1)) then
  write(ch5,'(i5.5)') td_current_density_counter
  pl=len_trim(td_total_current_density_filename_prefix)
  write(fname1,'(a,a)') td_total_current_density_filename_prefix(1:pl),ch5(1:5)
  write(fname2,'(a,a,a)') td_total_current_density_filename_prefix(1:pl),ch5(1:5),'.general'
  fnl=len_trim(fname1)
  !First write the current density into a data file (in ascii format)
  open(td_total_current_density_file,file=fname1,status='replace')
  do i=1,N_Lattice_points
    if(spin_polarized) then
      write(td_total_current_density_file,'(2ES14.6)')current_density_up(1,i),current_density_down(1,i)
    else
      write(td_total_current_density_file,'(ES14.6)')current_density(1,i)
    endif
  enddo
  close(td_total_current_density_file)
  !Now create a header file
  open(td_total_current_density_file,file=fname2,status='replace')
  write(td_total_current_density_file,'(1x,a,a)') 'file = ',fname1(1:fnl)
  write(str1,*) N_Lattice(1)
  str1=adjustl(str1)
  write(str2,*) N_Lattice(2)
  str2=adjustl(str2)
  write(str3,*) N_Lattice(3)
  str3=adjustl(str3)
  write(td_total_current_density_file,'(1x,a,a,a,a,a,a)') 'grid = ',trim(str1),' x ',trim(str2),' x ',trim(str3)
  write(td_total_current_density_file,'(1x,a)') 'format = ascii'
  write(td_total_current_density_file,'(1x,a)') 'interleaving = record'
  write(td_total_current_density_file,'(1x,a)') 'majority = row'
  write(td_total_current_density_file,'(1x,a)') 'field = field0'
  write(td_total_current_density_file,'(1x,a)') 'structure = scalar'
  write(td_total_current_density_file,'(1x,a)') 'type = double'
  write(td_total_current_density_file,'(1x,a)') 'dependency = positions'
  write(td_total_current_density_file,'(1x,a,6(1x,f12.6,a1))') 'positions = regular, regular, regular,', &
    -R_size(1),',',Grid_step(1),',',-R_size(2),',',Grid_step(2),',',-R_size(3),',',Grid_step(3)
  write(td_total_current_density_file,'(1x,a)') 'end'
  close(td_total_current_density_file)
endif

td_current_density_counter=td_current_density_counter+1

END SUBROUTINE output_td_current_density

! shenglai
SUBROUTINE output_td_SP_energy()
integer :: i
character(255) :: fname
character(5) :: ch5

write(ch5,'(i5.5)') td_sp_energy_counter
write(fname,'(a,a,a)') 'SP_energy',ch5(1:5),'.dat'
open(td_SP_energy_file,file=fname,status='replace')
do i=1,N_orbitals
  write(td_SP_energy_file,'(3ES16.8)') Sp_Energy(i)
enddo
close(td_SP_energy_file)
td_sp_energy_counter=td_sp_energy_counter+1
    
END SUBROUTINE output_td_SP_energy

subroutine compute_td_current_density()
integer    :: i,j,k,m,i1,i2,i3,grid,orbital
real(8)    :: f

!Warning! the current density is not in microamps/A^2, it is in elementary_charge/(fs*A^2)

if(spin_polarized) then
  !$omp parallel workshare
  current_density_up=0.d0
  !$omp end parallel workshare
  !$omp parallel workshare
  current_density_down=0.d0
  !$omp end parallel workshare
else
  !$omp parallel workshare
  current_density=0.d0
  !$omp end parallel workshare
endif

 do orbital=1,n_orbitals
  ! Only need to consider occupied orbitals here
  if(abs(occupation(orbital))<1.d-10) cycle
  !Compute the gradient of an orbital
  !$omp parallel do &
  !$omp default(shared) &
  !$omp private (grid, i1, i2, i3)
  do grid=1,N_lattice_points
    i1=Lattice(1,grid)
    i2=Lattice(2,grid)
    i3=Lattice(3,grid)
    wphi_c(i1,i2,i3)=Psi_c(grid,orbital)
  end do
  !$omp end parallel do
  call nabla
  !Now wlap_p(1:3,1:N_lattice_points) contains the gradient of an orbital
  f=-occupation(orbital)*hbar/ElectronMass  !electron has negative charge, i.e. -1
  if(spin_polarized) then
    if(orbital<=N_orbitals_down) then
      !$omp parallel do &
      !$omp default(shared) &
      !$omp private (grid, m)
      do grid=1,N_lattice_points
        do m=1,3
          current_density_down(m,grid)=current_density_down(m,grid)+f*imag(conjg(Psi_c(grid,orbital))*wlap_p(m,grid))
        enddo
      enddo
      !$omp end parallel do
    else
      !$omp parallel do &
      !$omp default(shared) &
      !$omp private (grid, m)
      do grid=1,N_lattice_points
        do m=1,3
          current_density_up(m,grid)=current_density_up(m,grid)+f*imag(conjg(Psi_c(grid,orbital))*wlap_p(m,grid))
        enddo
      enddo
      !$omp end parallel do
    endif
  else
    !$omp parallel do &
    !$omp default(shared) &
    !$omp private (grid, m)
    do grid=1,N_lattice_points
      do m=1,3
        current_density(m,grid)=current_density(m,grid)+f*imag(conjg(Psi_c(grid,orbital))*wlap_p(m,grid))
      enddo
    enddo
    !$omp end parallel do
  endif
enddo
end subroutine compute_td_current_density


function abssqr_Psi_val(x,y,z,orb)
!This function computes the numerical value of the absolute square of an 
!orbital Psi(:,orb) at a single point x,y,z. Coordinates x,y,z do 
!not need to coincide with the lattice points. Linear interpolation 
!is used.
real(8)  abssqr_Psi_val 
real(8)  x,y,z    
integer  orb      ! orbital index, orb=1..N_orbitals
integer  i,k,k1min,k1max,k2min,k2max,k3min,k3max
integer  k1l,k1r,k2l,k2r,k3l,k3r
real(8)  f,fl


k1min=N_Lattice_min(1)
k1max=N_Lattice_max(1)
k2min=N_Lattice_min(2)
k2max=N_Lattice_max(2)
k3min=N_Lattice_min(3)
k3max=N_Lattice_max(3)

if ( &
     (x<xgrid(k1min)).or.(x>xgrid(k1max)).or. &
     (y<ygrid(k2min)).or.(y>ygrid(k2max)).or. &
     (z<zgrid(k3min)).or.(z>zgrid(k3max)) &    
   ) then
   abssqr_Psi_val=0.0d0 
   return
endif 

k1l=k1min; k1r=k1max
do while (k1r-k1l>1)
  k=(k1l+k1r)/2
  if (x<xgrid(k)) then
    k1r=k
  else
    k1l=k
  endif
enddo 
k2l=k2min; k2r=k2max
do while (k2r-k2l>1)
  k=(k2l+k2r)/2
  if (y<ygrid(k)) then
    k2r=k
  else
    k2l=k
  endif
enddo 
k3l=k3min; k3r=k3max
do while (k3r-k3l>1)
  k=(k3l+k3r)/2
  if (z<zgrid(k)) then
    k3r=k
  else
    k3l=k
  endif
enddo 

i=Lattice_inv_xyz(k1l,k2l,k3l)
fl=0.0d0
if (i/=0) fl=Psi(i,orb)*Psi(i,orb)

f=fl

i=Lattice_inv_xyz(k1r,k2l,k3l)
if (i/=0) f=f+(Psi(i,orb)*Psi(i,orb)-fl)*(x-xgrid(k1l))/grid_step(1)

i=Lattice_inv_xyz(k1l,k2r,k3l)
if (i/=0) f=f+(Psi(i,orb)*Psi(i,orb)-fl)*(y-ygrid(k2l))/grid_step(2)

i=Lattice_inv_xyz(k1l,k2l,k3r)
if (i/=0) f=f+(Psi(i,orb)*Psi(i,orb)-fl)*(z-zgrid(k3l))/grid_step(3)

abssqr_Psi_val=f

end function abssqr_Psi_val 







subroutine calculate_rho_grid_PSIreal
  real*8             :: x,occ_k,totocc
  integer            :: j,k
  
  if(debug_output_level >= 2) write(log_file,*) "call to calculate_rho_grid"

if(spin_polarized) then
  !$omp parallel workshare
  density_down_new=0.0d0
  density_up_new=0.0d0
  !$omp end parallel workshare
  do k=1,N_orbitals_down
    occ_k=Occupation(k)
    !$omp parallel do &
    !$omp default(shared) &
    !$omp private (j)
    do j=1,N_lattice_points
      density_down_new(j)=density_down_new(j)+(Psi(j,k)**2)*occ_k
    enddo
    !$omp end parallel do
  enddo
  do k=N_orbitals_down+1,N_orbitals
    occ_k=Occupation(k)
    !$omp parallel do &
    !$omp default(shared) &
    !$omp private (j) 
    do j=1,N_lattice_points
      density_up_new(j)=density_up_new(j)+(Psi(j,k)**2)*occ_k
    enddo
    !$omp end parallel do
  enddo
  !$omp parallel workshare
  density_up=density_up_new
  density_down=density_down_new
  !$omp end parallel workshare
  !$omp parallel workshare
  density=density_down_new+density_up_new
  !$omp end parallel workshare
else
  k=1
  occ_k=Occupation(1)
  !$omp parallel do &
  !$omp default(shared) &
  !$omp private (j)
  do j=1,N_lattice_points
    density(j)=(Psi(j,k)**2)*occ_k
  enddo
  !$omp end parallel do
  do k=2,N_orbitals
		if((tddft_type==3).AND.(k==N_orbitals)) then
		  occ_k=1.d0
		else  
		  occ_k=Occupation(k)   
		endif
    !$omp parallel do &
    !$omp default(shared) &
    !$omp private (j)
    do j=1,N_lattice_points
      density(j)=density(j)+(Psi(j,k)**2)*occ_k
    enddo
    !$omp end parallel do
  enddo

endif

  totocc=0.d0
  totocc=totocc+sum(density(:))*grid_volume
  if((totocc > 20000).OR.isnan(totocc)) then
    write(log_file,*) "total occupation ",totocc
	write(log_file,*) "calculation is exploding"
	stop_tddft_calc=.TRUE.
  end if
  if((totocc < 1.0d-8)) then
    write(log_file,*) "total occupation ",totocc
	write(log_file,*) "system is completely ionized"
	stop_tddft_calc=.TRUE.
  end if
  if(debug_output_level >= 2) write(log_file,*) "End call to calculate_rho_grid"
end subroutine calculate_rho_grid_PSIreal





subroutine do_remove_dens_around_atom
implicit none
  integer            :: i,j,k,orbital
  real*8,allocatable :: rem_cutoff(:)
  real*8             :: r

  allocate(rem_cutoff(N_Lattice_points))
  rem_cutoff=0.d0
  rem_cutoff=1.d0
  k=remove_dens_around_atom_idx
  do i=1,N_Lattice_points
    r=sqrt((Position(1,k)-grid_point(1,i))**2 + (Position(2,k)-grid_point(2,i))**2 + (Position(3,k)-grid_point(3,i))**2)
	if(r<remove_dens_around_atom_rad) then
	  rem_cutoff(i)=0.d0
	else
	  rem_cutoff(i)=1.d0
	end if
  end do

  do orbital=1,N_total_orbitals
    do i=1,N_Lattice_points
	  Psi(i,orbital)=Psi(i,orbital)*rem_cutoff(i)
	end do
  end do
  
  
  
  deallocate(rem_cutoff)
end subroutine do_remove_dens_around_atom

subroutine do_split_region_mode
implicit none
  integer            :: i,j,k,orbital
  
  if(split_region_n_orb_lower+split_region_n_orb_upper/=N_total_orbitals) then
    write(log_file,*) "split_region_n_orb numbers do not add up to the total number of orbitals"
	write(log_file,*) split_region_n_orb_lower,split_region_n_orb_upper,N_total_orbitals
    stop
  endif
  
  ! lower region orbitals towards -z
  do orbital=1,split_region_n_orb_lower
    do i=1,N_Lattice_points
	  if(grid_point(3,i)>split_region_plane_z) Psi(i,orbital)=0.d0
	end do
  end do
  ! upper region orbitals towards +z
  do orbital=split_region_n_orb_lower+1,N_total_orbitals
    do i=1,N_Lattice_points
	  if(grid_point(3,i)<split_region_plane_z) Psi(i,orbital)=0.d0
	end do
  end do
  
end subroutine do_split_region_mode

subroutine print_forces_to_monitor(f_array,info1)
implicit none
real*8 :: f_array(3,N_total_atom)
integer :: atom,ai,elem
character*4 :: info1

    write(log_file,'(a,a)') "FORCE::",info1
    do atom=1,N_total_atom
      ai=atom_index(atom)
      elem=z_atom(ai)
      write(log_file,'(1x,a3,9(1x,e16.9))') &
        element_symbols(elem),f_array(1:3,atom)
    enddo
  
end subroutine print_forces_to_monitor

END MODULE HAMILTON
