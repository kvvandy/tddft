MODULE PSEUDOPOTENTIAL
  USE MOD_GLOBAL
  USE WORKPROCS
  implicit none

  !     Number of radial points per atom
  integer, dimension(:), allocatable          :: N_pp_radial_points
  !     mesh step for radial points
  real*8, dimension(:), allocatable           :: step_pp
  !     maximum angular momentum component per atom
  integer, dimension(:), allocatable          :: Max_L_pp
  !     pseudo charge
  real*8, dimension(:), allocatable           :: Charge_pp
  !     core radius
  real*8, dimension(:), allocatable           :: Core_radius
  !
  integer, dimension(:), allocatable          :: L_ref
  !     radial pseudo-wavefunction
  real*8, dimension(:,:,:), allocatable       :: psi_pp
  !     radial pseudo-potential
  real*8, dimension(:,:,:), allocatable       :: vnl_pp
  !
  !     to define the points of the grid within
  !     the core radius of the
  !     pseudopotential:
  !     number of points within the core radius
  integer,dimension(:), allocatable           :: num_ps_points
  !     max number of points within the core radius
  integer                                     :: max_ps_points
  !     the index of the grid point is a given
  !     supercell:
  integer,dimension(:,:), allocatable         :: ps_grid
  !
  !     pseudo potential
  real*8, dimension(:,:), allocatable         :: u
  real*8, dimension(:,:,:), allocatable       :: uV
  integer                                     :: uV_size
  real*8, dimension(:,:), allocatable         :: uVu
  real*8, dimension(:,:,:), allocatable       :: u_pp,v_pp
  real*8                                      :: r_max_pp
  integer,parameter                           :: nge=50
  real*8,parameter                            :: xe0=1.15d0,ae0=0.005d0
  real*8                                      :: gae(nge)
  real*8,dimension(:,:),allocatable           :: pot_ge
  real*8,dimension(:,:,:),allocatable         :: nl_pot_u,nl_pot_uv
!  real*8,dimension(:,:,:),allocatable         :: VNL
  integer,dimension(:,:,:), allocatable       :: ps_grid_cell
  real*8, dimension(:), allocatable           :: Phase_factor_r
  real*8, dimension(:), allocatable           :: Phase_factor_i

  real*8, dimension(:), allocatable           :: rho_bg_rad
  real*8, dimension(:), allocatable           :: vh_bg_rad
  real*8                                      :: step_bg
!  real*8,parameter                            :: rad_bg=20.d0
  integer,parameter                           :: N_points_bg=N_points_max

  integer :: nlvec_pp
  integer, dimension(:,:), allocatable        :: laux_in
  real*8, dimension(:,:), allocatable         :: laux

  integer :: n_edge_points
  integer, dimension(:), allocatable :: edge_points

  double precision :: y_lm(0:3,7) ! new CODY 20190408

!vk




  integer                                     :: N_nl
  integer,allocatable                         :: nl_ind(:),nl_tab(:,:)
  real*8,allocatable                          :: uv_nl(:,:)
  !real*8,allocatable                          :: duv_nl(:,:,:)
  integer,allocatable                         :: s_uvu_nl(:)
  !     lagrange interpolation
  integer,parameter                           :: nr_PS=5

  

  
CONTAINS

  subroutine build_aux_array
    real*8, allocatable :: lvec(:,:)
    integer, allocatable :: lvec_in(:,:)
    integer :: k, il1,il2,il3,ll(3),i
    real*8 :: rg(3),rg2

    nlvec_pp = (2*ln1+1) * (2*ln2+1) * (2*ln3+1)
    allocate(lvec(3,nlvec_pp))
    allocate(lvec_in(3,nlvec_pp))
    k = 1
    do il1=-ln1,ln1
    do il2=-ln2,ln2
    do il3=-ln3,ln3
       ll(1)=il1; ll(2)=il2; ll(3)=il3
       rg = 2.0d0*r_size*ll
       rg2 = sum(rg*rg)
       if (rg2 /= 0.0d0) then
          lvec(:,k) = rg
          lvec_in(:,k) = ll
          k = k + 1
       end if
    end do
    end do
    end do

    nlvec_pp = k - 1
    allocate(laux(3,nlvec_pp))
    allocate(laux_in(3,nlvec_pp))
    do i=1,nlvec_pp
       laux(:,i) = lvec(:,i)
       laux_in(:,i) = lvec_in(:,i)
    end do
    deallocate(lvec)
    deallocate(lvec_in)
  end subroutine build_aux_array

  subroutine init_edge_points(tol)
    ! finds all grid points within tol of the box_edge
    real(8), intent(in) :: tol

    real(8), dimension(3) :: r1,r2
    integer :: i,n,k

    n=0
    !$omp parallel do &
    !$omp default (shared) &
    !$omp private(i,r1,r2) &
    !$omp reduction(+: n)
    do i=1,n_lattice_points
       r1=abs(grid_point(:,i)-r_size)
       r2=abs(grid_point(:,i)+r_size)
       if ( any(r1 < tol ) .or. any(r2 < tol)) then
        n=n+1
       end if
    end do
    !$omp end parallel do
    if (allocated(edge_points)) deallocate(edge_points)
    allocate(edge_points(n))
    n_edge_points = n
    k=0
    do i=1,n_lattice_points
       r1=abs(grid_point(:,i)-r_size)
       r2=abs(grid_point(:,i)+r_size)
       if ( any(r1 < tol ) .or. any(r2 < tol)) then
          k=k+1
          edge_points(k)=i
       end if
    end do

    write(log_file,*) 'n_edge_points',n_edge_points,tol

  end subroutine init_edge_points

  subroutine cleanup_edge_points
    if (allocated(edge_points)) deallocate(edge_points)
  end subroutine cleanup_edge_points

  subroutine input_pseudo_potential
    integer       :: atom,points,l,i1,i2,i3,i,nm,memrq
    real*8        :: dummy,r,r1,r2,r3,rad(0:L_max)
    character*255 :: full_filename,symbol


    memrq = 5*N_species + 4*(N_points_max+1)*(L_max+1)*N_species
    memrq = memrq + 2*(N_points_bg+1)+(N_species+1)

    i=N_species
    allocate(N_pp_radial_points(i),L_ref(i),step_pp(i),Max_L_pp(i),Core_radius(i))
    allocate(Charge_pp(0:N_species),rho_bg_rad(0:N_points_bg),vh_bg_rad(0:N_points_bg))
    allocate(u_pp(0:N_points_max,0:L_max,N_species),v_pp(0:N_points_max,0:L_max,N_species), &
      psi_pp(0:N_points_max,0:L_max,N_species),vnl_pp(0:N_points_max,0:L_max,N_species))

    charge_pp=0.d0
	v_pp=0.d0
    r_max_pp=0
    max_l_pp=0
    rad=0
    step_pp=0.d0
    N_pp_radial_points=0
    !     read PP for each type of atom
    do atom=1,N_species
    if(z_atom(atom).ne.0) then

       symbol=element_symbols(Z_atom(atom))
       call convert_to_lowercase(symbol)
       write(full_filename,'(3a)')trim(adjustl(pp_path)),trim(adjustl(symbol)),trim(adjustl(pp_suffix))
       write(log_file,*)"Pseudopotential full_filename: ",trim(adjustl(full_filename))
       open(pp_file,file=trim(adjustl(full_filename)))

       L_ref(atom)=1
       read(pp_file,*)N_pp_radial_points(atom),step_pp(atom),Max_L_pp(atom),Charge_pp(atom)
	   write(log_file,'(a,i4,a,a)') "PP info: atom=",atom," ",symbol
	   write(log_file,'(a,i7)') "N_pp_radial_points=",N_pp_radial_points(atom)
	   write(log_file,'(a,f20.10)') "step_pp=",step_pp(atom)
	   write(log_file,'(a,i5)') "Max_L_pp=",Max_L_pp(atom)
	   write(log_file,'(a,f20.10)') "Charge_pp=",Charge_pp(atom)
       !     check input
       if(N_pp_radial_points(atom).gt.N_points_max) write(log_file,*)'error1'
       if(Max_L_pp(atom).gt.L_max) write(log_file,*)'error2'

       read(pp_file,*)(rad(l),l=0,Max_L_pp(atom))

       Core_radius(atom)=maxval(rad(0:L_max))
       if(Core_radius(atom).gt.r_max_pp) r_max_pp=Core_radius(atom)

       do points=0,N_pp_radial_points(atom)
          read(pp_file,*)dummy,(v_pp(points,l,atom),l=0,Max_L_pp(atom))
       end do

       do points=0,N_pp_radial_points(atom)
          read(pp_file,*)dummy,(u_pp(points,l,atom),l=0,Max_L_pp(atom))
       end do

       !       fill up the PP
       do l=0,Max_L_pp(atom)
         do points=N_pp_radial_points(atom)+1,N_points_max
            u_pp(points,l,atom)=0
            r=points*step_pp(atom)
            v_pp(points,l,atom)=-Charge_pp(atom)*E2/r
         end do
       end do

       do l=0,Max_L_pp(atom)
         do points=1,N_points_max
            r=points*step_pp(atom)
            ! old psi_pp(points,l,atom)=u_pp(points,l,atom)/r**(l+1)*sqrt((2*l+1.d0)/(4*Pi))
			psi_pp(points,l,atom)=u_pp(points,l,atom)/r*sqrt((2*l+1.d0)/(4*Pi))
            vnl_pp(points,l,atom)=(v_pp(points,l,atom)-v_pp(points,L_ref(atom),atom))*psi_pp(points,l,atom)
         end do
       psi_pp(0,l,atom)=psi_pp(1,l,atom)
       vnl_pp(0,l,atom)=vnl_pp(1,l,atom)
       end do
       close(pp_file)
    endif
    end do
    !
    !        step_bg=maxval(step_pp(1:N_species))
    step_bg=cutoff_bg_potential/N_points_bg
    do points=0,N_points_bg
       r=points*step_bg
       if(points==0) r=1.d-08
       rho_bg_rad(points)=(bg_beta/pi)**1.5d0*exp(-bg_beta*r**2)
       vh_bg_rad(points)=derf(sqrt(bg_beta)*r)/r*E2
    end do

    call init_orb
    write(log_file,*)'input_pseudo_potential   :  OK'
  end subroutine input_pseudo_potential

  subroutine init_potential
    USE COMMON_LIBRARY
    integer                      :: atom,gridi,it,L,intr,ierr,i,j,k,iii,lm
    real*8                       :: ra1,ra2,r2,su,su1,su2,r,x(3),y,wwx,nux,sug,tes(nge)
    integer,parameter            :: np=2000
    real*8                       :: step,dev,po,poe
    real*8                       :: pot(np),rp(np),cg(nge),nu(nge),url(np),uvrl(np),rq(np)
    integer                      :: memrq

    memrq = nge*N_species + 2*nge*(L_max+1)*N_species + 5*np + 3*nge

    allocate(pot_ge(nge,N_species),nl_pot_u(nge,0:L_max,N_species),nl_pot_uv(nge,0:L_max,N_species))

    do i=1,nge
       nu(i)=1.d0/(ae0*xe0**(i-1))**2
    end do

    if(np.gt.N_points_max) then
       write(log_file,*)'error in pseudo'
       stop
    endif

    step=0.005d0
    do it=1,N_species
    if(z_atom(it).ne.0) then
       L=L_ref(it)
       do gridi=1,np
          !      step=step_pp(it)
          r2=step*gridi
          rp(gridi)=r2
          intr=int(r2/step_pp(it))
          ra1=(r2/step_pp(it)-intr) ; ra2=1.d0-ra1
          pot(gridi)=ra1*v_pp(intr+1,L,it)+ra2*v_pp(intr,L,it)+derf(sqrt(bg_beta)*r2)/r2*E2*charge_pp(it)

          if(r2.gt.2.d0) pot(gridi)=0.d0
       end do

       call potential_fit(rp,pot,np,nu,nge,cg)

       pot_ge(:,it)=cg(:)
    endif
    end do

    dev=0.d0
    do it=1,N_species
    if(z_atom(it).ne.0) then
       L=L_ref(it)
       do gridi=1,np*5
          r2=step*gridi
          intr=int(r2/step_pp(it))
          ra1=(r2/step_pp(it)-intr) ; ra2=1.d0-ra1
          poe=ra1*v_pp(intr+1,L,it)+ra2*v_pp(intr,L,it)+derf(sqrt(bg_beta)*r2)/r2*E2*charge_pp(it)

          if(r2.gt.2.d0) poe=0.d0
          po=0.d0
          do i=1,Nge
             po=po+pot_ge(i,it)*exp(-nu(i)*r2**2)
          end do
          dev=dev+(po-poe)**2
          poe=(ra1*v_pp(intr+1,L,it)+ra2*v_pp(intr,L,it))/(1.d0/r2*E2*charge_pp(it))
       end do
    endif
    end do
    write(log_file,*)'init_potential :  OK'
  end subroutine init_potential

  subroutine init_pp
    real*4 :: t1,t2

       call background
       write(log_file,*)"background",sum(rho_bg)*grid_volume,grid_volume
       write(log_file,*)charge_pp
       call local_pseudo_potential

       if(grid_type==1) then
           call create_pseudo_potential
       endif

    write(log_file,*)'init_pp        :  OK'
  end subroutine init_pp

  subroutine init_orb
    integer :: i,k
    integer, allocatable :: N_el_box(:)
	real*8   :: totalnumelec

    Charge_pp(0)=0.d0 ! ghost atom

    num_electrons_sys_init=0
    allocate(N_el_box(N_box))
    N_el_box=0
    do i=1,N_total_atom
      N_el_box(box_atom(i))=N_el_box(box_atom(i))+idint(Charge_pp(atom_index(i)))
	  num_electrons_sys_init=num_electrons_sys_init+idint(Charge_pp(atom_index(i)))
    end do
	write(log_file,*) 'num_electrons_sys_init=',num_electrons_sys_init
    write(log_file,*)'Number of electrons per box'
    do i=1,N_box
      write(log_file,*)i,N_el_box(i)
    end do

  if(spin_polarized) then
    N_orbitals=N_orbitals_up+N_orbitals_down
    N_total_orbitals=N_orbitals
    allocate(Occupation(N_total_orbitals))
    Occupation=1.d0
  else if(man_set_N_orbitals) then
    N_orbitals=man_set_N_orbitals_num
	N_total_orbitals=N_orbitals+N_empty
	allocate(Occupation(N_total_orbitals))
	Occupation=0.d0
	do i=1,N_orbitals
	   Occupation(i)=2.d0
	end do
	k=0
    do i=1,N_total_atom
       k=k+idint(Charge_pp(atom_index(i)))
    end do
	write(log_file,*) "  total charge from atoms=",k
	write(log_file,*) "  total charge from electrons=",N_orbitals*2
  else
    k=0
    do i=1,N_total_atom
       k=k+idint(Charge_pp(atom_index(i)))
    end do
    if((-1)**k.eq.1) then
       N_orbitals=k/2
       N_total_orbitals=N_orbitals+N_empty
       allocate(Occupation(N_total_orbitals))
       Occupation=0.d0
       do i=1,N_orbitals
          Occupation(i)=2.d0
       end do
       if ((run_type/=60).and.(excitation_jump>1)) then
         Occupation(N_orbitals)=Occupation(N_orbitals)-1.0d0
         Occupation(N_orbitals+excitation_jump)=1.0d0
         N_orbitals=N_orbitals+1
       endif
    else
       N_orbitals=k/2+1
       N_total_orbitals=N_orbitals+N_empty
       allocate(Occupation(N_total_orbitals))
       Occupation=0.d0
       do i=1,N_orbitals-1
          Occupation(i)=2.d0
       end do
       Occupation(N_orbitals)=1.d0
       if ((run_type/=60).and.(excitation_jump>1)) then
         Occupation(N_orbitals)=Occupation(N_orbitals)-1.0d0
         Occupation(N_orbitals+excitation_jump)=1.0d0
       endif
    endif
  endif
  if(spin_polarized) then
    write(log_file,'(a,i5)') 'N_orbitals_up=',N_orbitals_up
    write(log_file,'(a,i5)') 'N_orbitals_down=',N_orbitals_down    
  else
    write(log_file,'(a,i5)') 'N_orbitals=',N_orbitals
    write(log_file,'(a,i5)') 'N_empty=',N_empty
    write(log_file,'(a,i5)') 'N_total_orbitals=',N_total_orbitals
  endif
  
  ! cody   control number of electrons in HOMO
  if (set_occupation_HOMO) then
    if (spin_polarized) then
	   Occupation(N_total_orbitals)=set_homo_occ_amount
	   	write(log_file,*) 'NOTE: set HOMO occupation to ',set_homo_occ_amount,' in spin_polarized mode'	   
	else
	   Occupation(N_orbitals)=set_homo_occ_amount
	   	write(log_file,*) 'NOTE: set HOMO occupation to ',set_homo_occ_amount
		do i=1,N_orbitals
		  write(log_file,*) i,Occupation(i)
		end do
	end if

	totalnumelec=sum(Occupation)
	write(log_file,*) ' Total number of electrons at initalization = ',totalnumelec
	
  end if
  ! cody   control number of electrons in HOMOm1
  if (set_occupation_HOMOm1) then
    if (spin_polarized) then
	   Occupation(N_total_orbitals-1)=set_homom1_occ_amount
	   	write(log_file,*) 'NOTE: set HOMO-1 occupation to ',set_homom1_occ_amount,' in spin_polarized mode'	   
	else
	   Occupation(N_orbitals-1)=set_homom1_occ_amount
	   	write(log_file,*) 'NOTE: set HOMO-1 occupation to ',set_homom1_occ_amount
		do i=1,N_orbitals
		  write(log_file,*) i,Occupation(i)
		end do
	end if

	totalnumelec=sum(Occupation)
	write(log_file,*) ' Total number of electrons at initalization = ',totalnumelec
  end if  
  
  allocate(Sp_Energy(N_total_orbitals))
end subroutine init_orb

subroutine Nonlocal_pseudo_potential(phi,Vphi)
implicit none
real*8 :: phi(N_Lattice_points),Vphi(N_Lattice_points)

  if(nl_pp_mode==1) then
    call Nonlocal_pseudo_potential_new(phi,Vphi)
  else if(nl_pp_mode==2) then
    call Nonlocal_pseudo_potential_old(phi,Vphi)
  else
    write(log_file,*) "unrecognized nl_pp_mode",nl_pp_mode
	stop
  end if
  
end subroutine Nonlocal_pseudo_potential

subroutine Nonlocal_pseudo_potential_new(phi,Vphi)
!This subroutine evaluates the action of the nonlocal 
!pseudopotential on a real-valued orbital phi. The result
!is returned in Vphi
real*8     :: phi(N_Lattice_points),Vphi(N_Lattice_points)
!Local variables
integer    :: j,it,grid,lm,atom
real*8     :: r1,r2,r3,kr,wi1,wi2,wr1,wr2
real*8     :: uV_Psi((L_max+1)**2)
real*8     :: f((L_max+1)**2)
real*8     :: rtemp

!$omp parallel do default(shared) private (j)
do j=1,N_Lattice_points
  Vphi(j)=0.d0
enddo
!$omp end parallel do
nl_pp_just_created=.false.

do atom=1,N_total_atom
  it=atom_index(atom)
  if(z_atom(it).ne.0) then
    uV_Psi=0.d0
    !$omp parallel do default(shared) &
    !$omp private (j, grid, lm) &
    !$omp reduction(+: uV_Psi)
    do j=1,num_ps_points(atom)
      grid=ps_grid(j,atom)
      do lm=1,(Max_L_pp(it)+1)**2
        if(abs(uVu(lm,it)).gt.pp_uVu_epsilon) then
          uV_Psi(lm)=uV_Psi(lm)+uV(lm,j,atom)*phi(grid)
        endif
      enddo     
    enddo
    !$omp end parallel do

    do lm=1,(Max_L_pp(it)+1)**2
      if(abs(uVu(lm,it)).gt.pp_uVu_epsilon) f(lm)=Grid_Volume/uVu(lm,it)
    enddo

    !This loop cannot be omp-parallelized as the value of index variable grid might be repeated    
    do j=1,num_ps_points(atom)
      grid=ps_grid(j,atom)
      rtemp=0.0d0
      !Summation over the points inside the supercell
      do lm=1,(Max_L_pp(it)+1)**2
        if(abs(uVu(lm,it)).gt.pp_uVu_epsilon) rtemp=rtemp+uV(lm,j,atom)*f(lm)*uV_Psi(lm)
      enddo
      Vphi(grid)=Vphi(grid)+rtemp
    enddo
  endif
enddo
end subroutine Nonlocal_pseudo_potential_new

subroutine Nonlocal_pseudo_potential_old(phi,Vphi)
!This subroutine evaluates the action of the nonlocal 
!pseudopotential on a real-valued orbital phi. The result
!is returned in Vphi
real*8     :: phi(N_Lattice_points),Vphi(N_Lattice_points)
!Local variables
integer    :: j,it,grid,lm,atom,i
real*8     :: r1,r2,r3,kr,wi1,wi2,wr1,wr2
real*8     :: uV_Psi
real*8     :: rtemp,f

!$omp parallel do default(shared) private (j)
do j=1,N_Lattice_points
  Vphi(j)=0.d0
enddo
!$omp end parallel do
nl_pp_just_created=.false.

do i=1,N_nl
    uV_Psi=0.d0
    atom=nl_ind(i)
    it=atom_index(atom)
    !$omp parallel do default(shared) &
    !$omp private (j, grid, lm) &
    !$omp reduction(+: uV_Psi)
    do j=1,num_ps_points(atom)
      grid=ps_grid(j,atom)
      uv_Psi=uv_Psi+uv_nl(j,i)*Phi(grid)
    end do    
    !$omp end parallel do
    f=Grid_Volume*s_uVu_nl(i)*uv_Psi
    !This loop cannot be omp-parallelized as the value of index variable grid might be repeated    
    do j=1,num_ps_points(atom)
      grid=ps_grid(j,atom)
      Vphi(grid)=Vphi(grid)+uV_nl(j,i)*f
    enddo
enddo
end subroutine Nonlocal_pseudo_potential_old

subroutine Nonlocal_pseudo_potential_c(phi,Vphi)
implicit none
complex*16 :: phi(N_Lattice_points),Vphi(N_Lattice_points)

  if(nl_pp_mode==1) then
    call Nonlocal_pseudo_potential_c_new(phi,Vphi)
  else if(nl_pp_mode==2) then
    call Nonlocal_pseudo_potential_c_old(phi,Vphi)
  else
    write(log_file,*) "unrecognized nl_pp_mode",nl_pp_mode
	stop
  end if
  
end subroutine Nonlocal_pseudo_potential_c


subroutine Nonlocal_pseudo_potential_c_new(phi,Vphi)
!This subroutine evaluates the action of the nonlocal 
!pseudopotential on a complex-valued orbital phi. The result
!is returned in Vphi
complex*16 :: phi(N_Lattice_points),Vphi(N_Lattice_points)
!Local variables
integer    :: j,it,grid,lm,atom
real*8     :: r1,r2,r3,kr,wi1,wi2,wr1,wr2
complex*16 :: uV_Psi((L_max+1)**2) ! L_max=4 max expected angular momentum component in the PP
real*8     :: f((L_max+1)**2)
complex*16 :: ctemp

!$omp parallel do default(shared) private (j)
do j=1,N_Lattice_points
  Vphi(j)=(0.d0,0.d0)
enddo
!$omp end parallel do
nl_pp_just_created=.false.

do atom=1,N_total_atom
  it=atom_index(atom)
  if(z_atom(it).ne.0) then
    uV_Psi=(0.d0,0.d0)
    !$omp parallel do default(shared) &
    !$omp private (j, grid, lm) &
    !$omp reduction(+: uV_Psi)
    do j=1,num_ps_points(atom)
      grid=ps_grid(j,atom)
      do lm=1,(Max_L_pp(it)+1)**2
        if(abs(uVu(lm,it)).gt.pp_uVu_epsilon) then
          uV_Psi(lm)=uV_Psi(lm)+uV(lm,j,atom)*phi(grid)
        endif
      enddo
    enddo
    !$omp end parallel do

    do lm=1,(Max_L_pp(it)+1)**2
      if(abs(uVu(lm,it)).gt.pp_uVu_epsilon) f(lm)=Grid_Volume/uVu(lm,it)
    enddo

    !This loop cannot be omp-parallelized as the value of index variable grid might be repeated
    do j=1,num_ps_points(atom)
      grid=ps_grid(j,atom)
      ctemp=(0.d0,0.d0)
      !Summation over the points inside the supercell
      do lm=1,(Max_L_pp(it)+1)**2
        if(abs(uVu(lm,it)).gt.pp_uVu_epsilon) ctemp=ctemp+uV(lm,j,atom)*f(lm)*uV_Psi(lm)
      enddo
      Vphi(grid)=Vphi(grid)+ctemp
    enddo
  endif
enddo
end subroutine Nonlocal_pseudo_potential_c_new

subroutine Nonlocal_pseudo_potential_c_old(phi,Vphi)
!This subroutine evaluates the action of the nonlocal 
!pseudopotential on a complex-valued orbital phi. The result
!is returned in Vphi
complex*16 :: phi(N_Lattice_points),Vphi(N_Lattice_points)
!Local variables
integer    :: i,j,it,grid,lm,atom
real*8     :: r1,r2,r3,kr,wi1,wi2,wr1,wr2
complex*16 :: uV_Psi  
complex*16 :: ctemp,f

!$omp parallel do default(shared) private (j)
do j=1,N_Lattice_points
  Vphi(j)=(0.d0,0.d0)
enddo
!$omp end parallel do
nl_pp_just_created=.false.

do i=1,N_nl
  atom=nl_ind(i)
  it=atom_index(atom)
  uV_Psi=(0.d0,0.d0)
  !$omp parallel do default(shared) &
  !$omp private (j, grid, lm) &
  !$omp reduction(+: uV_Psi)
  do j=1,num_ps_points(atom)
    grid=ps_grid(j,atom)
    uv_Psi=uv_Psi+uv_nl(j,i)*Phi(grid)
  end do
  !$omp end parallel do
  f=Grid_Volume*s_uVu_nl(i)*uv_Psi
!This loop cannot be omp-parallelized as the value of index variable grid might be repeated
  do j=1,num_ps_points(atom)
    grid=ps_grid(j,atom)
    Vphi(grid)=Vphi(grid)+uV_nl(j,i)*f
  enddo 
enddo
end subroutine Nonlocal_pseudo_potential_c_old

subroutine ps_sphere(atom,num,psp)
! find the ps sphere points
  implicit none
  integer          :: atom,num,psp(max_ps_points)

  integer          :: i1,i2,i3,j1,j2,j3,k1,k2,k3,n1,n2,n3,i,a
  double precision :: x(3),r
  num=0
  i1=idint((Position(1,atom)-xr1(1))/grid_step(1))
  i2=idint((Position(2,atom)-xr2(1))/grid_step(2))
  i3=idint((Position(3,atom)-xr3(1))/grid_step(3))
! try to guess the dimension of a cube embracing the ps sphere
  j1=idint(Core_radius(atom_index(atom))/grid_step(1))+5
  j2=idint(Core_radius(atom_index(atom))/grid_step(2))+5
  j3=idint(Core_radius(atom_index(atom))/grid_step(3))+5
  do k1=-j1,j1
    n1=i1+k1
    if ((n1 < 1).OR.(n1>N_Lattice(1))) then
      cycle  ! Skips the rest of this iteration
    end if
    do k2=-j2,j2
	  n2=i2+k2
	  if ((n2 < 1).OR.(n2>N_Lattice(2))) then
	    cycle  ! Skips the rest of this iteration
	  end if
      do k3=-j3,j3
	     n3=i3+k3  
	     if ((n3 < 1).OR.(n3>N_Lattice(3))) then
	       cycle  ! Skips the rest of this iteration
	     end if  
         i=Lattice_inv_xyz(n1,n2,n3)
         x(:)=Grid_Point(:,i)-Position(:,atom)
         r=sqrt(x(1)**2+x(2)**2+x(3)**2)
         !if(r.lt.Core_radius(atom_index(atom))) then
		 if(r.lt.Core_radius(atom_index(atom))+(nr_PS+1)/2*maxval(grid_step)) then
           num=num+1
           psp(num)=i
         endif
       end do
     end do
   end do
   
end subroutine ps_sphere

subroutine create_pseudo_potential
implicit none

  if(nl_pp_mode==1) then
    call create_pseudo_potential_new
  else if(nl_pp_mode==2) then
    call create_pseudo_potential_old2
  else
    write(log_file,*) "unrecognized nl_pp_mode",nl_pp_mode
	stop
  end if
  
end subroutine create_pseudo_potential

  subroutine create_pseudo_potential_new
    implicit none

    integer                             :: atom,num,grid,i1,i2,i3,nu,&
         &                                       it,L,j,lm,Max_LM_pp,intr,in(3),i
    real*8                              :: r1,r2,r3,r,url,uVrl,rr,&
         &                                       ratio1,ratio2,y,su,x(3)
    logical                             :: firstcall
    integer                             :: memrq
    integer,allocatable                 :: psp(:),psp0(:,:)
    real*4 :: t1,t2
    

    if (allocated(ps_grid)) then
      firstcall=.false.
    else
      firstcall=.true.
    endif

    if (firstcall) then
      Max_LM_pp=(maxval(Max_L_pp)+1)**2
      !max_ps_points is an estimate of the max number of grid points
      !within the core radius of the PP + some more
      max_ps_points=(4.0d0/3.0d0)*pi*r_max_pp**3/(grid_step(1)*grid_step(2)*grid_step(3)) + &
                    1.0d0*pi*r_max_pp**2/(grid_step(1)*grid_step(2)*grid_step(3)/maxval(grid_step))
                    !The 0.3*pi*... empirical term is there just for safety reason
      write(log_file,*)'max_ps_points=',max_ps_points
      allocate(num_ps_points(N_total_atom))
      allocate(ps_grid(max_ps_points,N_total_atom))
	  uV_size=Max_LM_pp*max_ps_points*N_total_atom
      allocate( uV(Max_LM_pp,max_ps_points,N_total_atom),uVu(Max_LM_pp,N_total_atom),u(max_ps_points,Max_LM_pp))
    endif

    call cpu_time(t1)
    allocate(psp(max_ps_points))
    do atom=1,N_total_atom
       if(z_atom(atom_index(atom)).ne.0) then
         call ps_sphere(atom,num,psp)
          if (firstcall) write(pseudopotential_log_file,*)'number of ps points',atom,num
          if(num.gt.max_ps_points) then
             write(log_file,*)
		         write(log_file,*)'[ERROR] in create_local_pseudopotential: number of points exceeds max_ps_points'
             write(log_file,*)"max_ps_points=",max_ps_points,", num=",num
             stop
          endif
          num_ps_points(atom)=num
          ps_grid(:,atom)=psp(:)
       endif
    end do
    deallocate(psp)
    call cpu_time(t2)
    if (save_timings.AND.MPI_master) write(timing_file,*)"create_pseudo_potential part1 ",t2-t1

      
!    call cpu_time(t1)
!    do atom=1,N_total_atom
!       if(z_atom(atom_index(atom)).ne.0) then
!         
!         num=0
!          do i=1,N_Lattice_points
!             x(:)=Grid_Point(:,i)-Position(:,atom)
!             r=sqrt(x(1)**2+x(2)**2+x(3)**2)
!             if(r.lt.Core_radius(atom_index(atom))) then
!                num=num+1
!                ps_grid(num,atom)=i
!             endif
!          end do
!          num_ps_points(atom)=num
!          if (firstcall) write(pseudopotential_log_file,*)'number of ps points',atom,num
!          if(num.gt.max_ps_points) then
!             write(log_file,*)
!		         write(log_file,*)'[ERROR] in create_local_pseudopotential: number of points exceeds max_ps_points'
!             write(log_file,*)"max_ps_points=",max_ps_points,", num=",num
!             stop
!          endif
!       endif
!    end do
!    call cpu_time(t2)
!    write(6,*)'?1',t2-t1
!    call cpu_time(t1)

    Max_LM_pp=(maxval(Max_L_pp)+1)**2

    Atoms : do atom=1,N_total_atom
       it=atom_index(atom)
       if(z_atom(it).ne.0) then
          do L=0,Max_L_pp(it)
             do j=1,num_ps_points(atom)
                x(:)=Grid_Point(:,ps_grid(j,atom))-Position(:,atom)
                r=sqrt(x(1)**2+x(2)**2+x(3)**2)+1.d-50
                intr=int(r/step_pp(it))
                ratio1=(r/step_pp(it)-intr) ; ratio2=1.d0-ratio1
                !url =ratio1*psi_pp(intr+1,L,it)+ratio2*psi_pp(intr,L,it)
                uVrl=ratio1*vnl_pp(intr+1,L,it)+ratio2*vnl_pp(intr,L,it)
!                do lm=L**2+1,(L+1)**2
!				   ! old y=ylm(x(1),x(2),x(3),lm)
!                   y=ylm(x(1),x(2),x(3),lm)/r**l
!                   u(j,lm)=url*y
!                   uV(lm,j,atom)=uVrl*y
!                end do
                call calc_ylm( x(1)/r ,x(2)/r,x(3)/r,r,l,y_lm)         
                do lm=L**2+1,(L+1)**2
                  uV(lm,j,atom)=uVrl*y_lm(0,lm-l**2)
                end do
				
             end do
          end do
       endif
    end do Atoms
    call cpu_time(t2)
	if (save_timings.AND.MPI_master) write(timing_file,*)"create_pseudo_potential part2 ",t2-t1
    call cpu_time(t1)
    if (firstcall) then
      do it=1,N_species
         do L=0,Max_L_pp(it)
            su=0.d0
            do i=1,N_pp_radial_points(it)   !do i=1,N_points_max
               rr=i*step_pp(it)
               ! old su=su+psi_pp(i,l,it)*vnl_pp(i,l,it)*rr**(2*l+2)*step_pp(it)*4.d0*pi/(2.d0*l+1)
               su=su+psi_pp(i,l,it)*vnl_pp(i,l,it)*rr**2*step_pp(it)*4.d0*pi/(2.d0*l+1)
            end do
            write(pseudopotential_log_file,*)'check',it,L,su
            do lm=L**2+1,(L+1)**2
               uvu(lm,it)=su
            end do
         end do
      end do
    endif
	
    nl_pp_just_created=.true.

  end subroutine create_pseudo_potential_new



  subroutine create_pseudo_potential_old2
    implicit none

    integer                             :: atom,num,grid,i1,i2,i3,&
         &                                       it,L,j,lm,Max_LM_pp,intr,in(3),i
    real*8                              :: r1,r2,r3,r,url,uVrl,rr,&
         &                                       ratio1,ratio2,y,su,x(3)
    logical                             :: firstcall
    integer                             :: memrq
    integer,allocatable                 :: psp(:),psp0(:,:)

    
    if (allocated(ps_grid)) then
      firstcall=.false.
    else
      firstcall=.true.
    endif

    if (firstcall) then
	  write(pseudopotential_log_file,*)'r_max_pp',r_max_pp
      Max_LM_pp=(maxval(Max_L_pp)+1)**2
      !max_ps_points is an estimate of the max number of grid points
      !within the core radius of the PP + some more
!vk
      max_ps_points=0
      do atom=1,N_total_atom
        if(z_atom(atom_index(atom)).ne.0) then
          num=0
          do i=1,N_Lattice_points
            x(:)=Grid_Point(:,i)-Position(:,atom)
            r=sqrt(x(1)**2+x(2)**2+x(3)**2)
! we need to extend the grid beyond the pp radius to include the interpolating functions
            if(r.lt.r_max_pp+(nr_PS+1)/2*maxval(grid_step)) num=num+1
          end do
          if(num.gt.max_ps_points) max_ps_points=num
        endif
      end do
	  write(log_file,*)'max_ps_points w/o added =',max_ps_points
      max_ps_points=max_ps_points+100
    
!      max_ps_points=(4.0d0/3.0d0)*pi*r_max_pp**3/(grid_step(1)*grid_step(2)*grid_step(3)) + &
!                    1.0d0*pi*r_max_pp**2/(grid_step(1)*grid_step(2)*grid_step(3)/maxval(grid_step))
!                    !The 0.3*pi*... empirical term is there just for safety reason
      write(log_file,*)'max_ps_points=',max_ps_points
      allocate(num_ps_points(N_total_atom))
      allocate(ps_grid(max_ps_points,N_total_atom))
      allocate( uV(Max_LM_pp,max_ps_points,N_total_atom),uVu(Max_LM_pp,N_total_atom),u(max_ps_points,Max_LM_pp))
      memrq = Max_LM_pp*Max_ps_points*N_total_atom + Max_LM_pp*(N_total_atom+max_ps_points)
    endif

! set the ps_grid
    allocate(psp(max_ps_points))
    do atom=1,N_total_atom
       if(z_atom(atom_index(atom)).ne.0) then
         call ps_sphere(atom,num,psp)
          if (firstcall) write(pseudopotential_log_file,*)'number of ps points',atom,num
          if(num.gt.max_ps_points) then
             write(log_file,*)
		         write(log_file,*)'[ERROR] in create_local_pseudopotential: number of points exceeds max_ps_points'
             write(log_file,*)"max_ps_points=",max_ps_points,", num=",num
             stop
          endif
          num_ps_points(atom)=num
          ps_grid(:,atom)=psp(:)
       endif
    end do
    deallocate(psp)

    Max_LM_pp=(maxval(Max_L_pp)+1)**2

    Atoms : do atom=1,N_total_atom
       it=atom_index(atom)
       if(z_atom(it).ne.0) then
          do L=0,Max_L_pp(it)
             do j=1,num_ps_points(atom)
                x(:)=Grid_Point(:,ps_grid(j,atom))-Position(:,atom)
                r=sqrt(x(1)**2+x(2)**2+x(3)**2)+1.d-50
                intr=int(r/step_pp(it))
                ratio1=(r/step_pp(it)-intr) ; ratio2=1.d0-ratio1
                !url =ratio1*psi_pp(intr+1,L,it)+ratio2*psi_pp(intr,L,it)
                uVrl=ratio1*vnl_pp(intr+1,L,it)+ratio2*vnl_pp(intr,L,it)
!                do lm=L**2+1,(L+1)**2
!				   ! old y=ylm(x(1),x(2),x(3),lm)
!                   y=ylm(x(1),x(2),x(3),lm)/r**l
!                   u(j,lm)=url*y
!                   uV(lm,j,atom)=uVrl*y
!                end do
				call calc_ylm( x(1)/r ,x(2)/r,x(3)/r,r,l,y_lm)         
                do lm=L**2+1,(L+1)**2
				   uV(lm,j,atom)=uVrl*y_lm(0,lm-l**2)
                end do
				
             end do
          end do
       endif
    end do Atoms

    if (firstcall) then
      do it=1,N_species
         do L=0,Max_L_pp(it)
            su=0.d0
            do i=1,N_pp_radial_points(it)   !do i=1,N_points_max
               rr=i*step_pp(it)
               ! old su=su+psi_pp(i,l,it)*vnl_pp(i,l,it)*rr**(2*l+2)*step_pp(it)*4.d0*pi/(2.d0*l+1)
               su=su+psi_pp(i,l,it)*vnl_pp(i,l,it)*rr**2*step_pp(it)*4.d0*pi/(2.d0*l+1)
            end do
            write(pseudopotential_log_file,*)'check',it,L,su
            do lm=L**2+1,(L+1)**2
               uvu(lm,it)=su
            end do
         end do
      end do
!vk
      allocate(nl_ind(Max_LM_pp*N_total_atom))
      allocate(nl_tab(Max_LM_pp,N_total_atom))     
      N_nl=0
      do atom=1,N_total_atom
        it=atom_index(atom)
        do L=0,Max_L_pp(it)
          do lm=L**2+1,(L+1)**2
            if(abs(uVu(lm,it)).gt.1d-5) then
              N_nl=N_nl+1
              nl_ind(N_nl)=atom
              nl_tab(lm,atom)=N_nl
            endif
          end do
        end do
      end do

      allocate(uV_nl(max_ps_points,N_nl),s_uVu_nl(N_nl))
	  write(*,*) "PP",MPI_proc_rank,max_ps_points,N_nl
      
    endif


    call nonlocal_setup
    
    nl_pp_just_created=.true.
	
    if (firstcall .AND. MPI_master) then
	  write(pseudopotential_log_file,*) N_nl
      do i=1,N_nl
	    atom=nl_ind(i)
        write(pseudopotential_log_file,'(a,3i5)') "N_nl=",i,nl_ind(i),atom_index(atom)
        do j=1,num_ps_points(atom)
          write(pseudopotential_log_file,'(i5,i10,ES16.8e3)') j,ps_grid(j,atom),uv_nl(j,i)
        end do
	  end do
	end if

  end subroutine create_pseudo_potential_old2


  !This is the old version of local_pseudo_potential
  SUBROUTINE local_pseudo_potential
    integer :: atom,k,i,g,it,L,grid,intr
    real*8  :: r(3),r2,ratio1,ratio2,invst

    !$omp parallel workshare
    V_l_pp=VH_BG
    !$omp end parallel workshare
    do atom=1,N_total_atom
      it=atom_index(atom)
      if(z_atom(it).ne.0) then
        L=L_ref(it)
        invst=1/step_pp(it)
        !$omp parallel do &
        !$omp default(shared) &
        !$omp private (i, r, r2, intr, ratio1, ratio2)
        do i=1,N_Lattice_points
          r(:)=Grid_Point(:,i)-Position(:,atom)
          r2=sqrt(r(1)**2+r(2)**2+r(3)**2)+1.d-50
          intr=int(r2*invst)
          ratio1=(r2*invst-intr) ; ratio2=1.d0-ratio1
          if(intr+1.gt.N_points_max) then
            V_l_pp(i)=V_l_pp(i)-Charge_pp(atom)*E2/r2
		  else
            V_l_pp(i)=V_l_pp(i)+ratio1*v_pp(intr+1,L,it)+ratio2*v_pp(intr,L,it)
		  end if
        enddo
        !$omp end parallel do
      endif
    enddo
    ! cody add_projectile_to_gs
    if (add_projectile_to_gs) then 
	   projectile_x=projectile_x0
	   projectile_y=projectile_y0
	   projectile_z=projectile_z0
	   call add_soft_coulomb_potential(V_l_pp,projectile_x0, &
	   projectile_y0,projectile_z0,projectile_charge,projectile_potential_soft_param)
	   write(log_file,*) ' Add projectile potential to the ground state'
	   write(log_file,*) 'Projectile parameters: ',projectile_x,',',projectile_y,',',projectile_z,',',projectile_charge
	endif
  END SUBROUTINE local_pseudo_potential

subroutine add_soft_coulomb_potential(matr,x_pcinsert,y_pcinsert,z_pcinsert,insert_charge,insert_potential_soft_param)
real*8  :: matr(N_lattice_points)
integer :: i
real*8  :: x,y,z,ff,insert_charge,insert_potential_soft_param,x_pcinsert,y_pcinsert,z_pcinsert
ff=E2*insert_charge
!$omp parallel do &
!$omp default(shared) &
!$omp private (i, x, y, z)
do i=1,N_lattice_points
  x=Grid_Point(1,i)-x_pcinsert
  y=Grid_Point(2,i)-y_pcinsert
  z=Grid_Point(3,i)-z_pcinsert
  matr(i)=matr(i)-ff/sqrt(x**2+y**2+z**2+insert_potential_soft_param**2)
enddo
!$omp end parallel do
end subroutine add_soft_coulomb_potential
  
  SUBROUTINE background
    integer :: j,i1,i2,i3,k1,k2,k3,i
    real*8  :: x,y,z,r,r2,xx,px0,py0,pz0,ww,rbg

    Rho_bg=0.d0
    VH_bg=0.d0
    rbg=cutoff_bg_density**2
    do i=1,N_lattice_points
       x=grid_point(1,i)
       y=grid_point(2,i)
       z=grid_point(3,i)
       do j=1,N_total_atom
          px0=Position(1,j); py0=Position(2,j); pz0=Position(3,j)
          xx=(x-px0)**2+(y-py0)**2+(z-pz0)**2
!          if(xx<rbg) then
            Rho_bg(i)=Rho_bg(i)+(bg_beta/pi)**1.5d0*exp(-bg_beta*xx)*charge_pp(atom_index(j))
            r=sqrt(xx)+1.d-16
            VH_bg(i)=VH_bg(i)+derf(sqrt(bg_beta)*r)/r*E2*charge_pp(atom_index(j))
!          endif
       enddo
    enddo
  END SUBROUTINE background

subroutine nonlocal_setup
    implicit none

    integer                             :: atom,num,grid,it,L,j,lm,intr,i,i1,i2,i3,k1,k2,k3,k,i_x,i_y,i_z
    real*8                              :: r1,r2,r3,r,url,uVrl,rr,ratio1,ratio2,y,x(3)
    real*8                              :: y_lm(0:3,7),uvrl1,d_uvrl,w,p_a(3),p_g(3)
    integer,parameter                   :: nx=9,ny=9,nz=9,nmesh=nx*ny*nz
    double precision                    :: fmesh(3,nmesh),fhx,fhy,fhz,wx,wy,wz,u,dxu,dyu,dzu,fv,wmesh(nmesh)
    double precision, allocatable       :: uint(:,:,:),dxuint(:,:,:),dyuint(:,:,:),dzuint(:,:,:)
    integer,allocatable                 :: ps_grid_member(:)
    double precision                    :: li(nr_PS**3)
    double precision                    :: lx(nr_PS),ly(nr_PS),lz(nr_PS)
    double precision                    :: xr(nr_PS),yr(nr_PS),zr(nr_PS)

!   setting up a fine mest for integration in a cube around the grid point
!   the weights takes care the double counting in the neighboring cells

    fhx=grid_step(1)/dfloat(nx-1)
    fhy=grid_step(2)/dfloat(ny-1)
    fhz=grid_step(3)/dfloat(nz-1)
    fv=fhx*fhy*fhz/Grid_Volume
    i=0
    do i3=0,nz-1
      do i2=0,ny-1
        do i1=0,nx-1
          i=i+1
          wx=1.d0
          wy=1.d0
          wz=1.d0
          if(i1==0.or.i1==nx-1) wx=0.5d0
          if(i2==0.or.i2==ny-1) wy=0.5d0
          if(i3==0.or.i3==nz-1) wz=0.5d0
          wmesh(i)=wx*wy*wz
          fmesh(1,i)=i1*fhx-0.5d0*grid_step(1)
          fmesh(2,i)=i2*fhy-0.5d0*grid_step(2)
          fmesh(3,i)=i3*fhz-0.5d0*grid_step(3)
        end do
      end do
    end do


    uv_nl=0.d0
    !duv_nl=0.d0
    Atoms : do atom=1,N_total_atom
    it=atom_index(atom)
    do L=0,Max_L_pp(it)      
      allocate(uint(nr_PS**3,num_ps_points(atom),0:(L+1)**2),dxuint(nr_PS**3,num_ps_points(atom),0:(L+1)**2), &
&       dyuint(nr_PS**3,num_ps_points(atom),0:(L+1)**2),dzuint(nr_PS**3,num_ps_points(atom),0:(L+1)**2), &
&       ps_grid_member(N_lattice_points))
      uint=0.d0; dxuint=0.d0; dyuint=0.d0; dzuint=0.d0
      ps_grid_member=0
      do j=1,num_ps_points(atom)
        grid=ps_grid(j,atom)
!   need to keep track of the global grid position of the pp shere points
        ps_grid_member(grid)=j        
!   position relative to the nuclear center
        p_a(:)=Grid_Point(:,grid)-Position(:,atom)
        r=sqrt(p_a(1)**2+p_a(2)**2+p_a(3)**2)+1.d-50
!   a smaller radius is enough, every integral is zero one grid outside the pp sphere
        if(r<r_max_pp+maxval(grid_step)) then
!   lagrange interpolation points around a given grid point
          do i=1,nr_PS
            xr(i)=p_g(1)+grid_step(1)*(i-(nr_PS+1)/2)
            yr(i)=p_g(2)+grid_step(2)*(i-(nr_PS+1)/2)
            zr(i)=p_g(3)+grid_step(3)*(i-(nr_PS+1)/2)
          end do
!
          do k=1,nmesh
! fine mesh around a given grid point
            x(:)=p_g(:)+fmesh(:,k)
! Lagrange interpolants on the fine mesh
            do i=1,nr_PS
              lx(i)=l_basis_func(x(1),i,nr_PS,xr)
              ly(i)=l_basis_func(x(2),i,nr_PS,yr)
              lz(i)=l_basis_func(x(3),i,nr_PS,zr)
            end do
! tensor product of the lagrange interpolants
            i=0
            do i3=1,nr_PS
              do i2=1,nr_PS
                do i1=1,nr_PS
                  i=i+1
                  li(i)=lx(i1)*ly(i2)*lz(i3)*fv
                end do
              end do
            end do
! interpolate the nl pp
            x(:)=p_a(:)+fmesh(:,k)
            r=sqrt(x(1)**2+x(2)**2+x(3)**2)+1.d-50
            intr=int(r/step_pp(it))
            ratio1=(r/step_pp(it)-intr) ; ratio2=1.d0-ratio1
            uVrl=ratio1*vnl_pp(intr+1,L,it)+ratio2*vnl_pp(intr,L,it)          
!         interpolate the derivative of potential
!            d_uVrl=ratio1*d_vnl(intr+1,L,it)+ratio2*d_vnl(intr,L,it)          
            call calc_ylm(x(1)/r,x(2)/r,x(3)/r,r,l,y_lm)          
            do lm=L**2+1,(L+1)**2
              if(abs(uVu(lm,it)).gt.1d-5) then              
                w=1.d0/sqrt(abs(uvu(lm,it)))*wmesh(k)              
!         pseudopotential
                u=uVrl*y_lm(0,lm-l**2)*w
!         derivative of the pseudopotential
!    d/dx [f(r)Y_lm(r)]= df/dr*dr/dx*Y_lm(r)+f(r)*d/dx Y_lm(r)
!                dxu=(d_uVrl*x(1)/r*y_lm(0,lm-l**2)+uVrl*y_lm(1,lm-l**2))*w              
!                dyu=(d_uVrl*x(2)/r*y_lm(0,lm-l**2)+uVrl*y_lm(2,lm-l**2))*w              
!                dzu=(d_uVrl*x(3)/r*y_lm(0,lm-l**2)+uVrl*y_lm(3,lm-l**2))*w              
                uint(:,j,lm)=uint(:,j,lm)+u*li(:)
!                dxuint(:,j,lm)=dxuint(:,j,lm)+dxu*li(:)
!                dyuint(:,j,lm)=dyuint(:,j,lm)+dyu*li(:)
!                dzuint(:,j,lm)=dzuint(:,j,lm)+dzu*li(:)
              endif
            end do  
          end do
        endif       
      end do
      
    
!  resumming to remap onto the pp grid (adding multiple used points)
      do j=1,num_ps_points(atom)
        grid=ps_grid(j,atom)
        k1=lattice(1,grid)+1 ; k2=lattice(2,grid)+1 ; k3=lattice(3,grid)+1
        do lm=L**2+1,(L+1)**2
          if(abs(uVu(lm,it)).gt.1d-5) then              
            s_uvu_nl(nl_tab(lm,atom))=uvu(lm,it)/abs(uvu(lm,it))              
            i=0
            do i3=1,nr_PS
              do i2=1,nr_PS
                do i1=1,nr_PS
                  i=i+1
!vk does this work with grid mapping?
                  i_x=k1+i1-(nr_PS+1)/2
				  i_y=k2+i2-(nr_PS+1)/2
				  i_z=k3+i3-(nr_PS+1)/2
				  if(i_x > N_Lattice(1) .OR. i_x <1) cycle
				  if(i_y > N_Lattice(2) .OR. i_y <1) cycle
				  if(i_z > N_Lattice(3) .OR. i_z <1) cycle
                  num=ps_grid_member(Lattice_inv_xyz(i_x,i_y,i_z))
                  if(num/=0) then
                    uV_nl(num,nl_tab(lm,atom))=uV_nl(num,nl_tab(lm,atom))+uint(i,j,lm)
!                    duV_nl(1,num,nl_tab(lm,atom))=duV_nl(1,num,nl_tab(lm,atom))+dxuint(i,j,lm)
!                    duV_nl(2,num,nl_tab(lm,atom))=duV_nl(2,num,nl_tab(lm,atom))+dyuint(i,j,lm)
!                    duV_nl(3,num,nl_tab(lm,atom))=duV_nl(3,num,nl_tab(lm,atom))+dzuint(i,j,lm)
                  end if                  
                end do                
              end do              
            end do
          endif
        end do
      end do
      deallocate(uint,dxuint,dyuint,dzuint,ps_grid_member)         
    end do      
    end do Atoms
    
          
end subroutine nonlocal_setup

subroutine nonlocal_setup_old
    implicit none

    integer                             :: atom,num,grid,it,L,j,lm,intr,i,i1,i2,i3,k1,k2,k3,k
    real*8                              :: r1,r2,r3,r,url,uVrl,rr,ratio1,ratio2,y,x(3)
    real*8                              :: y_lm(0:3,7),uvrl1,d_uvrl,w,p_a(3),p_g(3)
    integer,parameter                   :: nx=9,ny=9,nz=9,nmesh=nx*ny*nz
    double precision                    :: fmesh(3,nmesh),fhx,fhy,fhz,wx,wy,wz,u,dxu,dyu,dzu,fv,wmesh(nmesh)
    double precision, allocatable       :: uint(:,:,:),dxuint(:,:,:),dyuint(:,:,:),dzuint(:,:,:)
    integer,allocatable                 :: ps_grid_member(:)
    double precision                    :: li(nr_PS**3)
    double precision                    :: lx(nr_PS),ly(nr_PS),lz(nr_PS)
    double precision                    :: xr(nr_PS),yr(nr_PS),zr(nr_PS)

!   setting up a fine mest for integration in a cube around the grid point
!   the weights takes care the double counting in the neighboring cells

    fhx=grid_step(1)/dfloat(nx-1)
    fhy=grid_step(2)/dfloat(ny-1)
    fhz=grid_step(3)/dfloat(nz-1)
    fv=fhx*fhy*fhz/Grid_Volume
    i=0
    do i3=0,nz-1
      do i2=0,ny-1
        do i1=0,nx-1
          i=i+1
          wx=1.d0
          wy=1.d0
          wz=1.d0
          if(i1==0.or.i1==nx-1) wx=0.5d0
          if(i2==0.or.i2==ny-1) wy=0.5d0
          if(i3==0.or.i3==nz-1) wz=0.5d0
          wmesh(i)=wx*wy*wz
          fmesh(1,i)=i1*fhx-0.5d0*grid_step(1)
          fmesh(2,i)=i2*fhy-0.5d0*grid_step(2)
          fmesh(3,i)=i3*fhz-0.5d0*grid_step(3)
        end do
      end do
    end do


    do atom=1,N_total_atom
      num=0
      do i=1,N_Lattice_points    
        x(:)=Grid_Point(:,i)-Position(:,atom)        
        r=sqrt(x(1)**2+x(2)**2+x(3)**2)        
        if(r.lt.Core_radius(atom_index(atom))+(nr_PS+1)/2*maxval(grid_step)) then
          num=num+1
          ps_grid(num,atom)=i          
        endif        
      end do      
      num_ps_points(atom)=num      
      if(num > max_ps_points) then        
        write(6,*)'error in ps_grid'       
        stop
      endif                
    end do


    uv_nl=0.d0
    !duv_nl=0.d0
    Atoms : do atom=1,N_total_atom
    it=atom_index(atom)
    do L=0,Max_L_pp(it)      
      allocate(uint(nr_PS**3,num_ps_points(atom),0:(L+1)**2),dxuint(nr_PS**3,num_ps_points(atom),0:(L+1)**2), &
&       dyuint(nr_PS**3,num_ps_points(atom),0:(L+1)**2),dzuint(nr_PS**3,num_ps_points(atom),0:(L+1)**2), &
&       ps_grid_member(N_lattice_points))
      uint=0.d0; dxuint=0.d0; dyuint=0.d0; dzuint=0.d0
      ps_grid_member=0
      do j=1,num_ps_points(atom)
        grid=ps_grid(j,atom)
!   need to keep track of the global grid position of the pp shere points
        ps_grid_member(grid)=j        
!   position relative to the nuclear center
        p_a(:)=Grid_Point(:,grid)-Position(:,atom)
        r=sqrt(p_a(1)**2+p_a(2)**2+p_a(3)**2)+1.d-50
!   a smaller radius is enough, every integral is zero one grid outside the pp sphere
        if(r<r_max_pp+maxval(grid_step)) then
!   lagrange interpolation points around a given grid point
          do i=1,nr_PS
            xr(i)=p_g(1)+grid_step(1)*(i-(nr_PS+1)/2)
            yr(i)=p_g(2)+grid_step(2)*(i-(nr_PS+1)/2)
            zr(i)=p_g(3)+grid_step(3)*(i-(nr_PS+1)/2)
          end do
!
          do k=1,nmesh
! fine mesh around a given grid point
            x(:)=p_g(:)+fmesh(:,k)
! Lagrange interpolants on the fine mesh
            do i=1,nr_PS
              lx(i)=l_basis_func(x(1),i,nr_PS,xr)
              ly(i)=l_basis_func(x(2),i,nr_PS,yr)
              lz(i)=l_basis_func(x(3),i,nr_PS,zr)
            end do
! tensor product of the lagrange interpolants
            i=0
            do i3=1,nr_PS
              do i2=1,nr_PS
                do i1=1,nr_PS
                  i=i+1
                  li(i)=lx(i1)*ly(i2)*lz(i3)*fv
                end do
              end do
            end do
! interpolate the nl pp
            x(:)=p_a(:)+fmesh(:,k)
            r=sqrt(x(1)**2+x(2)**2+x(3)**2)+1.d-50
            intr=int(r/step_pp(it))
            ratio1=(r/step_pp(it)-intr) ; ratio2=1.d0-ratio1
            uVrl=ratio1*vnl_pp(intr+1,L,it)+ratio2*vnl_pp(intr,L,it)          
!         interpolate the derivative of potential
!            d_uVrl=ratio1*d_vnl(intr+1,L,it)+ratio2*d_vnl(intr,L,it)          
            call calc_ylm(x(1)/r,x(2)/r,x(3)/r,r,l,y_lm)          
            do lm=L**2+1,(L+1)**2
              if(abs(uVu(lm,it)).gt.1d-5) then              
                w=1.d0/sqrt(abs(uvu(lm,it)))*wmesh(k)              
!         pseudopotential
                u=uVrl*y_lm(0,lm-l**2)*w
!         derivative of the pseudopotential
!    d/dx [f(r)Y_lm(r)]= df/dr*dr/dx*Y_lm(r)+f(r)*d/dx Y_lm(r)
!                dxu=(d_uVrl*x(1)/r*y_lm(0,lm-l**2)+uVrl*y_lm(1,lm-l**2))*w              
!                dyu=(d_uVrl*x(2)/r*y_lm(0,lm-l**2)+uVrl*y_lm(2,lm-l**2))*w              
!                dzu=(d_uVrl*x(3)/r*y_lm(0,lm-l**2)+uVrl*y_lm(3,lm-l**2))*w              
                uint(:,j,lm)=uint(:,j,lm)+u*li(:)
!                dxuint(:,j,lm)=dxuint(:,j,lm)+dxu*li(:)
!                dyuint(:,j,lm)=dyuint(:,j,lm)+dyu*li(:)
!                dzuint(:,j,lm)=dzuint(:,j,lm)+dzu*li(:)
              endif
            end do  
          end do
        endif       
      end do
      
    
!  resumming to remap onto the pp grid (adding multiple used points)
      do j=1,num_ps_points(atom)
        grid=ps_grid(j,atom)
        k1=lattice(1,grid)+1 ; k2=lattice(2,grid)+1 ; k3=lattice(3,grid)+1
        do lm=L**2+1,(L+1)**2
          if(abs(uVu(lm,it)).gt.1d-5) then              
            s_uvu_nl(nl_tab(lm,atom))=uvu(lm,it)/abs(uvu(lm,it))              
            i=0
            do i3=1,nr_PS
              do i2=1,nr_PS
                do i1=1,nr_PS
                  i=i+1
!vk does this work with grid mapping?
                  num=ps_grid_member(Lattice_inv_xyz(k1+i1-(nr_PS+1)/2,k2+i2-(nr_PS+1)/2,k3+i3-(nr_PS+1)/2))
                  if(num/=0) then
                    uV_nl(num,nl_tab(lm,atom))=uV_nl(num,nl_tab(lm,atom))+uint(i,j,lm)
!                    duV_nl(1,num,nl_tab(lm,atom))=duV_nl(1,num,nl_tab(lm,atom))+dxuint(i,j,lm)
!                    duV_nl(2,num,nl_tab(lm,atom))=duV_nl(2,num,nl_tab(lm,atom))+dyuint(i,j,lm)
!                    duV_nl(3,num,nl_tab(lm,atom))=duV_nl(3,num,nl_tab(lm,atom))+dzuint(i,j,lm)
                  end if                  
                end do                
              end do              
            end do
          endif
        end do
      end do
      deallocate(uint,dxuint,dyuint,dzuint,ps_grid_member)         
    end do      
    end do Atoms
    
          
end subroutine nonlocal_setup_old

function l_basis_func(x,i,n,xr)
  integer             :: i,n
  real*8              :: x,xr(n)
  real*8              :: tx,l_basis_func,s
  integer             :: k

  s=1.d0
  do k=1,N
    if(k.ne.i) s=s*(x-xr(k))/(xr(i)-xr(k))
  end do
  l_basis_func=s
end function l_basis_func

END MODULE PSEUDOPOTENTIAL


!  notes
!  background sets VH_bg
!  local_pseudo_potential sets V_l_pp
!  create_pseudo_potential sets up nonlocal arrays
!
!
!
!
!