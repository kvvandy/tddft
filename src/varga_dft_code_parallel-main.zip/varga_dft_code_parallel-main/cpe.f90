
subroutine complex_diag(hm,om,n,en,v)
  USE MOD_GLOBAL, only: eigenvalues_file
implicit none

  integer                                     :: n
  complex*16                                  :: hm(n,n),v(n,n),en(n)
  real*8                                      :: om(n,n)

  integer                                     :: ifail,j,i,k,l
  double precision                            :: eps1
  logical                                     :: matv
  double precision,dimension(:,:),allocatable :: ai,ar,bi,br,vi,vr
  double precision,dimension(:),allocatable   :: alfi,alfr,beta,arr
  complex*16,dimension(:),allocatable         :: o
  integer,dimension(:),allocatable            :: iter,indx
  double precision,external                   :: x02ajf
  complex*16                                  :: su


  allocate(ai(n,n),ar(n,n),bi(n,n),br(n,n),vi(n,n),vr(n,n), &
&   alfi(n),alfr(n),beta(n),iter(n),o(n),indx(n),arr(n))

  do j=1,n
    do i=1,n
      ar(i,j)=real(hm(i,j))
      ai(i,j)=imag(hm(i,j))
      br(i,j)=om(i,j)
      bi(i,j)=0.d0
     end do
  end do

  EPS1 = X02AJF()
  MATV = .TRUE.
  IFAIL = 1

  CALL F02GJF(N,AR,N,AI,N,BR,N,BI,N,EPS1,ALFR,ALFI,BETA,MATV,VR,N,VI,N,ITER,IFAIL)

  do i=1,n
    arr(i)=alfr(i)/beta(i)
  end do

  call indexx(n,arr,indx)

  write(eigenvalues_file,*)"complex_diag"
  do j=1,n
    en(j)=cmplx(ALFR(indx(j))/BETA(indx(j)),ALFI(indx(j))/BETA(indx(j)),8)
    write(eigenvalues_file,*)j,en(j)
    do i=1,n
      v(i,j)=cmplx(vr(i,indx(j)),vi(i,indx(j)),8)
     end do
  end do

  do i=1,n
      su=(0.d0,0.d0)
      do k=1,n
        do l=1,n
          su=su+v(k,i)*v(l,i)*om(l,k)
        end do
      end do
     o(i)=su
  end do
  do i=1,n
    v(:,i)=v(:,i)/sqrt(o(i))
  end do


  deallocate(ai,ar,bi,br,vi,vr,alfi,alfr,beta,iter,o)

end subroutine complex_diag



      SUBROUTINE indexx(n,arr,indx)
      INTEGER :: n,indx(n),M,NSTACK
      REAL*8 :: arr(n)
      PARAMETER (M=7,NSTACK=50)
      INTEGER :: i,indxt,ir,itemp,j,jstack,k,l,istack(NSTACK)
      REAL*8 a
      do 11 j=1,n
        indx(j)=j
11    continue
      jstack=0
      l=1
      ir=n
1     if(ir-l.lt.M)then
        do 13 j=l+1,ir
          indxt=indx(j)
          a=arr(indxt)
          do 12 i=j-1,1,-1
            if(arr(indx(i)).le.a)goto 2
            indx(i+1)=indx(i)
12        continue
          i=0
2         indx(i+1)=indxt
13      continue
        if(jstack.eq.0)return
        ir=istack(jstack)
        l=istack(jstack-1)
        jstack=jstack-2
      else
        k=(l+ir)/2
        itemp=indx(k)
        indx(k)=indx(l+1)
        indx(l+1)=itemp
        if(arr(indx(l+1)).gt.arr(indx(ir)))then
          itemp=indx(l+1)
          indx(l+1)=indx(ir)
          indx(ir)=itemp
        endif
        if(arr(indx(l)).gt.arr(indx(ir)))then
          itemp=indx(l)
          indx(l)=indx(ir)
          indx(ir)=itemp
        endif
        if(arr(indx(l+1)).gt.arr(indx(l)))then
          itemp=indx(l+1)
          indx(l+1)=indx(l)
          indx(l)=itemp
        endif
        i=l+1
        j=ir
        indxt=indx(l)
        a=arr(indxt)
3       continue
          i=i+1
        if(arr(indx(i)).lt.a)goto 3
4       continue
          j=j-1
        if(arr(indx(j)).gt.a)goto 4
        if(j.lt.i)goto 5
        itemp=indx(i)
        indx(i)=indx(j)
        indx(j)=itemp
        goto 3
5       indx(l)=indx(j)
        indx(j)=indxt
        jstack=jstack+2
        if(jstack.gt.NSTACK)pause 'NSTACK too small in indexx'
        if(ir-i+1.ge.j-l)then
          istack(jstack)=ir
          istack(jstack-1)=i
          ir=j-1
        else
          istack(jstack)=j-1
          istack(jstack-1)=l
          l=i
        endif
      endif
      goto 1
      END subroutine indexx


