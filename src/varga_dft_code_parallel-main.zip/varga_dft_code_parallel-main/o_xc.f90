module o_xc

contains

      subroutine Exc_Cor(XC_inc,rhom,Vexc,Excc)
      use optics_data
      use parameters, only : Pi,Ry,a_B
      use mod_global

      implicit none
      character(4),intent(in)      :: XC_inc
      real(8),intent(out),optional :: Excc
      real(8),intent(in) :: rhom(:)
      real(8),intent(out)   :: Vexc(:)
      real(8) :: tExc

      select case(XC_inc)
         case('PZ','pz')     ; call Exc_Cor_Pz
         case('VWN','vwn')   ; call Exc_Cor_VWN(rhom,Vexc)
         case('LB94','lb94') ; call Exc_Cor_LB94(rhom,Vexc)
         case default
            write(*,*) "XC name "//XC_inc//" is invalid." ; stop
      end select

      if ( present(Excc) ) Excc=tExc

      contains

!@@@@@@@@@@@ LDA (Perdew-Zunger)

      subroutine Exc_Cor_PZ

      real(8),parameter :: gm=-0.1423d0, b1=1.0529d0, b2=0.3334d0
      real(8),parameter :: AU=0.0311d0 , BU=-0.048d0
      real(8),parameter :: CU=0.002d0  , DU=-0.0116d0
      real(8),allocatable :: trho(:),rs(:),Vx(:),Vc(:),Ex(:),Ec(:)
      real(8) :: Cx
      integer :: i

      allocate( trho(ML),rs(ML),Vx(ML),Vc(ML),Ex(ML),Ec(ML) )


      trho=rhom+1.d-20
      rs=(3.d0/(4*Pi*trho))**(1.d0/3.d0)/a_B

! Exchange

      Cx=3.d0/4.d0*(3.d0/(2*Pi))**(2.d0/3.d0)

      Vx=-4.d0/3.d0*Cx/rs ; Ex=-Cx/rs

! Correlation

      where ( rs > 1.d0 )
         Vc=gm*( 1.d0 + 7.d0/6.d0*b1*sqrt(rs) + 4.d0/3.d0*b2*rs ) &
             /( 1.d0 + b1*sqrt(rs) + b2*rs )**2
         Ec=gm/( 1.d0 + b1*sqrt(rs) + b2*rs )
      elsewhere
         Vc=AU*log(rs) + (BU-AU/3.d0) + 2.d0/3.d0*CU*rs*log(rs) &
             + (2.d0*DU-CU)/3.d0*rs
         Ec=AU*log(rs) + BU + CU*rs*log(rs) + DU*rs
      end where

      Vexc=2*Ry*(Vx+Vc) ; tExc=2*Ry*sum(trho*(Ex+Ec))*Grid_Volume

      deallocate( trho,rs,Vx,Vc,Ex,Ec )

      end subroutine Exc_Cor_PZ

!@@@@@@@@@ Vosko-Wilk-Nusair

      subroutine Exc_Cor_VWN(rhoms,Vexc)

      real(8),intent(out)   :: Vexc(:)
      real(8),intent(in) :: rhoms(:)
      real(8),parameter :: AA=0.0621814d0, d=-0.10498d0
      real(8),parameter :: b=3.72744d0   , c=12.9352d0
      real(8) :: Cx,Q,t1,t2,t3,x
      real(8),allocatable :: trho(:),rs(:),Vx(:),Ex(:),Vc(:),Ec(:)
      integer :: i

      allocate( trho(ML),rs(ML),Vx(ML),Ex(ML),Vc(ML),Ec(ML) )

      trho=rhoms+1.d-20
      rs=(3.d0/(4*Pi*trho))**(1.d0/3.d0)/a_B

! Exchange

      Cx=3.d0/4.d0*(3.d0/(2*Pi))**(2.d0/3.d0)

      Vx=-4.d0/3.d0*Cx/rs ; Ex=-Cx/rs

! Correlation

      Q = (4*c-b**2)**0.5d0

      do i=1,ML

         x  = sqrt( rs(i) )
         t1 =-(2*c+b*x)/(6*(c+x*(b+x))) + log( x**2/(c+x*(b+x)) )
         t2 = Q*x/(3*(b**2+Q**2+4*b*x+4*x**2)) + atan( Q/(b+2*x) )
         t3 = x*(2*c+b*x+d*(b+2*x))/(6*(d-x)*(c+x*(b+x))) &
             + log( (d-x)**2/(c+x*(b+x)) )
         Vc(i) = AA*( t1 + 2*b/Q * t2 &
             - b*d/(d**2+b*d+c) * ( t3 + 2*(b+2*d)/Q * t2 ) )
         Vc(i)=Vc(i)/2.d0

         t1 = log( x**2/(x**2+b*x+c) )
         t2 = atan( Q/(2*x+b) )
         t3 = log( (x-d)**2/(x**2+b*x+c) )
         Ec(i)=AA*(t1+2*b/Q*t2-b*d/(x**2+b*x+c)*(t3+2*(b+2*d)/Q*t2))
         Ec(i)=Ec(i)/2.d0

      end do

      Vexc=2*Ry*(Vx+Vc) ; tExc=2*Ry*sum(trho*(Ex+Ec))*Grid_Volume

      deallocate( trho,rs,Vx,Ex,Vc,Ec )

      end subroutine Exc_Cor_VWN

!@@@@@@@@@@@@@ LB94

      subroutine Exc_Cor_LB94(rhms,Vexcs)

      real(8),intent(out)   :: Vexcs(:)
      real(8),intent(in) :: rhms(:)
      real(8),parameter :: beta=0.05d0
      real(8),allocatable :: trho(:),dnx(:),dny(:),dnz(:)
      real(8),allocatable :: x(:),Vx_GGA(:)
      real(8) :: sum1,sum2,sum3,r,rms
      integer :: i,j,ix,iy,iz


      allocate( trho(ML),dnx(ML),dny(ML),dnz(ML) )

! LDA

      call Exc_Cor_VWN(rhms,Vexcs)

! Leeuwen-Baernds potential (LB94)

      trho = (rhms+1.d-20)*a_B**3
      trho = trho/2.d0

      wphi=0.d0

      do i=1,ML
         wphi(Lattice(1,i),Lattice(2,i),Lattice(3,i))=trho(i)
      end do

! 9-points finite-difference Laplacian

      do i=1,ML
         ix=Lattice(1,i) ; iy=Lattice(2,i) ; iz=Lattice(3,i)
         dnx(i) = ( bN1*( wphi(ix+1,iy,iz) - wphi(ix-1,iy,iz) ) &
                  +bN2*( wphi(ix+2,iy,iz) - wphi(ix-2,iy,iz) ) &
                  +bN3*( wphi(ix+3,iy,iz) - wphi(ix-3,iy,iz) ) &
                  +bN4*( wphi(ix+4,iy,iz) - wphi(ix-4,iy,iz) ) )/Grid_Step(1)*a_B
         dny(i) = ( bN1*( wphi(ix,iy+1,iz) - wphi(ix,iy-1,iz) ) &
                  +bN2*( wphi(ix,iy+2,iz) - wphi(ix,iy-2,iz) ) &
                  +bN3*( wphi(ix,iy+3,iz) - wphi(ix,iy-3,iz) ) &
                  +bN4*( wphi(ix,iy+4,iz) - wphi(ix,iy-4,iz) ) )/Grid_Step(2)*a_B
         dnz(i) = ( bN1*( wphi(ix,iy,iz+1) - wphi(ix,iy,iz-1) ) &
                  +bN2*( wphi(ix,iy,iz+2) - wphi(ix,iy,iz-2) ) &
                  +bN3*( wphi(ix,iy,iz+3) - wphi(ix,iy,iz-3) ) &
                  +bN4*( wphi(ix,iy,iz+4) - wphi(ix,iy,iz-4) ) )/Grid_Step(3)*a_B
      end do

      x=sqrt(dnx**2+dny**2+dnz**2)/trho**(4.d0/3.d0)

      Vx_GGA = -beta*trho**(1.d0/3.d0)*x**2 &
            /( 1.d0+3.d0*beta*x*log(x+sqrt(1+x**2)) )

      Vexcs=Vexcs+2.d0*Ry*Vx_GGA

      deallocate( trho,dnx,dny,dnz,x,Vx_GGA )

      end subroutine Exc_Cor_LB94

      end subroutine Exc_Cor

end module o_xc
