MODULE RADIAL_BASIS
  use parameters
  USE COMMON_LIBRARY
  USE PSEUDOPOTENTIAL
  USE MOD_GLOBAL
  USE HAMILTON
  USE MOD_IO
  use mixing
  use mod_converged
  use sparse
  use sets
  implicit none

!  complex*16,parameter  :: zi=(0.d0,1.d0)
  integer, parameter :: ylm_ngp=20000
  real*8, parameter :: ylm_dx=1.0d0/dble(ylm_ngp)

  ! precompute some parameters for basis_func
  ! maxval(l_max_basis) < 6    must be true...
  real(8), parameter :: bf_c1 = 2.0d0 / pi
  real(8), parameter :: bf_c2 = 3.5449077018110318d0 ! sqrt(4*pi)
  real(8), dimension(7), parameter :: bf_w1 = (/ 1.0d0, &
       0.816496580927726d0, 0.516397779494322d0, 0.276026223736942d0, & 
       0.130120009726471d0, 5.548335857176529d-2, 2.176236369516128d-2 /)
       
  integer :: max_p, npairs, nlvec
  integer, dimension(:),   allocatable :: ind,lc, lbasis, mc, mbasis
  integer, dimension(:,:), allocatable :: n_cell, overlap_atom_index, pair_list
  integer, dimension(:,:), allocatable :: Ind_cell, lvec

  complex(8), dimension(:), allocatable :: psi_a_c
  real*8, dimension(:),   allocatable    :: Psi_a, occ
  real*8, dimension(:,:), allocatable    :: ldisp
  double precision, dimension(:), allocatable :: h_overlap_r,h_overlap_i

  integer, dimension(:), allocatable   :: N_overlap_atom_gridpoint
  type(sparse_matrix) :: overlap_atom_gridpoint1, overlap_atom_gridpoint2

  real*8, dimension(:,:,:), allocatable :: psi_basis_kpt_r, psi_basis_kpt_i
  
  real(8), dimension(:,:), allocatable :: basis_cache
  integer, dimension(:), allocatable :: basis_cache_indx, qpos
  integer, allocatable :: nlvec_i(:,:), nlvec_atom(:),lmj_table(:,:)
  real*8, dimension(:,:,:,:), allocatable :: bf_table
  real*8, allocatable :: plgnr_table(:,:,:),ylm_coeff(:,:),nrm_table(:)

  ! storage for matrix element which do not depend on density
  integer, dimension(:,:), allocatable :: hm1_i
  real*8, dimension(:), allocatable :: hm1_nz, om0_nz

  !*****************************************************************************
  ! npair : number of overlaping atom pairs
  ! lvec  : stores cell displacement integers (1,0,0) means +1 cell in x
  ! nlvec : size of lvec
  ! ldisp : actual displacement vectors
  ! mcell : number of cells
  ! ind
  ! lc
  ! lbasis
  ! mbasis
  ! n_cell
  ! overlap_atom_index : inverse of pair list       (natoms, natoms)
  ! pair_list          : which atoms for each pair, (npairs, 2)
  ! ind_cell
  ! psi_a
  ! occ
  ! h_overlap_r
  ! c_basis
  ! overlap_atom_gridpoint : grid points in overlap for each pair (npair, npts)

CONTAINS


  subroutine init_compressed_ind_basis
    integer :: i,j,k,l,n,m,kmax
    ! ind_basis consists mostly of consecutive numbers
    ! the idea is to save memory and improve speed by only storing
    ! the 1st and last position of each stride
    logical, save :: first_call = .true.

    
    if (first_call) allocate(ind_basis_n(n_total_atom))
    ind_basis_n = 0

    ! find the maximum number of strides
    kmax = 0
    do i=1,n_total_atom
       k = 1
       do j=2,int_points(i)
          if (ind_basis(j-1,i) + 1 /= ind_basis(j,i)) then
             k = k + 1
          end if
       end do
       ind_basis_n(i) = k
       if (k > kmax) kmax = k
    end do

    if (.not. first_call) deallocate(ind_basis_indx)
    allocate(ind_basis_indx(2, kmax+1, n_total_atom))
    ind_basis_indx = 0
    do i=1,n_total_atom
       k = 1
       ind_basis_indx(1, k, i) = ind_basis(1,i)
       do j=2,int_points(i)
          if (ind_basis(j-1,i)+1 /= ind_basis(j,i)) then
             ind_basis_indx(2,k,i)=ind_basis(j-1,i)
             ind_basis_indx(1,k+1,i)=ind_basis(j,i)             
             k = k + 1
          end if
       end do
	   if(int_points(i)>0) then ! cody   fix problem
         ind_basis_indx(2,k,i) = ind_basis(int_points(i),i)
	   end if
    end do

    first_call = .false.

  end subroutine init_compressed_ind_basis

subroutine order_ind_basis
   integer               :: k,i,atom
   real*8,allocatable    :: arr(:)
   integer,allocatable   :: indx(:)

   do atom=1,N_total_atom
     k=int_points(atom)
     allocate(indx(k),arr(k))
      do i=1,k
        arr(i)=ind_basis(i,atom)
      end do
      call indexx(k,arr,indx)
      do i=1,k
        ind_basis(i,atom)=arr(indx(i))
      end do
      deallocate(indx,arr)
   end do
end subroutine order_ind_basis


  subroutine initial_random_wavefunction ! shenglai
  !real(8), allocatable    :: RandR(:), RandI(:)
  integer :: orbital,i
  real(8) :: norm,rnum

!        allocate(RandR(N_lattice_points))
!        allocate(RandI(N_lattice_points))
!        call random_seed()
!            do orbital = 1, N_orbitals+N_empty
!                call random_number(RandR)
!                call random_number(RandI)
!                Psi(:, orbital) = cmplx(RandR, RandI)
!                norm=sum(abs(psi(:,orbital)**2))*grid_volume
!                Psi(:, orbital)=Psi(:, orbital)/sqrt(norm)
!            enddo
!        
!       deallocate(RandR)
!       deallocate(RandI)
    call random_seed()
    do orbital = 1, N_orbitals+N_empty
	  do i=1,N_Lattice_points
	    call random_number(rnum)
		Psi(i,orbital)=rnum
      end do
	  norm=sum(Psi(:,orbital)**2)*grid_volume
	  Psi(:,orbital)=Psi(:,orbital)/sqrt(norm)
    end do
	
    end subroutine initial_random_wavefunction
 
    subroutine set_atom_pairs
    integer :: i,j,it,jt
    real(8), dimension(3) :: p0

    atom_pairs = 0
    do i=1,N_total_atom
       it=atom_index(i)
       p0 = Position(:,i)
       do j=1,N_total_atom
          jt=atom_index(j)
          if (sqrt(sum(p0 - position(:,j))**2) < 1.5*(wf_rad(it)+wf_rad(jt))) then
             atom_pairs(i,j) = 1
          end if
       end do
    end do

  end subroutine set_atom_pairs

  pure function basis_func(x,nu,l)
    ! coefficients and w1 values are now pre computed and stored as parameters
    real*8, intent(in) :: x, nu
    integer, intent(in) :: l
    real*8 :: basis_func
    !local variables
    real*8 :: w2
    w2 = (bf_c1 * nu)**0.75d0 * bf_c2 * bf_w1(l+1) * (sqrt(2.0d0*nu))**dble(l)
    basis_func=exp(-nu*x**2)*w2
  end function basis_func
  
!  function basis_func(x,nu,l)
!    integer :: l
!    real*8  :: x,nu,basis_func,w1,w2
!    w1=dexp(0.5d0*(x2n(l)-df(2*l+1)))
!    w2=(2.d0*nu/pi)**0.75d0*sqrt(4.d0*pi)*w1*(sqrt(2.d0*nu))**l
!    basis_func=exp(-nu*x**2)*w2
!  end function basis_func

  subroutine radial_wave_function
    integer           :: i,j,it,l,js
    real*8            :: wfr,xx,w,wm

    open(radial_basis_file,file=trim(adjustl(radial_basis_filename)))
    do it=1,N_species
       wm=0.d0
       do l=0,l_max_basis(it)
       do j=1,N_ao_l(l,it)
       do i=1000,0,-1
          xx=0.01d0*i
          if(z_atom(it)/=0) then
             wfr=0.d0
             do js=1,Ng
                wfr=wfr+c_exp(js,j,l,it)*basis_func(xx,gauss_p(js),l)*xx**l
             end do
          else
             wfr=basis_func(xx,gauss_p(isg),0)
          endif
          write(radial_basis_file,*)xx,wfr
          if(abs(wfr)>rwf_sm) then
             w=xx
             if(wm<=w) wm=w
          endif
       enddo
       write(radial_basis_file,*)
       enddo
       enddo
       wf_rad(it)=wm
       write(log_file,*)'lcao wavefunction radius',it,wm
    end do
    close(radial_basis_file)
  end subroutine radial_wave_function


  subroutine contraction(a,l1,it1,l2,it2,b)
    ! this should be optimized
    integer :: l1,l2,it1,it2,js,is,k1,k2
    real*8  :: a(Ngm,Ngm),b(Ngm,Ngm),su

    do is=1,N_ao_l(l1,it1)
    do js=1,N_ao_l(l2,it2)
       su=0.d0
       do k2=1,Ng
       do k1=1,Ng
          su=su+a(k1,k2)*c_exp(k1,is,l1,it1)*c_exp(k2,js,l2,it2)
       end do
    end do
    b(is,js)=su
    end do
    end do

  end subroutine contraction

  subroutine num_po
    integer                                      :: i,j,k,ii,orbital,i1,i2,j1,j2
    real*8                                       :: su
    real*4                                       :: t1,t2

    do i=1,N_diag
       i1=basis_atom(1,i)
       i2=basis_atom(2,i)
       !    Phi=0.d0
       H_Phi=0.d0
       do k=1,int_points(i2)
          ii=Ind_basis(k,i2)
          H_Phi(ii)=V_l_pp(ii)*psi_basis_r(k,i)
       end do
       !    call nonlocal_pseudo_potential(...)
       do j=1,i
          j1=basis_atom(1,j)
          j2=basis_atom(2,j)
          if(atom_pairs(i2,j2).eq.1) then
             su=0.d0
             do k=1,int_points(j2)
                ii=Ind_basis(k,j2)
                su=su+H_phi(ii)*psi_basis_r(k,j)
             end do
          endif
       end do
    end do
  end subroutine num_po

subroutine atomic_density_cached   
  integer :: atom,it,j,l,m,k,i,ii,jj
  real*8, allocatable :: psi_basis1(:)   
  
  call init_psi_basis
  allocate(psi_basis1(max_p))
  atomic_density=0.d0
  do atom=1,N_total_atom
     it=atom_index(atom)
     j=0
     do l=0,l_max_basis(it)
        do m=-l,l
           do k=1,N_ao_l(l,it)
              j=j+1
              jj=basis_atom_inv(j,atom)
              call get_psi_basis(jj,psi_basis1)
              do i=1,int_points(atom)
                 ii=Ind_basis(i,atom)
                 atomic_density(ii)=atomic_density(ii)+atom_occ(k,l,it)*psi_basis1(i)**2
              end do
           end do
        end do
     end do
  end do
  deallocate(psi_basis1)
  
end subroutine atomic_density_cached

subroutine atomic_density_complex
  integer :: atom,it,j,l,m,k,i,ii,jj
  atomic_density=0.d0
  do atom=1,N_total_atom
     it=atom_index(atom)
     j=0
     do l=0,l_max_basis(it)
        do m=-l,l
           do k=1,N_ao_l(l,it)
              j=j+1
              jj=basis_atom_inv(j,atom)
              do i=1,int_points(atom)
                 ii=Ind_basis(i,atom)
                 atomic_density(ii)=atomic_density(ii)+atom_occ(k,l,it) & 
                      *(psi_basis_r(i,jj)**2+psi_basis_i(i,jj)**2)
              end do
           end do
        end do
     end do
  end do
end subroutine atomic_density_complex

subroutine atomic_density_real
  integer :: atom,it,j,l,m,k,i,ii,jj
  atomic_density=0.d0
  do atom=1,N_total_atom
     it=atom_index(atom)
     j=0
     do l=0,l_max_basis(it)
        do m=-l,l
           do k=1,N_ao_l(l,it)
              j=j+1
              jj=basis_atom_inv(j,atom)
              do i=1,int_points(atom)
                 ii=Ind_basis(i,atom)
                 atomic_density(ii)=atomic_density(ii)+atom_occ(k,l,it) & 
                      *psi_basis_r(i,jj)**2
              end do
           end do
        end do
     end do
  end do

end subroutine atomic_density_real


subroutine init_basis_cache
  implicit none
  integer :: i,n
  
  n = min(n_diag, n_basis_cache)
  allocate(basis_cache(max_p, n))
  allocate(basis_cache_indx(n))    
  allocate(qpos(n))
  qpos=0
  basis_cache_indx=0
  basis_cache=0
  n_basis_cache=n

  write(log_file,*) 'basis cache size',n

end subroutine init_basis_cache
  

 subroutine init_int_points
    ! find the number of integration points
    ! set max_p
    ! set int_points
    implicit none
    integer :: j,k,na,nl,ic,ia,il,kc,ii
    real*8 :: p0(3),r0(3),r(3),wr
    integer :: icv(nlvec)
    integer, allocatable :: nlvec_i_tmp(:,:)

    max_p = 0
    na = N_total_atom
    nl = N_lattice_points

    allocate(nlvec_i_tmp(nlvec, na))
    allocate(nlvec_atom(na))

    int_points=0
    !$omp parallel do &
    !$omp default(shared) &
    !$omp private(ia,k,p0,wr,icv,il,j,r0,ic,r,kc,ii)
    do ia=1,na
       k = 0
       p0 = Position(:,ia)
       wr = wf_rad(atom_index(ia))
       icv=0
       do il=1,nl
          j = 0
          r0 = grid_point(:,il) - p0
          do ic=1,nlvec
             r = r0 + ldisp(:,ic)
             if (dnrm2b(r) < wr) then
                j = j + 1
                if (j == 1) k = k + 1
                if (icv(ic)==0) icv(ic)=1
             end if
          end do
       end do
!       if (k > max_p) max_p = k
       int_points(ia) = k
       nlvec_atom(ia) = count(icv /= 0)
       kc=1
       do ii=1,nlvec
          if (icv(ii)==1) then
             nlvec_i_tmp(kc,ia)=ii
             kc=kc+1
          end if
       end do
    end do
    !$omp end parallel do

    max_p = maxval(int_points)

    allocate(nlvec_i(maxval(nlvec_atom), na))
    do ia=1,na
       do j=1,nlvec_atom(ia)
          nlvec_i(j,ia)=nlvec_i_tmp(j,ia)
       end do
    end do

    deallocate(nlvec_i_tmp)

  end subroutine init_int_points

  subroutine init_ind_basis
    !set ind_basis
    !set n_cell
    implicit none
    integer               :: ia,il,ic,j,k,na,nl
    real*8                :: wr
    real*8, dimension(3)  :: p0,r0,r

    na = N_total_atom
    nl = N_lattice_points

    do ia=1,na
       k = 0
       p0 = Position(:,ia)
       wr = wf_rad(atom_index(ia))
       do il=1,nl
          j = 0
          r0 = grid_point(:,il) - p0
          do ic=1,nlvec
             r = r0 + ldisp(:,ic)
             if (dnrm2b(r) < wr) then
                j = j + 1
                if (j == 1) k = k + 1
                ind_basis(k, ia) = il
             end if
          end do
          if (j /= 0) n_cell(k,ia) = j
       end do
    end do

!    write(log_file,*) 'sparsity of ind_basis',sparsity(ind_basis)

    call init_compressed_ind_basis

  end subroutine init_ind_basis

  subroutine set_ind_cell(ia)
    !atom is the current index for ind_cell to set
    ! this flattens the 4d array into a 3d array
    ! sets ind_cell
    implicit none
    integer, intent(in)   :: ia
    integer               :: il,ic,j,k,nl,ipa,icmax
    real*8                :: wr2
    real*8, dimension(3)  :: p0,r0,r

    integer :: icc,nlv

    nlv=nlvec_atom(ia)
    ind_cell = 0
    nl = N_lattice_points
    k = 0
    p0 = Position(:,ia)
    wr2 = wf_rad(atom_index(ia))**2
    ipa=int_points(ia)
   l1: do il=1,nl
      j = 0
      r0 = grid_point(:,il) - p0      
      do icc=1,nlv
         ic=nlvec_i(icc,ia)
         r = r0 + ldisp(:,ic)
         if (r(1)*r(1)+r(2)*r(2)+r(3)*r(3) < wr2) then
            j = j + 1
            if (j == 1) then
               k = k + 1
               if (k > ipa) exit l1
            end if
            ind_cell(j,k) = ic
         end if
      end do
   end do l1   
 end subroutine set_ind_cell

function get_num_pairs()
  implicit none
  integer :: get_num_pairs
  integer :: i,j,k,na

  na = n_total_atom
  k = 0
  do i=1,na
  do j=i+1,na
     if (atom_pairs(j,i) == 1) k = k + 1
  end do
  end do
  get_num_pairs = k
end function get_num_pairs


subroutine init_atom_pairs
  ! set: pair_list, overlap_atom_index, atom_pairs, N_overlap_atom_gridpoint
  implicit none
  integer :: i,j,k,na,npts
  integer, dimension(:), allocatable :: gpts
  type(set) :: set1, set2

  na = n_total_atom

  allocate(overlap_atom_index(na,na))
  overlap_atom_index = 0

  if (npairs == 0) npairs = get_num_pairs()
  allocate(gpts(npairs))

  !get number of points in each overlaping region
  k = 0
  do i=1,na
     set1 = ind_basis(:,i)
     do j=1,i-1
        if (atom_pairs(j,i)==1) then
           set2 = ind_basis(:,j)
           npts = cardinality(intersection(set1,set2))
           if (npts /= 0) then
              k = k + 1
              gpts(k) = npts
              overlap_atom_index(i,j) = k
              overlap_atom_index(j,i) = k
           else
              atom_pairs(i,j)=0
              atom_pairs(j,i)=0
           end if
        end if
     end do
  end do

  npairs = k     !set actual number of pairs

  allocate(N_overlap_atom_gridpoint(npairs))
  forall (i=1:npairs) N_overlap_atom_gridpoint(i)=gpts(i)
  deallocate(gpts)


  allocate(pair_list(npairs,2))
  write(log_file, *) 'npairs',npairs
  k = 0
  do i=1,na
     do j=1,i-1
        if (atom_pairs(i,j) /= 0) then
           k = k + 1
           pair_list(k,:) = (/i, j/)
        end if
     end do
  end do

end subroutine init_atom_pairs

subroutine atomic_orbital_overlap
  implicit none
  integer   :: i,j,ki,kj,kk,mm,ii,jj,kkmax,k,memrq
  logical   :: exitnotneeded
  integer, dimension(:), allocatable :: N_overlap_atom_gridpoint_tmp
  logical, save :: first_call = .true.


  
  if (first_call) allocate(overlap_atom_index(N_total_atom,N_total_atom))
  overlap_atom_index = 0

!  if (npairs > 0) then
!     ! npairs is currently only set in rad_bas_periodic
!     allocate(N_overlap_atom_gridpoint_tmp(npairs))
!  else
  mm=0
  do i=1,n_total_atom
     do j=i+1,n_total_atom
        if (atom_pairs(i,j)==1) mm=mm+1
     end do
  end do
  allocate(N_overlap_atom_gridpoint_tmp(mm))
  npairs = mm
!  end if
  N_overlap_atom_gridpoint_tmp=0
  
  write(log_file,*)"npairs: ",npairs
  
  overlap_atom_index=0
  kkmax=0
  mm=0
  do i=1,N_total_atom
     do j=1,i-1
        if(atom_pairs(i,j)==1) then
           kk=0
           ki=1
           ii=Ind_basis(ki,i)
           kj=1
           jj=Ind_basis(kj,j)
           exitnotneeded=.true.
           do while (exitnotneeded)
              if (ii==jj) then
                 kk=kk+1
                 if (ki>=int_points(i)) then
                    exitnotneeded=.false.
                 else
                    ki=ki+1
                    ii=Ind_basis(ki,i)
                    if (kj>=int_points(j)) then
                       exitnotneeded=.false.
                    else
                       kj=kj+1
                       jj=Ind_basis(kj,j)
                    endif
                 endif
              else
                 if (ii>jj) then
                    if (kj>=int_points(j)) then
                       exitnotneeded=.false.
                    else
                       kj=kj+1
                       jj=Ind_basis(kj,j)
                    endif
                 else
                    if (ki>=int_points(i)) then
                       exitnotneeded=.false.
                    else
                       ki=ki+1
                       ii=Ind_basis(ki,i)
                    endif
                 endif
              endif
           enddo
           
           if(kk/=0) then
              if(kkmax<kk) kkmax=kk
              mm=mm+1
              overlap_atom_index(j,i)=mm
              overlap_atom_index(i,j)=mm
              N_overlap_atom_gridpoint_tmp(mm)=kk
           else
              atom_pairs(i,j)=0  !they aren't pairs if there are no points in overlap
              atom_pairs(j,i)=0
           endif
        endif
     end do
  end do
  
  k=size(N_overlap_atom_gridpoint_tmp)

  npairs = count(N_overlap_atom_gridpoint_tmp /= 0)

  if (allocated(N_overlap_atom_gridpoint)) deallocate(N_overlap_atom_gridpoint)
  allocate(N_overlap_atom_gridpoint(npairs))
  N_overlap_atom_gridpoint = 0

  ! fix atom_pair_ij and set N_overlap_atom_gridpoint
  mm=0
  do i=1,n_total_atom
     do j=1,i-1
        if (atom_pairs(i,j)==1) then
           k = overlap_atom_index(j,i)
           N_overlap_atom_gridpoint(k)=N_overlap_atom_gridpoint_tmp(k)
        end if
     end do
  end do
  
  deallocate(N_overlap_atom_gridpoint_tmp)

  if (.not. first_call) then
     call deallocate_sparse(overlap_atom_gridpoint1)
     call deallocate_sparse(overlap_atom_gridpoint2)
  end if

  call allocate_sparse(overlap_atom_gridpoint1, npairs, N_overlap_atom_gridpoint)
  call allocate_sparse(overlap_atom_gridpoint2, npairs, N_overlap_atom_gridpoint)


  write(log_file,*)"max_p: ",max_p
  if (allocated(h_overlap_r)) deallocate(h_overlap_r)  
  allocate(h_overlap_r(max_p))
  h_overlap_r = 0.0d0

  if(complexbasis) then
     if (allocated(h_overlap_i)) deallocate(h_overlap_i)
     allocate(h_overlap_i(max_p))
  end if

  do i=1,N_total_atom
     do j=1,i-1
        mm=overlap_atom_index(j,i)
        if(mm/=0) then
           kk=0
           ki=1
           ii=Ind_basis(ki,i)
           kj=1
           jj=Ind_basis(kj,j)
           exitnotneeded=.true.
           do while (exitnotneeded)
              if (ii==jj) then
                 kk=kk+1
                 call set_Aij(overlap_atom_gridpoint1,mm,kk,ki)
                 call set_Aij(overlap_atom_gridpoint2,mm,kk,kj)
                 if (ki>=int_points(i)) then
                    exitnotneeded=.false.
                 else
                    ki=ki+1
                    ii=Ind_basis(ki,i)
                    if (kj>=int_points(j)) then
                       exitnotneeded=.false.
                    else
                       kj=kj+1
                       jj=Ind_basis(kj,j)
                    endif
                 endif
              else
                 if (ii>jj) then
                    if (kj>=int_points(j)) then
                       exitnotneeded=.false.
                    else
                       kj=kj+1
                       jj=Ind_basis(kj,j)
                    endif
                 else
                    if (ki>=int_points(i)) then
                       exitnotneeded=.false.
                    else
                       ki=ki+1
                       ii=Ind_basis(ki,i)
                    endif
                 endif
              endif
           enddo
        endif
     enddo
  enddo

  first_call = .false.
  
end subroutine atomic_orbital_overlap

  subroutine plot_orbitals
    implicit none
    integer                         :: orbital,j,k,i,j1,j2,ii
    real*8,allocatable,dimension(:) :: wfun,wpsi,psi_basis1    

    if (cache_basis) allocate(psi_basis1(max_p))

    allocate(wfun(N_lattice(1)),wpsi(N_lattice_points))
    do orbital=1,N_orbitals+1
     wPsi=0.d0
       do j=1,N_diag
          j1=basis_atom(1,j)
          j2=basis_atom(2,j)
          if (cache_basis) then
             call get_psi_basis(j,psi_basis1)
             do k=1,int_points(j2)
                ii=Ind_basis(k,j2)
                wPsi(ii)=wPsi(ii)+evec(j,orbital)*psi_basis1(k)
             end do
          else
             do k=1,int_points(j2)
                ii=Ind_basis(k,j2)
                wPsi(ii)=wPsi(ii)+evec(j,orbital)*psi_basis_r(k,j)
             end do
          end if
       end do
      wfun=0.d0
      do i=1,N_lattice_points
        ii=Lattice(1,i)+1
        wfun(ii)=wfun(ii)+wPsi(i)**2
      end do
      do i=1,N_lattice(1)
        write(orbitals_file,*)xgrid(i),wfun(i)
      end do
      write(orbitals_file,*)
    end do

    if (cache_basis) deallocate(psi_basis1)

  end subroutine plot_orbitals

  SUBROUTINE input_scf
    integer       :: i,i1,i2,i3,error_code
    character*255 :: full_filename
    logical       :: file_exists

!    inquire(file=trim(adjustl(scf_data_filename)), exist=file_exists)
!    if(file_exists) then
!       full_filename=scf_data_filename
!    else

    if (use_checkpoint) then
      write(full_filename,'(a)')trim(adjustl(scf_data_filename))
    else
      write(full_filename,'(2a)')trim(adjustl(gs_path)),trim(adjustl(scf_data_filename))
    endif
       !    endif
    write(log_file,*)"SCF data full filename: ",trim(adjustl(full_filename))

    if (large_file_format(1:5)=='ascii') then
       open(scf_data_file,file=trim(adjustl(full_filename)),action='read',status='old',iostat=error_code)
       if(error_code/=0) then
          write(log_file,'(3a)')"ERROR: cannot open file '",trim(adjustl(full_filename)),"' in input_scf"
          stop
       endif

       read(scf_data_file,*)i1,i2,i3
       if((i1/=N_Lattice(1)).OR.(i2/=N_Lattice(2)).OR.(i3/=N_Lattice(3))) then
         write(log_file,*)"ERROR: lattice sizes do not match in input_scf"
         stop
       endif
       
       if (complexbasis) then
          do i=1,N_Lattice_points
             read(scf_data_file,*) density(i)
          end do
          call hamiltonian_density
       else if(spin_polarized) then
          do i=1,N_Lattice_points
             read(scf_data_file,*)density_up(i),density_down(i)
          end do
          Density=Density_up+Density_down
          call hamiltonian_density
       else
          do i=1,N_Lattice_points
             read(scf_data_file,*)V_hartree(i),V_exchange(i),density(i)
          end do
       endif
       close(scf_data_file)
    else
       open(scf_data_file,file=trim(adjustl(full_filename)), &
            form='unformatted',action='read',status='old',iostat=error_code)
       if(error_code/=0) then
          write(log_file,'(3a)')"ERROR: cannot open file '",trim(adjustl(full_filename)),"' in input_scf"
          stop
       endif

       read(scf_data_file)i1,i2,i3
       if((i1/=N_Lattice(1)).OR.(i2/=N_Lattice(2)).OR.(i3/=N_Lattice(3))) then
         write(log_file,*)"ERROR: lattice sizes do not match in input_scf"
		 write(log_file,*) i1,i2,i3
		 write(log_file,*)" when dft.inp is"
		 write(log_file,*) N_Lattice(1),N_Lattice(2),N_Lattice(3)
         stop
       endif
       
       if (complexbasis) then
          read(scf_data_file) density
          call hamiltonian_density
       else if(spin_polarized) then
          read(scf_data_file)density_up,density_down
          Density=Density_up+Density_down
          call hamiltonian_density
       else
          read(scf_data_file) V_hartree,V_exchange,density
       endif
       close(scf_data_file)    
    endif

    new_density=density
  END SUBROUTINE input_scf

SUBROUTINE output_orbital_slices
  integer                :: i,j,k,ii,num_mr,orbital,j2,k1
  real*8                 :: the_value
  real*8,allocatable     :: temp_density(:)
  complex*16,allocatable :: phi_orbital(:)
  character*255          :: gnuplot_filename,data_filename,output_basename,temp1,temp2

  gnuplot_filename="plot.gp"
  num_mr=size(mr)
  allocate(phi_orbital(N_Lattice_points),temp_density(N_Lattice_points))
  phi_orbital=cmplx(0.d0,0.0d0,8); temp_density=0.d0

  do orbital=1,n_orbitals
    write(temp1,*)orbital
    if(grid_calculation) then
      phi_orbital(:)=Psi_c(:,orbital)
    else
      if(box_basis_type==1) then
        phi_orbital=(0.d0,0.d0)
        do j=1,N_diag
          j2=basis_atom(2,j)
          do k=1,int_points(j2)
            k1=ind_basis(k,j2)
            phi_orbital(k1)=phi_orbital(k1)+c_basis(j,orbital)*psi_basis_r(k,j)
          enddo
        enddo
      elseif(box_basis_type==3) then
!        write(log_file,*)"WARNING: plot_time does not yet support box_basis_type==3"
        return
      else
        write(log_file,*)"ERROR: plot_time does not support box_basis_type==2"
        stop
      endif
    endif

    do k=1,num_mr
      write(temp2,*)k
      write(output_basename,'(4a)')"orbital_",trim(adjustl(temp1)),"_slice_",trim(adjustl(temp2))
      write(data_filename,'(2a)')trim(adjustl(output_basename)),".dat"
      open(gnuplot_data_file,file=trim(adjustl(data_filename)))
      do i=1,N_lattice(2)
        do j=1,N_lattice(3)
          ii=Lattice_inv_xyz(mr(k),i,j)
          the_value=real(Conjg(phi_orbital(ii))*phi_orbital(ii))
          write(gnuplot_data_file,*)i,j,the_value
          temp_density(ii)=temp_density(ii)+occupation(orbital)*the_value
        enddo
        write(gnuplot_data_file,*)
      enddo
      close(gnuplot_data_file)
      call gnuplot_2D(gnuplot_filename,data_filename,output_basename,N_lattice(2),N_lattice(3))
    enddo
  enddo

  if (output_mr_density_slice) then
    do k=1,num_mr
      do i=1,N_lattice(2)
        do j=1,N_lattice(3)
          ii=Lattice_inv_xyz(mr(k),i,j)
          write(mr_density_slice_file,'(ES16.8)')temp_density(ii)
        enddo
      enddo
    enddo
    write(mr_density_slice_file,*)
  endif

  deallocate(phi_orbital,temp_density)
END SUBROUTINE output_orbital_slices

  subroutine save_atomic_basis
    integer :: i,j,l

    open(basis_file,file=trim(adjustl(basis_filename)))
    write(basis_file,*)Ng
    do l=0,lexp
    do i=1,N_diag
       if(lbasis(i).eq.l) then
       if(mbasis(i).eq.0) then
          write(basis_file,*)occ(i),lbasis(i)
          do j=1,N_diag
             if(c_basis(j,i).ne.0.d0) write(basis_file,*)c_basis(j,i)
          end do
       endif
       endif
    end do
    end do
    close(basis_file)
  end subroutine save_atomic_basis


subroutine get_psi_basis(basis_indx, psi_basis1)
  ! LRU cache algo
  ! todo - account for current value of psi_basis1
  implicit none
  integer :: basis_indx
  real*8, dimension(:) :: psi_basis1

  logical :: found, file_exists
  integer :: i,j,tmp,loc,bin,m
  integer, save :: icache=1

  logical, parameter :: save_to_file=.true.
  character(256) :: fnum, fname

  psi_basis1=0.0d0
  m = int_points(basis_atom(2,basis_indx))

  found = .false.
  loop1 : do i=1,n_basis_cache
     if (basis_cache_indx(i)==basis_indx) then
        psi_basis1(1:M)=basis_cache(1:m,i)
        
        ! reorder the queue
        ! most recent goes first
        do j=1,n_basis_cache
           if (qpos(j) < qpos(i)) qpos(j)=qpos(j) + 1
        end do
        qpos(i)=1
        
        found = .true.
        exit loop1
     end if
  end do loop1 
  
  if (.not. found) then

     if (save_to_file) then
        ! cache to temp files on disk if a data file isn't there create it!!!
        write(fnum, *) basis_indx
        fname='b/basis_tmp_'//trim(adjustl(fnum))//'.dat'
        inquire(file=trim(adjustl(fname)), exist=file_exists)
        
        if (file_exists) then
           open(99, file=trim(adjustl(fname)), form='unformatted')
           read(99) psi_basis1
           close(99)
        else     
           open(99, file=trim(adjustl(fname)), form='unformatted')
           call calc_psi_basis(basis_indx, psi_basis1)
           write(99) psi_basis1
        end if
     else
        call calc_psi_basis(basis_indx, psi_basis1)
     end if

     ! add to cache if there is room
     ! otherwise replace oldest cached basis
     if (icache <= n_basis_cache) then
        basis_cache(1:m,icache)=psi_basis1(1:m)
        basis_cache_indx(icache)=basis_indx

        ! reorder cache
        do i=1,icache-1
           qpos(i)=qpos(i)+1
        end do
        qpos(icache)=1
     else
        loop2 : do j=1,n_basis_cache
           if (qpos(j) == n_basis_cache) then
              basis_cache(1:m,j)=psi_basis1(1:m)
              basis_cache_indx(j)=basis_indx
              
              ! reorder cache
              qpos=qpos+1
              qpos(j)=1

              exit loop2
           end if
        end do loop2
      end if
     icache = icache + 1
  end if

end subroutine get_psi_basis 

subroutine init_lmj_table
  
  integer :: kk,la,ma,j,basis_indx,atom,it,i

  allocate(lmj_table(3, n_diag))

  do basis_indx=1,n_diag
     atom=basis_atom(2,basis_indx)
     it=atom_index(atom)
     kk=0
     l1 : do la=0,l_max_basis(it)
        do ma=-la,la
           do j=1,N_ao_l(la,it)
              kk=kk+1
              if (basis_indx == basis_atom_inv(kk,atom)) then
                 lmj_table(:,basis_indx)=(/la,ma,j/)
                 exit l1
              end if
           end do
        end do
     end do l1
  end do

end subroutine init_lmj_table
     

subroutine calc_psi_basis(basis_indx, psi_basis1)
  implicit none
  integer, intent(in)  :: basis_indx
  real*8, dimension(:) :: psi_basis1

  integer :: atom,it,k,cell,ipa,mval,lval,jval,i
  real*8 :: p0(3),r0(3),r(3),xx,su
  complex*16 :: sh

  atom=basis_atom(2,basis_indx)
  it=atom_index(atom)      

  lval=lmj_table(1,basis_indx)
  mval=lmj_table(2,basis_indx)
  jval=lmj_table(3,basis_indx)

  p0 = Position(:,atom)
  call set_ind_cell(atom)  


  select case (mval)
  case(:-1)
     !$omp parallel do &
     !$omp default(shared) &
     !$omp private (k,i,r0,cell,r,xx,sh) &
     !$omp reduction(+: psi_basis1)
     do k=1,int_points(atom)
        i=Ind_basis(k,atom)
        r0 = grid_point(:,i) - p0
        do cell=1,N_cell(k,atom)
           r = r0 + ldisp(:,ind_cell(cell,k))        
           xx=sqrt(r(1)*r(1)+r(2)*r(2)+r(3)*r(3))
           sh=spherical_harmonics_fast(r(1),r(2),r(3),xx,lval,abs(mval))
           sh=(sh-Conjg(sh))/sqrt(2.d0)/zi           
           psi_basis1(k)=psi_basis1(k)+radial_spline2(xx,jval,lval,it)*real(sh)
        end do
     end do
     !$omp end parallel do
  case(0)
     !$omp parallel do &
     !$omp default(shared) &
     !$omp private (k,i,r0,cell,r,xx,sh) &
     !$omp reduction(+: psi_basis1)
     do k=1,int_points(atom)
        i=Ind_basis(k,atom)
        r0 = grid_point(:,i) - p0
        do cell=1,N_cell(k,atom)
           r = r0 + ldisp(:,ind_cell(cell,k))        
           xx=sqrt(r(1)*r(1)+r(2)*r(2)+r(3)*r(3))
           sh=spherical_harmonics_fast(r(1),r(2),r(3),xx,lval,abs(mval))  
           psi_basis1(k)=psi_basis1(k)+radial_spline2(xx,jval,lval,it)*real(sh)
        end do
     end do
     !$omp end parallel do
  case (1:)     
     !$omp parallel do &
     !$omp default(shared) &
     !$omp private (k,i,r0,cell,r,xx,sh) &
     !$omp reduction(+: psi_basis1)
     do k=1,int_points(atom)
        i=Ind_basis(k,atom)
        r0 = grid_point(:,i) - p0
        do cell=1,N_cell(k,atom)
           r = r0 + ldisp(:,ind_cell(cell,k))        
           xx=sqrt(r(1)*r(1)+r(2)*r(2)+r(3)*r(3))
           sh=spherical_harmonics_fast(r(1),r(2),r(3),xx,lval,abs(mval))
           sh=(sh+Conjg(sh))/sqrt(2.d0)
           psi_basis1(k)=psi_basis1(k)+radial_spline2(xx,jval,lval,it)*real(sh)
        end do
     end do
     !$omp end parallel do
  end select



  ipa=int_points(atom)
  !$omp parallel workshare
  psi_basis1(1:ipa)=psi_basis1(1:ipa)/nrm_table(basis_indx)
  !$omp end parallel workshare
end subroutine calc_psi_basis
  
subroutine init_psi_basis
  ! one loop through the basis to precompute normlization factors
  real*8, allocatable :: psi_basis1(:)
  integer :: i
  allocate(nrm_table(n_diag))
  allocate(psi_basis1(max_p))
  nrm_table=1.0d0
  do i=1,n_diag     
     psi_basis1=0.0d0
     call calc_psi_basis(i,psi_basis1)
     nrm_table(i)=sqrt(sum(psi_basis1**2.0d0)*grid_volume)
  end do
  deallocate(psi_basis1)
end subroutine init_psi_basis

!************** Explicitly calculate radial wavefunction
!
!!$  do k=1,int_points(atom)
!!$     i=Ind_basis(k,atom)
!!$     r0 = grid_point(:,i) - p0
!!$     do cell=1,N_cell(k,atom)
!!$        r = r0 + ldisp(:,ind_cell(cell,k))
!!$        xx=sqrt(r(1)*r(1)+r(2)*r(2)+r(3)*r(3))
!!$        wfr=0.d0
!!$        xl=xx**lval
!!$        do js=1,Ng
!!$           wfr=wfr+c_exp(js,jval,lval,it)* & 
!!$                basis_func(xx,gauss_p(js),lval)*xl
!!$        end do
!!$        spc=spherical_harmonics2(r,la,abs(ma))
!!$        if (mval < 0) then
!!$           sh=(spc-Conjg(spc))/sqrt(2.d0)/zi  
!!$        else if (mval > 0) then
!!$           sh=(spc+Conjg(spc))/sqrt(2.d0)
!!$        else
!!$           sh=spc
!!$        end if
!!$        psi_basis1(k)=psi_basis1(k)+wfr*real(sh)
!!$     end do
!!$  end do

subroutine interpolate_radial_func
  implicit none
  real*8 :: xmax,x,xl,wfr,fr,dx,dx2
  integer :: ngp,it,la,j,lmax,jmax,i,js

  dx = radial_fine_grid
  xmax = maxval(wf_rad)+0.1d0  
  ngp = int(xmax/dx)+2
  jmax = maxval(N_ao_l)
  lmax = maxval(l_max_basis)

  write(log_file,*) 'calculating radial wave function on fine grid'
  
  allocate(bf_table(ngp+2,jmax,0:lmax,maxval(atom_index)))  
  
  do it=1,maxval(atom_index)
  do la=0,lmax
     do j=1,jmax                
        do i=1,ngp+2
           x=(i-1)*dx
           fr=0.d0
           xl=x**la
           do js=1,Ng
              fr=fr+c_exp(js,j,la,it)*basis_func(x,gauss_p(js),la)*xl
           end do
           bf_table(i,j,la,it)=fr
        end do
     end do
  end do
  end do


!!$  dx2=dx/10.0d0
!!$!  do it=1,maxval(atom_index)
!!$  it=1
!!$!  do la=0,lmax
!!$  la=1
!!$  j=1
!!$!     do j=1,jmax                
!!$        do i=1,ngp*10+1
!!$           x=(i-1)*dx2
!!$           fr=0.d0
!!$           xl=x**la
!!$           do js=1,Ng
!!$              fr=fr+c_exp(js,j,la,it)*basis_func(x,gauss_p(js),la)*xl
!!$           end do
!!$           write(870,*) x,fr-radial_spline(x,j,la,it)
!!$           write(871,*) x,fr-radial_spline2(x,j,la,it)
!!$        end do
!!$!     end do
!!$!  end do
!!$!  end do
!!$  
!!$  stop


end subroutine interpolate_radial_func


pure function radial_spline(x, j, l, it)
  ! linear interpolation
  implicit none
  real*8 :: radial_spline
  real*8, intent(in) :: x
  integer, intent(in) :: j,l,it

  integer :: gp
  real*8 :: x0,x1,dx

  dx=radial_fine_grid

  gp=int(floor(x/dx))+1
  x0=(gp-1)*dx
  x1=x0+dx
 
  radial_spline=((x-x0)*bf_table(gp,j,l,it) + (x1-x)*bf_table(gp+1,j,l,it)) & 
       / (x1-x0)

end function radial_spline

pure function radial_spline2(x, j, l, it)
  implicit none
  real*8 :: radial_spline2
  real*8, intent(in) :: x
  integer, intent(in) :: j,l,it

  integer :: i
  real*8 :: x0,x1,x2,dx,d0,d1,d2

  dx=radial_fine_grid

  i=int(floor(x/dx))+1
  x0=(i-1)*dx
  x1=x0+dx
  x2=x1+dx
  d0=x-x0
  d1=x-x1
  d2=x-x2
  
  radial_spline2= (1/dx**2)*( &
       0.5d0*d1*d2*bf_table(i,j,l,it) &
       - d0*d2*bf_table(i+1,j,l,it) &
       + 0.5d0*d0*d1*bf_table(i+2,j,l,it) )
    
end function radial_spline2

subroutine interpolate_Ylm    
  ! assumes m>0
  implicit none
  real*8 :: xmax,x,xl,wfr,fr,dx 
  integer :: it,la,j,lmax,jmax,i,js,ma

  integer :: ngp=ylm_ngp
  real*8,parameter  :: xpi=3.141592653589793d0  
  real*8 :: fc

  real*8, parameter :: ff=1.0d0/(4.0d0*xpi)

  dx=ylm_dx
  lmax = maxval(l_max_basis)

  write(log_file,*) 'calculating Ylm on fine grid'

  allocate(plgnr_table(-ngp:ngp,0:lmax,0:lmax))
  allocate(ylm_coeff(0:lmax,0:lmax))
  
  do la=0,lmax
     do ma=0,la

        fc=ff*(2*la+1)
        do i=1,la-ma
           fc=fc*i
        end do
        do i=1,la+ma
           fc=fc/i
        end do
        ylm_coeff(la,ma) = sqrt(fc)

        do i=-ngp,ngp
           x=dx*dble(i)
           plgnr_table(i,la,ma)=plgndr(la,ma,x)*sqrt(fc)
        end do

     end do
  end do

!  do i=-ngp,ngp
!     write(864,*) i,i*dx
!  end do

end subroutine interpolate_Ylm

pure function spherical_harmonics_fast(x,y,z,r,l,m)
  !interpolated spherical harmonics
  ! assumes m > 0
  implicit none
  complex*16 :: spherical_harmonics_fast
  real*8, intent(in) :: x,y,z,r
  integer, intent(in) :: l,m
  
  complex*16,parameter  :: zi=(0.d0,1.d0)
  integer :: i
  real*8  :: cost,x0,x1
  complex*16 :: phi

  phi=((x+zi*y)/sqrt(x*x+y*y+1.0d-20))**m
  cost=z/(r+1.0d-40)

  i=int(floor(cost/ylm_dx))
  x0=i*ylm_dx
  x1=x0+ylm_dx
 
  spherical_harmonics_fast=phi*(((cost-x0)*plgnr_table(i,l,m) & 
       + (x1-cost)*plgnr_table(i+1,l,m)) / (x1-x0))

end function spherical_harmonics_fast


END MODULE RADIAL_BASIS
