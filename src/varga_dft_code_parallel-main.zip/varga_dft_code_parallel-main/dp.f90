implicit none
  real*8,allocatable   :: Dp(:),alpha_R(:),alpha_I(:)
  integer              :: N_time,N_energy
  real*8               :: dE,dt,x,S,t,tt,hw,f
  integer              :: i,n,m
  complex*16           :: zalpha,zi

  real(8),parameter    :: E2=14.4d0, H2M=3.81d0, a_B=0.529177d0
  real(8),parameter    :: Ry=13.6058d0, Pi=3.141592653589793d0




  zi=(0.d0,1.d0)
  dE=0.01d0
  N_energy=3000
  allocate(alpha_r(0:N_energy),alpha_i(0:N_energy))
  open(1,file='dp.dat')
    read(1,*)N_time,dt,f
    allocate(Dp(0:N_time))
    Dp=0.d0
    do i=1,N_time
      read(1,*)x,Dp(i)
    end do
  close(1)

! Fourier Transform

      TT = dt*N_time

      do m=0,N_energy
         hw=m*dE ; zalpha=(0.d0,0.d0)
         do n=1,N_time
            t=n*dt ; zalpha=zalpha+exp(zi*hw*t)*Dp(n)*(1-3*(t/TT)**2+2*(t/TT)**3)
         end do
         zalpha=zalpha*E2/F*dt        ! Complex polarizability
         alpha_R(m)=real(zalpha,8)    ! Real part
         alpha_I(m)=imag(zalpha)      ! Imaginary part
      end do


! Alpha
      open(1,file='alphar.dat')
      open(2,file='alphai.dat')
        do N=0,N_energy
           S=2*n*dE/(Pi*a_B*E2**2)*alpha_I(n)
            write(1,*) n*dE, alpha_R(n)
            write(log_file,*) n*dE, S
         end do
      close(1)
      close(2)
end
