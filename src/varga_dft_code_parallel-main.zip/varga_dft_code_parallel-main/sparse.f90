module sparse
  use parameters, only : log_file
  ! need to use pointers because allocatable arrays are not allowed in
  ! derived types
  ! important note - the second index is faster than the first
  !  the opposite is usual in fortran matricies
  !
  ! ie:
  ! do i=1,m
  ! do j=1,n
  !    x=A(i,j)
  ! is faster than
  ! do j=1,n
  ! do 1=1,n
  !    x=A(j,i)
  !
  ! Brandon

  !todo: if the memory gain is not enough add
  !         this will slow down access times...
  !         type(sparse_row_comp)
  !         the rows contain large blocks of consecutive integers
  !         ie. i,i+1,i+2,...,i+n
  !         in this case store i,n,j   (j is the 'real' position in the vec)
  !         must have 3*nb < n for savings...

  !type for general sparse matrix
  ! matrix = matrix_element[# of non zeros]
  type :: matrix_element
     integer :: row
     integer :: col
     real*8  :: val
  end type matrix_element

  type :: sparse_row
     integer, pointer :: c(:)
  end type sparse_row

  type :: sparse_row_comp
     integer          :: nb   !number of blocks
     integer, pointer :: i(:),n(:),j(:)
  end type sparse_row_comp

  type :: sparse_matrix
     integer                        :: mrow
     integer, pointer               :: ncol(:) !size of rows
     type(sparse_row), pointer      :: r(:)    !A%r(i) = ith row
     logical                        :: comp    !compression on/off
     type(sparse_row_comp), pointer :: r2(:)
  end type sparse_matrix

contains

  subroutine allocate_sparse(this, mrow, row_sizes)
    integer, intent(in)                :: mrow
    integer, dimension(:), intent(in)  :: row_sizes
    type(sparse_matrix), intent(inout) :: this
    this%mrow = mrow
    this%comp = .False.   !add optional arg to set this...
    allocate(this%ncol(mrow))
    allocate(this%r(mrow))
    do i=1,mrow
       this%ncol(i) = row_sizes(i)
       allocate(this%r(i)%c(row_sizes(i)), stat=ierr)
       if (ierr /= 0) then
          write(log_file,*) 'ERROR allocated in allocate_sparse',ierr
          stop
       end if
    end do
  end subroutine allocate_sparse

  subroutine deallocate_sparse(this)
    type(sparse_matrix), intent(inout) :: this
    do i=1,this%mrow
       deallocate(this%r(i)%c)
    end do
    deallocate(this%r)
    deallocate(this%ncol)
  end subroutine deallocate_sparse

  subroutine set_Aij(A,i,j,Aij)
    type(sparse_matrix), intent(inout) :: A
    integer, intent(in) :: i,j,Aij
    A%r(i)%c(j) = Aij
  end subroutine set_Aij

  function get_Aij(A,i,j)
    integer :: get_Aij
    type(sparse_matrix), intent(in) :: A
    integer, intent(in) :: i,j
    get_Aij = A%r(i)%c(j)
  end function get_Aij

  function get_ncol(A,i)
    integer :: get_ncol
    type(sparse_matrix), intent(in) :: A
    integer, intent(in) :: i  !row index
    get_ncol = A%ncol(i)
  end function get_ncol

  function percent_memory_saved(A)
    real*8 :: percent_memory_saved
    type(sparse_matrix), intent(in) :: A
    percent_memory_saved = 100.0d0 * dble(sum(A%ncol)) / (dble(A%mrow) * dble(maxval(A%ncol)))
  end function percent_memory_saved

  function get_size(A)
    ! Returns number of elements in A
    integer :: get_size
    type(sparse_matrix), intent(in) :: A
    get_size = sum(A%ncol)
  end function get_size

  function memory_saved(A)
    real*8 :: memory_saved
    real*8 :: n,m
    type(sparse_matrix), intent(in) :: A
    n = dble(sum(A%ncol))
    m = dble(A%mrow * maxval(A%ncol))
    memory_saved = 4 * (m - n) / dble(1048576)
  end function memory_saved

  function sparsity(A)
    real*8 :: sparsity
    integer, dimension(:,:), intent(in) :: A
    integer :: k
    m = size(A,1)
    n = size(A,2)
    k = 0
    do j=1,n
       do i=1,m
          if (A(i,j) == 0) k = k + 1
       end do
    end do
    sparsity = dble(k)/dble(m*n)
  end function sparsity


end module sparse
