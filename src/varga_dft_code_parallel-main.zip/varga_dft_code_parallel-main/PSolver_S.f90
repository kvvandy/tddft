Subroutine Poisson_Solver
USE MOD_GLOBAL
USE MOD_POISSON_SOLVER
implicit none

character(len=2)                    :: geocode
real*8,dimension(:,:,:),allocatable :: rhopot,pot_ion
real*8,pointer                      :: karray(:)
real*8                              :: hx,hy,hz,eh,exc,vxc,off,xx
integer                             :: ixc,n01,n02,n03,itype_scf
integer                             :: i,i1,i2,i3
integer                             :: ns1,ns2,ns3

n01=N_Lattice_max(1)-N_Lattice_min(1)+1
n02=N_Lattice_max(2)-N_Lattice_min(2)+1
n03=N_Lattice_max(3)-N_Lattice_min(3)+1
hx=Grid_Step(1)
hy=Grid_Step(2)
hz=Grid_Step(3)
allocate(rhopot(n01,n02,n03))
allocate(pot_ion(n01,n02,n03))
ixc=0
geocode="F"
itype_scf=8
off=0

if (box_type==1) then
  do i=1,N_Lattice_points
    i1=Lattice(1,i)+1
    i2=Lattice(2,i)+1
    i3=Lattice(3,i)+1
    rhopot(i1,i2,i3)=Density(i)-Rho_bg(i)
  end do
endif

if ((box_type==2).or.(box_type==3)) then
  ns3=0
  do i3=N_Lattice_min(3),N_Lattice_max(3)
    ns3=ns3+1
    ns2=0
    do i2=N_Lattice_min(2),N_Lattice_max(2)
      ns2=ns2+1
      ns1=0
      do i1=N_Lattice_min(1),N_Lattice_max(1)
        ns1=ns1+1
        i=Lattice_inv_xyz(i1,i2,i3)
        if (i>0) then
          rhopot(ns1,ns2,ns3)=Density(i)-Rho_bg(i)
        else
          rhopot(ns1,ns2,ns3)=0.0d0
        endif
      end do
    end do
  end do
endif

call createKernel(geocode,n01,n02,n03,hx,hy,hz,itype_scf,0,1,karray)
call PSolver(geocode,'G',0,1,n01,n02,n03,ixc,hx,hy,hz,rhopot,karray,pot_ion,eh,exc,vxc,off,.true.,1)

if(box_type==1) then

       do i=1,N_Lattice_points
         i1=Lattice(1,i)+1
         i2=Lattice(2,i)+1
         i3=Lattice(3,i)+1
         VH(i)=rhopot(i1,i2,i3)
       end do

endif

if ((box_type==2).or.(box_type==3)) then
  ns3=0
  do i3=N_Lattice_min(3),N_Lattice_max(3)
    ns3=ns3+1
    ns2=0
    do i2=N_Lattice_min(2),N_Lattice_max(2)
      ns2=ns2+1
      ns1=0
      do i1=N_Lattice_min(1),N_Lattice_max(1)
        ns1=ns1+1
        i=Lattice_inv_xyz(i1,i2,i3)
         if (i>0) VH(i)=rhopot(ns1,ns2,ns3)
      end do
    end do
  end do
endif

deallocate(karray)
deallocate(rhopot)
deallocate(pot_ion)
End Subroutine Poisson_Solver
