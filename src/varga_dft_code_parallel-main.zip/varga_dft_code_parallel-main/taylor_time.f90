MODULE  TAYLOR_TIME
  USE MOD_GLOBAL
  USE PSEUDOPOTENTIAL
  USE HAMILTON
  USE MASK_VOLKOV
  use moldynamics
  use taylor_extended
  use mpi
  implicit none
  real*8                          :: E_wp,Norm_wp
  real*8,dimension(:),allocatable :: density_wp(:)
  real*8                          :: kick_strength=0.01d0
  real*8,allocatable              :: o_t(:,:),h_t(:,:),psi_t(:,:),psi_tt(:,:),eig_val(:),eig_vec(:,:),b_t(:,:),psi_st(:,:)
  real*8,allocatable              :: h_r(:,:),h_0(:,:)
  complex*16,allocatable          :: c_proj(:,:)
  integer                         :: n_orbitals_t  
  INTEGER, DIMENSION (1)          :: seed = (/3/)
  real*8                          :: dpm_3comp(3),dpm_elec3comp(3),dpm_nuc3comp(3)
  real*8  :: energy_init_elec,energy_final_elec,energy_init_ions,energy_final_ions ! projectile stuff
  real*8   :: PREV_ENE,PREV_ENE10
  
  integer :: td_NL_counter
 ! real(4),dimension(:),allocatable,::sing_prec_rearranged_potential

  !variables for lanczos propagation
!  real*8,dimension(:),allocatable :: Dp
  integer                         :: n_lanczos,n_lanczos_basis
  complex*16,allocatable          :: c(:),q(:,:,:),q2(:,:),z(:),l_prop(:,:,:),lanczos_basis(:,:)
  complex*16,allocatable          :: l_basis_prop(:,:),proj_basis(:),cv_basis(:)
  complex*16,allocatable          :: am(:,:),bm(:,:),zo(:,:),cb(:),q_l(:,:)
  complex*16, allocatable         :: h_lanczos(:,:),o_lanczos(:,:),oi_lanczos(:,:)
  real*8, parameter           :: cap0=0.2d0

  real*8,allocatable           :: ipioniz_nelec_prev(:),innerproducts_iter(:,:)
  
CONTAINS


subroutine taylor_time_init_ALL
implicit none
integer :: i,k
integer :: k1min,k1max,k2min,k2max,k3min,k3max

do i=1,N_taylor
tc(i)=(-zi*time_step/hbar)**i
do k=1,i
 tc(i)=tc(i)/k
enddo
enddo


if(allocated(H_Phi_c)) deallocate(H_Phi_c)
if(allocated(Phi_c)) deallocate(Phi_c)
if(allocated(V_nl_pp_c)) deallocate(V_nl_pp_c)
if(allocated(T_Phi_c)) deallocate(T_Phi_c)
if(allocated(vpot)) deallocate(vpot)
if(allocated(wphi_c)) deallocate(wphi_c)
if(.NOT.allocated(full_density_save)) allocate(full_density_save(N_lattice_points))
allocate(H_phi_c(N_lattice_points),Phi_c(N_lattice_points))
allocate(Vpot(N_lattice_points),T_Phi_c(N_lattice_points),V_nl_pp_c(N_Lattice_points))

if(spin_polarized) then
  allocate(V_full_pot_up(N_lattice_points),V_full_pot_down(N_lattice_points))
else
  allocate(V_full_pot(N_lattice_points))
end if

do i=1,N_Lattice_points  
  V_nl_pp_c(i)=(0.d0,0.d0)
enddo    
 
k1min=N_Lattice_min(1)
k1max=N_Lattice_max(1)
k2min=N_Lattice_min(2)
k2max=N_Lattice_max(2)
k3min=N_Lattice_min(3)
k3max=N_Lattice_max(3)
allocate(wphi_c(k1min-Nd-1:k1max+Nd,k2min-Nd-1:k2max+Nd,k3min-Nd-1:k3max+Nd))
wphi_c=cmplx(0.0d0,0.0d0,8)
td_NL_counter=0

  if(td_prop_empty) then
     N_occupied_orbitals=N_orbitals
     N_orbitals=N_Total_orbitals
  end if

  allocate(MPItask_orbital_map(N_orbitals))
  allocate(sp_energy_save(N_Total_orbitals),buf_sp_energy_save(N_Total_orbitals))
  allocate(norm_save(N_Total_orbitals),buf_norm_save(N_Total_orbitals))
  
allocate(Psi_c(N_lattice_points,N_orbitals))
if (.not.allocated(wlap_p)) allocate(wlap_p(3,N_Lattice_points))
  wlap_p= (0.D0, 0.D0)  
  
  
end subroutine taylor_time_init_ALL

subroutine taylor_time_init_MASTER
implicit none
integer :: i,j
  
    write(log_file,*)'dipole_direction=',dipole_direction,kind(dipole_direction)
    if ((dipole_direction==1) .OR. (dipole_direction==0)) then
	  if(do_not_overwrite) then
	    open(dipole_x_file,file=trim(adjustl(dipole_x_filename)), status="old", position="append", action="write")
	  else
        open(dipole_x_file,file=trim(adjustl(dipole_x_filename)),action='write',status='replace')
		write(dipole_x_file,'(1x,i7,2(1x,es16.8))') N_time_steps,time_step,kick_strength
      end if
    endif
    if ((dipole_direction==2).OR. (dipole_direction==0)) then
      open(dipole_y_file,file=trim(adjustl(dipole_y_filename)),action='write',status='replace')
      write(dipole_y_file,'(1x,i7,2(1x,es16.8))') N_time_steps,time_step,kick_strength
    endif
    if ((dipole_direction==3) .OR. (dipole_direction==0)) then
      open(dipole_z_file,file=trim(adjustl(dipole_z_filename)),action='write',status='replace')
      write(dipole_z_file,'(1x,i7,2(1x,es16.8))') N_time_steps,time_step,kick_strength
    endif
    if(calc_dpm_elec_nuc) then
      open(dipole_all_file,file="dp_xyz_elec_nuc.dat",action='write',status='replace')
    end if
  
!  Psi_c=Psi
  do i=1,N_orbitals
    do j=1,N_lattice_points
      Psi_c(j,i)=cmplx(Psi(j,i),0.d0,8)
    enddo
  enddo
  
if (boost) call boost_wavefunction

if(boost_around_atom) then
  call boost_wf_around_atom(boost_around_atom_idx,boost_around_atom_rad)
end if

if(combine_gs_boost2) then
  call boost_wf2_combined
end if


  if (output_orb_density) then
     do i=1,N_orbitals
      density=0.d0
      do j=1,N_lattice_points
      density(j)=(real(Psi_c(j,i))**2+imag(Psi_c(j,i))**2)*Occupation(i)
      enddo
     call output_td_density(0)
    enddo
    density=0.d0
  endif

  call calculate_rho_grid
  dipole_mom_vec0(1)=dipole_moment(1)
  dipole_mom_vec0(2)=dipole_moment(2)
  dipole_mom_vec0(3)=dipole_moment(3)
  write(log_file,*) 'Initial dipole moment: ',dipole_mom_vec0(1:3)

  if(read_initial_occupation) then
    
    write(log_file,*) "Reading file occ_time.inp for initial orbital occupations"
    open(1234,file='occ_time.inp')
    do i=1,N_total_orbitals
      read(1234,*)occupation(i)
  	  write(log_file,*) i,occupation(i)
    end do
    close(1234)
    
    call calculate_rho_grid
    dipole_mom_vec0(1)=dipole_moment(1)
    dipole_mom_vec0(2)=dipole_moment(2)
    dipole_mom_vec0(3)=dipole_moment(3)
    write(log_file,*) 'Dipole After removal: ',dipole_mom_vec0(1:3)
  
  endif

  
  call Hamiltonian_density ! init for master. Should only run on the master.
  
  call print_orbital_energy_components_header
  call generate_full_td_pot(0,1.d0)
  call Total_Energy_grid_c(0)
  write(log_file,*)'Starting Energy',Energy
  PREV_ENE=Energy
  PREV_ENE10=Energy

  write(log_file,*)'number of electrons',sum(density)*grid_volume

  if (output_td_psi) call output_Psi_c(0)
  
  if(do_dealloc_psi) deallocate(Psi) ! save memory
  
  if(output_full_td_density) call output_td_density(0)
  if(output_full_td_current_density) call output_td_current_density(0)
  if(output_orbitals) call save_complex_orbitals(0)  
  if(output_orbitals2) call save_complex_orbitals2(0)
  if(output_full_td_sp_energy) call output_td_SP_energy()
  !if(output_inner_product) call print_projection_file_header !Arthur
  !if(output_inner_product) call update_projection_file(0) !Arthur
  if(output_td_current_cell_sum) then
    open(td_current_cell_sum_file,file=trim(adjustl(td_current_cell_sum_filename)),action='write',status='replace')
  endif 
  if(output_td_current_atom_sum) then
    allocate(td_current_atom_sum(3,N_total_atom))
	call do_td_current_plane_sum(0)
  end if
  
  if(use_projectile) then
    call init_projectile_stuff
  end if

end subroutine taylor_time_init_MASTER

subroutine init_projectile_stuff
implicit none

  projectile_energy0=projectile_energy
  write(log_file,*)'Parameters of the projectile'
  write(log_file,*)'particle mass [in eV*fs^2/Ang^2]: ',projectile_mass
  write(log_file,*)'particle mass [in gram/mol]: ',projectile_mass/mass_convfactor
  write(log_file,*)'particle charge [in elem. charges]: ',projectile_charge
  write(log_file,*)'point of start (x0,y0,z0) [Ang]: '
  write(log_file,*) '  ',projectile_x0,projectile_y0,projectile_z0
  write(log_file,*)'initial velocity (vx0,vy0,vz0) [Ang/fs]: '
  write(log_file,*) '  ',projectile_vx,projectile_vy,projectile_vz
  write(log_file,*)'initial speed [Ang/fs]: ',projectile_v0
  write(log_file,*)'initial speed [fraction of speed of light]: ',projectile_v0/c_light
  write(log_file,*)'initial energy [eV]: ',projectile_energy0
  write(log_file,*)'initial energy [fraction of particle rest energy]: ', &
                  projectile_energy0/(projectile_mass*c_squared)
  write(log_file,*)'initial de Broglie wavelength [Ang]: ', &
                    hbar*2*pi/(projectile_mass*projectile_v0)
                  !Relativistic expression:
                  !!(hbar*2*pi/projectile_mass)*sqrt(1/projectile_v0**2-1/c_squared)
  write(log_file,*)'initial direction (nx,ny,nz) [unit vector]:  '
  write(log_file,*) '  ',projectile_nx,projectile_ny,projectile_nz
  write(log_file,*)'projectile potential softening parameter: ',projectile_potential_soft_param

end subroutine init_projectile_stuff

subroutine sort_tasks(n_orb_needed)
implicit none
integer :: i,j,n_orb_needed

MPItask_orbital_map=0
j=0 ! first process is 0
do i=1,n_orb_needed
  if((only_propagate_occupied).AND.(occupation(i)<1.d-9)) then
    MPItask_orbital_map(i)=-99
	write(log_file,*) "Orb ",i," has no Occupation and will not be assigned to a task"
  else
    MPItask_orbital_map(i)=j
    write(log_file,*) "Orb ",i," will be on task ",j
    j=j+1
    ! the last one is MPI_num_proc-1. 
	! must handle case where last orbital does nlPP
	if(split_up_gen_nlpp) then
	  if(j>=MPI_num_proc-1) j=0
	  write(log_file,*) "Skip nlPP process",MPI_num_proc-1
	else
      if(j>=MPI_num_proc) j=0
	end if
  end if
end do

end subroutine sort_tasks

subroutine update_potential_MPI(iter)
implicit none
integer :: iter

	if(MPI_master) then
	  call generate_full_td_pot(iter,1.d0)
	endif
	
	! Broadcast all the potentials to the other tasks
    if(spin_polarized) then
      call MPI_BCAST(V_full_pot_up  ,N_lattice_points,MPI_DOUBLE_COMPLEX,0,taylor_time_communicator,MPI_ierror)
	  if(MPI_ierror/=0) call check_mpi_error(MPI_ierror,100)
	  call MPI_BCAST(V_full_pot_down,N_lattice_points,MPI_DOUBLE_COMPLEX,0,taylor_time_communicator,MPI_ierror)
	  if(MPI_ierror/=0) call check_mpi_error(MPI_ierror,200)
    else
      call MPI_BCAST(V_full_pot,N_lattice_points,MPI_DOUBLE_COMPLEX,0,taylor_time_communicator,MPI_ierror)
	  if(MPI_ierror/=0) call check_mpi_error(MPI_ierror,300)
    end if
	
	! V_l_pp+V_Hartree+V_Exchange_down+V_td
	if(print_orb_ene_comp_split) then
	  call MPI_BCAST(V_l_pp,N_lattice_points,MPI_DOUBLE_PRECISION,0,taylor_time_communicator,MPI_ierror)
	  if(MPI_ierror/=0) call check_mpi_error(MPI_ierror,400)
	  call MPI_BCAST(V_Hartree,N_lattice_points,MPI_DOUBLE_PRECISION,0,taylor_time_communicator,MPI_ierror)
	  if(MPI_ierror/=0) call check_mpi_error(MPI_ierror,500)
	  call MPI_BCAST(V_Exchange,N_lattice_points,MPI_DOUBLE_PRECISION,0,taylor_time_communicator,MPI_ierror)
	  if(MPI_ierror/=0) call check_mpi_error(MPI_ierror,600)
	  call MPI_BCAST(V_td,N_lattice_points,MPI_DOUBLE_PRECISION,0,taylor_time_communicator,MPI_ierror)
	  if(MPI_ierror/=0) call check_mpi_error(MPI_ierror,700)
	end if

end subroutine update_potential_MPI

subroutine check_energies_all_MPI(iter)
implicit none
integer :: iter,p1,i
logical :: test_passed=.true.
real*8  :: ene_diff


  p1=Lattice_inv_xyz(N_Lattice(1)/2,N_Lattice(2)/2,N_Lattice(3)/2)
  write(log_file,*) p1
  do i=1,N_orbitals
    write(log_file,*) "orb ",i,Psi_c(p1,i)
    write(log_file,'(10ES17.7E3)') Psi_c(1:10,i)
	write(log_file,'(10ES17.7E3)') Psi_c(N_Lattice_points-10:N_Lattice_points,i)
  end do
  do i=1,N_orbitals
    phi_c(:)=Psi_c(:,i)
    call kinetic_c(phi_c,T_phi_c)
    write(log_file,*) i,T_phi_c(p1)
  end do
  call SP_Energy_grid_c_SIMPLE(iter)
  if(MPI_master) then
    sp_energy_save(:)=Sp_energy(:)
  end if
  call MPI_BCAST(sp_energy_save,N_orbitals,MPI_DOUBLE_PRECISION,0,taylor_time_communicator,MPI_ierror)
  if(MPI_ierror/=0) call check_mpi_error(MPI_ierror,800)
  write(log_file,*) "---- ENERGY DIFFERENCES ------"
  do i=1,N_orbitals
    ene_diff=(sp_energy_save(i) - Sp_energy(i))
	if(abs(ene_diff)>1.d-5) test_passed=.FALSE.
	write(log_file,*) i,ene_diff
  end do
  if(test_passed .EQV. .FALSE.) then
    write(log_file,*) "MPI energy test failed."
	stop
  endif
  
end subroutine check_energies_all_MPI

subroutine check_forces_MPI
implicit none
real*8 :: f_compare(3,N_total_atom)
integer :: atom,ai,elem

  call calculate_force_MPI()
  f_compare=force
  if(MPI_master) then
    call calculate_force()
    do atom=1,N_total_atom
      ai=atom_index(atom)
      elem=z_atom(ai)
      write(log_file,'(1x,a3,9(1x,e16.9))') &
        element_symbols(elem),force(1:3,atom),f_compare(1:3,atom),(force(1:3,atom)-f_compare(1:3,atom))
    enddo
  end if

  ! send to all procs (only really needed on MPI_nlpp_slave)
  call MPI_BCAST(force,3*N_total_atom,MPI_DOUBLE_PRECISION,0,MPI_COMM_WORLD,MPI_ierror)
  if(MPI_ierror/=0) call check_mpi_error(MPI_ierror,900)
	  

end subroutine check_forces_MPI

subroutine trans_force_split_nl_PP_MPI
implicit none
 integer :: status(MPI_STATUS_SIZE)
 real*8  :: buf_force(3,N_total_atom)
 
	call MPI_BARRIER(MPI_COMM_WORLD, MPI_ierror)
	if(MPI_master) then
	  call MPI_Send(force,3*N_total_atom,MPI_DOUBLE_PRECISION,MPI_nlpp_process,99,MPI_COMM_WORLD,MPI_ierror)
	  if(MPI_ierror/=0) call check_mpi_error(MPI_ierror,1000)
	else if(MPI_nlpp_slave) then
	  call MPI_Recv(force,3*N_total_atom,MPI_DOUBLE_PRECISION,0,99,MPI_COMM_WORLD,status,MPI_ierror)
	  if(MPI_ierror/=0) call check_mpi_error(MPI_ierror,1100)
	end if
	call MPI_BARRIER(MPI_COMM_WORLD, MPI_ierror)
	if(MPI_master) then
	  call MPI_Recv(buf_force,3*N_total_atom,MPI_DOUBLE_PRECISION,MPI_nlpp_process,98,MPI_COMM_WORLD,status,MPI_ierror)
	  if(MPI_ierror/=0) call check_mpi_error(MPI_ierror,1200)
      if(abs(sum(buf_force-force))>1.d-6) then
	    write(log_file,*) "error sending force to nl_pp_slave ",abs(sum(buf_force-force))
		stop
	  end if
	else if(MPI_nlpp_slave) then
	  buf_force=force
	  call MPI_Send(buf_force,3*N_total_atom,MPI_DOUBLE_PRECISION,0,98,MPI_COMM_WORLD,MPI_ierror)
	  if(MPI_ierror/=0) call check_mpi_error(MPI_ierror,1300)
	end if

end subroutine trans_force_split_nl_PP_MPI

SUBROUTINE MPI_handle_molecular_dynamics(iter)
implicit none
integer,intent(in) :: iter
integer :: diff,atom,iter_check
real*4  :: t1,t2


  if(split_up_gen_nlpp) then
    
    diff=iter-MPI_nlpp_iter_advance
	write(log_file,*) "MOVE ATOMS",iter,MPI_nlpp_iter_advance
    if(diff==atomic_movement_frequency) then
      ! handle cases of 1st iter or restart
	  	  
	  call trans_force_split_nl_PP_MPI

	  if(MPI_nlpp_slave) then
        call make_atom_movement(iter)
		write(log_file,*) "SPECIAL nlpp_slave make_atom_movement ",iter
	  end if
	else if(diff/=0) then
	  write(log_file,*) "iteration=",iter
	  write(log_file,*) "MPI_nlpp_iter_advance=",MPI_nlpp_iter_advance
	  write(log_file,*) "Something is not right"
	end if
    ! get coordinates, V_l_pp and nlPP from the MPI_nlpp_process
	call sync_nl_pp_MPI
	call sync_split_md_MPI
	call MPI_BARRIER(MPI_COMM_WORLD, MPI_ierror)
	if(MPI_master) call Ion_Ion_Energy
	
	call CPU_TIME(propagator_time_t2)
    if(iter<20.AND.MPI_master.AND.diff==0) write(*,*) "WF prop time ",propagator_time_t2-propagator_time_t1
	
	! calculate force at the new position
	call CPU_TIME(t1)
	if(.NOT.MPI_nlpp_slave) call calculate_force_MPI()
	call CPU_TIME(t2)
	if (save_timings.AND.MPI_master) write(timing_file,*) "call calculate_force_MPI()",t2-t1
	if(iter<20.AND.MPI_master) write(*,*) "calculate force ",t2-t1

    call trans_force_split_nl_PP_MPI
	
	call CPU_TIME(propagator_time_t1)
	! the one process takes a step and recomputes the nl_pp
	if(MPI_nlpp_slave) then
	  call CPU_TIME(t1)
	  call make_atom_movement(iter+atomic_movement_frequency)
	  call CPU_TIME(t2)
	  if(iter<20) write(*,*) "move atoms and do nl PP ",t2-t1
	end if
	MPI_nlpp_iter_advance=iter+atomic_movement_frequency
  else 
      call CPU_TIME(t1)
      if(MPI_master) call make_atom_movement(iter)
      call sync_nl_pp_MPI
	  call CPU_TIME(t2)
	  if(iter<20.AND.MPI_master) write(*,*) "move and gen nl_pp ",t2-t1
	  ! requires updated density
      call MPI_BARRIER( taylor_time_communicator, MPI_ierror)
	  call CPU_TIME(t1)
	  call calculate_force_MPI()
	  !write(333760+MPI_proc_rank,*) iter,force(1,1)
	  call CPU_TIME(t2)
	  if (save_timings.AND.MPI_master) write(timing_file,*) "call calculate_force_MPI()",t2-t1
	  
	  ! used to check if forces are correct
	  !call pull_Psi_c_MPI
	  !call check_forces_MPI
	  
  end if
  
  if(MPI_proc_rank==MPI_nlpp_process) then
    if (print_ion_forces) then
      if (mod(iter,trajectory_output_frequency)==0) then
        call print_ion_xyzTofile_wN_Elec(iter,iter*time_step)    
        call print_ion_forcesTofile(iter,iter*time_step)
      end if
    endif
  end if
  
end subroutine MPI_handle_molecular_dynamics

subroutine taylor_time_init_OLD
integer :: i,k
real*8  :: x,y,z,t,a_0,p0x,p0y,p0z


! time propagation of wave packet
if(tddft_type==3) then
allocate(Phi_wp(N_Lattice_points),density_wp(N_lattice_points),Phi_o_wp(N_lattice_points))
! initialize wave packet
a_0=wp_width(1)
p0x=wp_momentum(1)
p0y=wp_momentum(2)
p0z=wp_momentum(3)
t=0.d0
write(log_file,*)'Wave_packet momentum',wp_momentum
write(log_file,*)'Wave_packet center',wp_center
do i=1,N_lattice_points
  x=grid_point(1,i)-wp_center(1)
  y=grid_point(2,i)-wp_center(2)
  z=grid_point(3,i)-wp_center(3)
  Phi_wp(i)=Gauss_wave_packet_3d(x,y,z,t,a_0,p0x,p0y,p0z)
end do
  if(use_high_energy_wp) then

  else
    write(log_file,*)'initial wave_packet norm',sum(abs(Phi_wp)**2)*grid_volume
    Phi_c=Phi_wp
    call Hamiltonian_wavefn_c(Phi_c,H_Phi_c)
    write(log_file,*)'initial wave_packet energy',sum(Conjg(Phi_c)*H_Phi_c)*Grid_Volume
  endif
endif

  write(log_file,*) "Propagator set to ",trim(adjustl(propagator))

end subroutine taylor_time_init_OLD

subroutine taylor_time_step_wave_packet(it)
integer :: it
! not yet supported
end subroutine taylor_time_step_wave_packet

subroutine update_ene_comp_MPI(it,sw)
  integer :: k,n,it,i
  real*8  :: sw,orb_ene_comp(7)
  
  do k=1,N_orbitals
    ! only do it orbital is assigned to this process
    if(MPItask_orbital_map(k)==MPI_proc_rank) then
      do i=1,N_Lattice_points    
        Phi_c(i)=Psi_c(i,k) ! Psi_c is at time t
      enddo    
    
      if(spin_polarized) then
        if(k<N_orbitals_down+1) then
          spin_down=.TRUE.
          spin_up=.FALSE.
        else
          spin_up=.TRUE.
          spin_down=.FALSE.
        endif
      endif  

	    if(print_orb_ene_comp_split) then
          call Hamiltonian_wavefn_c2(Phi_c,H_Phi_c)
		else
		  call Hamiltonian_wavefn_c(Phi_c,H_Phi_c)
		endif
		  sp_energy_save(k)=SUM(conjg(Phi_c)*H_Phi_c)*grid_volume
		  norm_save(k)=SUM(conjg(Phi_c)*Phi_c)*grid_volume
		  if(print_orb_ene_comp_split) then
		    orb_ene_comp(1)=SUM(conjg(Phi_c)*V_full_pot*Phi_c)*grid_volume
			orb_ene_comp(2)=SUM(conjg(Phi_c)*V_l_pp*Phi_c)*grid_volume
			orb_ene_comp(3)=SUM(conjg(Phi_c)*V_hartree*Phi_c)*grid_volume
			orb_ene_comp(4)=SUM(conjg(Phi_c)*V_Exchange*Phi_c)*grid_volume
			orb_ene_comp(5)=SUM(conjg(Phi_c)*V_td*Phi_c)*grid_volume
			orb_ene_comp(6)=SUM(conjg(Phi_c)*T_Phi_c)*grid_volume
			orb_ene_comp(7)=REAL(SUM(conjg(Phi_c)*V_nl_pp_c)*grid_volume)
			write(orb_ene_comp_split_filebase+k,'(F12.4,9ES26.16E3)') &
			  it*time_step,sp_energy_save(k),orb_ene_comp(1:7),norm_save(k)
		  end if
	else ! not an orbital this thread is doing...
	  sp_energy_save(k)=0.d0
	endif
  enddo
end subroutine update_ene_comp_MPI

subroutine taylor_time_step_MPI(it,sw)
  integer :: k,n,it,i
  real*8  :: sw,orb_ene_comp(7)
  complex*16 :: tc_n

  sp_energy_save=0.d0
  norm_save=0.d0
  
  do k=1,N_orbitals
    ! only do it orbital is assigned to this process
    if(MPItask_orbital_map(k)==MPI_proc_rank) then
      do i=1,N_Lattice_points    
        Phi_c(i)=Psi_c(i,k) ! Psi_c is at time t
      enddo    
    
      if(spin_polarized) then
        if(k<N_orbitals_down+1) then
          spin_down=.TRUE.
          spin_up=.FALSE.
        else
          spin_up=.TRUE.
          spin_down=.FALSE.
        endif
      endif  
      do n=1,N_taylor
	    if(print_orb_ene_comp_split) then
          call Hamiltonian_wavefn_c2(Phi_c,H_Phi_c)
		else
		  call Hamiltonian_wavefn_c(Phi_c,H_Phi_c)
		endif
		if(n==1) then
		  sp_energy_save(k)=SUM(conjg(Phi_c)*H_Phi_c)*grid_volume
		  norm_save(k)=SUM(conjg(Phi_c)*Phi_c)*grid_volume
		  if(print_orb_ene_comp_split) then
		    orb_ene_comp(1)=SUM(conjg(Phi_c)*V_full_pot*Phi_c)*grid_volume
			orb_ene_comp(2)=SUM(conjg(Phi_c)*V_l_pp*Phi_c)*grid_volume
			orb_ene_comp(3)=SUM(conjg(Phi_c)*V_hartree*Phi_c)*grid_volume
			orb_ene_comp(4)=SUM(conjg(Phi_c)*V_Exchange*Phi_c)*grid_volume
			orb_ene_comp(5)=SUM(conjg(Phi_c)*V_td*Phi_c)*grid_volume
			orb_ene_comp(6)=SUM(conjg(Phi_c)*T_Phi_c)*grid_volume
			orb_ene_comp(7)=REAL(SUM(conjg(Phi_c)*V_nl_pp_c)*grid_volume)
			write(orb_ene_comp_split_filebase+k,'(F12.4,9ES26.16E3)') &
			  it*time_step,sp_energy_save(k),orb_ene_comp(1:7),norm_save(k)
		  end if
        endif
		do i=1,N_Lattice_points
          Phi_c(i)=H_Phi_c(i)
        enddo  
        tc_n=tc(n)
        do i=1,N_Lattice_points  
          Psi_c(i,k)=Psi_c(i,k)+tc_n*Phi_c(i)
        enddo  
      enddo
	  ! Psi_c is at time t+dt
	else ! not an orbital this thread is doing...
	  sp_energy_save(k)=0.d0
	endif

  enddo
end subroutine taylor_time_step_MPI

subroutine taylor_time_step(it,sw)
  integer :: k,n,it,i
  real*8  :: sw
  complex*16 :: tc_n

  do k=1,N_orbitals
    orbital_index=k
    do i=1,N_Lattice_points    
      Phi_c(i)=Psi_c(i,k)
    enddo    
    
    if(spin_polarized) then
      if(k<N_orbitals_down+1) then
        spin_down=.TRUE.
        spin_up=.FALSE.
      else
        spin_up=.TRUE.
        spin_down=.FALSE.
      endif
    endif  
    do n=1,N_taylor
      call Hamiltonian_wavefn_c(Phi_c,H_Phi_c)
      do i=1,N_Lattice_points  
        Phi_c(i)=H_Phi_c(i)
      enddo  
      tc_n=tc(n)
      do i=1,N_Lattice_points  
        Psi_c(i,k)=Psi_c(i,k)+tc_n*Phi_c(i)
      enddo  
    enddo
  enddo
end subroutine taylor_time_step


subroutine taylor_time_step_subset(it,sw)
  integer :: k,n,it,i,n_start
  real*8  :: sw
  complex*16 :: tc_n

  n_start=N_orbitals-n_orb_prop+1
  do k=n_start,N_orbitals
    orbital_index=k
    !$omp parallel do default(shared) private (i)
    do i=1,N_Lattice_points    
      Phi_c(i)=Psi_c(i,k)
    enddo  
    !$omp end parallel do     
    
    if(spin_polarized) then
      if(k<N_orbitals_down+1) then
        spin_down=.TRUE.
        spin_up=.FALSE.
      else
        spin_up=.TRUE.
        spin_down=.FALSE.
      endif
    endif  
    do n=1,N_taylor
      call Hamiltonian_wavefn_c(Phi_c,H_Phi_c)
      !$omp parallel do default(shared) private (i)
      do i=1,N_Lattice_points  
        Phi_c(i)=H_Phi_c(i)
      enddo  
      !$omp end parallel do
      tc_n=tc(n)
      !$omp parallel do default(shared) private (i)
      do i=1,N_Lattice_points  
        Psi_c(i,k)=Psi_c(i,k)+tc_n*Phi_c(i)
      enddo  
      !$omp end parallel do 
    enddo
  enddo
end subroutine taylor_time_step_subset

subroutine taylor_time_evolution
  select case (tddft_type)
    case(1)
      write(log_file,*)'tddft_type: time_propagation_optical_absorbtion'
	  write(log_file,*) "NOT SUPPORTED IN PARALLEL MODE"
	  STOP
    case(2)
      write(log_file,*)'tddft_type: time_propagation_laser'
      call taylor_time_evolution_laser
    case(3)
      write(log_file,*)'tddft_type: time_propagation_wave_packet'
	  write(log_file,*) "NOT SUPPORTED IN PARALLEL MODE"
	  STOP
    case(4)
      write(log_file,*)'tddft_type: taylor_time_evolution_projectile'
	  write(log_file,*) "MODE DEPRECIATED USE tddft_type=2"
	  STOP
    case(5)
      write(log_file,*)'tddft_type: taylor_time_source_injection'
	  write(log_file,*) "NOT SUPPORTED IN PARALLEL MODE"
	  STOP
      call source_prop
    case default
      write(log_file,*)'no tddft_type is defined'
      stop
  end select
end subroutine taylor_time_evolution



subroutine advance_projectile(iter)
!Advances projectile position based on classical Newtonian mechanics
integer  :: iter,i
real(8)  :: pos_x,pos_y,pos_z,vx,vy,vz,time_step_proj_fine

!if(projectile_fine_eom) then
!  time_step_proj_fine=time_step/projectile_fine_eom_inum
!  do i=1,projectile_fine_eom_inum
!    call compute_force_on_projectile(projectile_f)
!    pos_x=projectile_x
!    vx=projectile_vx
!    projectile_x=pos_x+vx*time_step_proj_fine+0.5d0*projectile_invmass*projectile_f(1)*time_step_proj_fine**2
!    projectile_vx=vx+projectile_invmass*projectile_f(1)*time_step_proj_fine
!    projectile_x_prev=pos_x
!    pos_y=projectile_y
!    vy=projectile_vy
!    projectile_y=pos_y+vy*time_step_proj_fine+0.5d0*projectile_invmass*projectile_f(2)*time_step_proj_fine**2
!    projectile_vy=vy+projectile_invmass*projectile_f(2)*time_step_proj_fine
!    projectile_y_prev=pos_y
!    pos_z=projectile_z
!    vz=projectile_vz
!    projectile_z=pos_z+vz*time_step_proj_fine+0.5d0*projectile_invmass*projectile_f(3)*time_step_proj_fine**2
!    projectile_vz=vz+projectile_invmass*projectile_f(3)*time_step_proj_fine
!    projectile_z_prev=pos_z	
!  end do
!else
 if (iter>1) then
  !If second or more iteration then use the usual Verlet algoritm
  pos_x=projectile_x
  projectile_x=2*pos_x-projectile_x_prev+projectile_invmass*projectile_f(1)*time_step**2
  projectile_vx=(1.5d0*projectile_x-2*pos_x+0.5d0*projectile_x_prev)/time_step
  projectile_x_prev=pos_x
  pos_y=projectile_y
  projectile_y=2*pos_y-projectile_y_prev+projectile_invmass*projectile_f(2)*time_step**2
  projectile_vy=(1.5d0*projectile_y-2*pos_y+0.5d0*projectile_y_prev)/time_step
  projectile_y_prev=pos_y
  pos_z=projectile_z
  projectile_z=2*pos_z-projectile_z_prev+projectile_invmass*projectile_f(3)*time_step**2
  projectile_vz=(1.5d0*projectile_z-2*pos_z+0.5d0*projectile_z_prev)/time_step
  projectile_z_prev=pos_z
 endif
 if (iter==1) then
  !If first iteration then calculate forces on projectile using Taylor expansion
  pos_x=projectile_x
  vx=projectile_vx
  projectile_x=pos_x+vx*time_step+0.5d0*projectile_invmass*projectile_f(1)*time_step**2
  projectile_vx=vx+projectile_invmass*projectile_f(1)*time_step
  projectile_x_prev=pos_x
  pos_y=projectile_y
  vy=projectile_vy
  projectile_y=pos_y+vy*time_step+0.5d0*projectile_invmass*projectile_f(2)*time_step**2
  projectile_vy=vy+projectile_invmass*projectile_f(2)*time_step
  projectile_y_prev=pos_y
  pos_z=projectile_z
  vz=projectile_vz
  projectile_z=pos_z+vz*time_step+0.5d0*projectile_invmass*projectile_f(3)*time_step**2
  projectile_vz=vz+projectile_invmass*projectile_f(3)*time_step
  projectile_z_prev=pos_z
 endif

!end if

projectile_energy=0.5d0*projectile_mass*(projectile_vx**2+projectile_vy**2+projectile_vz**2)
!Calculate force. This call is done even if it is the zero-th order iteration
call compute_force_on_projectile(projectile_f)

end subroutine advance_projectile


subroutine taylor_time_evolution_laser
  integer :: i,j,k,restart_last_i,orbital,starting_timestep
  real*4  :: t1,t2,ctime1,ctime2,t7
  real(8) :: rcsum(3)
  logical :: need_current
  !Open files for dipole moment data (time vs. dp), and write the appropriate header for analysis with the program "optprop".
  !Note, the parameter kick_strength may need to be revised; it is a constant factor used in optprop.
 

  call taylor_time_init_ALL ! init stuff but MPI is not set up yet
  
  if(MPI_master) then 
    call taylor_time_init_MASTER
    call sort_tasks(N_orbitals)
    call open_formatted_file(avec_file,"avec_file.txt",append_or_overwrite)
    write(avec_file,'(a)') "#time        A(x)           A(y)           A(z)         E(x)        E(y)        E(z)"
  endif
  
  call taylor_time_init_ALL_part2

  !  cody    mask function and volkov propagation need tasks sorted to open right files.
  if(use_mask_volkov) then
	call init_Volkov
  end if

  starting_timestep=1
 
  if(resume_from_restart_taylor) then
	if(MPI_master) then
	  write(log_file,*) "#Loading all parameters from restart file"
      call do_read_restart_MPI(starting_timestep)
	  if(change_name_monitor) then
	    write(log_file,*) "...Change Restart filename back to monitor.out ..."
	    close(log_file)
		log_output_filename="monitor.out"
		open(log_file,file=trim(adjustl(log_output_filename)), status="old", position="append", action="write")
		write(log_file,*) "#Resume from restart file at iteration ",starting_timestep
	  end if
	else
	  write(log_file,*) "Waiting to Load all parameters from restart file"
	end if
	starting_timestep=starting_timestep+1 ! loop ended on previous step. Must increment
	call do_restart_broadcast_MPI(starting_timestep)
	if(MPI_master) then
      call background()
      call create_pseudo_potential() 
      call local_pseudo_potential()  
      call ion_ion_energy()
	end if
    call sync_nl_pp_MPI
	write(log_file,*) "# # Resume job at step ",starting_timestep
  endif
  
  if(split_up_gen_nlpp .AND. MPI_nlpp_slave) then
    MPI_nlpp_iter_advance=starting_timestep-1
	! at timestep 1 MPI_nlpp_iter_advance should be 0, same for restart condition
	call nl_pp_slave_timeloop(starting_timestep)
	! nl_pp_slave completes timeloop and skips time loop below.
	starting_timestep=n_time_steps+1 
  else
    call MPI_BARRIER( taylor_time_communicator, MPI_ierror)  
  end if 
  
  do i=starting_timestep,n_time_steps

    call CPU_TIME(t7)
	
	call update_potential_MPI(i)
	
	call Avec_update(i,1)
	call MPI_BARRIER( taylor_time_communicator, MPI_ierror)
	
	call CPU_TIME(t1)
    if(propagator=="taylor") then
       call taylor_time_step_MPI(i,1.d0)
    else if(propagator=="none") then
       call update_ene_comp_MPI(i,1.d0)
	else
	   write(*,*) "invalid propagator",trim(adjustl(propagator))
	   stop	  
    end if
	
    call CPU_TIME(t2) 
	ctime_propagator=ctime_propagator+t2-t1
	if (save_timings.AND.MPI_master) write(timing_file,*)"Propagator ",t2-t1
	if(i<5.AND.MPI_master) write(*,*) "propagator ",t2-t1
	
    if(use_mask_volkov) then
	  if(mod(i,mask_func_freq)==0) then
	    call CPU_TIME(t1)
        call mask_volkov_time_step(i)
		call CPU_TIME(t2) 
		if(MPI_master) write(log_file,*) "do_mask_function_step CPUTIME=",t2-t1
      end if
	  if(maskV_save_multi_PES) then
	    if(mod(i,maskV_save_multi_PES_freq)==0) then
		  call pull_volkov_stuff
		  if(MPI_master) call maskV_save_multi_PES_bovANDtxt(i)
		  maskV_mom_multi=0.d0
		end if
	  end if
	end if  
	
    if((output_inner_product).AND.(mod(i,output_inner_product_frequency)==0)) then
      call calc_GS_projection_MPI(i)
    end if
	
	! each process calculates the density for the orbitals it propagated.
    if(MPI_debug==77) then
	  call pull_Psi_c_MPI
	  if(MPI_master) then
	    call calculate_rho_grid
	  endif
	else
	  call calculate_rho_grid_MPI
    endif
	
	buf_norm_save=norm_save
	buf_sp_energy_save=sp_energy_save
	call MPI_Reduce(buf_sp_energy_save,sp_energy_save,N_orbitals,MPI_DOUBLE_PRECISION,MPI_SUM,0,taylor_time_communicator,MPI_ierror)
	if(MPI_ierror/=0) call check_mpi_error(MPI_ierror,1500)
    call MPI_Reduce(buf_norm_save     ,norm_save     ,N_orbitals,MPI_DOUBLE_PRECISION,MPI_SUM,0,taylor_time_communicator,MPI_ierror)
	if(MPI_ierror/=0) call check_mpi_error(MPI_ierror,1600)
	call MPI_BARRIER( taylor_time_communicator, MPI_ierror)
	
	if (mod(i,orb_en_comp_output_frequency)==0) then
	  call pull_Psi_c_MPI
	  if(MPI_master) call print_orbital_energy_components_MPI(i)
	endif
	
	if(MPI_master .OR. MPI_xc_slave) then
      call CPU_TIME(t1)
	  ! updates V_hartree on Master
      ! updates V_Exchange on Master with LDA
	  ! updates V_Exchange on xc_slave with GGA or LIBXC and sends to master
	  !  V_full_pot will get updated on all process when generate_full_td_pot is called
      call Hamiltonian_density_split
	end if
	if(MPI_master) then
	  if(mod(i,calc_energy_freq)==0) then
        call Total_Energy_grid_c_MPI(i)
        if (save_timings) write(timing_file,*)trim(adjustl(propagator)),&
		 "time_evolution_laser: call to Total_Energy_grid_c",t2-t1
        write(log_file,'(a,3es30.16e3)') "INFOLINE: ",i*time_step,sum(Density)*grid_volume,Energy
    	
	  end if
      call CPU_TIME(t2)
	  if (save_timings) write(timing_file,*)"Gen Hamiltonian ",t2-t1
      if(i<5) write(*,*) "Gen Hamiltonian propagator ",t2-t1
    endif

     if ((output_td_psi).AND.(mod(i,psi_output_frequency)==0)) then
        call output_Psi_c_MPI(i) 
     end if

    if((move_atoms) .AND. (mod(i,atomic_movement_frequency)==0)) then
      
	  call MPI_handle_molecular_dynamics(i)	  
      
	endif
	
	if(MPI_master) then

        if(output_full_td_current_density.AND.(mod(i,td_current_density_output_frequency)==0)) then
          call compute_td_current_density()
          time1=i
          call output_td_current_density(i)
    	  if (save_timings) write(timing_file,*)trim(adjustl(propagator)),&
		   "time_evolution_laser: call to output_td_current_density",t2-t1
        endif
    
        ! If enabled, append this time step's density to a file
        if(output_full_td_density.AND.(mod(i,td_density_output_frequency)==0)) then
          call CPU_TIME(t1)
          call output_td_density(i)
          call CPU_TIME(t2)
        endif
    
    	call update_dipole_moment
        dipole_mom_vec(:)=dipole_mom_vec(:)-dipole_mom_vec0(:)
        write(dipole_x_file,'(4ES16.8)')i*time_step,dipole_mom_vec(1:3)
    	 
    	 if ( switch_mode ) then
    	   call check_switch_conditions(i)
    	 end if	
    	 
    	 if(stop_tddft_calc) exit
		 
         if(use_projectile) then
		   call handle_projectile(i)
		 end if
		
	 endif
	 
	
	if(write_restart.AND.(mod(i,restart_update_frequency)==0)) then
	  call pull_Psi_c_MPI
	  if(use_mask_volkov) call pull_volkov_stuff
	  if(MPI_master) call do_write_restart_MPI(i)
	end if

   	if(write_restart.AND.(mod(i,100)==0)) then
   	   call check_for_stop_file_MPI(i)
   	end if	

    call CPU_TIME(t2) 
	if (save_timings.AND.MPI_master) write(timing_file,*)"Step ",t2-t7
	

	 
  enddo ! END TIME LOOP ------------------------------
  close(avec_file)
  close(dipole_x_file)
  close(dipole_y_file)
  close(dipole_z_file)
  
  !  cody   
  if(use_mask_volkov) then
    if(maskV_save_PES) then
	  call pull_volkov_stuff
      if(MPI_master) call maskV_save_PES_bovANDtxt(n_time_steps)
	  if(MPI_master) call maskV_save_PES_bov_orb(n_time_steps)
	end if
    call clean_up_volkov
  end if  

  call timings_taylor
  
  call taylor_loop_done_output
  
!  if(split_op_save_imagt_gs) then
!  !  Psi_c=Psi
!    do i=1,N_orbitals
!      do j=1,N_lattice_points
!        Psi(j,i)=abs(Psi_c(j,i))
!      enddo
!    enddo    
!  end if
  
end subroutine taylor_time_evolution_laser

SUBROUTINE handle_projectile(iter)
implicit none
integer :: iter
   if(projectile_fine_eom) then 
     ! projectile movement is done in make_atom_movement
   else
     call advance_projectile(iter)
   endif
   write(log_file,'(a,f12.5,es28.16e3,es28.16e3,3f12.5)') "PINFO: ",iter*time_step,projectile_energy,tot_kin_energy_ions,projectile_x,projectile_y,projectile_z

    if (iter==1) then
      energy_init_elec=energy
      energy_init_ions=tot_kin_energy_ions
    endif
    if (iter==n_time_steps) then
      energy_final_elec=energy
      energy_final_ions=tot_kin_energy_ions
    endif
	
     if(projectile_calc_near_elec) then
	   call calc_elec_near_projectile(iter)
	 endif

END SUBROUTINE handle_projectile

SUBROUTINE taylor_loop_done_output
implicit none
real*8 :: s
  if(use_projectile) then
    write(log_file,*) 'Energy transfer data [all values in eV]'
    write(log_file,*) 'Initial electronic energy:         ',energy_init_elec
    write(log_file,*) 'Initial kin. energy of ions:       ',energy_init_ions
    write(log_file,*) 'Final electronic energy:           ',energy_final_elec
    write(log_file,*) 'Final kin. energy of ions:         ',energy_final_ions
    write(log_file,*) 'Change in electronic energy:       ',energy_final_elec-energy_init_elec
    write(log_file,*) 'Change in kin. energy of ions:     ',energy_final_ions-energy_init_ions
    write(log_file,*) 'Total amount of energy transferred:', &
         energy_final_elec+energy_final_ions-energy_init_elec-energy_init_ions
    write(log_file,*) 'Initial projectile energy:         ',projectile_energy0
    s=1/sqrt(projectile_vx**2+projectile_vy**2+projectile_vz**2)
    projectile_nx=projectile_vx*s
    projectile_ny=projectile_vy*s
    projectile_nz=projectile_vz*s
    write(log_file,*) 'Final projectile energy:           ',projectile_energy
    write(log_file,*) 'Change in projectile energy:       ',projectile_energy-projectile_energy0
    write(log_file,*) 'Initial projectile velocity direction (nx,ny,nz) [unit vector]:'
    write(log_file,*) '  ',projectile_nx0,projectile_ny0,projectile_nz0
    write(log_file,*) 'Final projectile velocity direction (nx,ny,nz) [unit vector]:'
    write(log_file,*) '  ',projectile_nx,projectile_ny,projectile_nz
  end if

end SUBROUTINE taylor_loop_done_output

!cody
subroutine calc_td_DS_psi_c(iter)
implicit none
integer    :: iter,k,i,j,filenumber777=777
real*8     :: curtime,norm(N_orbitals),dipstr
complex*16 :: exptval
  
   curtime=iter*time_step
  ! use V_td
  open(filenumber777,POSITION='APPEND')
  write(filenumber777,'(e14.6)',advance='no') curtime
  if(using_v_fromfile) then
    write(filenumber777,'(e14.6)',advance='no') laser_xyz_t_iteration(1)
	write(filenumber777,'(e14.6)',advance='no') laser_xyz_t_iteration(2)
	write(filenumber777,'(e14.6)',advance='no') laser_xyz_t_iteration(3)
  else
    write(filenumber777,'(e14.6)',advance='no') factor_laser1
	write(filenumber777,'(e14.6)',advance='no') factor_laser2
	write(filenumber777,'(e14.6)',advance='no') factor_laser3
  end if
  do k=1,N_orbitals
    ! first normalize
	norm(k)=sum(conjg(Psi_C(:,k))*Psi_C(:,k))*grid_volume
  end do
  do k=1,N_orbitals
    ! first normalize
    do j=k+1,N_orbitals
	  exptval=sum(conjg(Psi_C(:,j))*V_td(:)*Psi_C(:,k))*grid_volume/sqrt(norm(j)*norm(k))
	  dipstr=conjg(exptval)*exptval
	  write(filenumber777,'(e19.12)',advance='no') dipstr
	end do
  end do
  close(filenumber777)
end subroutine calc_td_DS_psi_c

subroutine output_largest_offdiag_elem()
integer  i
end subroutine output_largest_offdiag_elem

function Gauss_wave_packet_3d(x,y,z,t,a,p0x,p0y,p0z)
!This function computes the value of a 3D Gausian wave packet propagating in free space.
!Parameters:
!  x,y,z [in Angstrom] - spatial coordinates of the point where the packet needs to be computed
!  t [in femtosec]    - time
!  a [in Angstrom]    - spatial width of the packet at t=0
!  p0x,p0y,p0z [in eV*fs/Angstrom] - the average momentum of the electron in the wave packet
!  KE=0.5mv^2 = 0.5p^2/m   sqrt(KE*2*m)=p
!It is assumed that the following global constants have been defined
!  hbar=0.658211899d0 [eV*fs]; H2M=3.80998174348d0 [eV*Angstom^2]; ElectronMass=hbar*hbar/(2*H2M) [eV*Angstom^2]
!
!It is also possible to use atomic units for input/output of this function. In this case one needs
!to pass all input values in atomic units while the global constants must be set as follows:
!  hbar=1.0;  H2M=0.5d0;  ElectronMass=1.0d0;
real(8)            :: x,y,z,t,a,p0x,p0y,p0z
complex(8)         :: Gauss_wave_packet_3d,fx,fy,fz,dc
real(8), parameter :: invm=1/ElectronMass
real(8), parameter :: invhbar=1/hbar

dc=1.d0+2*zi*hbar*invm*t/a**2
fx=(2.d0/(pi*a**2*dc**2))**0.25d0*exp(-(x-invm*p0x*t)**2/(a**2*dc))*exp(zi*invhbar*p0x*(x-0.5d0*invm*p0x*t))
fy=(2.d0/(pi*a**2*dc**2))**0.25d0*exp(-(y-invm*p0y*t)**2/(a**2*dc))*exp(zi*invhbar*p0y*(y-0.5d0*invm*p0y*t))
fz=(2.d0/(pi*a**2*dc**2))**0.25d0*exp(-(z-invm*p0z*t)**2/(a**2*dc))*exp(zi*invhbar*p0z*(z-0.5d0*invm*p0z*t))
Gauss_wave_packet_3d=fx*fy*fz

end function Gauss_wave_packet_3d

function Gauss_wave_packet_3d_as(x,y,z,t,ax,ay,az,p0x,p0y,p0z)
!This function computes the value of a 3D Gausian wave packet propagating in free space.
!Parameters:
!  x,y,z [in Angstrom] - spatial coordinates of the point where the packet needs to be computed
!  t [in femtosec]    - time
!  ax,ay,az [in Angstrom]    - spatial width of the packet at t=0
!  p0x,p0y,p0z [in eV*fs/Angstrom] - the average momentum of the electron in the wave packet
!
!It is assumed that the following global constants have been defined
!  hbar=0.658211899d0 [eV*fs]; H2M=3.80998174348d0 [eV*Angstom^2]; ElectronMass=hbar*hbar/(2*H2M) [eV*Angstom^2]
!
!It is also possible to use atomic units for input/output of this function. In this case one needs
!to pass all input values in atomic units while the global constants must be set as follows:
!  hbar=1.0;  H2M=0.5d0;  ElectronMass=1.0d0;
real(8)            :: x,y,z,t,ax,ay,az,p0x,p0y,p0z
complex(8)         :: Gauss_wave_packet_3d_as,fx,fy,fz,dc_x,dc_y,dc_z
real(8), parameter :: invm=1/ElectronMass
real(8), parameter :: invhbar=1/hbar

dc_x=1.d0+2*zi*hbar*invm*t/ax**2
dc_y=1.d0+2*zi*hbar*invm*t/ay**2
dc_z=1.d0+2*zi*hbar*invm*t/az**2
fx=(2.d0/(pi*ax**2*dc_x**2))**0.25d0*exp(-(x-invm*p0x*t)**2/(ax**2*dc_x))*exp(zi*invhbar*p0x*(x-0.5d0*invm*p0x*t))
fy=(2.d0/(pi*ay**2*dc_y**2))**0.25d0*exp(-(y-invm*p0y*t)**2/(ay**2*dc_y))*exp(zi*invhbar*p0y*(y-0.5d0*invm*p0y*t))
fz=(2.d0/(pi*az**2*dc_z**2))**0.25d0*exp(-(z-invm*p0z*t)**2/(az**2*dc_z))*exp(zi*invhbar*p0z*(z-0.5d0*invm*p0z*t))
Gauss_wave_packet_3d_as=fx*fy*fz
end function Gauss_wave_packet_3d_as

function Gauss_wave_packet_1d(x,t,a,p0x)
!This function computes the value of a 1D Gausian wave packet propagating in free space.
!Parameters:
!  x [in Angstrom] - spatial coordinates of the point where the packet needs to be computed
!  t [in femtosec]    - time
!  a [in Angstrom]    - spatial width of the packet at t=0
!  p0x [in eV*fs/Angstrom] - the average momentum of the electron in the wave packet
!
!It is assumed that the following global constants have been defined
!  hbar=0.658211899d0 [eV*fs]; H2M=3.80998174348d0 [eV*Angstom^2]; ElectronMass=hbar*hbar/(2*H2M) [eV*Angstom^2]
!
!It is also possible to use atomic units for input/output of this function. In this case one needs
!to pass all input values in atomic units while the global constants must be set as follows:
!  hbar=1.0;  H2M=0.5d0;  ElectronMass=1.0d0;
real(8)            :: x,t,a,p0x
complex(8)         :: Gauss_wave_packet_1d,fx,dc
real(8), parameter :: invm=1/ElectronMass
real(8), parameter :: invhbar=1/hbar

dc=1.d0+2*zi*hbar*invm*t/a**2
fx=(2.d0/(pi*a**2*dc**2))**0.25d0*exp(-(x-invm*p0x*t)**2/(a**2*dc))*exp(zi*invhbar*p0x*(x-0.5d0*invm*p0x*t))
Gauss_wave_packet_1d=fx

end function Gauss_wave_packet_1d


SUBROUTINE print_orbital_energy_components_header
    integer :: orbital,nc,j,nspaces
    integer,parameter  :: reclength=20
    integer,parameter  :: backmargin=3
    character(reclength)  str1,strorb
    character(2*reclength),parameter :: spstr=' '
    
    nc = 9.d0
    nc = nc+(2+min(6,orb_en_comp_output_level))*N_orbitals
    if(use_projectile) then 
        nc=nc+1
    end if
    
    write(orbital_energy_components_file,'(2x,a2)',advance='no') '#1'
    write(orbital_energy_components_file,'(18x,a2)',advance='no') '#2'    
    do j=3,nc
        write(orbital_energy_components_file,'(1x,i19)',advance='no') j
    end do
    write(orbital_energy_components_file,*)
    
    write(orbital_energy_components_file,'(2x,a)',advance='no') '#iter'
    write(orbital_energy_components_file,'(8x,a,3x)',advance='no') '#time[fs]'

    do orbital=1,N_orbitals
        write(strorb,*) orbital
        
        write(str1,*) 'occupation',trim(adjustl(strorb))
        nspaces=reclength-backmargin-len_trim(str1)
        write(orbital_energy_components_file,'(a)',advance='no') spstr(1:nspaces)
        write(orbital_energy_components_file,'(a)',advance='no') trim(str1)
        write(orbital_energy_components_file,'(a)',advance='no') spstr(1:backmargin)
        
        write(str1,*) 'energy',trim(adjustl(strorb)),'[eV]'
        nspaces=reclength-backmargin-len_trim(str1)
        write(orbital_energy_components_file,'(a)',advance='no') spstr(1:nspaces)
        write(orbital_energy_components_file,'(a)',advance='no') trim(str1)
        write(orbital_energy_components_file,'(a)',advance='no') spstr(1:backmargin)
        
        if(orb_en_comp_output_level>=1) then
            write(str1,*) 'l_pp',trim(adjustl(strorb)),'[eV]'
            nspaces=reclength-backmargin-len_trim(str1)
            write(orbital_energy_components_file,'(a)',advance='no') spstr(1:nspaces)
            write(orbital_energy_components_file,'(a)',advance='no') trim(str1)
            write(orbital_energy_components_file,'(a)',advance='no') spstr(1:backmargin)
        end if  
        
        if(orb_en_comp_output_level>=2) then
            write(str1,*) 'hartree',trim(adjustl(strorb)),'[eV]'
            nspaces=reclength-backmargin-len_trim(str1)
            write(orbital_energy_components_file,'(a)',advance='no') spstr(1:nspaces)
            write(orbital_energy_components_file,'(a)',advance='no') trim(str1)
            write(orbital_energy_components_file,'(a)',advance='no') spstr(1:backmargin) 
        end if
        
        if(orb_en_comp_output_level>=3) then
            write(str1,*) 'exchange',trim(adjustl(strorb)),'[eV]'
            nspaces=reclength-backmargin-len_trim(str1)
            write(orbital_energy_components_file,'(a)',advance='no') spstr(1:nspaces)
            write(orbital_energy_components_file,'(a)',advance='no') trim(str1)
            write(orbital_energy_components_file,'(a)',advance='no') spstr(1:backmargin)        
        end if

        if(orb_en_comp_output_level>=4) then
            write(str1,*) 'nl_pp',trim(adjustl(strorb)),'[eV]'
            nspaces=reclength-backmargin-len_trim(str1)
            write(orbital_energy_components_file,'(a)',advance='no') spstr(1:nspaces)
            write(orbital_energy_components_file,'(a)',advance='no') trim(str1)
            write(orbital_energy_components_file,'(a)',advance='no') spstr(1:backmargin)
        end if
        
        if(orb_en_comp_output_level>=5) then
            write(str1,*) 'kinetic',trim(adjustl(strorb)),'[eV]'
            nspaces=reclength-backmargin-len_trim(str1)
            write(orbital_energy_components_file,'(a)',advance='no') spstr(1:nspaces)
            write(orbital_energy_components_file,'(a)',advance='no') trim(str1)
            write(orbital_energy_components_file,'(a)',advance='no') spstr(1:backmargin)         
        end if
            
        if(orb_en_comp_output_level>=6) then
            write(str1,*) 'timeDep',trim(adjustl(strorb)),'[eV]'
            nspaces=reclength-backmargin-len_trim(str1)
            write(orbital_energy_components_file,'(a)',advance='no') spstr(1:nspaces)
            write(orbital_energy_components_file,'(a)',advance='no') trim(str1)
            write(orbital_energy_components_file,'(a)',advance='no') spstr(1:backmargin)
        end if
    end do
    
    write(orbital_energy_components_file,'(5x,a,3x)',advance='no') 'numElectrons'
    write(orbital_energy_components_file,'(4x,a,3x)',advance='no') 'Sp_energy[eV]'
    write(orbital_energy_components_file,'(6x,a,3x)',advance='no') 'hartree[eV]'
    write(orbital_energy_components_file,'(6x,a,3x)',advance='no') 'ion_ion[eV]'
    write(orbital_energy_components_file,'(5x,a,3x)',advance='no') 'exchange[eV]'        
    write(orbital_energy_components_file,'(8x,a,3x)',advance='no') 'ha+xc[eV]'
    if(use_projectile) then
        write(orbital_energy_components_file,'(2x,a,3x)',advance='no') 'proj_energy[eV]'
    end if
    write(orbital_energy_components_file,'(2x,a,3x)',advance='no') 'totalEnergy[eV]'
    
    write(orbital_energy_components_file,*)
    flush(orbital_energy_components_file)
    
END SUBROUTINE print_orbital_energy_components_header

subroutine print_orbital_energy_components_MPI(it)
implicit none
integer :: it,orbital

  write(orbital_energy_components_file,'(1x,i6)',advance='no') it
  write(orbital_energy_components_file,'(1x,e19.12)',advance='no') it*time_step
  do orbital=1,N_orbitals
    Phi_c=Psi_c(:,orbital)
    write(orbital_energy_components_file,'(1x,e19.12)',advance='no') sum(abs(Phi_c)**2)*occupation(orbital)*grid_volume
	write(orbital_energy_components_file,'(1x,e19.12)',advance='no') sp_energy_save(orbital)
  enddo

  write(orbital_energy_components_file,*)
  flush(orbital_energy_components_file)

end subroutine print_orbital_energy_components_MPI

!Arthur
subroutine output_Psi_c(iter)
!outputs the Psi into a binary file
    integer        :: iter
    integer        :: atom,ai,pl
    character(255) :: fname1,fname2
    character(5)   :: ch5
   
    write(ch5,'(i5.5)') td_psi_counter
    
    pl=len_trim(psi_data_filename_prefix)
    write(fname1,'(a,a,a)') psi_data_filename_prefix(1:pl),ch5(1:5),'.dat'

    open(psi_data_file,file=trim(adjustl(fname1)),form='unformatted',status='replace')
    if (using_injection) then
    write(psi_data_file) Phi_source
    else
    write(psi_data_file) Psi_c(:,1:N_orbitals)
    endif
    close(psi_data_file)
    
    !output the structure at the corresponding time
    pl=len_trim(structure_output_filename_prefix)
    write(fname2,'(a,a,a)') structure_output_filename_prefix(1:pl),ch5(1:5),'.dat'
    
    open(structure_output_file,file=trim(adjustl(fname2)))
    write(structure_output_file,*) "#",iter
    write(structure_output_file,'(12x,i3,12x,i3,12x,i3,12x,i3)') N_total_atom,N_atom_L,N_atom_C,N_atom_R
    do atom=1,N_total_atom
        ai=atom_index(atom)
        write(structure_output_file,'(3(F20.14,1x))',advance='no') Position(1,atom),Position(2,atom),Position(3,atom)
        write(structure_output_file,'(i3,2x,i3)') z_atom(ai),box_atom(atom)
    end do
    if(grid_step(1)==grid_step(2) .AND. grid_step(1)==grid_step(3)) then
        write(structure_output_file,*) grid_step(1),n_lattice(1),n_lattice(2),n_lattice(3)
    else
        write(structure_output_file,*)grid_step(1),grid_step(2),grid_step(3),n_lattice(1),n_lattice(2),n_lattice(3)
    end if
    
    close(structure_output_file)
        
    td_psi_counter=td_psi_counter+1
    
end subroutine output_Psi_c

subroutine pull_Psi_c_MPI
implicit none
integer :: i,j,task_w_orb
integer :: MPI_TAG=1
  do i=1,N_orbitals
    task_w_orb=MPItask_orbital_map(i)
    if(MPI_master) then
	  if(task_w_orb==MPI_proc_rank) then ! this is the master task
		! orbital is already here on master task. Do nothing
	    
	  else
	    call MPI_RECV(Phi_c,N_lattice_points,MPI_DOUBLE_COMPLEX,task_w_orb,MPI_TAG,taylor_time_communicator, &
		              MPI_STATUS_IGNORE,MPI_ierror)
		if(MPI_ierror/=0) call check_mpi_error(MPI_ierror,1700)
		Psi_c(:,i)=Phi_c(:)
	  end if
	else if(task_w_orb==MPI_proc_rank) then
	    Phi_c(:)=Psi_c(:,i)
	    call MPI_SEND(Phi_c,N_lattice_points,MPI_DOUBLE_COMPLEX,0,MPI_TAG,taylor_time_communicator,MPI_ierror)
		if(MPI_ierror/=0) call check_mpi_error(MPI_ierror,1800)
	end if
	call MPI_BARRIER( taylor_time_communicator, MPI_ierror)
  end do
  
end subroutine pull_Psi_c_MPI

subroutine output_Psi_c_MPI(iter)
!outputs the Psi into a binary file
    integer        :: iter
    integer        :: atom,ai,pl,orbital,i
    character(255) :: fname1,fname2
    character(5)   :: ch5
	complex*16     :: buf_psi_c(N_Lattice_points,N_orbitals)

    do orbital=1,N_orbitals
	  if(MPItask_orbital_map(orbital)==MPI_proc_rank) then
	   ! do nothing
      else
	    Psi_c(:,orbital)=0.d0
	  end if
	end do
    
	i=N_Lattice_points*N_orbitals
	buf_psi_c=Psi_c
	call MPI_Reduce(buf_psi_c,Psi_c,i,MPI_DOUBLE_COMPLEX,MPI_SUM,0,taylor_time_communicator,MPI_ierror)
	if(MPI_ierror/=0) call check_mpi_error(MPI_ierror,1900)
	
	if(MPI_master) then
      write(ch5,'(i5.5)') td_psi_counter
      
      pl=len_trim(psi_data_filename_prefix)
      write(fname1,'(a,a,a)') psi_data_filename_prefix(1:pl),ch5(1:5),'.dat'
      
      open(psi_data_file,file=trim(adjustl(fname1)),form='unformatted',status='replace')
      write(psi_data_file) Psi_c(:,1:N_orbitals)
      close(psi_data_file)
      
      td_psi_counter=td_psi_counter+1
    end if 
	
end subroutine output_Psi_c_MPI

!cody
subroutine restart_file_read_laser(iter)
!
   integer        :: iter,getiter
    character(255) :: fname1,fnameuse
    character(7)   :: ch7
   integer         :: j=898989

   ! ------------------ laser file------------------------
   fnameuse=restart_file_lasername
   open(j,file=trim(adjustl(fnameuse)),form='unformatted',action='read')
   read(j) getiter
   read(j) A_vec
   read(j) A_vec_int
   read(j) A_vec_2_int
   close(j)
   if(getiter/=iter) then
      write (log_file,*) 'iterations do not match between restart files ',iter,' vs ',getiter
	  stop     
   end if
   ! --------------------------------------------------------
   ! ------------------ volkov file------------------------
  if(use_mask_volkov) then
   fnameuse=restart_file_volkname
   open(j,file=trim(adjustl(fnameuse)),form='unformatted',action='read')
   read(j) getiter
   read(j) Psi_volkov
   close(j)
     if(getiter/=iter) then
      write (log_file,*) 'iterations do not match between Volkov restart files ',iter,' vs ',getiter
	  stop     
     end if
  end if
   ! --------------------------------------------------------
   ! ------------------ volkov PES file------------------------
  if(maskV_save_PES) then
   fnameuse=restart_file_mPESname
   open(j,file=trim(adjustl(fnameuse)),form='unformatted',action='read')
   read(j) getiter
   read(j) maskV_mom_final
   close(j)
     if(getiter/=iter) then
      write (log_file,*) 'iterations do not match between PES restart files ',iter,' vs ',getiter
	  stop     
     end if
  end if
   ! --------------------------------------------------------
end subroutine restart_file_read_laser

!cody
subroutine restart_file_update_laser(iter)
!outputs the Psi,iteration, into a binary file
   integer        :: iter
    character(255) :: fname1,fnameuse
    character(7)   :: ch7
   integer         :: j=898989
   ! rename/move to keep a 2nd copy. Do not keep all restarts with VOlkov. Too much data
   ! ------------------ laser file------------------------
   fnameuse=restart_file_lasername
   write(fname1,'(a,a)') 'backup_',trim(adjustl(restart_file_lasername))
   call rename(trim(adjustl(fnameuse)),trim(adjustl(fname1)))
   ! open all files at once to prevent possible errors from full disk
   open(j,file=trim(adjustl(fnameuse)),form='unformatted',status='replace',action='write')
   
   write(j) iter
   write(j) A_vec
   write(j) A_vec_int
   write(j) A_vec_2_int
   close(j)
   ! --------------------------------------------------------
   ! ------------------ volkov file------------------------
  if(use_mask_volkov) then
   fnameuse=restart_file_volkname
   write(fname1,'(a,a)') 'backup_',trim(adjustl(fnameuse))
   call rename(trim(adjustl(fnameuse)),trim(adjustl(fname1)))
   ! open all files at once to prevent possible errors from full disk
   open(j,file=trim(adjustl(fnameuse)),form='unformatted',status='replace',action='write')
   
   write(j) iter
   write(j) Psi_volkov
   close(j)
  end if
   ! --------------------------------------------------------
   ! ------------------ volkov PES file------------------------
  if(maskV_save_PES) then
   fnameuse=restart_file_mPESname
   write(fname1,'(a,a)') 'backup_',trim(adjustl(fnameuse))
   call rename(trim(adjustl(fnameuse)),trim(adjustl(fname1)))
   ! open all files at once to prevent possible errors from full disk
   open(j,file=trim(adjustl(fnameuse)),form='unformatted',status='replace',action='write')
   
   write(j) iter
   write(j) maskV_mom_final
   close(j)
  end if
   ! --------------------------------------------------------
end subroutine restart_file_update_laser

!cody
subroutine restart_file_update_elec(iter)
!outputs the Psi,iteration, into a binary file
   integer        :: iter
    character(255) :: fname1,fname2
    character(7)   :: ch7
   
   if( keep_all_restart ) then
      write(ch7,'(i7.7)') iter
	  write(fname1,'(a,a)') 'saved_RESTART_electronic_',ch7
	  write(fname2,'(a,a)') 'saved_RESTART_iter_',ch7
      call rename(trim(adjustl(restart_file_elecname)),trim(adjustl(fname1)))
      call rename(trim(adjustl(restart_file_itername)),trim(adjustl(fname2)))
   else 
      ! rename/move to keep a 2nd copy
      call rename(trim(adjustl(restart_file_elecname)),'backup_RESTART_electronic')
      call rename(trim(adjustl(restart_file_itername)),'backup_RESTART_iter')
   end if
 ! open all files at once to prevent possible errors from full disk
   open(restart_file_electronic,file=trim(adjustl(restart_file_elecname)),form='unformatted',status='replace',action='write')
   open(restart_file_iter,file=trim(adjustl(restart_file_itername)),status='replace',action='write')
   write(restart_file_electronic) iter
   write(restart_file_electronic) N_lattice_points
   write(restart_file_electronic) N_orbitals
   write(restart_file_electronic) Psi_c(:,1:N_orbitals)
   write(restart_file_electronic) density(:)
   write(restart_file_electronic) Occupation(1:N_orbitals)
   close(restart_file_electronic)
   write(restart_file_iter,'(i15)') iter
   close(restart_file_iter)
   
end subroutine restart_file_update_elec
  
!cody
subroutine restart_file_read_elec(iter)
!reads the Psi_c,iteration,ion positions, and ion velocities from a binary file
   integer        :: iter,iter_check,N_lat_check,N_orb_check
   
   open(restart_file_electronic,file=trim(adjustl(restart_file_elecname)),form='unformatted')
   read(restart_file_electronic) iter
   read(restart_file_electronic) N_lat_check
   read(restart_file_electronic) N_orb_check
   read(restart_file_electronic) Psi_c(:,1:N_orbitals)
   read(restart_file_electronic) density(:)
   read(restart_file_electronic) Occupation(1:N_orbitals)
   close(restart_file_electronic)
   if(N_lat_check .NE. N_lattice_points) then
      write (log_file,*) 'Lattice points do not match! ',N_lattice_points,' vs ',N_lat_check
	  stop   
   end if
   if(N_orb_check .NE. N_orbitals) then
      write (log_file,*) 'Number of orbitals do not match! ',N_orbitals,' vs ',N_orb_check
	  stop   
   end if
   open(restart_file_iter,file=trim(adjustl(restart_file_itername)))
   read(restart_file_iter,'(i15)') iter_check
   close(restart_file_iter)
   if(iter .NE. iter_check) then
      write (log_file,*) 'iterations do not match between restart files ',iter,' vs ',iter_check
	  stop
   end if
end subroutine restart_file_read_elec

!cody
subroutine restart_file_update_ion(iter)
!outputs ion positions (including previous position, and ion velocities into a binary file
   integer        :: iter
    character(255) :: fname1
    character(7)   :: ch7
   
   if( keep_all_restart ) then
      write(ch7,'(i7.7)') iter
	  write(fname1,'(a,a)') 'saved_RESTART_ion_',ch7
      call rename(trim(adjustl(restart_file_ionname)),trim(adjustl(fname1)))
   else 
     ! rename/move to keep a 2nd copy
     call rename(trim(adjustl(restart_file_ionname)),'backup_RESTART_ion')
   end if

   open(restart_file_ion,file=trim(adjustl(restart_file_ionname)),form='unformatted',status='replace',action='write')
   write(restart_file_ion) iter
   write(restart_file_ion) N_total_atom
   write(restart_file_ion) Position(:,:)
   write(restart_file_ion) Position_prev(:,:)
   write(restart_file_ion) atom_velocity(:,:)
   close(restart_file_ion)
end subroutine restart_file_update_ion  

!cody
subroutine restart_file_read_ion(iter)
   integer        :: iter,iter_check,N_atom_check
   open(restart_file_ion,file=trim(adjustl(restart_file_ionname)),form='unformatted')
   read(restart_file_ion) iter_check
   read(restart_file_ion) N_atom_check
   read(restart_file_ion) Position(:,:)
   read(restart_file_ion) Position_prev(:,:)
   read(restart_file_ion) atom_velocity(:,:)
   close(restart_file_ion)
   if(N_atom_check .NE. N_total_atom) then
      write (log_file,*) 'Number of atoms do not match! ',N_total_atom,' vs ',N_atom_check
	  stop   
   end if
   if(iter .NE. iter_check) then
      write (log_file,*) 'iterations do not match between restart files ',iter,' vs ',iter_check
	  stop
   end if
end subroutine restart_file_read_ion

!cody
subroutine restart_file_update_proj(iter)
!outputs projectile positions (including previous position, and ion velocities into a binary file
   integer        :: iter
    character(255) :: fname1
    character(7)   :: ch7

   open(restart_file_proj,file=trim(adjustl(restart_file_projname)),form='unformatted',status='replace',action='write')
   write(restart_file_proj) iter
   write(restart_file_proj) projectile_x
   write(restart_file_proj) projectile_y
   write(restart_file_proj) projectile_z
   write(restart_file_proj) projectile_x_prev
   write(restart_file_proj) projectile_y_prev
   write(restart_file_proj) projectile_z_prev
   write(restart_file_proj) projectile_vx
   write(restart_file_proj) projectile_vy
   write(restart_file_proj) projectile_vz
   write(restart_file_proj) projectile_f
   close(restart_file_proj)
end subroutine restart_file_update_proj

!cody
subroutine restart_file_read_proj(iter)
   integer        :: iter,iter_check
   open(restart_file_proj,file=trim(adjustl(restart_file_projname)),form='unformatted')
   read(restart_file_proj) iter_check
   read(restart_file_proj) projectile_x
   read(restart_file_proj) projectile_y
   read(restart_file_proj) projectile_z
   read(restart_file_proj) projectile_x_prev
   read(restart_file_proj) projectile_y_prev
   read(restart_file_proj) projectile_z_prev
   read(restart_file_proj) projectile_vx
   read(restart_file_proj) projectile_vy
   read(restart_file_proj) projectile_vz
   read(restart_file_proj) projectile_f
   close(restart_file_proj)
   if(iter .NE. iter_check) then
      write (log_file,*) 'iterations do not match between restart files of projectile',iter,' vs ',iter_check
	  stop
   end if
end subroutine restart_file_read_proj

subroutine taylor_time_step_injection(t)
  implicit none
  integer     :: n,kpoint,i,t

  kpoint=1
  
  Phi_c=Phi_source
  do n=1,N_taylor
    call Hamiltonian_wavefn_c(Phi_c,H_Phi_c)
    do i=1,N_Lattice_points
      Phi_c(i)=H_Phi_c(i)
    end do
    Phi_source=Phi_source+tc(n)*Phi_c
  end do

end subroutine taylor_time_step_injection

subroutine inject_save_points_init
implicit none
  integer           :: i,j,k,inject_file_num
  
  inject_num_points_save=0
  do i=1,N_lattice_points
    if( (Lattice(1,i)>=inject_save_x_left).AND.(Lattice(1,i)<=inject_save_x_right) ) then
	  if( (Lattice(2,i)>=inject_save_y_left).AND.(Lattice(2,i)<=inject_save_y_right) ) then
	    if( (Lattice(3,i)>=inject_save_z_left).AND.(Lattice(3,i)<=inject_save_z_right) ) then
		  inject_num_points_save=inject_num_points_save+1
		end if
	  end if
	end if
  end do
  write(log_file,*) 'write out complex wf at ',inject_num_points_save,'points'
  write(log_file,*) ' See files fort.50000+'
  allocate(inject_points_map(inject_num_points_save))

  inject_num_points_save=0
  do i=1,N_lattice_points
    if( (Lattice(1,i)>=inject_save_x_left).AND.(Lattice(1,i)<=inject_save_x_right) ) then
	  if( (Lattice(2,i)>=inject_save_y_left).AND.(Lattice(2,i)<=inject_save_y_right) ) then
	    if( (Lattice(3,i)>=inject_save_z_left).AND.(Lattice(3,i)<=inject_save_z_right) ) then
		  inject_num_points_save=inject_num_points_save+1
		  inject_points_map(inject_num_points_save)=i
		  write(50000+inject_num_points_save,'(a,3f10.5)') '##XYZ ',grid_point(1,i),grid_point(2,i),grid_point(3,i) 
		  write(log_file,'(a,i6,a,3f10.5)') 'save GP ',&
		    inject_num_points_save,' at ',grid_point(1,i),grid_point(2,i),grid_point(3,i)
		end if
	  end if
	end if
  end do  

end subroutine inject_save_points_init

subroutine inject_save_points(iter)
implicit none
  integer    :: i,j,iter
  
  do i=1,inject_num_points_save
    j=inject_points_map(i)
    write(50000+i,'(f10.5,2es24.16)') iter*time_step,real(phi_source(j)),imag(phi_source(j))
  end do

end subroutine inject_save_points

subroutine source_prop
  implicit none
  integer  :: it,i1,i2,i3,i,ns,j,n
  double precision  :: dx(N_Lattice(1)),x0,dy(n_lattice(2)),e,norm,t1,t2
  real*8 :: sconvergence,snorm1,snorm2,dnorm1,t,ramp
  complex*8 :: sconvergence_c
  allocate(phi_source(n_lattice_points))
  allocate(Phi_source_density(n_lattice_points)) 
  allocate(Psi_c(N_lattice_points,N_orbitals))
  allocate(Phi_source_previous(n_lattice_points))
  allocate(Phi_source_density_previous(n_lattice_points))
  if(.not.allocated(sing_prec_rearranged_density)) allocate(sing_prec_rearranged_density(n_lattice_points))
 ! e=0.1d0
  !ns=30
  sconvergence=0.d0
  snorm1=0.d0
  snorm2=0.d0
  sconvergence_c=cmplx(0.d0,0.d0)
  phi_source=cmplx(0.d0,0.d0)
  Phi_source_previous=cmplx(0.d0,0.d0)
  Phi_source_density_previous=0.0d0
 call taylor_time_init_ALL
 if(MPI_master) call taylor_time_init_MASTER
 if(debug_output_level >= 2) write(log_file,*) "allocate wlap_p"
 if (.not.allocated(wlap_p)) allocate(wlap_p(3,N_Lattice_points))
 if(debug_output_level >= 2) write(log_file,*) "Set Psi_c"
 
 do i=1,N_orbitals
    do j=1,N_lattice_points
	  !if(debug_output_level >= 3) write(log_file,'(2i5,es17.8e3)') j,i,Psi(j,i)
	  if(periodic) then
	    Psi_c(j,i)=Psi_p(j,i,1)
	  else
        Psi_c(j,i)=cmplx(Psi(j,i),0.d0,8)
      end if
	enddo
 enddo
 call calculate_rho_grid
 call Hamiltonian_density
 write(log_file,*)'Starting Energy',Energy
write(log_file,*)'number of electrons',sum(density)*grid_volume
if(output_full_td_density) call output_td_density(0)
if(output_full_td_current_density) call output_td_current_density(0)
if (output_td_psi) call output_Psi_c(0)   
  ! it=1
     ! if(lattice(1,i)==inject_x.and.lattice(2,i)==inject_y.and.lattice(3,i)==inject_z) then
       ! phi_source(i)=exp(-zi*injection_E*it*time_step)
       ! norm=Conjg(phi_source(i))*phi_source(i)
       ! phi_source(i)=exp(-zi*e*it*time_step)/sqrt(norm)
     ! endif

  norm=0.d0
  n=0
  if(inject_source_nonsingular) then
     do i=1,n_lattice_points
           if(((lattice(1,i)>=injection_x1).and.(lattice(1,i)<=injection_x2))&
		   .and.((lattice(2,i)>=injection_y1).and.(lattice(2,i)<=injection_y2))&
		   .and.((lattice(3,i)>=injection_z1).and.(lattice(3,i)<=injection_z2))) then
           n=n+1
           endif

     enddo
  else
     do i=1,n_lattice_points
           if(((lattice(1,i)==injection_x1).and.(lattice(2,i)==injection_y1).and.(lattice(3,i)==injection_z1))) then
              n=n+1
			  write(log_file,*) 'Injection at grid point ',lattice(1,i),',',lattice(2,i),',',lattice(3,i)
			  write(log_file,*) ' or ',grid_point(1,i),',',grid_point(2,i),',',grid_point(3,i)
           endif
           if(((lattice(1,i)==injection_p2_x1).and.(lattice(2,i)==injection_p2_y1).and.(lattice(3,i)==injection_p2_z1))) then
              n=n+1
			  write(log_file,*) 'Injection at grid point ',lattice(1,i),',',lattice(2,i),',',lattice(3,i)
			  write(log_file,*) ' or ',grid_point(1,i),',',grid_point(2,i),',',grid_point(3,i)
           endif
     enddo
	 if(n==0) then
	    write(log_file,*) 'Injection at ',n,' Lattice points!'
		stop
	 endif
  endif
  write(log_file,*) 'Injection at ',n,' Lattice points '
  
  if(inject_save_wf_points) then
    call inject_save_points_init
  end if
  
  do it=1,n_time_steps
     t=it*time_step
     ramp=1.d0
     if((ramp_time>0.d0).AND.(t<ramp_time)) ramp=t/ramp_time

   ! norm=sum(Conjg(phi_source(:))*phi_source(:))*grid_volume
     norm=0.d0
 !    if (grid_change)
      do i=1,n_lattice_points
	   ! cody   make controls more natural for injecting at a single point.
	   if(.NOT.inject_source_nonsingular) then
          if(((lattice(1,i)==injection_x1).and.(lattice(2,i)==injection_y1).and.(lattice(3,i)==injection_z1))) then
           phi_source(i)=exp(-zi*injection_E*it*time_step/hbar)
           norm=Conjg(phi_source(i))*phi_source(i)
           phi_source(i)=ramp*phi_source(i)/sqrt(norm)
          endif	   
          if(((lattice(1,i)==injection_p2_x1).and.(lattice(2,i)==injection_p2_y1).and.(lattice(3,i)==injection_p2_z1))) then
           phi_source(i)=exp(-zi*injection_p2_E*it*time_step/hbar)
           norm=Conjg(phi_source(i))*phi_source(i)
           phi_source(i)=ramp*phi_source(i)/sqrt(norm)
          endif	  
	   
	   else
          if(((lattice(1,i)>=injection_x1).and.(lattice(1,i)<=injection_x2))&
		  .and.((lattice(2,i)>=injection_y1).and.(lattice(2,i)<=injection_y2))&
		  .and.((lattice(3,i)>=injection_z1).and.(lattice(3,i)<=injection_z2))) then
           phi_source(i)=exp(-zi*injection_E*it*time_step/hbar)
           norm=Conjg(phi_source(i))*phi_source(i)
           phi_source(i)=ramp*phi_source(i)/sqrt(n*norm)
          endif
	   endif
	   ! IF NORMALIZING norm=norm + Conjg(phi_source(i))*phi_source(i)
    enddo
!endif	  ! cody normalize
      ! phi_source=phi_source/sqrt(norm)

    call taylor_time_step_injection(it)

    if(output_full_td_density.AND.(mod(it,td_density_output_frequency)==0)) then
      call CPU_TIME(t1)
      call output_td_density(it)
      call CPU_TIME(t2); write(timing_file,*)trim(adjustl(propagator)),&
	    "time_evolution_injection: call to output_td_density",t2-t1
    endif

	!cody
    if(output_source_td_density.AND.(mod(it,output_source_td_dens_frequency)==0)) then
	  dnorm1=0.d0
	  ! do not need to add grid volumne because it cancels out
	  do j=1,N_lattice_points
         Phi_source_density(j)=(real(phi_source(j))**2+imag(phi_source(j))**2)
		 dnorm1=dnorm1+Phi_source_density(j)
      enddo
	  Phi_source_density=Phi_source_density/dnorm1
	  call output_td_density_source(i)
	endif

    if(output_td_current_density_slices.AND.(mod(it,td_current_density_slice_output_frequency)==0)) then
      call CPU_TIME(t1)
	  td_current_density_slice_output_counter=td_current_density_slice_output_counter+1
      call do_output_td_current_density_slices(td_current_density_slice_output_counter,i*time_step)
      call CPU_TIME(t2)
	  if (save_timings) write(timing_file,*)trim(adjustl(propagator)),&
	    "time_evolution_laser: call to output_td_current_density",t2-t1
    endif
	
   !cody
    if( (it>inject_save_skip_nstep).AND.(mod(it,inject_save_freq)==0) ) then
	  call inject_save_points(it)
	end if
	
	! cody
    if (mod(it,source_check_congerg_freq)==0) then
	  do j=1,N_lattice_points
         Phi_source_density(j)=(real(phi_source(j))**2+imag(phi_source(j))**2)
      enddo
	  ! innerproducts no need for grid volumn 
	  sconvergence_c=sum(conjg(Phi_source_previous)*Phi_source)
	  snorm1=sum(conjg(Phi_source_previous)*Phi_source_previous)
	  snorm2=sum(conjg(Phi_source)*Phi_source)
	  if((snorm1 .NE. 0.d0).AND.(snorm2 .NE. 0.d0)) sconvergence_c = sconvergence_c/sqrt(snorm1*snorm2)
	  sconvergence=conjg(sconvergence_c)*sconvergence_c

	  write(log_file,'(i6,a,f15.10)') it,' source injection convergence ',sconvergence
	  Phi_source_previous=1.d0*Phi_source
	end if

    ! If enabled, append this time step's current density to a file
    if(output_full_td_current_density.AND.(mod(it,td_current_density_output_frequency)==0)) then
      call CPU_TIME(t1)
      time1=i
      call output_td_current_density(it)
      call CPU_TIME(t2); write(timing_file,*)trim(adjustl(propagator)),&
	    "time_evolution_injeciotn: call to output_td_current_density",t2-t1
    endif
    if(mod(it,1000)==0) write(6,*)it
    if(mod(it,td_current_density_output_frequency)==0) then
      write(6,*)it

      dx=0.d0
      dy=0.d0
      do i=1,n_lattice_points
        dx(Lattice(1,i)+1)=dx(Lattice(1,i)+1)+Conjg(phi_source(i))*phi_source(i)
        dy(Lattice(2,i)+1)=dy(Lattice(2,i)+1)+Conjg(phi_source(i))*phi_source(i)
      end do
      do i=1,N_Lattice(1)
        write(source_x,*)i,dx(i)
      end do
      write(source_y,*)
      do i=1,N_Lattice(2)
        write(source_y,*)i,dy(i)
      end do
      write(source_y,*)
    endif
if ((output_td_psi).AND.(mod(it,psi_output_frequency)==0)) then
        call output_Psi_c(it)
end if
enddo

  do i=1,n_lattice_points
    write(100,*)phi_source(i)
  end do

end subroutine source_prop

! cody
SUBROUTINE output_td_density_source(iter)
!This subroutine saves electron density of phi_source as bov format
integer :: iter
integer :: i,j,k,ind,pl,fnl,dk1,dk2,dk3,k1min,k2min,k3min,k1max,k2max,k3max
character(255) :: fname1,fname2
character(5)   :: ch5
character(16)  :: str1,str2,str3
k1min=N_Lattice_min(1)
k1max=N_Lattice_max(1)
k2min=N_Lattice_min(2)
k2max=N_Lattice_max(2)
k3min=N_Lattice_min(3)
k3max=N_Lattice_max(3)
dk1=(k1max-k1min+1)
dk2=(k2max-k2min+1)
dk3=(k3max-k3min+1)

!Bov format (bricks of data) which can easily be read by VisIt software.
!It is fast and reasonable in terms of disk space. Works only in the
!case of rectangular box
    write(ch5,'(i5.5)') td_density_counter_source
    pl=len_trim(td_total_density_filename_prefix)
    write(fname1,'(a,a,a,a)') 'source',td_total_density_filename_prefix(1:pl),ch5(1:5),'.dat'
    write(fname2,'(a,a,a,a)') 'source',td_total_density_filename_prefix(1:pl),ch5(1:5),'.bov'
    fnl=len_trim(fname1)
    !First write the density into a data file, which is of binary form.
    !Note that the density data is rearranged as z,y,x --> x,y,z (C-like
    !storage of array elements)  and converted to single precision before
    !saving it to disk (single precision is used to reduce disk usage).
    !Rearrangement must be done using an auxiliary array
    !(called sing_prec_rearranged_density) because the data cannot be
    !simply written into the binary file by making an appropriate do-loop
    !(writing an entire array at once and writing it step-by-step gives
    !different result in fortran when it is a binary file).
    ind=0
    do k=N_Lattice_min(3),N_Lattice_max(3)
      do j=N_Lattice_min(2),N_Lattice_max(2)
        do i=N_Lattice_min(1),N_Lattice_max(1)
          ind=ind+1
          if (Lattice_inv_xyz(i,j,k)>0) then
            sing_prec_rearranged_density(ind)=Phi_source_density(Lattice_inv_xyz(i,j,k))
          else
            sing_prec_rearranged_density(ind)=0.0d0
          endif
        enddo
      enddo
    enddo
    open(td_total_density_file,file=fname1,form='unformatted',status='replace')
    write(td_total_density_file) sing_prec_rearranged_density
    close(td_total_density_file)
    !Now create a header file corresponding to the above datafile. The header file
    !is in ascii text form
    open(td_total_density_file,file=fname2,status='replace')
    write(td_total_density_file,'(1x,a,1x,es23.15)') 'TIME:',iter*time_step
    write(td_total_density_file,'(1x,a,1x,a)') 'DATA_FILE:',fname1(1:fnl)
    write(td_total_density_file,'(1x,a,3(1x,i6))') 'DATA_SIZE:',dk1,dk2,dk3
    write(td_total_density_file,'(1x,a)') 'DATA_FORMAT:  FLOAT'
    write(td_total_density_file,'(1x,a)') 'VARIABLE:  density'
    write(td_total_density_file,'(1x,a)') 'DATA_ENDIAN:  LITTLE'
    write(td_total_density_file,'(1x,a)') 'CENTERING:  zonal'
    write(td_total_density_file,'(1x,a,3(1x,es23.15))') 'BRICK_ORIGIN:',xgrid(k1min),ygrid(k2min),zgrid(k3min)
    write(td_total_density_file,'(1x,a,3(1x,es23.15))') 'BRICK_SIZE:', &
        xgrid(k1max)-xgrid(k1min),ygrid(k2max)-ygrid(k2min),zgrid(k3max)-zgrid(k3min)
    write(td_total_density_file,'(1x,a)') 'BYTE_OFFSET: 4'
    close(td_total_density_file)

td_density_counter_source=td_density_counter_source+1

END SUBROUTINE output_td_density_source

! cody
SUBROUTINE output_positive_neg_psi_c(orbn,iter)
!This subroutine saves electron density of phi_source as bov format
integer :: orbn,iter
integer :: i,j,k,ind,pl,fnl,dk1,dk2,dk3,k1min,k2min,k3min,k1max,k2max,k3max
character(255) :: fname1,fname2
character(5)   :: ch5
character(7)   :: ch7
character(16)  :: str1,str2,str3
complex*16 :: phi(N_lattice_points),zero_c=(0.d0,0.d0)
real*8     :: phireal(N_Lattice_points)
k1min=N_Lattice_min(1)
k1max=N_Lattice_max(1)
k2min=N_Lattice_min(2)
k2max=N_Lattice_max(2)
k3min=N_Lattice_min(3)
k3max=N_Lattice_max(3)
dk1=(k1max-k1min+1)
dk2=(k2max-k2min+1)
dk3=(k3max-k3min+1)

   if( .NOT.allocated(sing_prec_rearranged_density)) allocate(sing_prec_rearranged_density(N_Lattice_points))
   	write(log_file,*) 'allocate single presision array?'
   ! real part positive

   do i=1,N_Lattice_points
     if( real(Psi_c(i,orbn)) > 0.d0 ) then
	   phi(i)=Psi_c(i,orbn)
	 else
       phi(i)=zero_c
     end if	 
	 phireal(i)=conjg(phi(i))*phi(i)
   end do
   phireal=sqrt(phireal)
!Bov format (bricks of data) which can easily be read by VisIt software.
!It is fast and reasonable in terms of disk space. Works only in the
!case of rectangular box
    write(ch5,'(i5.5)') orbn
	write(ch7,'(i7.7)') iter
    write(fname1,'(a,a,a,a,a)') 'phic_positive_orb_',ch5(1:5),'_iter',ch7(1:7),'.dat'
    write(fname2,'(a,a,a,a,a)') 'phic_positive_orb_',ch5(1:5),'_iter',ch7(1:7),'.bov'
	write(log_file,*) 'psi postive file name ',fname2
    fnl=len_trim(fname1)
    !First write the density into a data file, which is of binary form.
    !Note that the density data is rearranged as z,y,x --> x,y,z (C-like
    !storage of array elements)  and converted to single precision before
    !saving it to disk (single precision is used to reduce disk usage).
    !Rearrangement must be done using an auxiliary array
    !(called sing_prec_rearranged_density) because the data cannot be
    !simply written into the binary file by making an appropriate do-loop
    !(writing an entire array at once and writing it step-by-step gives
    !different result in fortran when it is a binary file).
    ind=0
    do k=N_Lattice_min(3),N_Lattice_max(3)
      do j=N_Lattice_min(2),N_Lattice_max(2)
        do i=N_Lattice_min(1),N_Lattice_max(1)
          ind=ind+1
          if (Lattice_inv_xyz(i,j,k)>0) then
            sing_prec_rearranged_density(ind)=phireal(Lattice_inv_xyz(i,j,k))
          else
            sing_prec_rearranged_density(ind)=0.0d0
          endif
        enddo
      enddo
    enddo
    open(td_total_density_file,file=fname1,form='unformatted',status='replace')
    write(td_total_density_file) sing_prec_rearranged_density
    close(td_total_density_file)
    !Now create a header file corresponding to the above datafile. The header file
    !is in ascii text form
    open(td_total_density_file,file=fname2,status='replace')
    write(td_total_density_file,'(1x,a,1x,es23.15)') 'TIME:',iter*time_step
    write(td_total_density_file,'(1x,a,1x,a)') 'DATA_FILE:',fname1(1:fnl)
    write(td_total_density_file,'(1x,a,3(1x,i6))') 'DATA_SIZE:',dk1,dk2,dk3
    write(td_total_density_file,'(1x,a)') 'DATA_FORMAT:  FLOAT'
    write(td_total_density_file,'(1x,a)') 'VARIABLE:  density'
    write(td_total_density_file,'(1x,a)') 'DATA_ENDIAN:  LITTLE'
    write(td_total_density_file,'(1x,a)') 'CENTERING:  zonal'
    write(td_total_density_file,'(1x,a,3(1x,es23.15))') 'BRICK_ORIGIN:',xgrid(k1min),ygrid(k2min),zgrid(k3min)
    write(td_total_density_file,'(1x,a,3(1x,es23.15))') 'BRICK_SIZE:', &
        xgrid(k1max)-xgrid(k1min),ygrid(k2max)-ygrid(k2min),zgrid(k3max)-zgrid(k3min)
    write(td_total_density_file,'(1x,a)') 'BYTE_OFFSET: 4'
    close(td_total_density_file)

   ! real part negative
  
   do i=1,N_Lattice_points
     if( real(Psi_c(i,orbn)) < 0.d0 ) then
	   phi(i)=Psi_c(i,orbn)
	 else
       phi(i)=zero_c
     end if	 
	 phireal(i)=conjg(phi(i))*phi(i)
   end do
   phireal=sqrt(phireal)

!Bov format (bricks of data) which can easily be read by VisIt software.
!It is fast and reasonable in terms of disk space. Works only in the
!case of rectangular box
    write(fname1,'(a,a,a,a,a)') 'phic_negative_orb_',ch5(1:5),'_iter',ch7(1:7),'.dat'
    write(fname2,'(a,a,a,a,a)') 'phic_negative_orb_',ch5(1:5),'_iter',ch7(1:7),'.bov'
    fnl=len_trim(fname1)
	write(log_file,*) 'psi postive file name ',fname2
    !First write the density into a data file, which is of binary form.
    !Note that the density data is rearranged as z,y,x --> x,y,z (C-like
    !storage of array elements)  and converted to single precision before
    !saving it to disk (single precision is used to reduce disk usage).
    !Rearrangement must be done using an auxiliary array
    !(called sing_prec_rearranged_density) because the data cannot be
    !simply written into the binary file by making an appropriate do-loop
    !(writing an entire array at once and writing it step-by-step gives
    !different result in fortran when it is a binary file).
    ind=0
    do k=N_Lattice_min(3),N_Lattice_max(3)
      do j=N_Lattice_min(2),N_Lattice_max(2)
        do i=N_Lattice_min(1),N_Lattice_max(1)
          ind=ind+1
          if (Lattice_inv_xyz(i,j,k)>0) then
            sing_prec_rearranged_density(ind)=phireal(Lattice_inv_xyz(i,j,k))
          else
            sing_prec_rearranged_density(ind)=0.0d0
          endif
        enddo
      enddo
    enddo
    open(td_total_density_file,file=fname1,form='unformatted',status='replace')
    write(td_total_density_file) sing_prec_rearranged_density
    close(td_total_density_file)
    !Now create a header file corresponding to the above datafile. The header file
    !is in ascii text form
    open(td_total_density_file,file=fname2,status='replace')
    write(td_total_density_file,'(1x,a,1x,es23.15)') 'TIME:',iter*time_step
    write(td_total_density_file,'(1x,a,1x,a)') 'DATA_FILE:',fname1(1:fnl)
    write(td_total_density_file,'(1x,a,3(1x,i6))') 'DATA_SIZE:',dk1,dk2,dk3
    write(td_total_density_file,'(1x,a)') 'DATA_FORMAT:  FLOAT'
    write(td_total_density_file,'(1x,a)') 'VARIABLE:  density'
    write(td_total_density_file,'(1x,a)') 'DATA_ENDIAN:  LITTLE'
    write(td_total_density_file,'(1x,a)') 'CENTERING:  zonal'
    write(td_total_density_file,'(1x,a,3(1x,es23.15))') 'BRICK_ORIGIN:',xgrid(k1min),ygrid(k2min),zgrid(k3min)
    write(td_total_density_file,'(1x,a,3(1x,es23.15))') 'BRICK_SIZE:', &
        xgrid(k1max)-xgrid(k1min),ygrid(k2max)-ygrid(k2min),zgrid(k3max)-zgrid(k3min)
    write(td_total_density_file,'(1x,a)') 'BYTE_OFFSET: 4'
    close(td_total_density_file)

   ! real part postive and negative (negative as a negative density)
   
   do i=1,N_Lattice_points
	 phireal(i)=conjg(Psi_c(i,orbn))*Psi_c(i,orbn)
	 phireal(i)=sqrt(phireal(i))
     if( real(Psi_c(i,orbn)) < 0.d0 ) then
	   phireal(i)=(-1.d0)*phireal(i)
     end if	 
   end do
   
   
!Bov format (bricks of data) which can easily be read by VisIt software.
!It is fast and reasonable in terms of disk space. Works only in the
!case of rectangular box
    write(fname1,'(a,a,a,a,a)') 'phic_orb_',ch5(1:5),'_iter',ch7(1:7),'.dat'
    write(fname2,'(a,a,a,a,a)') 'phic_orb_',ch5(1:5),'_iter',ch7(1:7),'.bov'
    fnl=len_trim(fname1)
    !First write the density into a data file, which is of binary form.
    !Note that the density data is rearranged as z,y,x --> x,y,z (C-like
    !storage of array elements)  and converted to single precision before
    !saving it to disk (single precision is used to reduce disk usage).
    !Rearrangement must be done using an auxiliary array
    !(called sing_prec_rearranged_density) because the data cannot be
    !simply written into the binary file by making an appropriate do-loop
    !(writing an entire array at once and writing it step-by-step gives
    !different result in fortran when it is a binary file).
    ind=0
    do k=N_Lattice_min(3),N_Lattice_max(3)
      do j=N_Lattice_min(2),N_Lattice_max(2)
        do i=N_Lattice_min(1),N_Lattice_max(1)
          ind=ind+1
          if (Lattice_inv_xyz(i,j,k)>0) then
            sing_prec_rearranged_density(ind)=phireal(Lattice_inv_xyz(i,j,k))
          else
            sing_prec_rearranged_density(ind)=0.0d0
          endif
        enddo
      enddo
    enddo
    open(td_total_density_file,file=fname1,form='unformatted',status='replace')
    write(td_total_density_file) sing_prec_rearranged_density
    close(td_total_density_file)
    !Now create a header file corresponding to the above datafile. The header file
    !is in ascii text form
    open(td_total_density_file,file=fname2,status='replace')
    write(td_total_density_file,'(1x,a,1x,es23.15)') 'TIME:',iter*time_step
    write(td_total_density_file,'(1x,a,1x,a)') 'DATA_FILE:',fname1(1:fnl)
    write(td_total_density_file,'(1x,a,3(1x,i6))') 'DATA_SIZE:',dk1,dk2,dk3
    write(td_total_density_file,'(1x,a)') 'DATA_FORMAT:  FLOAT'
    write(td_total_density_file,'(1x,a)') 'VARIABLE:  density'
    write(td_total_density_file,'(1x,a)') 'DATA_ENDIAN:  LITTLE'
    write(td_total_density_file,'(1x,a)') 'CENTERING:  zonal'
    write(td_total_density_file,'(1x,a,3(1x,es23.15))') 'BRICK_ORIGIN:',xgrid(k1min),ygrid(k2min),zgrid(k3min)
    write(td_total_density_file,'(1x,a,3(1x,es23.15))') 'BRICK_SIZE:', &
        xgrid(k1max)-xgrid(k1min),ygrid(k2max)-ygrid(k2min),zgrid(k3max)-zgrid(k3min)
    write(td_total_density_file,'(1x,a)') 'BYTE_OFFSET: 4'
    close(td_total_density_file)

	
END SUBROUTINE output_positive_neg_psi_c



!Arthur
SUBROUTINE print_projection_file_header
    integer :: orbital,nc,j,nspaces,k
    integer,parameter  :: reclength=20
    integer,parameter  :: backmargin=3
    character(reclength)  str1,strorb1,strorb2
	character(28) :: str3
    character(2*reclength),parameter :: spstr=' '
    
	allocate(innerproducts_iter(N_orbitals,N_Total_orbitals))
	innerproducts_iter=0.d0
        ! N_orbitals
    nc = N_orbitals*N_Total_orbitals+2

    write(projection_file,'(2x,a2)',advance='no') '#1'
    write(projection_file,'(18x,a2)',advance='no') '#2'    
    do j=3,nc
        write(projection_file,'(1x,i19)',advance='no') j
    end do
    write(projection_file,*)
    
    write(projection_file,'(2x,a)',advance='no') '#iter'
    write(projection_file,'(8x,a,3x)',advance='no') '#time[fs]'

      do orbital=1,N_orbitals
       do j=1,N_Total_orbitals
          write(strorb1,*) orbital
          write(strorb2,*) j
          
          write(str1,*) '|<',trim(adjustl(strorb1)),'(t)|',trim(adjustl(strorb2)),'(0)>|^2'
          nspaces=reclength-backmargin-len_trim(str1)
          write(projection_file,'(a)',advance='no') spstr(1:nspaces)
          write(projection_file,'(a)',advance='no') trim(str1)
          write(projection_file,'(a)',advance='no') spstr(1:backmargin)
       end do
      end do	

    write(projection_file,*)
    flush(projection_file)
    
	if(output_inner_product_s2) then
	  open(projection_sum_file,file="projection_sum.dat")
	  write(projection_sum_file,'(2x,a)',advance='no') '#iter'
      write(projection_sum_file,'(8x,a,3x)',advance='no') '#time[fs]'
      do orbital=1,N_orbitals
	    write(strorb2,*) orbital
        write(str3,*) 'S|<(',trim(adjustl(strorb2)),'(t)|i(0)>|^2'
		write(projection_sum_file,'(a)',advance='no') str3
	  end do
	  write(projection_sum_file,'(a)') "   total"
      flush(projection_sum_file)
	end if
  END SUBROUTINE print_projection_file_header


! Arthur and modified by Cody
subroutine update_projection_file(iter)
!This subroutine writes current positions, velocities, and forces
!Parameters:
! iter - iteration number (for ionic motion)
! t    - time in femtoseconds
!Parameters iter and t are printed in the first two columns
integer iter,atom,elem,j,p,ai,orbital
real(8) t,Xcm,Ycm,Zcm,Vcmx,Vcmy,Vcmz,V2,projection_squared,getnorm,orbsum1,totsum1
complex*8 :: projection

t=iter*time_step

write(projection_file,'(1x,i6)',advance='no') iter
write(projection_file,'(1x,e19.12)',advance='no') t

if(output_inner_product_s2) then
 
 totsum1=0.d0
 write(projection_sum_file,'(1x,i6)',advance='no') iter
 write(projection_sum_file,'(1x,e19.12)',advance='no') t
 do orbital=1,N_orbitals
    orbsum1=0.d0
    do j=1,N_Total_orbitals
	  getnorm=sum(conjg(psi_c(:,orbital))*psi_c(:,orbital))*grid_volume
	  projection=sum(psi(:,j)*psi_c(:,orbital))*grid_volume/sqrt(getnorm)
	  projection_squared=CONJG(projection)*projection
      write(projection_file,'(1x,e19.12)',advance='no') projection_squared
	  innerproducts_iter(orbital,j)=projection_squared
	  if(j<=N_orbitals) orbsum1=orbsum1+projection_squared
    end do
	write(projection_sum_file,'(es28.16e3)',advance='no') orbsum1
	totsum1=totsum1+orbsum1
 end do
 write(projection_sum_file,'(es28.16e3)') totsum1
 
else
 do orbital=1,N_orbitals
    do j=1,N_Total_orbitals
      projection=sum(psi(:,j)*psi_c(:,orbital))*grid_volume
	  projection_squared=CONJG(projection)*projection
      write(projection_file,'(1x,e19.12)',advance='no') projection_squared
	  innerproducts_iter(orbital,j)=projection_squared
    end do
 end do
end if

write(projection_file,*)
flush(projection_file)

end subroutine update_projection_file


subroutine check_switch_conditions(iter)
  implicit none
  integer :: iter
  logical  :: switch_stop=.FALSE.
  real*8   :: nelec
  integer  :: scode
  
  scode=0
  
  !projectile position condition
  if(switch_proj_z) then
    if(projectile_z<switch_proj_z_min) then
	  switch_stop=.TRUE.
	  scode=514
	  write(log_file,'(a,f15.7,a,f15.7)') "SWITCH_MODE:Projectile Z position is ",&
	    projectile_z," which is < ",switch_proj_z_min
	end if
  end if
  


  
  if ( switch_stop ) then
  ! if contition is met
    open(9876,file=trim(adjustl("SWITCH.dat")),form='formatted',status='replace')
	write(9876,*) scode
	close(9876)
	 	   write(log_file,*) 'Write restart files for iteration ',iter
	 	   call restart_file_update_elec(iter)
	 	   if(move_atoms) then
	 	     call restart_file_update_ion(iter)
	 	  end if
		  if(use_projectile) then
		     call restart_file_update_proj(iter)
		  end if
		  write(log_file,'(a,i5.5)')"Switch Mode called program stop. CODE=",scode
		  write(log_file,'(2a)')"Run finished: ",trim(adjustl(timestamp()))
		  stop
  end if
end subroutine check_switch_conditions

subroutine pull_volkov_stuff
implicit none
integer :: i,j,task_w_orb
integer :: MPI_TAG=6000

! pull Psi_Volkov
  do i=1,N_orbitals
    task_w_orb=MPItask_orbital_map(i)
    if(MPI_master) then
	  if(task_w_orb==MPI_proc_rank) then ! this is the master task
		! orbital is already here on master task. Do nothing
	    
	  else
	    call MPI_RECV(Phi_Volkov2,volkov_N_points,MPI_DOUBLE_COMPLEX,task_w_orb,MPI_TAG+i,taylor_time_communicator, &
		              MPI_STATUS_IGNORE,MPI_ierror)
		if(MPI_ierror/=0) call check_mpi_error(MPI_ierror,2000)
		Psi_Volkov(:,:,:,i)=Phi_Volkov2(:,:,:)
	  end if
	else if(task_w_orb==MPI_proc_rank) then
	    Phi_Volkov2(:,:,:)=Psi_Volkov(:,:,:,i)
	    call MPI_SEND(Phi_Volkov2,volkov_N_points,MPI_DOUBLE_COMPLEX,0,MPI_TAG+i,taylor_time_communicator,MPI_ierror)
		if(MPI_ierror/=0) call check_mpi_error(MPI_ierror,2100)
	end if
	call MPI_BARRIER( taylor_time_communicator, MPI_ierror)
  end do
  MPI_TAG=7000
if(maskV_save_PES) then ! pull maskV_mom_final NOTE it is only single precision cpx
! but will use same array as double complex for simplicity
  do i=1,N_orbitals
    task_w_orb=MPItask_orbital_map(i)
    if(MPI_master) then
	  if(task_w_orb==MPI_proc_rank) then ! this is the master task
		! orbital is already here on master task. Do nothing
	    
	  else
	    call MPI_RECV(Phi_Volkov2,volkov_N_points,MPI_DOUBLE_COMPLEX,task_w_orb,MPI_TAG+i,taylor_time_communicator, &
		              MPI_STATUS_IGNORE,MPI_ierror)
		if(MPI_ierror/=0) call check_mpi_error(MPI_ierror,2200)
		maskV_mom_final(:,:,:,i)=Phi_Volkov2(:,:,:)
	  end if
	else if(task_w_orb==MPI_proc_rank) then
	    Phi_Volkov2(:,:,:)=maskV_mom_final(:,:,:,i)
	    call MPI_SEND(Phi_Volkov2,volkov_N_points,MPI_DOUBLE_COMPLEX,0,MPI_TAG+i,taylor_time_communicator,MPI_ierror)
		if(MPI_ierror/=0) call check_mpi_error(MPI_ierror,2300)
	end if
	call MPI_BARRIER( taylor_time_communicator, MPI_ierror)
  end do
end if
  MPI_TAG=8000
if(maskV_save_multi_PES) then ! pull maskV_mom_multi NOTE it is only single precision cpx
! but will use same array as double complex for simplicity
  do i=1,N_orbitals
    task_w_orb=MPItask_orbital_map(i)
    if(MPI_master) then
	  if(task_w_orb==MPI_proc_rank) then ! this is the master task
		! orbital is already here on master task. Do nothing
	    
	  else
	    call MPI_RECV(Phi_Volkov2,volkov_N_points,MPI_DOUBLE_COMPLEX,task_w_orb,MPI_TAG+i,taylor_time_communicator, &
		              MPI_STATUS_IGNORE,MPI_ierror)
		if(MPI_ierror/=0) call check_mpi_error(MPI_ierror,2400)
		maskV_mom_multi(:,:,:,i)=Phi_Volkov2(:,:,:)
	  end if
	else if(task_w_orb==MPI_proc_rank) then
	    Phi_Volkov2(:,:,:)=maskV_mom_multi(:,:,:,i)
	    call MPI_SEND(Phi_Volkov2,volkov_N_points,MPI_DOUBLE_COMPLEX,0,MPI_TAG+i,taylor_time_communicator,MPI_ierror)
		if(MPI_ierror/=0) call check_mpi_error(MPI_ierror,2500)
	end if
	call MPI_BARRIER( taylor_time_communicator, MPI_ierror)
  end do
end if

end subroutine pull_volkov_stuff

subroutine do_write_restart_MPI(iter)
  implicit none
  integer :: iter
  
  
  open(restart_file_electronic,file=trim(adjustl(restart_file_name)),form='unformatted',status='replace',action='write')
   write(restart_file_electronic) iter
   write(restart_file_electronic) N_lattice_points
   write(restart_file_electronic) N_orbitals
   write(restart_file_electronic) Psi_c
   write(restart_file_electronic) density
   write(restart_file_electronic) Occupation
   if(nl_pp_mode==2) then
     write(restart_file_electronic) uV_nl
     write(restart_file_electronic) ps_grid ! no need for this
   end if
   write(restart_file_electronic) Position
   write(restart_file_electronic) atom_velocity
   write(restart_file_electronic) Position_prev
   write(restart_file_electronic) force
   write(restart_file_electronic) V_Hartree
   write(restart_file_electronic) V_l_pp
   write(restart_file_electronic) V_td
    if(spin_polarized) then
      write(restart_file_electronic) V_Exchange_up 
	  write(restart_file_electronic) V_Exchange_down
    else
      write(restart_file_electronic) V_Exchange
    end if
	
   write(restart_file_electronic) td_density_counter
   write(restart_file_electronic) td_psi_counter
   if(use_mask_volkov) then
     write(restart_file_electronic) A_vec
	 write(restart_file_electronic) A_vec_int
	 write(restart_file_electronic) A_vec_2_int
	 write(restart_file_electronic) A_vec_TplusdT
	 write(restart_file_electronic) A_vec_int_prev
	 write(restart_file_electronic) A_vec_2_int_prev
	 write(restart_file_electronic) Psi_Volkov
	 write(restart_file_electronic) td_density_counter_volkov
	 if(maskV_save_PES) write(restart_file_electronic) maskV_mom_final
	 if(maskV_save_multi_PES) write(restart_file_electronic) maskV_mom_multi
   end if
   close(restart_file_electronic)
 
   if(use_projectile) then
     call restart_file_update_proj(iter)
   end if
end subroutine

subroutine do_read_restart_MPI(iter)
  implicit none
  integer,intent(inout) :: iter
  integer :: iter2,n_lat_check,n_orb_check
  
  open(restart_file_electronic,file=trim(adjustl(restart_file_name)),form='unformatted',action='read')
   read(restart_file_electronic) iter
   read(restart_file_electronic) n_lat_check
   read(restart_file_electronic) n_orb_check
   read(restart_file_electronic) Psi_c
   read(restart_file_electronic) density
   read(restart_file_electronic) Occupation
   if(nl_pp_mode==2) then
     read(restart_file_electronic) uV_nl
     read(restart_file_electronic) ps_grid
   end if
   read(restart_file_electronic) Position
   read(restart_file_electronic) atom_velocity
   read(restart_file_electronic) Position_prev
   read(restart_file_electronic) force
   read(restart_file_electronic) V_Hartree
   read(restart_file_electronic) V_l_pp
   read(restart_file_electronic) V_td
    if(spin_polarized) then
      read(restart_file_electronic) V_Exchange_up 
	  read(restart_file_electronic) V_Exchange_down
    else
      read(restart_file_electronic) V_Exchange
    end if
   read(restart_file_electronic) td_density_counter
   read(restart_file_electronic) td_psi_counter
   if(use_mask_volkov) then
     read(restart_file_electronic) A_vec
	 read(restart_file_electronic) A_vec_int
	 read(restart_file_electronic) A_vec_2_int
	 read(restart_file_electronic) A_vec_TplusdT
	 read(restart_file_electronic) A_vec_int_prev
	 read(restart_file_electronic) A_vec_2_int_prev
	 read(restart_file_electronic) Psi_Volkov
	 read(restart_file_electronic) td_density_counter_volkov
	 if(maskV_save_PES) read(restart_file_electronic) maskV_mom_final
	 if(maskV_save_multi_PES) read(restart_file_electronic) maskV_mom_multi
   end if
   close(restart_file_electronic)
   if(n_lat_check /= N_lattice_points) then
      write(log_file,*) 'Error: N_lattice_points in restart file does not match input! ', N_lattice_points, ' vs ', n_lat_check
      stop
   end if
   if(n_orb_check /= N_orbitals) then
      write(log_file,*) 'Error: N_orbitals in restart file does not match input! ', N_orbitals, ' vs ', n_orb_check
      stop
   end if

   if(use_projectile) then
     call restart_file_read_proj(iter)
   end if
end subroutine

subroutine do_restart_broadcast_MPI(iter)
  implicit none
  integer :: iter

  call MPI_BCAST(iter,1,MPI_INTEGER   ,0,MPI_COMM_WORLD,MPI_ierror)
  if(MPI_ierror/=0) call check_mpi_error(MPI_ierror,2600)
  call MPI_BCAST(Psi_c,N_Lattice_points*N_orbitals,MPI_DOUBLE_COMPLEX,0,MPI_COMM_WORLD,MPI_ierror)
  if(MPI_ierror/=0) call check_mpi_error(MPI_ierror,2700)

  ! other processes do not need to have atom positions
  ! the potentials will be updated upon the start of the loop with update_potential_MPI
  
  if(use_mask_volkov) then
    call MPI_BCAST(A_vec,3,MPI_DOUBLE_PRECISION,0,MPI_COMM_WORLD,MPI_ierror)
	if(MPI_ierror/=0) call check_mpi_error(MPI_ierror,2800)
	call MPI_BCAST(A_vec_int,3,MPI_DOUBLE_PRECISION,0,MPI_COMM_WORLD,MPI_ierror)
	if(MPI_ierror/=0) call check_mpi_error(MPI_ierror,2900)
	call MPI_BCAST(A_vec_2_int,3,MPI_DOUBLE_PRECISION,0,MPI_COMM_WORLD,MPI_ierror)
	if(MPI_ierror/=0) call check_mpi_error(MPI_ierror,3000)
	call MPI_BCAST(A_vec_TplusdT,3,MPI_DOUBLE_PRECISION,0,MPI_COMM_WORLD,MPI_ierror)
	if(MPI_ierror/=0) call check_mpi_error(MPI_ierror,3100)
	call MPI_BCAST(Psi_Volkov,volkov_N_points*N_orbitals,MPI_DOUBLE_COMPLEX,0,MPI_COMM_WORLD,MPI_ierror)
	if(MPI_ierror/=0) call check_mpi_error(MPI_ierror,3200)
	if(maskV_save_PES) then
	  call MPI_BCAST(maskV_mom_final,volkov_N_points*N_orbitals,MPI_COMPLEX,0,MPI_COMM_WORLD,MPI_ierror)
	  if(MPI_ierror/=0) call check_mpi_error(MPI_ierror,3300)
	end if
	if(maskV_save_multi_PES) then
	  call MPI_BCAST(maskV_mom_multi,volkov_N_points*N_orbitals,MPI_COMPLEX,0,MPI_COMM_WORLD,MPI_ierror)
	  if(MPI_ierror/=0) call check_mpi_error(MPI_ierror,3400)
	end if
  end if
  
end subroutine do_restart_broadcast_MPI

subroutine check_for_stop_file_MPI(i)
logical :: stop_requested
integer,intent(in) :: i

  stop_requested = .false.    
  if(MPI_master) then
    inquire(file="JOB_TO_BE_KILLED", exist=stop_requested)
  end if
  
  call MPI_BCAST(stop_requested,1,MPI_LOGICAL,0,taylor_time_communicator,MPI_ierror)
  if(MPI_ierror/=0) call check_mpi_error(MPI_ierror,3500)
  
  if (stop_requested) then
      write(log_file,*) "JOB_TO_BE_KILLED found. writing restarts"
	  call pull_Psi_c_MPI
	  if(use_mask_volkov) call pull_volkov_stuff
	  if(MPI_master) call do_write_restart_MPI(i)
	  call MPI_BARRIER( taylor_time_communicator, MPI_ierror)
	  call MPI_FINALIZE(MPI_ierror)
	  ! does not work with split_nlpp mode. need to fix.
	  write(log_file,*) "stopping now"
	  stop
  end if
end subroutine check_for_stop_file_MPI

subroutine calc_GS_projection_MPI(iter)
implicit none
  integer :: iter,u_number,k,j
  real(8)  :: preal,norm
  complex*16 :: pcomp
  
  do k=1,N_orbitals
    ! only do it orbital is assigned to this process
    if(MPItask_orbital_map(k)==MPI_proc_rank) then
	  u_number=36513000+k
      if(iter==0) then
	    if(resume_from_restart_taylor .AND. do_not_overwrite) then
		  open(u_number, status="old", position="append", action="write")
		else
		  open(u_number)
		end if
	  else
	    norm=sum(conjg(psi_c(:,k))*psi_c(:,k))*grid_volume
		write(u_number,'(F12.4,es19.10e3)',advance='no') iter*time_step,norm
		do j=1,N_Total_orbitals
		  pcomp=sum(psi(:,j)*psi_c(:,k))*grid_volume/sqrt(norm)
		  preal=CONJG(pcomp)*pcomp
		  write(u_number,'(es18.10e3)',advance='no') preal
		end do
        write(u_number,*)
        flush(u_number)
      end if
    end if
  end do

end subroutine

SUBROUTINE taylor_time_init_ALL_part2
implicit none
integer :: k

  ! send to MPI_COMM_WORLD since everyone needs to know their tasks.
  call MPI_BCAST(MPItask_orbital_map,N_orbitals,MPI_INTEGER,0,MPI_COMM_WORLD,MPI_ierror)
  if(MPI_ierror/=0) call check_mpi_error(MPI_ierror,3600)

  ! Copy Psi_c to all processes 
  k=N_Lattice_points*N_orbitals
  call MPI_BCAST(Psi_c,k,MPI_DOUBLE_COMPLEX,0,MPI_COMM_WORLD,MPI_ierror)
  if(MPI_ierror/=0) call check_mpi_error(MPI_ierror,3700)


  if(output_inner_product) then
    if(.NOT.allocated(Psi)) allocate(Psi(N_lattice_points,N_total_orbitals))
	k=N_Lattice_points*N_total_orbitals
	call MPI_BCAST(Psi,k,MPI_DOUBLE_PRECISION,0,MPI_COMM_WORLD,MPI_ierror)
	if(MPI_ierror/=0) call check_mpi_error(MPI_ierror,3800)
    call calc_GS_projection_MPI(0)
  end if
  
  if(.NOT.MPI_nlpp_slave) then
    call update_potential_MPI(0)
    call check_energies_all_MPI(0)
  end if
  
  if(move_atoms) then
    if(.NOT.MPI_nlpp_slave) call check_forces_MPI
    if(split_up_gen_nlpp) then
      if(MPI_nlpp_slave) then
	    call make_atom_movement(0)
	  end if
	else
      if(MPI_master) then
	    call make_atom_movement(0)
	  end if
	end if
    
  end if
  
  A_vec=0.d0; A_vec_Tplusdt=0.d0
  
  if(read_initial_occupation) then
    call MPI_BCAST(occupation,N_total_orbitals,MPI_DOUBLE_PRECISION,0,MPI_COMM_WORLD,MPI_ierror)
	if(MPI_ierror/=0) call check_mpi_error(MPI_ierror,3900)
  end if

end SUBROUTINE taylor_time_init_ALL_part2

SUBROUTINE sync_nl_pp_MPI
implicit none
 ! MPI_nlpp_process is the process that updates the nl_pp
  
  !write(log_file,*) MPI_nlpp_process,max_ps_points*N_total_atom,N_total_atom,N_nl
  !write(log_file,*) "communicator=",MPI_COMM_WORLD
  !  if (allocated(ps_grid)) then
  !    write(log_file,*) "ps_grid allocated"
  !  else
  !    write(log_file,*) "ps_grid IS NOT allocated"
  !  endif

  if(nl_pp_mode==1) then
    call MPI_BCAST(uV     ,uV_size                    ,MPI_DOUBLE_PRECISION,MPI_nlpp_process,MPI_COMM_WORLD,MPI_ierror)
	if(MPI_ierror/=0) call check_mpi_error(MPI_ierror,4000)
	call MPI_BCAST(ps_grid,max_ps_points*N_total_atom ,MPI_INTEGER,MPI_nlpp_process,MPI_COMM_WORLD,MPI_ierror)
	if(MPI_ierror/=0) call check_mpi_error(MPI_ierror,4100)
	call MPI_BCAST(num_ps_points ,N_total_atom        ,MPI_INTEGER,MPI_nlpp_process,MPI_COMM_WORLD,MPI_ierror)
	if(MPI_ierror/=0) call check_mpi_error(MPI_ierror,4200)
  else if(nl_pp_mode==2) then
    !write(log_file,*) "MPI_BCAST(uV_nl"
	!write(log_file,*) 'Rank', MPI_proc_rank, 'uV_nl allocated:', allocated(uV_nl)
    !write(log_file,*) 'Rank', MPI_proc_rank, 'size:', max_ps_points, '*', N_nl, '=', max_ps_points * N_nl
    call MPI_BCAST(uV_nl   ,max_ps_points*N_nl        ,MPI_DOUBLE_PRECISION,MPI_nlpp_process,MPI_COMM_WORLD,MPI_ierror)
	if(MPI_ierror/=0) call check_mpi_error(MPI_ierror,4300)
	!write(log_file,*) MPI_ierror
    !write(log_file,*) "ps_grid"
	call MPI_BCAST(ps_grid ,max_ps_points*N_total_atom,MPI_INTEGER,MPI_nlpp_process,MPI_COMM_WORLD,MPI_ierror)
	if(MPI_ierror/=0) call check_mpi_error(MPI_ierror,4400)
    !write(log_file,*) MPI_ierror
	!write(log_file,*) "s_uVu_nl"
	call MPI_BCAST(s_uVu_nl,N_nl                      ,MPI_INTEGER,MPI_nlpp_process,MPI_COMM_WORLD,MPI_ierror)
	if(MPI_ierror/=0) call check_mpi_error(MPI_ierror,4500)
	!write(log_file,*) "num_ps_points"
	call MPI_BCAST(num_ps_points ,N_total_atom        ,MPI_INTEGER,MPI_nlpp_process,MPI_COMM_WORLD,MPI_ierror)
	if(MPI_ierror/=0) call check_mpi_error(MPI_ierror,4600)
  else
    write(log_file,*) "unrecognized nl_pp_mode",nl_pp_mode
	stop
  end if
  
end SUBROUTINE sync_nl_pp_MPI

subroutine sync_split_md_MPI
implicit none
 INTEGER :: MPI_TAG ! arbitrary INTEGER to match
 integer :: status(MPI_STATUS_SIZE)
 
  !write(log_file,*) "sync_split_md_MPI"
  if(MPI_master) then
    MPI_TAG=100
    call MPI_Recv(VH_bg,N_Lattice_points,MPI_DOUBLE_PRECISION,MPI_nlpp_process,MPI_TAG,MPI_COMM_WORLD,status,MPI_ierror)
	if(MPI_ierror/=0) call check_mpi_error(MPI_ierror,4700)
	MPI_TAG=101
	call MPI_Recv(V_l_pp,N_Lattice_points,MPI_DOUBLE_PRECISION,MPI_nlpp_process,MPI_TAG,MPI_COMM_WORLD,status,MPI_ierror)
	if(MPI_ierror/=0) call check_mpi_error(MPI_ierror,4800)
	MPI_TAG=102
	call MPI_Recv(Position,3*N_total_atom,MPI_DOUBLE_PRECISION,MPI_nlpp_process,MPI_TAG,MPI_COMM_WORLD,status,MPI_ierror)
	if(MPI_ierror/=0) call check_mpi_error(MPI_ierror,4900)
	MPI_TAG=103
	call MPI_Recv(atom_velocity,3*N_total_atom,MPI_DOUBLE_PRECISION,MPI_nlpp_process,MPI_TAG,MPI_COMM_WORLD,status,MPI_ierror)
	if(MPI_ierror/=0) call check_mpi_error(MPI_ierror,5000)
	MPI_TAG=104
	call MPI_Recv(Rho_bg,N_Lattice_points,MPI_DOUBLE_PRECISION,MPI_nlpp_process,MPI_TAG,MPI_COMM_WORLD,status,MPI_ierror)
	if(MPI_ierror/=0) call check_mpi_error(MPI_ierror,5100)
	MPI_TAG=105
	call MPI_Send(density,N_lattice_points,MPI_DOUBLE_PRECISION,MPI_nlpp_process,MPI_TAG,MPI_COMM_WORLD,MPI_ierror)
	if(MPI_ierror/=0) call check_mpi_error(MPI_ierror,5200)
  else if(MPI_nlpp_slave) then
    MPI_TAG=100
    call MPI_Send(VH_bg,N_Lattice_points,MPI_DOUBLE_PRECISION,0,MPI_TAG,MPI_COMM_WORLD,MPI_ierror)
	if(MPI_ierror/=0) call check_mpi_error(MPI_ierror,5300)
	MPI_TAG=101
	call MPI_Send(V_l_pp,N_Lattice_points,MPI_DOUBLE_PRECISION,0,MPI_TAG,MPI_COMM_WORLD,MPI_ierror)
	if(MPI_ierror/=0) call check_mpi_error(MPI_ierror,5400)
	MPI_TAG=102
	call MPI_Send(Position,3*N_total_atom,MPI_DOUBLE_PRECISION,0,MPI_TAG,MPI_COMM_WORLD,MPI_ierror)
	if(MPI_ierror/=0) call check_mpi_error(MPI_ierror,5500)
    MPI_TAG=103
	call MPI_Send(atom_velocity,3*N_total_atom,MPI_DOUBLE_PRECISION,0,MPI_TAG,MPI_COMM_WORLD,MPI_ierror)
	if(MPI_ierror/=0) call check_mpi_error(MPI_ierror,5600)
    MPI_TAG=104
	call MPI_Send(Rho_bg,N_Lattice_points,MPI_DOUBLE_PRECISION,0,MPI_TAG,MPI_COMM_WORLD,MPI_ierror)
	if(MPI_ierror/=0) call check_mpi_error(MPI_ierror,5700)
    MPI_TAG=105
	call MPI_Recv(density,N_lattice_points,MPI_DOUBLE_PRECISION,0,MPI_TAG,MPI_COMM_WORLD,status,MPI_ierror)
	if(MPI_ierror/=0) call check_mpi_error(MPI_ierror,5800)
	! density is required by calculate_fragment_info

  end if
  !write(log_file,*) "done sync_split_md_MPI"

end subroutine sync_split_md_MPI

subroutine nl_pp_slave_timeloop(starting_timestep)
implicit none
integer,intent(inout) :: starting_timestep
integer :: i

  do i=starting_timestep,n_time_steps
  
    if((move_atoms) .AND. (mod(i,atomic_movement_frequency)==0)) then
      
	  call MPI_handle_molecular_dynamics(i)	  
      
	endif
	
  end do
  
  starting_timestep=n_time_steps

end subroutine nl_pp_slave_timeloop

subroutine check_mpi_error(ierr, loc_id)
  implicit none
  integer, intent(in) :: ierr
  integer, intent(in) :: loc_id
  
  ! In MPI, 0 is MPI_SUCCESS. Anything else is an error.
  if (ierr /= 0) then
    ! Print to standard output (shows up in the terminal/slurm.out)
    write(*,*) "======================================================"
    write(*,*) "FATAL MPI ERROR DETECTED!"
    write(*,*) "Location ID : ", loc_id
    write(*,*) "Error Code  : ", ierr
    write(*,*) "======================================================"
    
    ! Try to write to the log file as well
    write(log_file,*) "FATAL MPI ERROR DETECTED at Location ID: ", loc_id, " Code: ", ierr
    
    ! Abort all MPI processes safely to prevent hanging jobs
    call MPI_Abort(MPI_COMM_WORLD, ierr, ierr)
    stop
  end if
end subroutine check_mpi_error

END MODULE  TAYLOR_TIME

      SUBROUTINE tqli(d,e,n,np,z)
      INTEGER n,np
      REAL*8 d(np),e(np),z(np,np)
!     USES pythag
      INTEGER i,iter,k,l,m
      REAL*8 b,c,dd,f,g,p,r,s,pythag
      do 11 i=2,n
        e(i-1)=e(i)
11    continue
      e(n)=0.
      do 15 l=1,n
        iter=0
1       do 12 m=l,n-1
          dd=abs(d(m))+abs(d(m+1))
          if (abs(e(m))+dd.eq.dd) goto 2
12      continue
        m=n
2       if(m.ne.l)then
          if(iter.eq.30)pause 'too many iterations in tqli'
          iter=iter+1
          g=(d(l+1)-d(l))/(2.*e(l))
          r=pythag(g,1.d0)
          g=d(m)-d(l)+e(l)/(g+sign(r,g))
          s=1.
          c=1.
          p=0.
          do 14 i=m-1,l,-1
            f=s*e(i)
            b=c*e(i)
            r=pythag(f,g)
            e(i+1)=r
            if(r.eq.0.)then
              d(i+1)=d(i+1)-p
              e(m)=0.
              goto 1
            endif
            s=f/r
            c=g/r
            g=d(i+1)-p
            r=(d(i)-g)*s+2.*c*b
            p=s*r
            d(i+1)=g+p
            g=c*r-b
!     Omit lines from here ...
            do 13 k=1,n
              f=z(k,i+1)
              z(k,i+1)=s*z(k,i)+c*f
              z(k,i)=c*z(k,i)-s*f
13          continue
!     ... to here when finding only eigenvalues.
14        continue
          d(l)=d(l)-p
          e(l)=g
          e(m)=0.
          goto 1
        endif
15    continue
      return
      END

      FUNCTION pythag(a,b)
      REAL*8 a,b,pythag
      REAL*8 absa,absb
      absa=abs(a)
      absb=abs(b)
      if(absa.gt.absb)then
        pythag=absa*sqrt(1.+(absb/absa)**2)
      else
        if(absb.eq.0.)then
          pythag=0.
        else
          pythag=absb*sqrt(1.+(absa/absb)**2)
        endif
      endif
      return
      END
