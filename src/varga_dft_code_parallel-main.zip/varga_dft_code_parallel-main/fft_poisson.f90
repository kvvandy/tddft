MODULE FFT_POISSON
  USE MOD_GLOBAL
  implicit none

  ! Fourier mesh
  integer                            :: N_L(3),N_G_vec(3),N_G_vec_points
  real*8,dimension(:),allocatable    :: G_length
  real*8,dimension(:,:),allocatable  :: G_vec
  integer,dimension(:),allocatable   :: G_index
  integer,dimension(:,:),allocatable :: G_index_inv
  real*8 :: Reciprocal_Cell(3) ! size of the supercell in reciprocal space

CONTAINS

subroutine init_fft
  integer :: i,k,k1,k2,k3,num,nm(3),shift(3),grid

  N_L=N_Lattice
  N_G_vec(:)=(N_L(:)-1)/2
  Reciprocal_Cell=Pi/R_size
  N_G_vec_points=(2*N_G_vec(1)+1)*(2*N_G_vec(2)+1)*(2*N_G_vec(3)+1)
  allocate(G_vec(3,N_G_vec_points))
  allocate(G_length(N_G_vec_points))
  allocate(G_index(N_G_vec_points))
  allocate(G_index_inv(3,N_G_vec_points))

  num=0
  nm=N_G_vec/N_L+1
  shift=nm*N_L
  do k1 = -N_G_vec(1), N_G_vec(1)
    do k2 = -N_G_vec(2), N_G_vec(2)
      do k3 = -N_G_vec(3), N_G_vec(3)
        num=num+1
        G_vec(1,num)=k1*Reciprocal_Cell(1)
        G_vec(2,num)=k2*Reciprocal_Cell(2)
        G_vec(3,num)=k3*Reciprocal_Cell(3)
        G_length(num)=G_vec(1,num)**2+G_vec(2,num)**2+G_vec(3,num)**2
        nm(1)=mod(shift(1)+k1,N_L(1))
        nm(2)=mod(shift(2)+k2,N_L(2))
        nm(3)=mod(shift(3)+k3,N_L(3))
        grid=nm(3)+1+N_L(3)*nm(2)+N_L(3)*N_L(2)*nm(1)
        G_index(num)=grid
        G_index_inv(1,num)=nm(1)+1
        G_index_inv(2,num)=nm(2)+1
        G_index_inv(3,num)=nm(3)+1
      enddo
    enddo
  enddo
  write(log_file,*)'init_fft       :  OK'
end subroutine init_fft

subroutine solve_poisson_periodic
  integer                                  :: i1,i2,i3,i,mode
  real*8                                   :: f,ff
  complex*16, dimension(:,:,:),allocatable :: rho
  logical                                  :: inv

  allocate(rho(N_L(1),N_L(2),N_L(3)))

  ff=4.d0*pi*E2
  do i=1,N_lattice_points
    i1=Lattice(1,i)+1
    i2=Lattice(2,i)+1
    i3=Lattice(3,i)+1
    rho(i1,i2,i3)=Density(i)-Rho_bg(i)
!    rho(i1,i2,i3)=Density(i)
  enddo

  ! Fourier transformed density
  mode=+1
  call cfftw(rho,N_L(1),N_L(2),N_L(3),mode)

  do i=1,N_G_vec_points
    i1=Lattice(1,G_index(i))+1
    i2=Lattice(2,G_index(i))+1
    i3=Lattice(3,G_index(i))+1
    if(G_length(i).gt.1.d-10) then
      f=ff/G_length(i)
      rho(i1,i2,i3)=f*rho(i1,i2,i3)
    else
!     G=0
      rho(i1,i2,i3)=(0.d0,0.d0)
    endif
  enddo

  ! Trasformation to real space
  mode=-1
  call cfftw(rho,N_L(1),N_L(2),N_L(3),mode)
  do i=1,N_lattice_points
    i1=Lattice(1,i)+1
    i2=Lattice(2,i)+1
    i3=Lattice(3,i)+1
    V_Hartree(i)=rho(i1,i2,i3)
  enddo
  deallocate(rho)
end subroutine solve_poisson_periodic

END MODULE FFT_POISSON
