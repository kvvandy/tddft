MODULE GAUSS_BASIS
USE PARAMETERS
  implicit none
  integer,parameter                     :: lexp=1  !,ngd=(lexp+1)**2*ng
  integer                               :: select
  real*8,dimension(:),allocatable       :: xgr,wgr
  integer,parameter                     :: npow=10,npow_max=100
  real*8,dimension(:),allocatable       :: fa

  integer,parameter                     :: nge=50
!  real*8,parameter                      :: xe0=1.16d0,ae0=0.001d0
   real*8,parameter                      :: xe0=1.15d0,ae0=0.005d0
   real*8                                :: gae(nge)

  real*8,dimension(:,:),allocatable     :: pot_ge
  real*8,dimension(:,:,:),allocatable   :: nl_pot_u,nl_pot_uv
  real*8                                :: stm(-lexp:lexp,-lexp:lexp),som(-lexp:lexp,-lexp:lexp)
  real*8                                :: spm(-lexp:lexp,-lexp:lexp)
  real*8                                :: gis(0:lexp+2,0:lexp+2)
  real*8                                :: gis1(0:lexp+2,0:lexp+2)
  real*8                                :: clm(npow,(lexp+1)**2)
  integer                               :: px(npow,(lexp+1)**2),py(npow,(lexp+1)**2),pz(npow,(lexp+1)**2), &
&                                          nlm((lexp+1)**2)

CONTAINS


function power(x,n)
  implicit none
  real*8       :: power,x
  integer      :: n
  if(x.eq.0.d0) then
    if(n.eq.0) then
      power=1.d0
    else
      power=0.d0
    endif
  else
    power=x**n
  endif
end function power



subroutine gauss_init
  implicit none
  integer                                  :: i,l,m,na,in
  real*8                                   :: clma(npow)
  integer                                  :: pxa(npow),pya(npow),pza(npow)
  allocate(fa(0:npow_max))

  fa(0)=1
  do i=1,npow_max
    fa(i)=fa(i-1)*i
  end do

  do l=0,lexp
    do m=-l,l
      in=l**2+l+m+1
      call sphar(l,m,na,clma,pxa,pya,pza)
      nlm(in)=na
      clm(:,in)=clma(:)
      px(:,in)=pxa(:)
      py(:,in)=pya(:)
      pz(:,in)=pza(:)
    end do
  end do


end subroutine  gauss_init

subroutine gauss_potential_m(a,ra,la,b,rb,lb,c,rc)
!
!  exp(-mu*(r-Rc)**2)
!
implicit none
  integer             :: la,ma,lb,mb,ina,inb
  real*8              :: a,b,c,ra(3),rb(3),rc(3),s

  integer             :: ia,ib,na,nb
  real*8              :: clma(npow)
  integer             :: pxa(npow),pya(npow),pza(npow)
  real*8              :: clmb(npow)
  integer             :: pxb(npow),pyb(npow),pzb(npow)
  real*8              :: w,cx,cy,cz,sx,sy,sz,xa,xb,xc
  real*8              :: sxm(0:lexp+2,0:lexp+2),sym(0:lexp+2,0:lexp+2),szm(0:lexp+2,0:lexp+2)

  spm=0.d0

  xc=a*b/(a+b+c)*((ra(1)-rb(1))**2+(ra(2)-rb(2))**2+(ra(3)-rb(3))**2)
  xb=a*c/(a+b+c)*((ra(1)-rc(1))**2+(ra(2)-rc(2))**2+(ra(3)-rc(3))**2)
  xa=c*b/(a+b+c)*((rc(1)-rb(1))**2+(rc(2)-rb(2))**2+(rc(3)-rb(3))**2)

  w=norma(la,a)*norma(lb,b)*(pi/(a+b+c))**1.5d0*exp(-xa-xb-xc)
  call gauss_int3(a,b,c,ra(1),rb(1),rc(1),la,lb)
  sxm=gis
  call gauss_int3(a,b,c,ra(2),rb(2),rc(2),la,lb)
  sym=gis
  call gauss_int3(a,b,c,ra(3),rb(3),rc(3),la,lb)
  szm=gis



do ma=-la,la
  ina=la**2+la+ma+1
  na=nlm(ina)
  clma(:)=clm(:,ina)
  pxa(:)=px(:,ina)
  pya(:)=py(:,ina)
  pza(:)=pz(:,ina)

  do mb=-lb,lb
    inb=lb**2+lb+mb+1
    nb=nlm(inb)
    clmb(:)=clm(:,inb)
    pxb(:)=px(:,inb)
    pyb(:)=py(:,inb)
    pzb(:)=pz(:,inb)

  s=0.d0
  do ia=1,na
    do ib=1,nb
      if(clma(ia)*clmb(ib).ne.0.d0) then
        sx=sxm(pxa(ia),pxb(ib))
        sy=sym(pya(ia),pyb(ib))
        sz=szm(pza(ia),pzb(ib))
        s=s+clma(ia)*clmb(ib)*w*sx*sy*sz
      endif
    end do
  end do
  spm(ma,mb)=s
end do
end do

end subroutine gauss_potential_m

subroutine gauss_kinetic_m(a,ra,la,b,rb,lb)
implicit none
  integer             :: la,ma,lb,mb,ina,inb
  real*8              :: a,b,ra(3),rb(3)

  integer             :: ia,ib,na,nb
  real*8              :: clma(npow)
  integer             :: pxa(npow),pya(npow),pza(npow)
  real*8              :: clmb(npow)
  integer             :: pxb(npow),pyb(npow),pzb(npow)
  real*8              :: w,cx,cy,cz,sx,sy,sz,xxx
  real*8              :: tx1,tx2,ty1,ty2,tz1,tz2,tx,ty,tz
  real*8              :: sxm(0:lexp+2,0:lexp+2),sym(0:lexp+2,0:lexp+2),szm(0:lexp+2,0:lexp+2)

  xxx=a*b/(a+b)*((ra(1)-rb(1))**2+(ra(2)-rb(2))**2+(ra(3)-rb(3))**2)
  w=norma(la,a)*norma(lb,b)*(pi/(a+b))**1.5d0*exp(-xxx)
  som=0.d0
  stm=0.d0
  tx1=0.d0; tx2=0.d0
  ty1=0.d0; ty2=0.d0
  tz1=0.d0; tz2=0.d0

  call gauss_int(a,b,ra(1),rb(1),la,lb+2)
  sxm=gis
  call gauss_int(a,b,ra(2),rb(2),la,lb+2)
  sym=gis
  call gauss_int(a,b,ra(3),rb(3),la,lb+2)
  szm=gis

do ma=-la,la
  ina=la**2+la+ma+1
  na=nlm(ina)
  clma(:)=clm(:,ina)
  pxa(:)=px(:,ina)
  pya(:)=py(:,ina)
  pza(:)=pz(:,ina)

  do mb=-lb,lb
    inb=lb**2+lb+mb+1
    nb=nlm(inb)
    clmb(:)=clm(:,inb)
    pxb(:)=px(:,inb)
    pyb(:)=py(:,inb)
    pzb(:)=pz(:,inb)


  do ia=1,na
    do ib=1,nb
      if(clma(ia)*clmb(ib).ne.0.d0) then

      sx=sxm(pxa(ia),pxb(ib))
      sy=sym(pya(ia),pyb(ib))
      sz=szm(pza(ia),pzb(ib))


      if(pxb(ib)*(pxb(ib)-1).ne.0) tx1=sxm(pxa(ia),pxb(ib)-2)
      tx2=sxm(pxa(ia),pxb(ib)+2)
      tx=(pxb(ib)*(pxb(ib)-1)*tx1-2.d0*b*(2*pxb(ib)+1)*sx+4.d0*b**2*tx2)*sy*sz

      if(pyb(ib)*(pyb(ib)-1).ne.0) ty1=sym(pya(ia),pyb(ib)-2)
      ty2=sym(pya(ia),pyb(ib)+2)
      ty=(pyb(ib)*(pyb(ib)-1)*ty1-2.d0*b*(2*pyb(ib)+1)*sy+4.d0*b**2*ty2)*sx*sz

      if(pzb(ib)*(pzb(ib)-1).ne.0) tz1=szm(pza(ia),pzb(ib)-2)
      tz2=szm(pza(ia),pzb(ib)+2)
      tz=(pzb(ib)*(pzb(ib)-1)*tz1-2.d0*b*(2*pzb(ib)+1)*sz+4.d0*b**2*tz2)*sx*sy

      som(ma,mb)=som(ma,mb)+clma(ia)*clmb(ib)*w*sx*sy*sz
      stm(ma,mb)=stm(ma,mb)-clma(ia)*clmb(ib)*w*(tx+ty+tz)
      endif
    end do
  end do
    end do
  end do
end subroutine gauss_kinetic_m


subroutine gauss_int(a,b,xa,xb,na,nb)
!
!   integrate((x-xa)**na*(x-xb)**nb*exp(-a*(x-xa)**2-b*(x-xb)**2)
!
  implicit none
  integer            :: na,nb,ka,kb,i,k
  real*8             :: a,b,xa,xb,s,wa,wb,c,pc(0:nb),x,xx
  real*8             :: h(0:na+nb)

  c=xb-xa
  x=b*c/sqrt(a+b)
  xx=0.5d0/sqrt(a+b)
  call c_hermite_pol(x,na+nb,h)
  do i=0,nb
    pc(i)=power(-c,i)
  end do

  gis=0.d0
  do kb=0,nb
    do ka=0,na
      s=0.d0
      do i=0,kb
        s=s+fa(kb)/(fa(i)*fa(kb-i))*pc(i)*power(xx,(ka+kb-i))*h(ka+kb-i)
      end do
      gis(ka,kb)=s
    end do
  end do


end subroutine gauss_int

subroutine gauss_int3(a,b,c,xa,xb,xc,na,nb)
!
!   integrate((x-xa)**na*(x-xb)**nb*exp(-a*(x-xa)**2-b*(x-xb)**2-c*(x-xc)**2)
!
  implicit none
  integer            :: na,nb,ia,ib,ka,kb,i
  real*8             :: a,b,c,xa,xb,xc,s,wa,wb,pc(0:nb),ba,ca,xx,x,h(0:na+nb)


  ba=xb-xa
  ca=xc-xa
  x=(b*ba+c*ca)/sqrt(a+b+c)
  xx=0.5d0/sqrt(a+b+c)
  call c_hermite_pol(x,na+nb,h)
  do i=0,nb
    pc(i)=power(-ba,i)
  end do

  gis=0.d0
  do kb=0,nb
    do ka=0,na
      s=0.d0
      do i=0,kb
        s=s+fa(kb)/(fa(i)*fa(kb-i))*pc(i)*power(xx,(ka+kb-i))*h(ka+kb-i)
      end do
      gis(ka,kb)=s
    end do
  end do

end subroutine gauss_int3


function norma(l,a)
  implicit none
  real*8                     :: a,norma,f
  integer                    :: i,l

  f=1.d0
  do i=1,l
    f=f*(2.d0*i+1)
  end do
  f=f*sqrt(pi)/2.d0**(l+1)
  norma=sqrt(2.d0*(2.d0*a)**(l+1.5d0)/f)/sqrt(4.d0*pi)
end function norma


subroutine basint(a,b,n,c)
  implicit none
  real*8                                :: a,b,x,ww,aa
  integer                               :: n,i
  real*8                                :: c(0:n),h(0:n)

  aa=0.5d0/sqrt(a)
  x=b*aa
  call c_hermite_pol(x,n,h)
  ww=1.d0/aa
  do i=0,n
    ww=ww*aa
    c(i)=ww*h(i)
  end do

end subroutine basint


subroutine c_hermite_pol(x,n,h)
  implicit none
  integer                               :: n,i
  real*8                                :: x
  real*8                                :: h(0:n)

  h=0.d0
  h(0)=1.d0
  if(n.ge.1) h(1)=2.d0*x
  if(n.ge.2) then
    do i=1,n-1
      h(i+1)=2.d0*(x*h(i)+i*h(i-1))
    end do
  endif

end subroutine c_hermite_pol

subroutine sphar(l,m1,n,clm,px,py,pz)
  implicit none
  real*8                :: clm(npow),w1,w2,w3,w4
  integer               :: px(npow),py(npow),pz(npow)
  integer               :: l,m,n,p,q,i,j,k,m1

  m=abs(m1)
  w1=sqrt((2.d0*l+1.d0)*fa(l+m)*fa(l-m))
  n=0
  do q=0,l
    do p=0,l
      if(p+q.le.l.and.p-q.eq.m) then
        w2=(-1)**p/(fa(p)*fa(q)*fa(l-p-q))/2**(p+q)
        if(m.eq.0) then
          do i=0,p
            n=n+1
            w3=fa(p)/(fa(i)*fa(p-i))
            clm(n)=w1*w2*w3
            px(n)=2*i
            py(n)=2*(p-i)
            pz(n)=l-2*p
          end do
        else
          do i=0,p
            do j=0,q
              n=n+1
              w3=fa(p)/(fa(i)*fa(p-i))*fa(q)/(fa(j)*fa(q-j))*(-1)**(q-j)
              k=p+q-i-j
              if(m1.gt.0) w4=(zi**k+(-zi)**k)/sqrt(2.d0)
              if(m1.lt.0) w4=(zi**k-(-zi)**k)/sqrt(2.d0)/zi
              clm(n)=w1*w2*w3*w4
              px(n)=i+j
              py(n)=p+q-i-j
              pz(n)=l-p-q
            end do
          end do
        end if
      end if
    end do
  end do

end subroutine sphar


subroutine potential_fit(rp,pot,np,nu,ng,cg)
! fit the local potentials with gaussians
  implicit none
  integer              :: ierr,i,j,k,np,ng
  real*8               :: pot(np),rp(np),cg(ng)
  real*8               :: am(ng,ng),bm(ng),bf(ng)
  real*8               :: r2,nu(ng)




  am=0.d0
  bm=0.d0
  do k=1,np
    r2=rp(k)
    do i=1,ng
      bf(i)=exp(-nu(i)*r2**2)
    end do
    do i=1,ng
      do j=1,ng
        am(j,i)=am(j,i)+bf(i)*bf(j)
      end do
      bm(i)=bm(i)+bf(i)*pot(k)
    end do
  end do

  call gaussj(am,ng,ng,bm,1,1,ierr)

  cg=bm

end subroutine potential_fit




END MODULE GAUSS_BASIS


      SUBROUTINE gaussj(a,n,np,b,m,mp,ierr)
      implicit real*8(a-h,o-z)
      dimension a(np,np),b(np,mp)
      PARAMETER (NMAX=500)
      dimension indxc(NMAX),indxr(NMAX),ipiv(NMAX)
      do 11 j=1,n
        ipiv(j)=0
11    continue
      do 22 i=1,n
        big=0.
        do 13 j=1,n
          if(ipiv(j).ne.1)then
            do 12 k=1,n
              if (ipiv(k).eq.0) then
                if (abs(a(j,k)).ge.big)then
                  big=abs(a(j,k))
                  irow=j
                  icol=k
                endif
              else if (ipiv(k).gt.1) then
                ierr=1
                return
              endif
12          continue
          endif
13      continue
        ipiv(icol)=ipiv(icol)+1
        if (irow.ne.icol) then
          do 14 l=1,n
            dum=a(irow,l)
            a(irow,l)=a(icol,l)
            a(icol,l)=dum
14        continue
          do 15 l=1,m
            dum=b(irow,l)
            b(irow,l)=b(icol,l)
            b(icol,l)=dum
15        continue
        endif
        indxr(i)=irow
        indxc(i)=icol
        if (a(icol,icol).eq.0.) then
        ierr=1
        return
        endif
        pivinv=1./a(icol,icol)
        a(icol,icol)=1.
        do 16 l=1,n
          a(icol,l)=a(icol,l)*pivinv
16      continue
        do 17 l=1,m
          b(icol,l)=b(icol,l)*pivinv
17      continue
        do 21 ll=1,n
          if(ll.ne.icol)then
            dum=a(ll,icol)
            a(ll,icol)=0.
            do 18 l=1,n
              a(ll,l)=a(ll,l)-a(icol,l)*dum
18          continue
            do 19 l=1,m
              b(ll,l)=b(ll,l)-b(icol,l)*dum
19          continue
          endif
21      continue
22    continue
      do 24 l=n,1,-1
        if(indxr(l).ne.indxc(l))then
          do 23 k=1,n
            dum=a(k,indxr(l))
            a(k,indxr(l))=a(k,indxc(l))
            a(k,indxc(l))=dum
23        continue
        endif
24    continue
      return
      END




