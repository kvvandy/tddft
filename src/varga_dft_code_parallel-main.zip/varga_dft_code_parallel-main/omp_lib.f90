module omp_lib
!Fake omp_lib module for non-OpenMP compiling

contains

function omp_get_max_threads()
integer omp_get_max_threads
  omp_get_max_threads=1
end function omp_get_max_threads

function omp_get_num_procs()
integer omp_get_num_procs
  omp_get_num_procs=-1
end function omp_get_num_procs

function omp_get_thread_num()
integer omp_get_thread_num
  omp_get_thread_num=0
end function omp_get_thread_num

function omp_get_wtime()
real*8 omp_get_wtime
real*8 t
call cpu_time(t)
omp_get_wtime = t
end function omp_get_wtime

end module omp_lib
