module moldynamics
use hamilton
use marsaglia
implicit none

contains

subroutine init_molecular_dynamics_SLAVE
implicit none

  allocate(force(3,N_total_atom),wlap_p(3,N_lattice_points))

end subroutine init_molecular_dynamics_SLAVE

subroutine init_molecular_dynamics_NO_OPEN
implicit none

allocate(force(3,N_total_atom),atom_velocity(3,N_total_atom),Position_prev(3,N_total_atom))
if(.not.periodic) allocate(wlap_p(3,N_lattice_points))
allocate(atomic_mass(N_Species))
call compute_atomic_masses(atomic_mass)
call compute_total_mass_of_all_atoms(total_mass_of_all_atoms)

! processes are initialized one at a time, so the master and nl_pp_slave can both run these without issue.
if(input_initial_velocity.EQV..TRUE.) then !Arthur
    !This will input atomic velocities as read from velocity_input_file
    call input_atomic_velocities(atom_velocity)
end if
    
if ((av_kin_energy_ions<=0.0d0).and.(temperature_ions<=0.0d0).and.(.not.input_initial_velocity)) then
  !Initial temperature is zero
  atom_velocity=0.d0
  av_kin_energy_ions=0.0d0
  tot_kin_energy_ions=0.0d0
  temperature_ions=0.0d0

else if (input_initial_velocity.EQV..FALSE.) then
  !Nonzero initial temperature, need to set random
  !atomic velocities (i.e. the velocities of ions) according to the
  !Maxwell-Boltzmann distribution
  call initialize_atomic_velocities(atom_velocity,temperature_ions)
  call compute_atomic_temperature(atom_velocity,temperature_ions, &
                                  av_kin_energy_ions,tot_kin_energy_ions)
endif
if(combine_gs_boost2) then
    call set_atomic_vel_combine_gs2_boost(atom_velocity)
end if

Position_prev=Position

end subroutine init_molecular_dynamics_NO_OPEN

subroutine init_molecular_dynamics()
 integer :: i,ai,j
 integer :: cpos,pos2
 character(255) :: substr1,substr2,fname_frag
 character(3)   :: ch3
 logical :: file_exists99
!This subroutine initializes data necessary for ion dynamics.
!It should be called only once

allocate(force(3,N_total_atom),atom_velocity(3,N_total_atom),Position_prev(3,N_total_atom))
if(calc_force_gs_psi) then
  allocate(force_psiREAL(3,N_total_atom))
  allocate(force_c_prev(3,N_total_atom))
end if

if(.not.periodic) allocate(wlap_p(3,N_lattice_points))
allocate(atomic_mass(N_Species))
call compute_atomic_masses(atomic_mass)
call compute_total_mass_of_all_atoms(total_mass_of_all_atoms)

if(input_initial_velocity.EQV..TRUE.) then !Arthur
    !This will input atomic velocities as read from velocity_input_file
    call input_atomic_velocities(atom_velocity)
end if
    
if ((av_kin_energy_ions<=0.0d0).and.(temperature_ions<=0.0d0).and.(.not.input_initial_velocity)) then
  !Initial temperature is zero
  atom_velocity=0.d0
  av_kin_energy_ions=0.0d0
  tot_kin_energy_ions=0.0d0
  temperature_ions=0.0d0

else if (input_initial_velocity.EQV..FALSE.) then
  !Nonzero initial temperature, need to set random
  !atomic velocities (i.e. the velocities of ions) according to the
  !Maxwell-Boltzmann distribution
  call initialize_atomic_velocities(atom_velocity,temperature_ions)
  call compute_atomic_temperature(atom_velocity,temperature_ions, &
                                  av_kin_energy_ions,tot_kin_energy_ions)
endif
if(combine_gs_boost2) then
    call set_atomic_vel_combine_gs2_boost(atom_velocity)
end if

Position_prev=Position
if (moldyn_output_level>0) open(mol_dynamics_file,file=trim(adjustl(mol_dynamics_filename)))
if (save_trajectory) then
  INQUIRE(FILE=trim(adjustl(trajectory_filename)), EXIST=file_exists99)
  if((do_not_overwrite).AND.(file_exists99)) then
    open(trajectory_file,file=trim(adjustl(trajectory_filename)), status="old", position="append", action="write")
  else
    open(trajectory_file,file=trim(adjustl(trajectory_filename)))
  endif
end if
if (print_ion_forces) then
  open(mdforces_file,FILE=trim(adjustl(md_forcesfilename)) )!,STATUS='UNKNOWN', POSITION='APPEND')
  open(mdxyz_file,FILE=trim(adjustl(md_xyz_wE_filename)) )
end if

  
  
  if(md_give_inf_mass_specific) then
    write(log_file,*)"parse md_inf_mass_string"
    allocate(md_inf_mass(N_total_atom))
	md_inf_mass=.FALSE.
    do i=1,md_inf_mass_numberofatoms
	  cpos=index(md_inf_mass_string,",")
	  if(cpos/=0) then
	    substr1=md_inf_mass_string(1:cpos-1)
	    substr2=md_inf_mass_string(cpos+1:255)
	    md_inf_mass_string=trim(adjustl(substr2))
	  else
	    substr1=md_inf_mass_string
	  end if
	  read(substr1,*) j
	  write(log_file,*) "assign infinite mass to atom ",j
	  md_inf_mass(j)=.TRUE.
	end do
  ! print out all atom info
    write(log_file,'(a)') "               atom info          "
    write(log_file,'(a)') " Num Anum  mass(eV_fs^2/A^2)   C_pp    Moveable   atom_index   infinit_mass  Core_radius" 
    do i=1,N_total_atom
      ai=atom_index(i)
      write(log_file,'(i4,i5,f15.8,f12.3,L8,i11,L10,f18.7)') i,z_atom(ai),atomic_mass(ai),Charge_pp(ai), &
	    atom_movable(i),ai,md_inf_mass(i),Core_radius(ai)
    end do
  else
    ! print out all atom info
    write(log_file,'(a)') "               atom info          "
    write(log_file,'(a)') " Num Anum  mass(eV_fs^2/A^2)   C_pp    Moveable   atom_index  Core_radius" 
    do i=1,N_total_atom
      ai=atom_index(i)
      write(log_file,'(i4,i5,f15.8,f12.3,L8,i11,f10.5)') i,z_atom(ai),atomic_mass(ai), &
	    Charge_pp(ai),atom_movable(i),ai,Core_radius(ai)
    end do  
  end if  
  call md_calc_com(initial_COM)
  write(log_file,'(a,3f15.7)') 'initial COM=',initial_COM
  if(md_subtract_com_motion) write(log_file,*) 'subtract out any COM movement'
  
  if(print_bond_info) then
  
  end if
  if(print_fragment_info) then
    do i=1,N_total_atom 
      write(ch3,'(i3.3)') i
      write(fname_frag,'(a,a,a)') 'frag_info_atom',ch3(1:3),'.dat'
	  
      INQUIRE(FILE=trim(adjustl(fname_frag)), EXIST=file_exists99)
      if((do_not_overwrite).AND.(file_exists99)) then
        open(fragment_info_file_block+i,file=trim(adjustl(fname_frag)), status="old", position="append", action="write")
      else
        open(fragment_info_file_block+i,file=trim(adjustl(fname_frag)),form='formatted',status='replace')
      endif
    end do
  end if 
end subroutine init_molecular_dynamics

subroutine make_atom_movement(iter)
!This subroutine moves atoms (i.e. ions) classically after calculating
!quantum forces on them. It moves only the atoms which are allowed to move.
!The argument iter specifies which atom movement iteration (or step) it is.
!If this is the first iteration then the usual Taylor expansion is
!applied to calculate the next position and velocity. Otherwise, the Verlet
!algoritm is used.
!Warning: before doing the time evolution the subroutine has to be called
!with iter=0. This will evaluate the initial forces and print the header
!as well as the initial position/velocities/forces/temperature in log
!file (mol_dynamics_file)
integer iter
integer atom,ai,j,elem
real(8) t,dt,invdt,invmass,P,V,two_damp,one_damp,ccom(3),dcom(3),t1,t2

!Exit quickly if no ions need to be moved in this iteration
if (mod(iter,atomic_movement_frequency)/=0) then
  if ((save_trajectory).and.(mod(iter,trajectory_output_frequency)==0)) then
    t=iter*time_step
    call update_trajectory_file(iter,t)
  endif
  return
endif

dt=time_step*atomic_movement_frequency
invdt=1/dt
t=iter*time_step

!If zeroth iteration then calculate forces, create a header in the log
!file, print the initial positions, velocities and forces and then exit
if (iter==0) then
   !  call calculate_force() ! NOW done after startup with check_forces_MPI 
  if (moldyn_output_level>0) call print_mol_dynamics_file_header()
  if (moldyn_output_level>0) call update_mol_dynamics_file(iter,t)
  if (save_trajectory) then
    if(resume_from_restart_taylor.AND.do_not_overwrite) then
	  write(log_file,*) "Restart--do not update trajectory file at iter 0."
	else
      call update_trajectory_file(iter,t)
	end if
  end if
  if (print_ion_forces) then
    call print_ion_xyzTofile_wN_Elec(iter,t)    
    call print_ion_forcesTofile(iter,t)
  endif
  return
endif

! cody
if(md_give_inf_mass_specific) then
  do atom=1,N_total_atom
    if(md_inf_mass(atom)) then
	  force(:,atom)=0.d0
	end if
  end do
end if

!write(253760+MPI_proc_rank,*) "START ",iter
!do atom=1,N_total_atom
!write(253760+MPI_proc_rank,*) atom,atom_velocity(1:3,atom),force(1:3,atom),Position(1:3,atom)
!end do

!dt is the time step for ionic motion
!Here we calculate positions and velocities at time iter*dt
!To do this we use forces obtained at previous iteration. In the end we
!also calculate forces at time iter*dt, which will be used when the subroutine
!is called next time
!Rememeber that atoms are moved every atomic_movement_frequency iteration
if(projectile_fine_eom) then
  call nuc_movement_fine(iter)
else
  if (iter>atomic_movement_frequency) then
    !Move atoms using the Verlet algorithm
    two_damp=2.0d0-md_damping_coeff
    one_damp=1.0d0-md_damping_coeff
    do atom=1,N_total_atom
      if (atom_movable(atom)) then
        ai=atom_index(atom)
        elem=z_atom(ai)
        if (elem/=0) then
          invmass=1/atomic_mass(ai)
          do j=1,3
            P=Position(j,atom)
            Position(j,atom)=two_damp*P-one_damp*Position_prev(j,atom)+invmass*force(j,atom)*dt**2
            atom_velocity(j,atom)=(1.5d0*Position(j,atom)-2*P+0.5d0*Position_prev(j,atom))*invdt
            Position_prev(j,atom)=P
          enddo
        endif
      endif
    enddo
  else
    !if iter=1 then we have to move atoms using Taylor
    !expansion because there is no sufficient number of initial conditions
    !to use the Verlet algorithm
    do atom=1,N_total_atom
      if (atom_movable(atom)) then
        ai=atom_index(atom)
        elem=z_atom(ai)
        if (elem/=0) then
          invmass=1/atomic_mass(ai)
          do j=1,3
            P=Position(j,atom)
            V=atom_velocity(j,atom)
            Position(j,atom)=P+V*dt+0.5d0*invmass*force(j,atom)*dt**2
            atom_velocity(j,atom)=V+invmass*force(j,atom)*dt
            Position_prev(j,atom)=P
          enddo
        endif
      endif
    enddo
  endif
end if


if(traj_debug) then
  write(1357513,*) iter
 do atom=1,N_total_atom
  ai=atom_index(atom)
  elem=z_atom(ai)
  write(1357513,'(1x,a3,9(1x,es26.16e3))') &
     element_symbols(elem),Position(1:3,atom),force(1:3,atom),atom_velocity(1:3,atom)
 enddo
end if

!write(253760+MPI_proc_rank,*) "END ", iter
!do atom=1,N_total_atom
!write(253760+MPI_proc_rank,*) atom,atom_velocity(1:3,atom),force(1:3,atom),Position(1:3,atom)
!end do
!FLUSH(253760+MPI_proc_rank)

if(md_subtract_com_motion) then
  call md_calc_com(ccom)
  dcom=ccom-initial_COM
  do atom=1,N_total_atom
    Position(:,atom)=Position(:,atom)-dcom
	Position_prev(:,atom)=Position_prev(:,atom)-dcom
  end do
end if

!Compute temperature, and total and average kinetic energy of ions
call compute_atomic_temperature(atom_velocity,temperature_ions,av_kin_energy_ions,tot_kin_energy_ions)

!Write positions, velocities, forces, as well as
!temperature and total kinetic energy of ions, laser field strengths
!into log file
if (moldyn_output_level>0) then
  if(mod(iter,moldyn_output_frequency)==0) call update_mol_dynamics_file(iter,t)
endif

!Write positions into an xyz-trajectory file
if (save_trajectory) then
  if (mod(iter,trajectory_output_frequency)==0) call update_trajectory_file(iter,t)
endif

!Recalculate nonlocal pseudopotential
    
call CPU_TIME(t1)
call background()
call CPU_TIME(t2)
if (save_timings) write(timing_file,*) "call background() ",t2-t1
call CPU_TIME(t1)
call create_pseudo_potential() 
call CPU_TIME(t2)
if (save_timings) write(timing_file,*) "call create_pseudo_potential() ",t2-t1
!if ((use_fine_grid).or.(grid_type>1)) then
!  call lf_nonlocal_setup()
!else
!  call nonlocal_setup()
!endif

!Recalculate local pseudopotential
! requires VH_BG to be set with the background subroutine
call CPU_TIME(t1)
call local_pseudo_potential()  
call CPU_TIME(t2)
if (save_timings) write(timing_file,*) "call local_pseudo_potential() ",t2-t1
!Recalculate ion-ion energy
call ion_ion_energy()

!Calculate forces, at time (iter+1)*dt
!They will be used in the next iteration
! NOW an MPI function called after make atom movement. call calculate_force()


if(print_fragment_info) then
  if (mod(iter,print_fragment_freq)==0) then
    call calculate_fragment_info(iter)
  end if
endif

end subroutine make_atom_movement

!cody
subroutine nuc_movement_fine(iter)
integer iter
integer atom,ai,j,elem,i,k
real(8) t,dt,invdt,invmass,P,V,two_damp,one_damp,dt_fine_eom,dt_fine,invdt_fine
real*8  :: fi_const(3,N_total_atom),fi_proj(3,N_total_atom),f_tot(3),fp1(3),fp2(3)
real*8  :: pos_x,pos_y,pos_z,vx,vy,vz

dt=time_step*atomic_movement_frequency
invdt=1/dt
t=iter*time_step
dt_fine=dt/projectile_fine_eom_inum
invdt_fine=1.d0/dt_fine
 call calculate_force_ion_proj(fi_proj,N_total_atom)
 fi_const=force-fi_proj ! force without projectile
 call compute_force_on_projectile_elec(fp1)
 do k=1,projectile_fine_eom_inum
  ! Move ions. we have to move atoms using Taylor
  ! must calculate the force each step on the atoms
  ! but only need to change to force term on the projectile
  call calculate_force_ion_proj(fi_proj,N_total_atom)
  do atom=1,N_total_atom
    
    f_tot=fi_const(:,atom)+fi_proj(:,atom)
    if (atom_movable(atom)) then
      ai=atom_index(atom)
      elem=z_atom(ai)
      if (elem/=0) then
        invmass=1/atomic_mass(ai)
        do j=1,3
		  if(iter==1) then ! taylor expansion instead of Verlet
            P=Position(j,atom)
            V=atom_velocity(j,atom)
            Position(j,atom)=P+V*dt_fine+0.5d0*invmass*f_tot(j)*dt_fine**2
            atom_velocity(j,atom)=V+invmass*f_tot(j)*dt_fine
            Position_prev(j,atom)=P
		  else
		    P=Position(j,atom)
            Position(j,atom)=2*P-Position_prev(j,atom)+invmass*f_tot(j)*dt_fine**2
            atom_velocity(j,atom)=(1.5d0*Position(j,atom)-2*P+0.5d0*Position_prev(j,atom))*invdt_fine
            Position_prev(j,atom)=P
		  end if
        enddo
		!write(64080+atom,'(f15.8,6es26.12e3)') t+dt_fine*k,fi_const(:,atom),fi_proj(:,atom)
      endif
    endif
  enddo
  
  ! move projectile
    call compute_force_on_projectile_nuc(fp2)
	f_tot=fp1+fp2
  	if(iter==1) then ! taylor expansion instead of Verlet
      pos_x=projectile_x
      vx=projectile_vx
      projectile_x=pos_x+vx*dt_fine+0.5d0*projectile_invmass*f_tot(1)*dt_fine**2
      projectile_vx=vx+projectile_invmass*f_tot(1)*dt_fine
      projectile_x_prev=pos_x
      pos_y=projectile_y
      vy=projectile_vy
      projectile_y=pos_y+vy*dt_fine+0.5d0*projectile_invmass*f_tot(2)*dt_fine**2
      projectile_vy=vy+projectile_invmass*f_tot(2)*dt_fine
      projectile_y_prev=pos_y
      pos_z=projectile_z
      vz=projectile_vz
      projectile_z=pos_z+vz*dt_fine+0.5d0*projectile_invmass*f_tot(3)*dt_fine**2
      projectile_vz=vz+projectile_invmass*f_tot(3)*dt_fine
      projectile_z_prev=pos_z
	else
	  pos_x=projectile_x
      projectile_x=2*pos_x-projectile_x_prev+projectile_invmass*f_tot(1)*dt_fine**2
      projectile_vx=(1.5d0*projectile_x-2*pos_x+0.5d0*projectile_x_prev)/dt_fine
      projectile_x_prev=pos_x
      pos_y=projectile_y
      projectile_y=2*pos_y-projectile_y_prev+projectile_invmass*f_tot(2)*dt_fine**2
      projectile_vy=(1.5d0*projectile_y-2*pos_y+0.5d0*projectile_y_prev)/dt_fine
      projectile_y_prev=pos_y
      pos_z=projectile_z
      projectile_z=2*pos_z-projectile_z_prev+projectile_invmass*f_tot(3)*dt_fine**2
      projectile_vz=(1.5d0*projectile_z-2*pos_z+0.5d0*projectile_z_prev)/dt_fine
      projectile_z_prev=pos_z
	  !write(64073,'(f15.8,6es26.12e3)') t+dt_fine*k,projectile_x,projectile_y,projectile_z,f_tot
	end if
 end do
 !write(64074,'(f10.4,6es26.12e3)') t,fp1,fp2
projectile_energy=0.5d0*projectile_mass*(projectile_vx**2+projectile_vy**2+projectile_vz**2)


end subroutine nuc_movement_fine


! cody
subroutine print_ion_xyzTofile_wN_Elec(iter,time)
!  iter -- current iteration of ionic motion
!  time -- current simulation time [in femtoseconds]
integer  iter,atom,ai,elem
real(8)  time
write(mdxyz_file,'(1x,i5)') N_total_atom
write(mdxyz_file,'(1x,a,i6,a,f10.5,a,f10.5)') '# iter =',iter,'  time[fs]=',time,' ##N_ELEC=',sum(Density)*grid_volume
do atom=1,N_total_atom
  ai=atom_index(atom)
  elem=z_atom(ai)
  write(mdxyz_file,'(1x,a3,3(1x,e16.9))') &
     element_symbols(elem),Position(1,atom),Position(2,atom),Position(3,atom)
enddo



end subroutine print_ion_xyzTofile_wN_Elec

! cody
subroutine print_ion_forcesTofile(iter,time)
!  iter -- current iteration of ionic motion
!  time -- current simulation time [in femtoseconds]
integer  iter,atom,ai,elem
real(8)  time
! mdforces_file=102
!open(mdforces_file,FILE=trim(adjustl(md_forcesfilename)),STATUS='UNKNOWN', POSITION='APPEND')
write(mdforces_file,'(1x,i5)') N_total_atom
write(mdforces_file,'(1x,a,i6,a,f10.5,a,f10.5)') '# iter =',iter,'  time[fs]=',time,' ##N_ELEC=',sum(Density)*grid_volume
do atom=1,N_total_atom
  ai=atom_index(atom)
  elem=z_atom(ai)
  write(mdforces_file,'(1x,a3,3(1x,e16.9))') &
     element_symbols(elem),force(1,atom),force(2,atom),force(3,atom)
enddo



end subroutine print_ion_forcesTofile

subroutine print_mol_dynamics_file_header
!This subroutine prints a header in mol_dynamics_file
integer      atom,elem,j,nspaces,p
character(16)   stratom
integer,parameter  :: reclength=20
integer,parameter  :: backmargin=3
character(reclength)  str1,str2,str3
character(2*reclength),parameter :: spstr=' '
integer :: cn

p=moldyn_output_level
if (p==0) return

cn=3
if (p>1) cn=cn+1
if ((p>1).and.using_v_laser1) cn=cn+1
if ((p>1).and.using_v_laser2) cn=cn+1
if ((p>1).and.using_v_laser3) cn=cn+1
if ((p>1).and.using_v_ext) cn=cn+1
if (output_projectile_trajectory) cn=cn+3
if (p>2) cn=cn+6
do atom=1,N_total_atom
  if (atom_movable(atom)) then
    elem=z_atom(atom_index(atom))
    if (elem/=0) then  
      cn=cn+3
      if (p>2) cn=cn+6
      if (p>4) cn=cn+1
    endif
  endif  
enddo  
if ((p>2).and.output_projectile_trajectory) cn=cn+6
if ((p>4).and.output_projectile_trajectory) cn=cn+1

write(mol_dynamics_file,'(2x,a2)',advance='no') '#1'
write(mol_dynamics_file,'(18x,a2)',advance='no') '#2'
do j=3,cn
  write(mol_dynamics_file,'(1x,i19)',advance='no') j
enddo
write(mol_dynamics_file,*)

write(mol_dynamics_file,'(2x,a)',advance='no')    '#iter'
write(mol_dynamics_file,'(8x,a,3x)',advance='no') '#time[fs]'
write(mol_dynamics_file,'(3x,a,3x)',advance='no') 'temperature[K]'
if (p>1) then
  write(mol_dynamics_file,'(3x,a,3x)',advance='no') 'tot_kin_en[eV]'
  if (using_v_laser1) write(mol_dynamics_file,'(5x,a,3x)',advance='no') 'Elaser1[V/A]'
  if (using_v_laser2) write(mol_dynamics_file,'(5x,a,3x)',advance='no') 'Elaser2[V/A]'
  if (using_v_laser3) write(mol_dynamics_file,'(5x,a,3x)',advance='no') 'Elaser3[V/A]'
  if (using_v_ext)    write(mol_dynamics_file,'(5x,a,3x)',advance='no') 'Estatic[V/A]'
endif
if (output_projectile_trajectory) then
  write(mol_dynamics_file,'(9x,a,3x)',advance='no') 'Xproj[A]'
  write(mol_dynamics_file,'(9x,a,3x)',advance='no') 'Yproj[A]'
  write(mol_dynamics_file,'(9x,a,3x)',advance='no') 'Zproj[A]'
endif
if (p>2) then
  write(mol_dynamics_file,'(11x,a,3x)',advance='no') 'XCM[A]'
  write(mol_dynamics_file,'(11x,a,3x)',advance='no') 'YCM[A]'
  write(mol_dynamics_file,'(11x,a,3x)',advance='no') 'ZCM[A]'
  write(mol_dynamics_file,'(10x,a,3x)',advance='no') 'VCMx[A]'
  write(mol_dynamics_file,'(10x,a,3x)',advance='no') 'VCMy[A]'
  write(mol_dynamics_file,'(10x,a,3x)',advance='no') 'VCMz[A]'
endif
do atom=1,N_total_atom
  if (atom_movable(atom)) then
    elem=z_atom(atom_index(atom))
    if (elem/=0) then
      write(stratom,*) atom
      write(str1,*) 'X',trim(adjustl(stratom)),'[A]'
      write(str2,*) 'Y',trim(adjustl(stratom)),'[A]'
      write(str3,*) 'Z',trim(adjustl(stratom)),'[A]'
      nspaces=reclength-backmargin-len_trim(str1)
      write(mol_dynamics_file,'(a)',advance='no') spstr(1:nspaces)
      write(mol_dynamics_file,'(a)',advance='no') trim(str1)
      write(mol_dynamics_file,'(a)',advance='no') spstr(1:backmargin+nspaces)
      write(mol_dynamics_file,'(a)',advance='no') trim(str2)
      write(mol_dynamics_file,'(a)',advance='no') spstr(1:backmargin+nspaces)
      write(mol_dynamics_file,'(a)',advance='no') trim(str3)
      write(mol_dynamics_file,'(a)',advance='no') spstr(1:backmargin)
    endif
  endif
enddo
if (p>2) then
  if (output_projectile_trajectory) then
    write(mol_dynamics_file,'(7x,a,1x)',advance='no') 'Vxproj[A/fs]'
    write(mol_dynamics_file,'(7x,a,1x)',advance='no') 'Vyproj[A/fs]'
    write(mol_dynamics_file,'(7x,a,1x)',advance='no') 'Vzproj[A/fs]'
  endif
  do atom=1,N_total_atom
    if (atom_movable(atom)) then
      elem=z_atom(atom_index(atom))
      if (elem/=0) then
        write(stratom,*) atom
        write(str1,*) 'V',trim(adjustl(stratom)),'x[A/fs]'
        write(str2,*) 'V',trim(adjustl(stratom)),'y[A/fs]'
        write(str3,*) 'V',trim(adjustl(stratom)),'z[A/fs]'
        nspaces=reclength-backmargin-len_trim(str1)
        write(mol_dynamics_file,'(a)',advance='no') spstr(1:nspaces)
        write(mol_dynamics_file,'(a)',advance='no') trim(str1)
        write(mol_dynamics_file,'(a)',advance='no') spstr(1:backmargin+nspaces)
        write(mol_dynamics_file,'(a)',advance='no') trim(str2)
        write(mol_dynamics_file,'(a)',advance='no') spstr(1:backmargin+nspaces)
        write(mol_dynamics_file,'(a)',advance='no') trim(str3)
        write(mol_dynamics_file,'(a)',advance='no') spstr(1:backmargin)
      endif
    endif
  enddo
  if (output_projectile_trajectory) then
    write(mol_dynamics_file,'(7x,a,1x)',advance='no') 'Fxproj[eV/A]'
    write(mol_dynamics_file,'(7x,a,1x)',advance='no') 'Fyproj[eV/A]'
    write(mol_dynamics_file,'(7x,a,1x)',advance='no') 'Fzproj[eV/A]'
  endif
  do atom=1,N_total_atom
    if (atom_movable(atom)) then
      elem=z_atom(atom_index(atom))
      if (elem/=0) then
        write(stratom,*) atom
        write(str1,*) 'F',trim(adjustl(stratom)),'x[eV/A]'
        write(str2,*) 'F',trim(adjustl(stratom)),'y[eV/A]'
        write(str3,*) 'F',trim(adjustl(stratom)),'z[eV/A]'
        nspaces=reclength-backmargin-len_trim(str1)
        write(mol_dynamics_file,'(a)',advance='no') spstr(1:nspaces)
        write(mol_dynamics_file,'(a)',advance='no') trim(str1)
        write(mol_dynamics_file,'(a)',advance='no') spstr(1:backmargin+nspaces)
        write(mol_dynamics_file,'(a)',advance='no') trim(str2)
        write(mol_dynamics_file,'(a)',advance='no') spstr(1:backmargin+nspaces)
        write(mol_dynamics_file,'(a)',advance='no') trim(str3)
        write(mol_dynamics_file,'(a)',advance='no') spstr(1:backmargin)
      endif
    endif
  enddo
endif
if (p>4) then
  if (output_projectile_trajectory) then
    write(mol_dynamics_file,'(9x,a,1x)',advance='no') 'KEproj[eV]'
  endif
  do atom=1,N_total_atom
    if (atom_movable(atom)) then
      elem=z_atom(atom_index(atom))
      if (elem/=0) then
        write(stratom,*) atom
        write(str1,*) 'KE',trim(adjustl(stratom)),'[eV]'
        nspaces=reclength-backmargin-len_trim(str1)
        write(mol_dynamics_file,'(a)',advance='no') spstr(1:nspaces)
        write(mol_dynamics_file,'(a)',advance='no') trim(str1)
        write(mol_dynamics_file,'(a)',advance='no') spstr(1:backmargin)
      endif
    endif
  enddo  
endif  
write(mol_dynamics_file,*)
flush(mol_dynamics_file)

end subroutine print_mol_dynamics_file_header


subroutine update_mol_dynamics_file(iter,t)
!This subroutine writes current positions, velocities, and forces
!Parameters:
! iter - iteration number (for ionic motion)
! t    - time in femtoseconds
!Parameters iter and t are printed in the first two columns
integer iter,atom,elem,j,p,ai
real(8) t,Xcm,Ycm,Zcm,Vcmx,Vcmy,Vcmz,V2

p=moldyn_output_level
if (p==0) return
write(mol_dynamics_file,'(1x,i6)',advance='no') iter
write(mol_dynamics_file,'(1x,e19.12)',advance='no') t
write(mol_dynamics_file,'(1x,e19.12)',advance='no') temperature_ions
if (p>1) then
  write(mol_dynamics_file,'(1x,e19.12)',advance='no') tot_kin_energy_ions
  if (using_v_laser1) write(mol_dynamics_file,'(1x,e19.12)',advance='no') E_laser1*factor_laser1
  if (using_v_laser2) write(mol_dynamics_file,'(1x,e19.12)',advance='no') E_laser2*factor_laser2
  if (using_v_laser3) write(mol_dynamics_file,'(1x,e19.12)',advance='no') E_laser3*factor_laser3
  if (using_v_ext)    write(mol_dynamics_file,'(1x,e19.12)',advance='no') E_ext*factor_static_ef
endif
if (output_projectile_trajectory) then
  write(mol_dynamics_file,'(1x,e19.12)',advance='no') projectile_x
  write(mol_dynamics_file,'(1x,e19.12)',advance='no') projectile_y
  write(mol_dynamics_file,'(1x,e19.12)',advance='no') projectile_z
endif
if (p>2) then
  call compute_center_of_mass_state(Xcm,Ycm,Zcm,Vcmx,Vcmy,Vcmz)
  write(mol_dynamics_file,'(1x,e19.12)',advance='no') Xcm
  write(mol_dynamics_file,'(1x,e19.12)',advance='no') Ycm
  write(mol_dynamics_file,'(1x,e19.12)',advance='no') Zcm
  write(mol_dynamics_file,'(1x,e19.12)',advance='no') Vcmx
  write(mol_dynamics_file,'(1x,e19.12)',advance='no') Vcmy
  write(mol_dynamics_file,'(1x,e19.12)',advance='no') Vcmz
endif
do atom=1,N_total_atom
  if (atom_movable(atom)) then
    elem=z_atom(atom_index(atom))
    if (elem/=0) then
      do j=1,3
        write(mol_dynamics_file,'(1x,e19.12)',advance='no') Position(j,atom)
      enddo
    endif
  endif
enddo
if (p>2) then
  if (output_projectile_trajectory) then
    write(mol_dynamics_file,'(1x,e19.12)',advance='no') projectile_vx
    write(mol_dynamics_file,'(1x,e19.12)',advance='no') projectile_vy
    write(mol_dynamics_file,'(1x,e19.12)',advance='no') projectile_vz
  endif
  do atom=1,N_total_atom
    if (atom_movable(atom)) then
      elem=z_atom(atom_index(atom))
      if (elem/=0) then
        do j=1,3
          write(mol_dynamics_file,'(1x,e19.12)',advance='no') atom_velocity(j,atom)
        enddo
      endif
    endif
  enddo
  if (output_projectile_trajectory) then
    write(mol_dynamics_file,'(1x,e19.12)',advance='no') projectile_f(1)
    write(mol_dynamics_file,'(1x,e19.12)',advance='no') projectile_f(2)
    write(mol_dynamics_file,'(1x,e19.12)',advance='no') projectile_f(3)
  endif
  do atom=1,N_total_atom
    if (atom_movable(atom)) then
      elem=z_atom(atom_index(atom))
      if (elem/=0) then
        do j=1,3
          write(mol_dynamics_file,'(1x,e19.12)',advance='no') force(j,atom)
        enddo
      endif
    endif
  enddo
endif
if (p>4) then
  if (output_projectile_trajectory) then
    write(mol_dynamics_file,'(1x,e19.12)',advance='no') projectile_energy
  endif  
  do atom=1,N_total_atom
    if (atom_movable(atom)) then
      ai=atom_index(atom)
      elem=z_atom(ai)
      if (elem/=0) then
        V2=atom_velocity(1,atom)**2+atom_velocity(2,atom)**2+atom_velocity(3,atom)**2
        write(mol_dynamics_file,'(1x,e19.12)',advance='no') 0.5d0*atomic_mass(ai)*V2
      endif
    endif
  enddo  
endif  
write(mol_dynamics_file,*)
flush(mol_dynamics_file)

end subroutine update_mol_dynamics_file


subroutine initialize_atomic_velocities(v,temperature)
!This subroutine gives each atom (ion), which is allowed to move,
!a random velocity in x,y,z directions according to the Maxwell-Boltzmann
!distribution at certain temperature
!Input parameters:
!  temperature - temperature [in Kelvins]
!Output data:
!  v(1:3,1:N_total_atom) - an array where the random velocities are returned [in A/femtosec]
real(8) v(3,N_total_atom),temperature
integer atom,ai,j,elem
real(8) f1,f2,temp,av_kin,tot_kin

!Seed uniform random generator
call kiss_setseed(ion_velocity_init_seed,43,59,171)
!Generate velocities
f1=k_Boltzmann*temperature
do atom=1,N_total_atom
  if (atom_movable(atom)) then
    ai=atom_index(atom)
    elem=z_atom(ai)
    if (elem/=0) then
      f2=sqrt(f1/atomic_mass(ai))
      do j=1,3
        v(j,atom)=rndnor()*f2
      enddo
    else
      v(1:3,atom)=0.0d0
    endif
  endif
enddo

!Since the number of ions in not infinite, after generating the
!x,y,z-velocities with Gaussian distribution we will find the average
!kinetic energy per ion to be slightly different from k*T (due to
!statistical error). Here we simply normalize all the velocities in
!such a way that the relation E_kin = k*T holds exactly.
call compute_atomic_temperature(v,temp,av_kin,tot_kin)
f1=sqrt(temperature/temp)
do atom=1,N_total_atom
  if (atom_movable(atom)) then
    ai=atom_index(atom)
    elem=z_atom(ai)
    if (elem/=0) then
      v(1:3,atom)=f1*v(1:3,atom)
    endif
  endif
enddo

end subroutine initialize_atomic_velocities

subroutine input_atomic_velocities(v) !Arthur
    !Initialize atomic velocities using velocity_input_file
    !First line of velocity_input_file is the number of atoms
    !the subsequent lines are the initial velocities in x, y, and z for each atom
    !units for velocity_input_file must be Angstrom/femtoseconds
    real(8) :: v(3,N_total_atom)
    integer :: num,i
    
    open(velocity_input_file,FILE=trim(adjustl(velocity_input_filename)))
    
    read(velocity_input_file,*) num
    if(num.NE.N_total_atom) then
        write(log_file,*) "number of velocities does not match number of atoms!"
		stop
    else 
        do i=1,N_total_atom
            read(velocity_input_file, *) v(1,i),v(2,i),v(3,i)
			write(log_file,'(a,i4,3f20.10)') "loading_vel_atom ",i, v(1,i),v(2,i),v(3,i)
        end do
    end if
                
    close(velocity_input_file)
    write(log_file,*) "done loading atom velocities"
end subroutine

subroutine set_atomic_vel_combine_gs2_boost(v)
! if 2 different GS files are merged, 1 can be boosted. 
! this will boost the 2nd GS file.
    real(8) :: v(3,N_total_atom)
    integer :: num,i,a_start
    
	a_start=combine_gs_num_atom_file1+1
	write(log_file,*) "Of the ",N_total_atom," loaded"
	write(log_file,*) combine_gs_num_atom_file1," were from file1"
	write(log_file,*) combine_gs_num_atom_file2," were from file2"
	write(log_file,*) "Set initial velocity of atoms ",a_start," to ",N_total_atom
	write(log_file,*) "V=",combine_gs_boost_vx,combine_gs_boost_vy,combine_gs_boost_vz
	do i=a_start,N_total_atom
	  v(1,i)=combine_gs_boost_vx
	  v(2,i)=combine_gs_boost_vy
	  v(3,i)=combine_gs_boost_vz
	end do
end subroutine set_atomic_vel_combine_gs2_boost

subroutine compute_atomic_temperature(v,temper,av_kin,tot_kin)
!This subroutine computes the temperature, as well as the total
!and average kinetic energies of ions. It only counts the ions
!that are allowed to move.
!Input parameters:
!  v(1:3,1:N_total_atoms) - atomic (i.e. ionic) velocities
!Output data is returned in three variables:
!  temper -- temperature of ions [in K]
!  av_kin -- average kinetic energy of ions, which is the basically
!                        the same as temper [in eV]
!  tot_kin -- total kinetic energy of ions [in eV]
real(8) v(3,N_total_atom),temper,av_kin,tot_kin
integer atom,j,ai,elem,atom_count
real(8) mass,f,te

atom_count=0
te=0.0d0
do atom=1,N_total_atom
  if (atom_movable(atom)) then
    ai=atom_index(atom)
    elem=z_atom(ai)
    if (elem/=0) then
      atom_count=atom_count+1
      mass=atomic_mass(ai)
	  
      do j=1,3
        te=te+mass*v(j,atom)*v(j,atom)
      enddo
    endif
  endif
enddo
te=0.5d0*te
tot_kin=te
av_kin=tot_kin/atom_count
temper=(2.0d0/3.0d0)*av_kin/k_Boltzmann

end subroutine compute_atomic_temperature


subroutine compute_center_of_mass_state(Xcm,Ycm,Zcm,Vcmx,Vcmy,Vcmz)
!This subroutine computes the current position and velocity of
!the center of mass of the system. It counts only those atoms, which
!are allowed to move. The components of the position
!vector of the center of mass are returned in Xcm,Ycm,Zcm. The
!components of the center of mass velocity are returned in
!Vcmx,Vcmy,Vcmz
real(8) Xcm,Ycm,Zcm,Vcmx,Vcmy,Vcmz
integer atom,ai,elem
real(8) im,mass

Xcm=0.0d0
Ycm=0.0d0
Zcm=0.0d0
Vcmx=0.0d0
Vcmy=0.0d0
Vcmz=0.0d0
do atom=1,N_total_atom
  if (atom_movable(atom)) then
    ai=atom_index(atom)
    elem=z_atom(ai)
    if (elem/=0) then
      mass=atomic_mass(ai)
      Xcm=Xcm+mass*Position(1,atom)
      Ycm=Ycm+mass*Position(2,atom)
      Zcm=Zcm+mass*Position(3,atom)
      Vcmx=Vcmx+mass*atom_velocity(1,atom)
      Vcmy=Vcmy+mass*atom_velocity(2,atom)
      Vcmz=Vcmz+mass*atom_velocity(3,atom)
    endif
  endif
enddo
im=1/total_mass_of_all_atoms
Xcm=Xcm*im
Ycm=Ycm*im
Zcm=Zcm*im
Vcmx=Vcmx*im
Vcmy=Vcmy*im
Vcmz=Vcmz*im

end subroutine compute_center_of_mass_state


subroutine compute_total_mass_of_all_atoms(totmass)
!This subroutine computes the total mass of all the atoms in the
!system, which are allowed to move .
real(8) totmass
integer atom,ai,elem
totmass=0.0d0
do atom=1,N_total_atom
  if (atom_movable(atom)) then
    ai=atom_index(atom)
    elem=z_atom(ai)
    if (elem/=0) then
      totmass=totmass+atomic_mass(ai)
    endif
  endif
enddo

end subroutine compute_total_mass_of_all_atoms


subroutine compute_atomic_masses(mass)
!This subroutine computes the atomic masses of all species present in
!the system
!Output data:
! mass(1:N_Species) -- the array where the masses of atoms are returned
! if read_isotope_mass==.TRUE. then those values that were loaded are used.
real(8) mass(N_Species)
integer i,elem

do i=1,N_Species
  elem=z_atom(i)
  if (elem/=0) then
    if(read_isotope_mass) then
	  mass(i)=m_atom(i)*mass_convfactor
    else if (use_average_atomic_mass) then
      mass(i)=element_num_nucleons(elem)*mass_convfactor
    else
      mass(i)=element_average_atomic_mass(elem)*mass_convfactor
    endif
  endif
enddo
end subroutine compute_atomic_masses

subroutine update_trajectory_file(iter,time)
!This subroutine updates xyz-file with atomic trajectories
!The trajectory xyz-file is basically a big xyz-file containing
!all consequtive snapshots (no blank lines between snapshots).
!In the second line of each snapshot (second line of an xyz-file
!can be anything and is ignored by most visualization software) we
!put a comment line with the time [in femtoseconds] when the spapshot
!was made
!Input parameters:
!  iter -- current iteration of ionic motion
!  time -- current simulation time [in femtoseconds]
integer  iter,atom,ai,elem
real(8)  time
if (output_projectile_trajectory) then
  write(trajectory_file,'(1x,i5)') N_total_atom+1
else  
  write(trajectory_file,'(1x,i5)') N_total_atom
endif
write(trajectory_file,'(1x,a,i6,a,f8.5)') '# iter =',iter,'  time[fs]=',time
do atom=1,N_total_atom
  ai=atom_index(atom)
  elem=z_atom(ai)
  write(trajectory_file,'(1x,a3,3(1x,e16.9))') &
     element_symbols(elem),Position(1,atom),Position(2,atom),Position(3,atom)
enddo
if (output_projectile_trajectory) then
  write(trajectory_file,'(1x,a3,3(1x,e16.9))') ' Xx',projectile_x,projectile_y,projectile_z
endif
flush(trajectory_file)
end subroutine update_trajectory_file


subroutine find_closest_ions(Pos,closest_ion_index)
!This subroutine computes for each ion its closest neighbor
!and returns the indicies of those neighbor ions 
!Input parameters:
!   Pos -- array containing ion coordinates
!Output: 
!   closest_ion_index -- array containing the indices of the closest neighbors 
real*8   :: Pos(3,N_total_atom)
integer  :: closest_ion_index(N_total_atom)
integer  :: i,j
real*8   :: r2,r2min

if (N_total_atom==1) closest_ion_index(1)=1
do i=1,N_total_atom
  r2min=huge(r2)
  do j=1,N_total_atom
    if (j/=i) then
      r2=(Pos(1,j)-Pos(1,i))**2 + (Pos(2,j)-Pos(2,i))**2 + (Pos(3,j)-Pos(3,i))**2
      if (r2<r2min) then
        r2min=r2
        closest_ion_index(i)=j
      endif 
    endif  
  enddo 
enddo 
end subroutine find_closest_ions 


function max_abs_rel_displacement_ions(Pos,Pos_init,closest_ion_index)
!This function evaluates the maximum relative distance between ions
!and their closest neighbors 
!Input parameters:
!   Pos -- array containing current ion positions
!   Pos_init -- array containing initial ion positions 
!Output: 
!   closest_ion_index -- array containing the indices of the closest neighbors 
!                        (in the initial geometry), which should be calculated
!                        using subroutine find_closest_ions
real*8     :: max_abs_rel_displacement_ions
real*8     :: Pos(3,N_total_atom),Pos_init(3,N_total_atom)
integer    :: closest_ion_index(N_total_atom)
integer    :: i,j
real*8     :: hmax,h,ri,rc

max_abs_rel_displacement_ions=0.0d0
if (N_total_atom==1) return

hmax=0.0d0
do i=1,N_total_atom
  j=closest_ion_index(i)
  rc=sqrt((Pos(1,i)-Pos_init(1,j))**2+(Pos(2,i)-Pos_init(2,j))**2+(Pos(3,i)-Pos_init(3,j))**2) 
  ri=sqrt((Pos_init(1,i)-Pos_init(1,j))**2+(Pos_init(2,i)-Pos_init(2,j))**2+(Pos_init(3,i)-Pos_init(3,j))**2)
  h=abs(rc-ri)/ri
  if (h>hmax) hmax=h
enddo
max_abs_rel_displacement_ions=hmax
end function max_abs_rel_displacement_ions


subroutine init_bohmian_md
!This subroutine makes initializations needed to run Bohmian molecular dynamics
integer   i,j,b,orbital,metr_acc,metr_acc_tot  
real(8)   avg_den,x,y,z,xt,yt,zt
real(8)   xmin,xmax,ymin,ymax,zmin,zmax
real(8)   dens_orb,dens_orb_t,w
logical   less_than_threshold

N_BohmianPart=0
do i=1,N_orbitals
  N_BohmianPart=N_BohmianPart+occupation(i)  
enddo 
allocate(PosBohmianPart(3,N_BohmianPart))
allocate(PosBohmianPart_prev(3,N_BohmianPart))
if(generate_bmd_seed) then
  !Set a seed using system time
  call system_clock(count=bmd_seed)
endif 
!Seed random generator
i=bmd_seed
call kiss_setseed(i+17,i+113,i+7919,i+11)
!Set the step size for random walk, which will be used in the Metropolis sampling
!if (.not.bmd_walker_step_supplied) bmd_walker_step=0.7d0*(grid_step(1)+grid_step(2)+grid_step(3))
if (.not.bmd_walker_step_supplied) bmd_walker_step=0.45d0  !some empirical value

avg_den=1.0d0/(grid_volume*N_lattice_points)
xmin=xgrid(N_Lattice_min(1)); xmax=xgrid(N_Lattice_max(1))
ymin=ygrid(N_Lattice_min(2)); ymax=ygrid(N_Lattice_max(2))
zmin=zgrid(N_Lattice_min(3)); zmax=zgrid(N_Lattice_max(3))

write(log_file,'(1x,a)') 'Bohmian particle position initialization (by Metropolis sampling)'
write(log_file,'(1x,a,f10.7)') 'with walker average step size of ',bmd_walker_step
write(log_file,'(1x,a)') '   orbital  particle   (accepted steps)/(total steps):'
metr_acc_tot=0
b=0  !Bohmian particle counter
do orbital=1,N_orbitals
  do j=1,nint(occupation(orbital))
    b=b+1
    !Initialize the walker (based on uniform distribution within the simulation box, but
    !it can only be placed at a point where the orbital density is not vanishing, i.e. where 
    !it exceeds some small threshold equal to 0.001 of the average orbital density in the box)    
    less_than_threshold=.true.
    do while (less_than_threshold)
      x=xmin+rkiss()*(xmax-xmin)
      y=ymin+rkiss()*(ymax-ymin)
      z=zmin+rkiss()*(zmax-zmin)
      dens_orb=abssqr_Psi_val(x,y,z,orbital)
      if (dens_orb>0.001d0*avg_den) less_than_threshold=.false.
    enddo
    !Now do the Metropolis sampling of a single point. For that
    !bmd_n_walker_steps is made (acceptance/rejection ratio is not adjusted so
    !this number has to be sufficiently large). Each step has the average size  
    !bmd_walker_step 
    metr_acc=0
    do i=1,bmd_n_walker_steps
      xt=x+rndnor()*bmd_walker_step
      yt=y+rndnor()*bmd_walker_step
      zt=z+rndnor()*bmd_walker_step
      dens_orb_t=abssqr_Psi_val(xt,yt,zt,orbital)
      w=rkiss()      
      if (min(dens_orb_t/dens_orb,1.0d0)>w) then 
        x=xt
        y=yt
        z=zt
        dens_orb=dens_orb_t
        metr_acc=metr_acc+1
      endif       
    enddo     
    PosBohmianPart(1,b)=x
    PosBohmianPart(2,b)=y
    PosBohmianPart(3,b)=z 
    write(log_file,'(1x,i7,i10,7x,f17.12)') orbital,j,metr_acc*1.0d0/bmd_n_walker_steps
    metr_acc_tot=metr_acc_tot+metr_acc
  enddo
enddo
write(log_file,'(3x,a8,14x,f17.12)') 'average:',metr_acc_tot*1.0d0/(bmd_n_walker_steps*N_BohmianPart)


end subroutine init_bohmian_md

subroutine md_calc_com(com)
implicit none
 real*8,intent(out) :: com(3)
 real*8  :: mass,totmass,x(3)
 integer :: i,j,ai,atom
 
  totmass=0
  com=0.d0
  do atom=1,N_total_atom
    ai=atom_index(atom)
	mass=atomic_mass(ai)
	totmass=totmass+mass
	x=Position(:,atom)
	com=com+x*mass
  end do
  com=com/totmass
end subroutine md_calc_com  

! calculate density around atoms and nearest atom.
subroutine calculate_fragment_info(iter)
implicit none
 integer :: i,j,k,atom,iter
 real*8  :: dens_sum,dx,dy,dz,dr,time,atom_dist_min
 
 time=iter*time_step
 do atom=1,N_total_atom
   dens_sum=0.d0
   do i=1,N_Lattice(1)
     dx=abs(xgrid(i)-Position(1,atom)) 
	 ! save some time by not having to check every point.
	 if(dx>fragment_dens_rad) CYCLE
     do j=1,N_Lattice(2)
       dy=abs(ygrid(j)-Position(2,atom)) 
	   ! save some time by not having to check every point.
	   if(dy>fragment_dens_rad) CYCLE
	   do k=1,N_Lattice(3)
         dz=abs(zgrid(j)-Position(3,atom)) 
	     ! save some time by not having to check every point.
	     if(dz>fragment_dens_rad) CYCLE
		 dr=sqrt(dx**2+dy**2+dz**2)
		 if(dr<fragment_dens_rad) then
		   dens_sum=dens_sum+density(Lattice_inv_xyz(i,j,k))*grid_volume
		 end if
	   end do
	 end do
   end do
   atom_dist_min=9.d9
   do j=1,N_total_atom
     if(j==atom) CYCLE
	 dx=Position(1,atom)-Position(1,j)
	 dy=Position(2,atom)-Position(2,j)
	 dz=Position(3,atom)-Position(3,j)
     dr=sqrt(dx**2+dy**2+dz**2)
	 if(dr<atom_dist_min) then
	   atom_dist_min=dr
	 end if
   end do
   write(fragment_info_file_block+atom,'(f11.3,es28.16e3,f12.4)') time,dens_sum,atom_dist_min
 end do
 
end subroutine calculate_fragment_info


end module moldynamics

