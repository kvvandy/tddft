Module Taylor_extended
  USE MOD_GLOBAL
  USE PSEUDOPOTENTIAL
  use moldynamics
  USE HAMILTON
implicit none

  complex*16                      :: tc(N_taylor)


Contains

subroutine laser_at_time_t(iter,sw,efiteration)
! also sets factor_laser1,factor_laser2,factor_laser3 ... which are GLOBAL VARIABLES for some reason
implicit none
  integer    :: iter
  real*8     :: ramp,pulse(3),t,sw
  real*8,intent(inout)  :: efiteration(3)

  pulse=1.d0  
  t=iter*time_step
  ramp=1.d0
  if((ramp_time>0.d0).AND.(t<ramp_time)) ramp=t/ramp_time

if(using_v_laser1) then
  if (laser_envelope_type1=='gaussian') then
    if(laser_pulse_width1>0) then
      pulse(1)=exp(-((t-laser_pulse_shift1)/laser_pulse_width1)**2)
      if(abs(pulse(1))<1d-20) pulse(1)=0.d0
    endif
    time_factor(1)=pulse(1)*sin(laser_frequency1*(t-laser_pulse_shift1)+laser_phase1)
  endif   
  if (laser_envelope_type1=='fermi') then
    pulse(1)=1.0d0-1.0d0/(1.0d0+exp((t-laser_envelope_up_point1)/laser_envelope_up_steepness1))
    time_factor(1)=pulse(1)*sin(laser_frequency1*(t-laser_envelope_up_point1)+laser_phase1)
  endif 
  if (laser_envelope_type1=='doublefermi') then
    pulse(1)=1.0d0-1.0d0/(1.0d0+exp((t-laser_envelope_up_point1)/laser_envelope_up_steepness1))
    pulse(1)=pulse(1)/(1.0d0+exp((t-laser_envelope_down_point1)/laser_envelope_down_steepness1))
    time_factor(1)=pulse(1)*sin(laser_frequency1*(t-laser_envelope_up_point1)+laser_phase1)
  endif 
  factor_laser1=time_factor(1)*ramp*sw
endif

if(using_v_laser2) then
  if (laser_envelope_type2=='gaussian') then
    if(laser_pulse_width2>0) then
      pulse(2)=exp(-((t-laser_pulse_shift2)/laser_pulse_width2)**2)
      if(abs(pulse(2))<1d-20) pulse(2)=0.d0
    endif
    time_factor(2)=pulse(2)*sin(laser_frequency2*(t-laser_pulse_shift2)+laser_phase2)
  endif   
  if (laser_envelope_type2=='fermi') then
    pulse(2)=1.0d0-1.0d0/(1.0d0+exp((t-laser_envelope_up_point2)/laser_envelope_up_steepness2))
    time_factor(2)=pulse(2)*sin(laser_frequency2*(t-laser_envelope_up_point2)+laser_phase2)
  endif 
  if (laser_envelope_type2=='doublefermi') then
    pulse(2)=1.0d0-1.0d0/(1.0d0+exp((t-laser_envelope_up_point2)/laser_envelope_up_steepness2))
    pulse(2)=pulse(2)/(1.0d0+exp((t-laser_envelope_down_point2)/laser_envelope_down_steepness2))
    time_factor(2)=pulse(2)*sin(laser_frequency2*(t-laser_envelope_up_point2)+laser_phase2)
  endif 
  factor_laser2=time_factor(2)*ramp*sw
endif

if(using_v_laser3) then
  if (laser_envelope_type3=='gaussian') then
    if(laser_pulse_width3>0) then
      pulse(3)=exp(-((t-laser_pulse_shift3)/laser_pulse_width3)**2)
      if(abs(pulse(3))<1d-20) pulse(3)=0.d0
    endif
    time_factor(3)=pulse(3)*sin(laser_frequency3*(t-laser_pulse_shift3)+laser_phase3)
  endif   
  if (laser_envelope_type3=='fermi') then
    pulse(3)=1.0d0-1.0d0/(1.0d0+exp((t-laser_envelope_up_point3)/laser_envelope_up_steepness3))
    time_factor(3)=pulse(3)*sin(laser_frequency3*(t-laser_envelope_up_point3)+laser_phase3)
  endif 
  if (laser_envelope_type3=='doublefermi') then
    pulse(3)=1.0d0-1.0d0/(1.0d0+exp((t-laser_envelope_up_point3)/laser_envelope_up_steepness3))
    pulse(3)=pulse(3)/(1.0d0+exp((t-laser_envelope_down_point3)/laser_envelope_down_steepness3))
    time_factor(3)=pulse(3)*sin(laser_frequency3*(t-laser_envelope_up_point3)+laser_phase3)
  endif 
  factor_laser3=time_factor(3)*ramp*sw
endif

efiteration(1)=E_laser1*factor_laser1
efiteration(2)=E_laser2*factor_laser2
efiteration(3)=E_laser3*factor_laser3
if(using_v_ext) then
  if(e_ext_direction==1) efiteration(1)=efiteration(1)+E_ext*ramp*sw
  if(e_ext_direction==2) efiteration(2)=efiteration(2)+E_ext*ramp*sw
  if(e_ext_direction==3) efiteration(3)=efiteration(3)+E_ext*ramp*sw
end if 

if(using_v_fromfile) then ! cody 
   if ((iter <= laser_xyz_t_number).and.(iter >0)) then
	  efiteration(1) = laser_xyz_t(2,iter)
	  efiteration(2) = laser_xyz_t(3,iter)
	  efiteration(3) = laser_xyz_t(4,iter)
   else
      efiteration(1)=0.d0
	  efiteration(2)=0.d0
	  efiteration(3)=0.d0
   endif
   
endif

  
end subroutine laser_at_time_t

subroutine add_projectile_potential(matr,sw)
real*8  :: matr(N_lattice_points),sw
integer :: i
real*8  :: x,y,z,ff
ff=E2*sw*projectile_charge
!$omp parallel do &
!$omp default(shared) &
!$omp private (i, x, y, z)
do i=1,N_lattice_points
  x=Grid_Point(1,i)-projectile_x
  y=Grid_Point(2,i)-projectile_y
  z=Grid_Point(3,i)-projectile_z
  matr(i)=matr(i)-ff/sqrt(x**2+y**2+z**2+projectile_potential_soft_param**2)
enddo
!$omp end parallel do
end subroutine add_projectile_potential

subroutine generate_full_td_pot(it,sw)
implicit none
integer    :: it,i,j
real*8     :: sw,t
real*8     :: ramp,pulse(3),interp1

if(spin_polarized) then
  V_full_pot_up=0.d0
  V_full_pot_down=0.d0
else
  V_full_pot=0.d0
end if

t=it*time_step
ramp=1.d0
if((ramp_time>0.d0).AND.(t<ramp_time)) ramp=t/ramp_time

pulse=1.d0

if(using_v_laser1) then
  if (laser_envelope_type1=='gaussian') then
    if(laser_pulse_width1>0) then
      pulse(1)=exp(-((t-laser_pulse_shift1)/laser_pulse_width1)**2)
      if(abs(pulse(1))<1d-20) pulse(1)=0.d0
    endif
    time_factor(1)=pulse(1)*sin(laser_frequency1*(t-laser_pulse_shift1)+laser_phase1)
  endif   
  if (laser_envelope_type1=='fermi') then
    pulse(1)=1.0d0-1.0d0/(1.0d0+exp((t-laser_envelope_up_point1)/laser_envelope_up_steepness1))
    time_factor(1)=pulse(1)*sin(laser_frequency1*(t-laser_envelope_up_point1)+laser_phase1)
  endif 
  if (laser_envelope_type1=='doublefermi') then
    pulse(1)=1.0d0-1.0d0/(1.0d0+exp((t-laser_envelope_up_point1)/laser_envelope_up_steepness1))
    pulse(1)=pulse(1)/(1.0d0+exp((t-laser_envelope_down_point1)/laser_envelope_down_steepness1))
    time_factor(1)=pulse(1)*sin(laser_frequency1*(t-laser_envelope_up_point1)+laser_phase1)
  endif 
  factor_laser1=time_factor(1)*ramp*sw
endif

if(using_v_laser2) then
  if (laser_envelope_type2=='gaussian') then
    if(laser_pulse_width2>0) then
      pulse(2)=exp(-((t-laser_pulse_shift2)/laser_pulse_width2)**2)
      if(abs(pulse(2))<1d-20) pulse(2)=0.d0
    endif
    time_factor(2)=pulse(2)*sin(laser_frequency2*(t-laser_pulse_shift2)+laser_phase2)
  endif   
  if (laser_envelope_type2=='fermi') then
    pulse(2)=1.0d0-1.0d0/(1.0d0+exp((t-laser_envelope_up_point2)/laser_envelope_up_steepness2))
    time_factor(2)=pulse(2)*sin(laser_frequency2*(t-laser_envelope_up_point2)+laser_phase2)
  endif 
  if (laser_envelope_type2=='doublefermi') then
    pulse(2)=1.0d0-1.0d0/(1.0d0+exp((t-laser_envelope_up_point2)/laser_envelope_up_steepness2))
    pulse(2)=pulse(2)/(1.0d0+exp((t-laser_envelope_down_point2)/laser_envelope_down_steepness2))
    time_factor(2)=pulse(2)*sin(laser_frequency2*(t-laser_envelope_up_point2)+laser_phase2)
  endif 
  factor_laser2=time_factor(2)*ramp*sw
endif

if(using_v_laser3) then
  if (laser_envelope_type3=='gaussian') then
    if(laser_pulse_width3>0) then
      pulse(3)=exp(-((t-laser_pulse_shift3)/laser_pulse_width3)**2)
      if(abs(pulse(3))<1d-20) pulse(3)=0.d0
    endif
    time_factor(3)=pulse(3)*sin(laser_frequency3*(t-laser_pulse_shift3)+laser_phase3)
  endif   
  if (laser_envelope_type3=='fermi') then
    pulse(3)=1.0d0-1.0d0/(1.0d0+exp((t-laser_envelope_up_point3)/laser_envelope_up_steepness3))
    time_factor(3)=pulse(3)*sin(laser_frequency3*(t-laser_envelope_up_point3)+laser_phase3)
  endif 
  if (laser_envelope_type3=='doublefermi') then
    pulse(3)=1.0d0-1.0d0/(1.0d0+exp((t-laser_envelope_up_point3)/laser_envelope_up_steepness3))
    pulse(3)=pulse(3)/(1.0d0+exp((t-laser_envelope_down_point3)/laser_envelope_down_steepness3))
    time_factor(3)=pulse(3)*sin(laser_frequency3*(t-laser_envelope_up_point3)+laser_phase3)
  endif 
  factor_laser3=time_factor(3)*ramp*sw
endif


if (using_v_ext) then
  factor_static_ef=ramp*sw
endif

if (using_v_step) then
 V_td = ramp*V_steppot
end if

if ((using_v_laser1).and.(using_v_laser2).and.(using_v_laser3).and.(using_v_ext)) then
!$omp parallel workshare
V_td=factor_laser1*V_laser1+factor_laser2*V_laser2+factor_laser3*V_laser3+factor_static_ef*V_ext
!$omp end parallel workshare
endif
if ((.not.using_v_laser1).and.(using_v_laser2).and.(using_v_laser3).and.(using_v_ext)) then
!$omp parallel workshare
V_td=factor_laser2*V_laser2+factor_laser3*V_laser3+factor_static_ef*V_ext
!$omp end parallel workshare
endif
if ((using_v_laser1).and.(.not.using_v_laser2).and.(using_v_laser3).and.(using_v_ext)) then
!$omp parallel workshare
V_td=factor_laser1*V_laser1+factor_laser3*V_laser3+factor_static_ef*V_ext
!$omp end parallel workshare
endif
if ((using_v_laser1).and.(using_v_laser2).and.(.not.using_v_laser3).and.(using_v_ext)) then
!$omp parallel workshare
V_td=factor_laser1*V_laser1+factor_laser2*V_laser2+factor_static_ef*V_ext
!$omp end parallel workshare
endif
if ((using_v_laser1).and.(using_v_laser2).and.(using_v_laser3).and.(.not.using_v_ext)) then
!$omp parallel workshare
V_td=factor_laser1*V_laser1+factor_laser2*V_laser2+factor_laser3*V_laser3
!$omp end parallel workshare
endif
if ((.not.using_v_laser1).and.(.not.using_v_laser2).and.(using_v_laser3).and.(using_v_ext)) then
!$omp parallel workshare
V_td=factor_laser3*V_laser3+factor_static_ef*V_ext
!$omp end parallel workshare
endif
if ((.not.using_v_laser1).and.(using_v_laser2).and.(.not.using_v_laser3).and.(using_v_ext)) then
!$omp parallel workshare
V_td=factor_laser2*V_laser2+factor_static_ef*V_ext
!$omp end parallel workshare
endif
if ((.not.using_v_laser1).and.(using_v_laser2).and.(using_v_laser3).and.(.not.using_v_ext)) then
!$omp parallel workshare
V_td=factor_laser2*V_laser2+factor_laser3*V_laser3
!$omp end parallel workshare
endif
if ((using_v_laser1).and.(.not.using_v_laser2).and.(.not.using_v_laser3).and.(using_v_ext)) then
!$omp parallel workshare
V_td=factor_laser1*V_laser1+factor_static_ef*V_ext
!$omp end parallel workshare
endif
if ((using_v_laser1).and.(.not.using_v_laser2).and.(using_v_laser3).and.(.not.using_v_ext)) then
!$omp parallel workshare
V_td=factor_laser1*V_laser1+factor_laser3*V_laser3
!$omp end parallel workshare
endif
if ((using_v_laser1).and.(using_v_laser2).and.(.not.using_v_laser3).and.(.not.using_v_ext)) then
!$omp parallel workshare
V_td=factor_laser1*V_laser1+factor_laser2*V_laser2
!$omp end parallel workshare
endif
if ((.not.using_v_laser1).and.(.not.using_v_laser2).and.(.not.using_v_laser3).and.(using_v_ext)) then
!$omp parallel workshare
V_td=factor_static_ef*V_ext 
!$omp end parallel workshare
endif
if ((.not.using_v_laser1).and.(.not.using_v_laser2).and.(using_v_laser3).and.(.not.using_v_ext)) then
!$omp parallel workshare
V_td=factor_laser3*V_laser3
!$omp end parallel workshare
endif
if ((.not.using_v_laser1).and.(using_v_laser2).and.(.not.using_v_laser3).and.(.not.using_v_ext)) then
!$omp parallel workshare
V_td=factor_laser2*V_laser2 
!$omp end parallel workshare
endif
if ((using_v_laser1).and.(.not.using_v_laser2).and.(.not.using_v_laser3).and.(.not.using_v_ext)) then
!$omp parallel do default(shared) private (i)
do i=1,N_Lattice_points
  V_td(i)=factor_laser1*V_laser1(i) 
enddo  
!$omp end parallel do
endif
if ((.not.using_v_laser1).and.(.not.using_v_laser2).and.(.not.using_v_laser3)&
 .and.(.not.using_v_ext).and.(.not.using_v_step).and.(.not.using_v_fromfile)) then
!$omp parallel workshare
V_td=0.0d0
!$omp end parallel workshare
endif  

if(using_v_laser1) laser_xyz_t_iteration(1)=factor_laser1*E_laser1
if(using_v_laser2) laser_xyz_t_iteration(2)=factor_laser2*E_laser2
if(using_v_laser3) laser_xyz_t_iteration(3)=factor_laser3*E_laser3

 ! V_laser1 V_laser2 V_laser3 is set in subroutine setup_lattice as  x, y, z operators
if(using_v_fromfile) then ! cody 
   if ((t < laser_xyz_t(1,laser_xyz_t_number)).and.(it >0)) then
      j=1
	  do i=1,laser_xyz_t_number
	    if(laser_xyz_t(1,i)>t) then
		  j=i
		  EXIT
		end if
	  end do
	  ! do linear interpolation interpolation
	  interp1=(t-laser_xyz_t(1,j-1))/(laser_xyz_t(1,j)-laser_xyz_t(1,j-1))
	  laser_xyz_t_iteration(1) = laser_xyz_t(2,j-1)+interp1*(laser_xyz_t(2,j)-laser_xyz_t(2,j-1))
	  laser_xyz_t_iteration(2) = laser_xyz_t(3,j-1)+interp1*(laser_xyz_t(3,j)-laser_xyz_t(3,j-1))
	  laser_xyz_t_iteration(3) = laser_xyz_t(4,j-1)+interp1*(laser_xyz_t(4,j)-laser_xyz_t(4,j-1))
      !$omp parallel do default(shared) private (i)
	  do i=1,N_Lattice_points
        V_td(i)=laser_xyz_t_iteration(1)*V_laser1(i) + laser_xyz_t_iteration(2)*V_laser2(i) + laser_xyz_t_iteration(3)*V_laser3(i)
      enddo
	  !$omp end parallel do
	  write(log_file,'(A,3E15.8)') ' Eext=', laser_xyz_t_iteration(1) , laser_xyz_t_iteration(2) , laser_xyz_t_iteration(3) 
   else
      laser_xyz_t_iteration(1)=0.d0
	  laser_xyz_t_iteration(2)=0.d0
	  laser_xyz_t_iteration(3)=0.d0
      !$omp parallel workshare
      V_td=0.0d0
      !$omp end parallel workshare
	  write(log_file,*) ' Eext= 0.0 0.0 0.0'
   endif
   
endif

! cody  I think this should be moved as the projectile potential need only be updated ever step
if (use_projectile) then
call add_projectile_potential(V_td,sw)
endif
if(using_cap) then
  if(spin_polarized) then
    V_full_pot_up=V_l_pp+V_Hartree+V_Exchange_up+V_td+sw*zi*captotal
    V_full_pot_down=V_l_pp+V_Hartree+V_Exchange_down+V_td+sw*zi*captotal
  else
    V_full_pot=V_l_pp+V_Hartree+V_Exchange+V_td+sw*zi*captotal
  end if
else
  if(spin_polarized) then
    V_full_pot_up=V_l_pp+V_Hartree+V_Exchange_up+V_td
    V_full_pot_down=V_l_pp+V_Hartree+V_Exchange_down+V_td
  else
    V_full_pot=V_l_pp+V_Hartree+V_Exchange+V_td
  end if
end if

end subroutine generate_full_td_pot

subroutine Hamiltonian_wavefn_c(phi,Hphi)
!Calculates the action of time-dependent Hamiltonian on a complex-valued orbital phi
!Input variables:     
!  phi - A linear array containing the orbital |phi>
!Output variables:
! Hphi - A linear array containing H|phi>

complex*16 :: phi(N_lattice_points),Hphi(N_lattice_points)
integer :: i

call Kinetic_c(phi,T_phi_c)   

call Nonlocal_pseudo_potential_c(phi,V_nl_pp_c)  

if(spin_polarized) then
  if(spin_down) then
    do i=1,N_Lattice_points 
      Hphi(i)=V_nl_pp_c(i)+T_Phi_c(i)+V_full_pot_down(i)*phi(i)
	end do
  else if(spin_up) then
    do i=1,N_Lattice_points 
      Hphi(i)=V_nl_pp_c(i)+T_Phi_c(i)+V_full_pot_up(i)*phi(i)
	end do
  endif
else ! not spin polarized
  do i=1,N_Lattice_points 
    Hphi(i)=V_nl_pp_c(i)+T_Phi_c(i)+V_full_pot(i)*phi(i)
  end do
endif

end subroutine Hamiltonian_wavefn_c


subroutine Hamiltonian_wavefn_c2(phi,Hphi)
!Calculates the action of time-dependent Hamiltonian on a complex-valued orbital phi
!Input variables:     
!  phi - A linear array containing the orbital |phi>
!Output variables:
! Hphi - A linear array containing H|phi>
integer :: i 
complex*16 :: phi(N_lattice_points),Hphi(N_lattice_points)


call Kinetic_c(phi,T_phi_c)   

call Nonlocal_pseudo_potential_c(phi,V_nl_pp_c)  

do i=1,N_Lattice_points 
  Hphi(i)=V_nl_pp_c(i)+T_Phi_c(i)+(V_l_pp(i)+V_Hartree(i)+V_Exchange(i)+V_td(i))*phi(i)
end do
end subroutine Hamiltonian_wavefn_c2


subroutine Hamiltonian_wavefn_c_no_pot(it,sw,phi,Hphi)
!Calculates the action of time-dependent Hamiltonian on a complex-valued orbital phi
!Input variables:     
!   sw - A switch, which controls the addition of the explicitly time-dependent component of
!        the potential (i.g. laser). Normally it should be set to 1.0d0. However, it can be set to
!        0.0d0 or any other constant if needed.  
!   it - Current iteration 
!  phi - A linear array containing the orbital |phi>
!Output variables:
! Hphi - A linear array containing H|phi>
integer    :: it
real*8     :: sw,ctime1,ctime2
complex*16 :: phi(N_lattice_points),Hphi(N_lattice_points)
!complex*16,dimension(:),allocatable :: cphi1
!Local variables:
integer    :: i,i1,i2,i3,j,k
real*8     :: ramp,pulse(3),t,mrd,sf
complex*16 :: wlap_x

!allocate(cphi1(N_Lattice_points))
t=it*time_step
ramp=1.d0
if((ramp_time>0.d0).AND.(t<ramp_time)) ramp=t/ramp_time

pulse=1.d0

if(using_v_laser1) then
  if (laser_envelope_type1=='gaussian') then
    if(laser_pulse_width1>0) then
      pulse(1)=exp(-((t-laser_pulse_shift1)/laser_pulse_width1)**2)
      if(abs(pulse(1))<1d-20) pulse(1)=0.d0
    endif
    time_factor(1)=pulse(1)*sin(laser_frequency1*(t-laser_pulse_shift1)+laser_phase1)
  endif   
  if (laser_envelope_type1=='fermi') then
    pulse(1)=1.0d0-1.0d0/(1.0d0+exp((t-laser_envelope_up_point1)/laser_envelope_up_steepness1))
    time_factor(1)=pulse(1)*sin(laser_frequency1*(t-laser_envelope_up_point1)+laser_phase1)
  endif 
  if (laser_envelope_type1=='doublefermi') then
    pulse(1)=1.0d0-1.0d0/(1.0d0+exp((t-laser_envelope_up_point1)/laser_envelope_up_steepness1))
    pulse(1)=pulse(1)/(1.0d0+exp((t-laser_envelope_down_point1)/laser_envelope_down_steepness1))
    time_factor(1)=pulse(1)*sin(laser_frequency1*(t-laser_envelope_up_point1)+laser_phase1)
  endif 
  factor_laser1=time_factor(1)*ramp*sw
endif

if(using_v_laser2) then
  if (laser_envelope_type2=='gaussian') then
    if(laser_pulse_width2>0) then
      pulse(2)=exp(-((t-laser_pulse_shift2)/laser_pulse_width2)**2)
      if(abs(pulse(2))<1d-20) pulse(2)=0.d0
    endif
    time_factor(2)=pulse(2)*sin(laser_frequency2*(t-laser_pulse_shift2)+laser_phase2)
  endif   
  if (laser_envelope_type2=='fermi') then
    pulse(2)=1.0d0-1.0d0/(1.0d0+exp((t-laser_envelope_up_point2)/laser_envelope_up_steepness2))
    time_factor(2)=pulse(2)*sin(laser_frequency2*(t-laser_envelope_up_point2)+laser_phase2)
  endif 
  if (laser_envelope_type2=='doublefermi') then
    pulse(2)=1.0d0-1.0d0/(1.0d0+exp((t-laser_envelope_up_point2)/laser_envelope_up_steepness2))
    pulse(2)=pulse(2)/(1.0d0+exp((t-laser_envelope_down_point2)/laser_envelope_down_steepness2))
    time_factor(2)=pulse(2)*sin(laser_frequency2*(t-laser_envelope_up_point2)+laser_phase2)
  endif 
  factor_laser2=time_factor(2)*ramp*sw
endif

if(using_v_laser3) then
  if (laser_envelope_type3=='gaussian') then
    if(laser_pulse_width3>0) then
      pulse(3)=exp(-((t-laser_pulse_shift3)/laser_pulse_width3)**2)
      if(abs(pulse(3))<1d-20) pulse(3)=0.d0
    endif
    time_factor(3)=pulse(3)*sin(laser_frequency3*(t-laser_pulse_shift3)+laser_phase3)
  endif   
  if (laser_envelope_type3=='fermi') then
    pulse(3)=1.0d0-1.0d0/(1.0d0+exp((t-laser_envelope_up_point3)/laser_envelope_up_steepness3))
    time_factor(3)=pulse(3)*sin(laser_frequency3*(t-laser_envelope_up_point3)+laser_phase3)
  endif 
  if (laser_envelope_type3=='doublefermi') then
    pulse(3)=1.0d0-1.0d0/(1.0d0+exp((t-laser_envelope_up_point3)/laser_envelope_up_steepness3))
    pulse(3)=pulse(3)/(1.0d0+exp((t-laser_envelope_down_point3)/laser_envelope_down_steepness3))
    time_factor(3)=pulse(3)*sin(laser_frequency3*(t-laser_envelope_up_point3)+laser_phase3)
  endif 
  factor_laser3=time_factor(3)*ramp*sw
endif


sf=1.0d0
if (suppress_field_upon_ion_motion) then
  if (.not.field_suppression_on) then
    mrd=max_abs_rel_displacement_ions(Position,Position_init,closest_ion_init)
    if (mrd>field_suppression_trd) then
      field_suppression_start_time=t
      field_suppression_on=.true.
      write(log_file,*) 'field_suppression_start_time : ',field_suppression_start_time
    endif 
  endif 
  if (field_suppression_on) then
    sf=exp(-abs((t-field_suppression_start_time)/field_suppression_timescale)**field_suppression_power)
    factor_laser1=factor_laser1*sf
    factor_laser2=factor_laser2*sf
    factor_laser3=factor_laser3*sf 
    factor_static_ef=factor_static_ef*sf
  endif  
endif 

if (using_v_ext) then
  factor_static_ef=ramp*sw
endif

if (using_v_step) then
 V_td = ramp*V_steppot
end if

if ((using_v_laser1).and.(using_v_laser2).and.(using_v_laser3).and.(using_v_ext)) then
!$omp parallel workshare
V_td=factor_laser1*V_laser1+factor_laser2*V_laser2+factor_laser3*V_laser3+factor_static_ef*V_ext
!$omp end parallel workshare
endif
if ((.not.using_v_laser1).and.(using_v_laser2).and.(using_v_laser3).and.(using_v_ext)) then
!$omp parallel workshare
V_td=factor_laser2*V_laser2+factor_laser3*V_laser3+factor_static_ef*V_ext
!$omp end parallel workshare
endif
if ((using_v_laser1).and.(.not.using_v_laser2).and.(using_v_laser3).and.(using_v_ext)) then
!$omp parallel workshare
V_td=factor_laser1*V_laser1+factor_laser3*V_laser3+factor_static_ef*V_ext
!$omp end parallel workshare
endif
if ((using_v_laser1).and.(using_v_laser2).and.(.not.using_v_laser3).and.(using_v_ext)) then
!$omp parallel workshare
V_td=factor_laser1*V_laser1+factor_laser2*V_laser2+factor_static_ef*V_ext
!$omp end parallel workshare
endif
if ((using_v_laser1).and.(using_v_laser2).and.(using_v_laser3).and.(.not.using_v_ext)) then
!$omp parallel workshare
V_td=factor_laser1*V_laser1+factor_laser2*V_laser2+factor_laser3*V_laser3
!$omp end parallel workshare
endif
if ((.not.using_v_laser1).and.(.not.using_v_laser2).and.(using_v_laser3).and.(using_v_ext)) then
!$omp parallel workshare
V_td=factor_laser3*V_laser3+factor_static_ef*V_ext
!$omp end parallel workshare
endif
if ((.not.using_v_laser1).and.(using_v_laser2).and.(.not.using_v_laser3).and.(using_v_ext)) then
!$omp parallel workshare
V_td=factor_laser2*V_laser2+factor_static_ef*V_ext
!$omp end parallel workshare
endif
if ((.not.using_v_laser1).and.(using_v_laser2).and.(using_v_laser3).and.(.not.using_v_ext)) then
!$omp parallel workshare
V_td=factor_laser2*V_laser2+factor_laser3*V_laser3
!$omp end parallel workshare
endif
if ((using_v_laser1).and.(.not.using_v_laser2).and.(.not.using_v_laser3).and.(using_v_ext)) then
!$omp parallel workshare
V_td=factor_laser1*V_laser1+factor_static_ef*V_ext
!$omp end parallel workshare
endif
if ((using_v_laser1).and.(.not.using_v_laser2).and.(using_v_laser3).and.(.not.using_v_ext)) then
!$omp parallel workshare
V_td=factor_laser1*V_laser1+factor_laser3*V_laser3
!$omp end parallel workshare
endif
if ((using_v_laser1).and.(using_v_laser2).and.(.not.using_v_laser3).and.(.not.using_v_ext)) then
!$omp parallel workshare
V_td=factor_laser1*V_laser1+factor_laser2*V_laser2
!$omp end parallel workshare
endif
if ((.not.using_v_laser1).and.(.not.using_v_laser2).and.(.not.using_v_laser3).and.(using_v_ext)) then
!$omp parallel workshare
V_td=factor_static_ef*V_ext 
!$omp end parallel workshare
endif
if ((.not.using_v_laser1).and.(.not.using_v_laser2).and.(using_v_laser3).and.(.not.using_v_ext)) then
!$omp parallel workshare
V_td=factor_laser3*V_laser3
!$omp end parallel workshare
endif
if ((.not.using_v_laser1).and.(using_v_laser2).and.(.not.using_v_laser3).and.(.not.using_v_ext)) then
!$omp parallel workshare
V_td=factor_laser2*V_laser2 
!$omp end parallel workshare
endif
if ((using_v_laser1).and.(.not.using_v_laser2).and.(.not.using_v_laser3).and.(.not.using_v_ext)) then
!$omp parallel do default(shared) private (i)
do i=1,N_Lattice_points
  V_td(i)=factor_laser1*V_laser1(i) 
enddo  
!$omp end parallel do
endif
if ((.not.using_v_laser1).and.(.not.using_v_laser2).and.(.not.using_v_laser3).and. &
  (.not.using_v_ext).and.(.not.using_v_step).and.(.not.using_v_fromfile)) then
!$omp parallel workshare
V_td=0.0d0
!$omp end parallel workshare
endif  

if(using_v_laser1) laser_xyz_t_iteration(1)=factor_laser1*E_laser1
if(using_v_laser2) laser_xyz_t_iteration(2)=factor_laser2*E_laser2
if(using_v_laser3) laser_xyz_t_iteration(3)=factor_laser3*E_laser3

 ! V_laser1 V_laser2 V_laser3 is set in subroutine setup_lattice as  x, y, z operators
if(using_v_fromfile) then ! cody 
   if ((it <= laser_xyz_t_number).and.(it >0)) then
	  laser_xyz_t_iteration(1) = laser_xyz_t(2,it)
	  laser_xyz_t_iteration(2) = laser_xyz_t(3,it)
	  laser_xyz_t_iteration(3) = laser_xyz_t(4,it)
      !$omp parallel do default(shared) private (i)
	  do i=1,N_Lattice_points
        V_td(i)=laser_xyz_t_iteration(1)*V_laser1(i) + laser_xyz_t_iteration(2)*V_laser2(i) + laser_xyz_t_iteration(3)*V_laser3(i)
      enddo
	  !$omp end parallel do
	  write(log_file,'(A,3E15.8)') ' Eext=', laser_xyz_t_iteration(1) , laser_xyz_t_iteration(2) , laser_xyz_t_iteration(3) 
   else
      laser_xyz_t_iteration(1)=0.d0
	  laser_xyz_t_iteration(2)=0.d0
	  laser_xyz_t_iteration(3)=0.d0
      !$omp parallel workshare
      V_td=0.0d0
      !$omp end parallel workshare
	  write(log_file,*) ' Eext= 0.0 0.0 0.0'
   endif
   
endif


if(grid_type==1) call Kinetic_c(phi,T_phi_c)
if(grid_type==2) call lf_Kinetic_c(phi,T_phi_c)   
if(grid_type==3) call lf_Kinetic_fast_c(phi,T_phi_c)   


    !$omp parallel do default(shared) private (i)
    do i=1,N_Lattice_points 
      if(using_cap)	then
	    Hphi(i)=T_Phi_c(i)+(V_td(i)+sw*zi*captotal(i))*phi(i)
      else
		Hphi(i)=T_Phi_c(i)+(V_td(i))*phi(i)
      end if
    enddo

!deallocate(cphi)
end subroutine Hamiltonian_wavefn_c_no_pot


subroutine Hamiltonian_wavefn_c_fd_velocity(it,sw,phi,Hphi,A)
!Calculates the action of time-dependent Hamiltonian on a complex-valued orbital phi
!Input variables:     
!   sw - A switch, which controls the addition of the explicitly time-dependent component of
!        the potential (i.g. laser). Normally it should be set to 1.0d0. However, it can be set to
!        0.0d0 or any other constant if needed.  
!   it - Current iteration 
!  phi - A linear array containing the orbital |phi>
!Output variables:
! Hphi - A linear array containing H|phi>
integer    :: it
real*8     :: sw,ctime1,ctime2,A(3)
complex*16 :: phi(N_lattice_points),Hphi(N_lattice_points)
!complex*16,dimension(:),allocatable :: cphi1
!Local variables:
integer    :: i,i1,i2,i3,j,k
real*8     :: ramp,pulse(3),t,mrd,sf
complex*16 :: wlap_x

!allocate(cphi1(N_Lattice_points))
t=it*time_step


if(grid_type/=1) then
  write(log_file,*) "only grid type 1 allowed for fd_velocity propagation"
  stop
end if

call Kinetic_c_fd_velocity(phi,T_phi_c,A)

call Nonlocal_pseudo_potential_c(phi,V_nl_pp_c)  

if((spin_polarized).and.(spin_down)) then
  if(using_cap) then
    !$omp parallel workshare
    Hphi=V_nl_pp_c+T_Phi_c+(V_l_pp+V_Hartree+V_Exchange_down+V_td+sw*zi*captotal)*phi
    !$omp end parallel workshare
  else
    !$omp parallel workshare
    Hphi=V_nl_pp_c+T_Phi_c+(V_l_pp+V_Hartree+V_Exchange_down+V_td)*phi
    !$omp end parallel workshare
  endif
  endif
  if((spin_polarized).and.(spin_up)) then
  if(using_cap) then
    !$omp parallel workshare
    Hphi=V_nl_pp_c+T_Phi_c+(V_l_pp+V_Hartree+V_Exchange_up+V_td+sw*zi*captotal)*phi
    !$omp end parallel workshare
  else
    !$omp parallel workshare
    Hphi=V_nl_pp_c+T_Phi_c+(V_l_pp+V_Hartree+V_Exchange_up+V_td)*phi
    !$omp end parallel workshare
  endif
  endif
  if(.not.spin_polarized) then
  if((using_cap).and.(.not.add_projector_cap)) then
    !$omp parallel do default(shared) private (i)
    do i=1,N_Lattice_points      
      Hphi(i)=V_nl_pp_c(i)+T_Phi_c(i)+(V_l_pp(i)+V_Hartree(i)+V_Exchange(i)+V_td(i)+sw*zi*captotal(i))*phi(i)
   enddo
  else if((using_cap).and.(add_projector_cap)) then
  ! Cap does not absorb ground state orbitals --shenglai
    call CPU_TIME(ctime1)
    cphi=0
    do i=1,N_orbitals
       cphi=cphi+(captotal*dot_product(Psi(:,i),phi)*Psi(:,i)+dot_product(phi_cap(:,i)-cap_m_phi(:,i),phi)*Psi(:,i))*Grid_volume
    enddo
    do i=1,N_Lattice_points
      Hphi(i)=V_nl_pp_c(i)+T_Phi_c(i)+(V_l_pp(i)+V_Hartree(i)+V_Exchange(i)+V_td(i)+sw*zi*captotal(i))*phi(i)-sw*zi*cphi(i)
    enddo
	call CPU_TIME(ctime2); ctime_projector_cap=ctime_projector_cap+ctime2-ctime1
  else
    !$omp parallel do default(shared) private (i)
    do i=1,N_Lattice_points     
      Hphi(i)=V_nl_pp_c(i)+T_Phi_c(i)+(V_l_pp(i)+V_Hartree(i)+V_Exchange(i)+V_td(i))*phi(i)
    enddo  
    !$omp end parallel do
  endif
endif
!deallocate(cphi)
end subroutine Hamiltonian_wavefn_c_fd_velocity

subroutine V_wavefn_c_wL(it,sw,phi,Hphi)
!Calculates the action of time-dependent Hamiltonian on a complex-valued orbital phi
!Input variables:     
!   sw - A switch, which controls the addition of the explicitly time-dependent component of
!        the potential (i.g. laser). Normally it should be set to 1.0d0. However, it can be set to
!        0.0d0 or any other constant if needed.  
!   it - Current iteration 
!  phi - A linear array containing the orbital |phi>
!Output variables:
! Hphi - A linear array containing H|phi>
integer    :: it
real*8     :: sw
complex*16 :: phi(N_lattice_points),Hphi(N_lattice_points)
!complex*16,dimension(:),allocatable :: cphi1
!Local variables:
integer    :: i,i1,i2,i3,j,k
real*8     :: ramp,pulse(3),t,mrd,sf
complex*16 :: wlap_x

!allocate(cphi1(N_Lattice_points))
t=it*time_step
ramp=1.d0
if((ramp_time>0.d0).AND.(t<ramp_time)) ramp=t/ramp_time

pulse=1.d0

if(using_v_laser1) then
  if (laser_envelope_type1=='gaussian') then
    if(laser_pulse_width1>0) then
      pulse(1)=exp(-((t-laser_pulse_shift1)/laser_pulse_width1)**2)
      if(abs(pulse(1))<1d-20) pulse(1)=0.d0
    endif
    time_factor(1)=pulse(1)*sin(laser_frequency1*(t-laser_pulse_shift1)+laser_phase1)
  endif   
  if (laser_envelope_type1=='fermi') then
    pulse(1)=1.0d0-1.0d0/(1.0d0+exp((t-laser_envelope_up_point1)/laser_envelope_up_steepness1))
    time_factor(1)=pulse(1)*sin(laser_frequency1*(t-laser_envelope_up_point1)+laser_phase1)
  endif 
  if (laser_envelope_type1=='doublefermi') then
    pulse(1)=1.0d0-1.0d0/(1.0d0+exp((t-laser_envelope_up_point1)/laser_envelope_up_steepness1))
    pulse(1)=pulse(1)/(1.0d0+exp((t-laser_envelope_down_point1)/laser_envelope_down_steepness1))
    time_factor(1)=pulse(1)*sin(laser_frequency1*(t-laser_envelope_up_point1)+laser_phase1)
  endif 
  factor_laser1=time_factor(1)*ramp*sw
endif

if(using_v_laser2) then
  if (laser_envelope_type2=='gaussian') then
    if(laser_pulse_width2>0) then
      pulse(2)=exp(-((t-laser_pulse_shift2)/laser_pulse_width2)**2)
      if(abs(pulse(2))<1d-20) pulse(2)=0.d0
    endif
    time_factor(2)=pulse(2)*sin(laser_frequency2*(t-laser_pulse_shift2)+laser_phase2)
  endif   
  if (laser_envelope_type2=='fermi') then
    pulse(2)=1.0d0-1.0d0/(1.0d0+exp((t-laser_envelope_up_point2)/laser_envelope_up_steepness2))
    time_factor(2)=pulse(2)*sin(laser_frequency2*(t-laser_envelope_up_point2)+laser_phase2)
  endif 
  if (laser_envelope_type2=='doublefermi') then
    pulse(2)=1.0d0-1.0d0/(1.0d0+exp((t-laser_envelope_up_point2)/laser_envelope_up_steepness2))
    pulse(2)=pulse(2)/(1.0d0+exp((t-laser_envelope_down_point2)/laser_envelope_down_steepness2))
    time_factor(2)=pulse(2)*sin(laser_frequency2*(t-laser_envelope_up_point2)+laser_phase2)
  endif 
  factor_laser2=time_factor(2)*ramp*sw
endif

if(using_v_laser3) then
  if (laser_envelope_type3=='gaussian') then
    if(laser_pulse_width3>0) then
      pulse(3)=exp(-((t-laser_pulse_shift3)/laser_pulse_width3)**2)
      if(abs(pulse(3))<1d-20) pulse(3)=0.d0
    endif
    time_factor(3)=pulse(3)*sin(laser_frequency3*(t-laser_pulse_shift3)+laser_phase3)
  endif   
  if (laser_envelope_type3=='fermi') then
    pulse(3)=1.0d0-1.0d0/(1.0d0+exp((t-laser_envelope_up_point3)/laser_envelope_up_steepness3))
    time_factor(3)=pulse(3)*sin(laser_frequency3*(t-laser_envelope_up_point3)+laser_phase3)
  endif 
  if (laser_envelope_type3=='doublefermi') then
    pulse(3)=1.0d0-1.0d0/(1.0d0+exp((t-laser_envelope_up_point3)/laser_envelope_up_steepness3))
    pulse(3)=pulse(3)/(1.0d0+exp((t-laser_envelope_down_point3)/laser_envelope_down_steepness3))
    time_factor(3)=pulse(3)*sin(laser_frequency3*(t-laser_envelope_up_point3)+laser_phase3)
  endif 
  factor_laser3=time_factor(3)*ramp*sw
endif


sf=1.0d0
if (suppress_field_upon_ion_motion) then
  if (.not.field_suppression_on) then
    mrd=max_abs_rel_displacement_ions(Position,Position_init,closest_ion_init)
    if (mrd>field_suppression_trd) then
      field_suppression_start_time=t
      field_suppression_on=.true.
      write(log_file,*) 'field_suppression_start_time : ',field_suppression_start_time
    endif 
  endif 
  if (field_suppression_on) then
    sf=exp(-abs((t-field_suppression_start_time)/field_suppression_timescale)**field_suppression_power)
    factor_laser1=factor_laser1*sf
    factor_laser2=factor_laser2*sf
    factor_laser3=factor_laser3*sf 
    factor_static_ef=factor_static_ef*sf
  endif  
endif 

if (using_v_ext) then
  factor_static_ef=ramp*sw
endif

if (using_v_step) then
 V_td = ramp*V_steppot
end if

if ((using_v_laser1).and.(using_v_laser2).and.(using_v_laser3).and.(using_v_ext)) then
!$omp parallel workshare
V_td=factor_laser1*V_laser1+factor_laser2*V_laser2+factor_laser3*V_laser3+factor_static_ef*V_ext
!$omp end parallel workshare
endif
if ((.not.using_v_laser1).and.(using_v_laser2).and.(using_v_laser3).and.(using_v_ext)) then
!$omp parallel workshare
V_td=factor_laser2*V_laser2+factor_laser3*V_laser3+factor_static_ef*V_ext
!$omp end parallel workshare
endif
if ((using_v_laser1).and.(.not.using_v_laser2).and.(using_v_laser3).and.(using_v_ext)) then
!$omp parallel workshare
V_td=factor_laser1*V_laser1+factor_laser3*V_laser3+factor_static_ef*V_ext
!$omp end parallel workshare
endif
if ((using_v_laser1).and.(using_v_laser2).and.(.not.using_v_laser3).and.(using_v_ext)) then
!$omp parallel workshare
V_td=factor_laser1*V_laser1+factor_laser2*V_laser2+factor_static_ef*V_ext
!$omp end parallel workshare
endif
if ((using_v_laser1).and.(using_v_laser2).and.(using_v_laser3).and.(.not.using_v_ext)) then
!$omp parallel workshare
V_td=factor_laser1*V_laser1+factor_laser2*V_laser2+factor_laser3*V_laser3
!$omp end parallel workshare
endif
if ((.not.using_v_laser1).and.(.not.using_v_laser2).and.(using_v_laser3).and.(using_v_ext)) then
!$omp parallel workshare
V_td=factor_laser3*V_laser3+factor_static_ef*V_ext
!$omp end parallel workshare
endif
if ((.not.using_v_laser1).and.(using_v_laser2).and.(.not.using_v_laser3).and.(using_v_ext)) then
!$omp parallel workshare
V_td=factor_laser2*V_laser2+factor_static_ef*V_ext
!$omp end parallel workshare
endif
if ((.not.using_v_laser1).and.(using_v_laser2).and.(using_v_laser3).and.(.not.using_v_ext)) then
!$omp parallel workshare
V_td=factor_laser2*V_laser2+factor_laser3*V_laser3
!$omp end parallel workshare
endif
if ((using_v_laser1).and.(.not.using_v_laser2).and.(.not.using_v_laser3).and.(using_v_ext)) then
!$omp parallel workshare
V_td=factor_laser1*V_laser1+factor_static_ef*V_ext
!$omp end parallel workshare
endif
if ((using_v_laser1).and.(.not.using_v_laser2).and.(using_v_laser3).and.(.not.using_v_ext)) then
!$omp parallel workshare
V_td=factor_laser1*V_laser1+factor_laser3*V_laser3
!$omp end parallel workshare
endif
if ((using_v_laser1).and.(using_v_laser2).and.(.not.using_v_laser3).and.(.not.using_v_ext)) then
!$omp parallel workshare
V_td=factor_laser1*V_laser1+factor_laser2*V_laser2
!$omp end parallel workshare
endif
if ((.not.using_v_laser1).and.(.not.using_v_laser2).and.(.not.using_v_laser3).and.(using_v_ext)) then
!$omp parallel workshare
V_td=factor_static_ef*V_ext 
!$omp end parallel workshare
endif
if ((.not.using_v_laser1).and.(.not.using_v_laser2).and.(using_v_laser3).and.(.not.using_v_ext)) then
!$omp parallel workshare
V_td=factor_laser3*V_laser3
!$omp end parallel workshare
endif
if ((.not.using_v_laser1).and.(using_v_laser2).and.(.not.using_v_laser3).and.(.not.using_v_ext)) then
!$omp parallel workshare
V_td=factor_laser2*V_laser2 
!$omp end parallel workshare
endif
if ((using_v_laser1).and.(.not.using_v_laser2).and.(.not.using_v_laser3).and.(.not.using_v_ext)) then
!$omp parallel do default(shared) private (i)
do i=1,N_Lattice_points
  V_td(i)=factor_laser1*V_laser1(i) 
enddo  
!$omp end parallel do
endif
if ((.not.using_v_laser1).and.(.not.using_v_laser2).and.(.not.using_v_laser3).and. &
  (.not.using_v_ext).and.(.not.using_v_step).and.(.not.using_v_fromfile)) then
!$omp parallel workshare
V_td=0.0d0
!$omp end parallel workshare
endif  

if(using_v_laser1) laser_xyz_t_iteration(1)=factor_laser1*E_laser1
if(using_v_laser2) laser_xyz_t_iteration(2)=factor_laser2*E_laser2
if(using_v_laser3) laser_xyz_t_iteration(3)=factor_laser3*E_laser3

 ! V_laser1 V_laser2 V_laser3 is set in subroutine setup_lattice as  x, y, z operators
if(using_v_fromfile) then ! cody 
   if (it <= laser_xyz_t_number) then
	  laser_xyz_t_iteration(1) = laser_xyz_t(2,it)
	  laser_xyz_t_iteration(2) = laser_xyz_t(3,it)
	  laser_xyz_t_iteration(3) = laser_xyz_t(4,it)
      !$omp parallel do default(shared) private (i)
	  do i=1,N_Lattice_points
        V_td(i)=laser_xyz_t_iteration(1)*V_laser1(i) + laser_xyz_t_iteration(2)*V_laser2(i) + laser_xyz_t_iteration(3)*V_laser3(i)
      enddo
	  !$omp end parallel do
	  write(log_file,'(A,3E15.8)') ' Eext=', laser_xyz_t_iteration(1) , laser_xyz_t_iteration(2) , laser_xyz_t_iteration(3) 
   else
      laser_xyz_t_iteration(1)=0.d0
	  laser_xyz_t_iteration(2)=0.d0
	  laser_xyz_t_iteration(3)=0.d0
      !$omp parallel workshare
      V_td=0.0d0
      !$omp end parallel workshare
	  write(log_file,*) ' Eext= 0.0 0.0 0.0'
   endif
   
endif

! cody  I think this should be moved as the projectile potential need only be updated ever step
if (use_projectile) then
call add_projectile_potential(V_td,sw)
endif

call Nonlocal_pseudo_potential_c(phi,V_nl_pp_c)  

if((spin_polarized).and.(spin_down)) then
  if(using_cap) then
    !$omp parallel workshare
    Hphi=V_nl_pp_c+(V_l_pp+V_Hartree+V_Exchange_down+V_td+sw*zi*captotal)*phi
    !$omp end parallel workshare
  else
    !$omp parallel workshare
    Hphi=V_nl_pp_c+(V_l_pp+V_Hartree+V_Exchange_down+V_td)*phi
    !$omp end parallel workshare
  endif
  endif
  if((spin_polarized).and.(spin_up)) then
  if(using_cap) then
    !$omp parallel workshare
    Hphi=V_nl_pp_c+(V_l_pp+V_Hartree+V_Exchange_up+V_td+sw*zi*captotal)*phi
    !$omp end parallel workshare
  else
    !$omp parallel workshare
    Hphi=V_nl_pp_c+(V_l_pp+V_Hartree+V_Exchange_up+V_td)*phi
    !$omp end parallel workshare
  endif
  endif
  if(.not.spin_polarized) then
  if((using_cap).and.(.not.add_projector_cap)) then
    !$omp parallel do default(shared) private (i)
    do i=1,N_Lattice_points      
      Hphi(i)=V_nl_pp_c(i)+(V_l_pp(i)+V_Hartree(i)+V_Exchange(i)+V_td(i)+sw*zi*captotal(i))*phi(i)
   enddo
  else if((using_cap).and.(add_projector_cap)) then
  ! Cap does not absorb ground state orbitals --shenglai
    cphi=0
    do i=1,N_orbitals
       cphi=cphi+(captotal*dot_product(Psi(:,i),phi)*Psi(:,i)+dot_product(phi_cap(:,i)-cap_m_phi(:,i),phi)*Psi(:,i))*Grid_volume
    enddo
   do i=1,N_Lattice_points
      Hphi(i)=V_nl_pp_c(i)+(V_l_pp(i)+V_Hartree(i)+V_Exchange(i)+V_td(i)+sw*zi*captotal(i))*phi(i)-sw*zi*cphi(i)
  enddo
  else
    !$omp parallel do default(shared) private (i)
    do i=1,N_Lattice_points     
      Hphi(i)=V_nl_pp_c(i)+(V_l_pp(i)+V_Hartree(i)+V_Exchange(i)+V_td(i))*phi(i)
    enddo  
    !$omp end parallel do
  endif
endif
!deallocate(cphi)
end subroutine V_wavefn_c_wL


subroutine V_wavefn_c_noLaser
implicit none
  integer :: i
  real*8  :: sw=1.d0
    
  V_td=0.d0
  if (use_projectile) then
    call add_projectile_potential(V_td,sw)
  endif  
  
  call Nonlocal_pseudo_potential_c(Phi_c,V_nl_pp_c)
  H_Phi_c=0.d0
if((spin_polarized).and.(spin_down)) then
  if(using_cap) then
    H_Phi_c=V_nl_pp_c+(V_l_pp+V_Hartree+V_Exchange_down+V_td+sw*zi*captotal)*Phi_c
  else
    H_Phi_c=V_nl_pp_c+(V_l_pp+V_Hartree+V_Exchange_down+V_td)*Phi_c
  endif
  endif
  if((spin_polarized).and.(spin_up)) then
  if(using_cap) then
    H_Phi_c=V_nl_pp_c+(V_l_pp+V_Hartree+V_Exchange_up+V_td+sw*zi*captotal)*Phi_c
  else
    H_Phi_c=V_nl_pp_c+(V_l_pp+V_Hartree+V_Exchange_up+V_td)*Phi_c
  endif
  endif
  if(.not.spin_polarized) then
  if((using_cap).and.(.not.add_projector_cap)) then
    do i=1,N_Lattice_points      
      H_Phi_c(i)=V_nl_pp_c(i)+(V_l_pp(i)+V_Hartree(i)+V_Exchange(i)+V_td(i)+sw*zi*captotal(i))*Phi_c(i)
   enddo
  else if((using_cap).and.(add_projector_cap)) then
  ! removed
   write(*,*) "if((using_cap).and.(add_projector_cap)) removed"
   stop
  else
    do i=1,N_Lattice_points     
      H_Phi_c(i)=V_nl_pp_c(i)+(V_l_pp(i)+V_Hartree(i)+V_Exchange(i)+V_td(i))*Phi_c(i)
    enddo  
  endif
endif
  
end subroutine V_wavefn_c_noLaser

subroutine V_wavefn_c_noLaser_pass(phi)
implicit none
  integer :: i
  real*8  :: sw=1.d0
  complex*16,intent(inout) :: phi(N_Lattice_points)
  complex*16 :: hphi(N_Lattice_points),vnlppc(N_Lattice_points)
  real*8     :: vtd(N_Lattice_points)
  vtd=0.d0
  if (use_projectile) then
    call add_projectile_potential(vtd,sw)
  endif  
  
  call Nonlocal_pseudo_potential_c(phi,vnlppc)
  hphi=0.d0
if((spin_polarized).and.(spin_down)) then
  if(using_cap) then
    hphi=vnlppc+(V_l_pp+V_Hartree+V_Exchange_down+vtd+sw*zi*captotal)*phi
  else
    hphi=vnlppc+(V_l_pp+V_Hartree+V_Exchange_down+vtd)*phi
  endif
  endif
  if((spin_polarized).and.(spin_up)) then
  if(using_cap) then
    hphi=vnlppc+(V_l_pp+V_Hartree+V_Exchange_up+vtd+sw*zi*captotal)*phi
  else
    hphi=vnlppc+(V_l_pp+V_Hartree+V_Exchange_up+vtd)*phi
  endif
  endif
  if(.not.spin_polarized) then
  if((using_cap).and.(.not.add_projector_cap)) then
    do i=1,N_Lattice_points      
      hphi(i)=vnlppc(i)+(V_l_pp(i)+V_Hartree(i)+V_Exchange(i)+vtd(i)+sw*zi*captotal(i))*phi(i)
   enddo
  else if((using_cap).and.(add_projector_cap)) then
  ! removed
   write(*,*) "if((using_cap).and.(add_projector_cap)) removed"
   stop
  else
    do i=1,N_Lattice_points     
      hphi(i)=vnlppc(i)+(V_l_pp(i)+V_Hartree(i)+V_Exchange(i)+vtd(i))*phi(i)
    enddo  
  endif
endif
  phi=hphi
end subroutine V_wavefn_c_noLaser_pass

subroutine lf_kinetic_fast_c(phi,Tphi)
!Evaluates the action of the kinetic energy operator on a complex
!orbital phi. This is a fast Lagrange function version. The result is returned in Tphi. 
complex*16 :: phi(N_lattice_points),Tphi(N_lattice_points)
integer    :: i,i1,i2,i3,j1,j2,j3
complex*16 :: t

Tphi=(0.d0,0.d0)
!$omp parallel do default(shared) &
!$omp private (i, i1, i2, i3, j1, j2, j3, t)
do i=1,N_Lattice_points
  i1=Lattice(1,i)+1; i2=Lattice(2,i)+1; i3=Lattice(3,i)+1
  t=(0.d0,0.d0)   
  do j1=max(1,i1-N_gc(1)),min(i1+N_gc(1),N_Lattice(1))
        t=t+tm1(j1,i1)*phi(Lattice_inv_xyz(j1,i2,i3))
  enddo
  do j2=max(1,i2-N_gc(2)),min(i2+N_gc(2),N_Lattice(2))
        t=t+tm2(j2,i2)*phi(Lattice_inv_yzx(j2,i3,i1))
  enddo
  do j3=max(1,i3-N_gc(3)),min(i3+N_gc(3),N_Lattice(3))
        t=t+tm3(j3,i3)*phi(Lattice_inv_zxy(j3,i1,i2))
  enddo
  Tphi(i)=t  
enddo
!$omp end parallel do
end subroutine lf_kinetic_fast_c

subroutine lf_kinetic_c(phi,Tphi)
!Evaluates the action of the kinetic energy operator on a complex
!orbital phi. This is a Lagrange function version. The result is returned in Tphi. 
complex*16 :: phi(N_lattice_points),Tphi(N_lattice_points)
integer    :: i,i1,i2,i3,j1,j2,j3
complex*16 :: t

!$omp parallel do default(shared) &
!$omp private (i, i1, i2, i3, j1, j2, j3, t)
do i=1,N_Lattice_points
  i1=Lattice(1,i)+1; i2=Lattice(2,i)+1; i3=Lattice(3,i)+1
  t=(0.d0,0.d0)
  do j1=1,N_Lattice(1)
    t=t+tm1(j1,i1)*phi(Lattice_inv_xyz(j1,i2,i3))
  enddo
  do j2=1,N_Lattice(2)
    t=t+tm2(j2,i2)*phi(Lattice_inv_yzx(j2,i3,i1))
  enddo
  do j3=1,N_Lattice(3)
    t=t+tm3(j3,i3)*phi(Lattice_inv_zxy(j3,i1,i2))
  enddo
  Tphi(i)=t
enddo
!$omp end parallel do
end subroutine lf_kinetic_c

SUBROUTINE kinetic_c(phi,Tphi)
!Evaluates the action of the kinetic energy operator on a complex
!orbital phi. The result is returned in Tphi. 
complex*16 :: phi(N_lattice_points),Tphi(N_lattice_points) 
integer  :: i1,i2,i3,grid

!$omp parallel do &
!$omp default(shared) &
!$omp private (grid, i1, i2, i3)
do grid=1,N_lattice_points
  i1=Lattice(1,grid)
  i2=Lattice(2,grid)
  i3=Lattice(3,grid)
  wphi_c(i1,i2,i3)=phi(grid)
enddo
!$omp end parallel do
call laplacian_c(wphi_c,Tphi)
end subroutine kinetic_c

SUBROUTINE kinetic_c_fd_velocity(phi,Tphi,A)
!Evaluates the action of the kinetic energy operator on a complex
!orbital phi. The result is returned in Tphi. 
complex*16 :: phi(N_lattice_points),Tphi(N_lattice_points) 
integer  :: i,i1,i2,i3,grid
real*8     :: ss1,ss2,ss3,s1,hs1,hss1,hss2,hss3,A(3)
real*8     :: cE1
complex*16 :: g,kvec_x,h2m_kvec_x_2,h2m_kvec_x_two_zi,w_x
complex*16 :: mih_MC
!Precompute some constants
ss1=1/Grid_Step(1)**2
s1=1/Grid_Step(1)
hss1=-h2m*ss1
hs1=s1
cE1=ElectronMass*convertE2AU*convertT2AU
mih_MC=-zi*hbar/cE1

if((Grid_Step(1)/=Grid_Step(2)).or.(Grid_Step(1)/=Grid_Step(3))) then
  write(log_file,*) "cannot use uneven grid for fd_velocity propagation"
  stop
end if

if (use_high_energy_wp) then
  kvec_x=wp_momentum(1)/hbar
  h2m_kvec_x_2=h2m*kvec_x**2
  h2m_kvec_x_two_zi=2*h2m*zi*kvec_x
endif

!$omp parallel do &
!$omp default(shared) &
!$omp private (grid, i1, i2, i3)
do grid=1,N_lattice_points
  i1=Lattice(1,grid)
  i2=Lattice(2,grid)
  i3=Lattice(3,grid)
  wphi_c(i1,i2,i3)=phi(grid)
enddo
!$omp end parallel do
!call laplacian_c(wphi_c,Tphi)

  !$omp parallel do &
  !$omp default(shared) &
  !$omp private (i, i1, i2, i3)
  do i=1,N_Lattice_points
    i1=Lattice(1,i); i2=Lattice(2,i); i3=Lattice(3,i)
    Tphi(i)=(3*fd_coeff_second_derivative(0)*wphi_c(i1,i2,i3)+ &
      fd_coeff_second_derivative(1)*(wphi_c(i1+1,i2,i3)+wphi_c(i1-1,i2,i3)+wphi_c(i1,i2+1,i3)+ &
                                     wphi_c(i1,i2-1,i3)+wphi_c(i1,i2,i3+1)+wphi_c(i1,i2,i3-1))+ &
      fd_coeff_second_derivative(2)*(wphi_c(i1+2,i2,i3)+wphi_c(i1-2,i2,i3)+wphi_c(i1,i2+2,i3)+ &
                                     wphi_c(i1,i2-2,i3)+wphi_c(i1,i2,i3+2)+wphi_c(i1,i2,i3-2))+ &
      fd_coeff_second_derivative(3)*(wphi_c(i1+3,i2,i3)+wphi_c(i1-3,i2,i3)+wphi_c(i1,i2+3,i3)+ &
                                     wphi_c(i1,i2-3,i3)+wphi_c(i1,i2,i3+3)+wphi_c(i1,i2,i3-3))+ &
      fd_coeff_second_derivative(4)*(wphi_c(i1+4,i2,i3)+wphi_c(i1-4,i2,i3)+wphi_c(i1,i2+4,i3)+ &
                                     wphi_c(i1,i2-4,i3)+wphi_c(i1,i2,i3+4)+wphi_c(i1,i2,i3-4)))*hss1&
	  +mih_MC*A(1)*(fd_coeff_first_derivative(1)*(wphi_c(i1+1,i2,i3)-wphi_c(i1-1,i2,i3))+&
	                   fd_coeff_first_derivative(2)*(wphi_c(i1+2,i2,i3)-wphi_c(i1-2,i2,i3))+&
	                   fd_coeff_first_derivative(3)*(wphi_c(i1+3,i2,i3)-wphi_c(i1-3,i2,i3))+&
	                   fd_coeff_first_derivative(4)*(wphi_c(i1+4,i2,i3)-wphi_c(i1-4,i2,i3)))&
	  +mih_MC*A(2)*(fd_coeff_first_derivative(1)*(wphi_c(i1,i2+1,i3)-wphi_c(i1,i2-1,i3))+&
	                   fd_coeff_first_derivative(2)*(wphi_c(i1,i2+2,i3)-wphi_c(i1,i2-2,i3))+&
	                   fd_coeff_first_derivative(3)*(wphi_c(i1,i2+3,i3)-wphi_c(i1,i2-3,i3))+&
	                   fd_coeff_first_derivative(4)*(wphi_c(i1,i2+4,i3)-wphi_c(i1,i2-4,i3)))&
	  +mih_MC*A(3)*(fd_coeff_first_derivative(1)*(wphi_c(i1,i2,i3+1)-wphi_c(i1,i2,i3-1))+&
	                   fd_coeff_first_derivative(2)*(wphi_c(i1,i2,i3+2)-wphi_c(i1,i2,i3-2))+&
	                   fd_coeff_first_derivative(3)*(wphi_c(i1,i2,i3+3)-wphi_c(i1,i2,i3-3))+&
	                   fd_coeff_first_derivative(4)*(wphi_c(i1,i2,i3+4)-wphi_c(i1,i2,i3-4)))&
	  +0.5d0*((A(1)/cE1)**2+(A(1)/cE1)**2+(A(1)/cE1)**2)*wphi_c(i1,i2,i3)
    if(use_high_energy_wp.and.orbital_index==N_orbitals) then
    w_x=hs1*(fd_coeff_first_derivative(1)*(wphi_c(i1+1,i2,i3)-wphi_c(i1-1,i2,i3))+ &
             fd_coeff_first_derivative(2)*(wphi_c(i1+2,i2,i3)-wphi_c(i1-2,i2,i3))+ &
             fd_coeff_first_derivative(3)*(wphi_c(i1+3,i2,i3)-wphi_c(i1-3,i2,i3))+ &
             fd_coeff_first_derivative(4)*(wphi_c(i1+4,i2,i3)-wphi_c(i1-4,i2,i3)))
      Tphi(i)=Tphi(i)-h2m_kvec_x_two_zi*w_x+h2m_kvec_x_2*wphi_c(i1,i2,i3)
    endif
  enddo
  !$omp end parallel do


end subroutine kinetic_c_fd_velocity

subroutine split_propagator_grid(iter)
implicit none
  integer :: iter,i,k,n,maxele
  complex*16 :: tc(N_taylor),Phi_c2(N_Lattice_points),tc2(N_taylor),Phi_T(N_Lattice_points)
  real*8     :: maxv1
  
  do i=1,N_taylor
    tc(i)=(-zi*time_step/hbar)**i
    do k=1,i
      tc(i)=tc(i)/k
    enddo
  enddo
  do i=1,N_taylor
    tc2(i)=(-zi*0.5d0*time_step/hbar)**i
    do k=1,i
      tc2(i)=tc2(i)/k
    enddo
  enddo  
  
  do n=1,N_orbitals
    Phi_c=Psi_c(:,n)
	Phi_c2=Phi_c

    maxv1=0.d0
	do i=1,N_Lattice_points
	  if(abs(Psi_c(i,n))>maxv1) then
	    maxv1=abs(Psi_c(i,n))
		maxele=i
	  end if
	end do	
	
    write(log_file,'(i2,a,i6,2es28.15e3)') n," max ele ",maxele,real(Phi_c(maxele)),imag(Phi_c(maxele))
	
	!write(77700000+n*10000+iter*100+0,'(2es30.16e3)')  Phi_c
	do i=1,N_taylor
	  call Kinetic_c(Phi_c2,Phi_T)
      Phi_c2=Phi_T
	  Phi_c=Phi_c+tc2(i)*Phi_c2
	end do
    Phi_c2=Phi_c
	
    write(log_file,'(i2,a,i6,2es28.15e3)') n," max eleK",maxele,real(Phi_c(maxele)),imag(Phi_c(maxele))
	!write(77700000+n*10000+iter*100+1,'(2es30.16e3)')  Phi_c
	do i=1,N_taylor
	  call V_wavefn_c_noLaser
      Phi_c=H_Phi_c
	  Phi_c2=Phi_c2+tc(i)*Phi_c
	end do	
	Phi_c=Phi_c2
	
    write(log_file,'(i2,a,i6,2es28.15e3)') n," max eleV",maxele,real(Phi_c(maxele)),imag(Phi_c(maxele))
	!write(77700000+n*10000+iter*100+2,'(2es30.16e3)')  Phi_c
	do i=1,N_taylor
	  call Kinetic_c(Phi_c2,Phi_T)
      Phi_c2=Phi_T
	  Phi_c=Phi_c+tc2(i)*Phi_c2
	end do
	
    write(log_file,'(i2,a,i6,2es28.15e3)') n," max eleK",maxele,real(Phi_c(maxele)),imag(Phi_c(maxele))
	!write(77700000+n*10000+iter*100+3,'(2es30.16e3)')  Phi_c
	Psi_c(:,n)=Phi_c
  end do
  
  

end subroutine split_propagator_grid

subroutine calc_elec_near_projectile(iter)
integer :: i,iter
real*8  :: x,y,z,d,nearden

nearden=0.d0

do i=1,N_lattice_points
  x=Grid_Point(1,i)-projectile_x
  y=Grid_Point(2,i)-projectile_y
  z=Grid_Point(3,i)-projectile_z
  d=sqrt(x**2+y**2+z**2)
  if(d<projectile_calc_near_elec_dist) then
    nearden=nearden+density(i)
  end if
enddo
  write(log_file,'(f12.5,a,es28.16e3,a,es28.16e3,a,3f12.5)') iter*time_step," PDen_near= ",&
    nearden*grid_volume," TOTDen= ",sum(density)*grid_volume," PPos=",projectile_x,projectile_y,projectile_z
end subroutine calc_elec_near_projectile

subroutine init_resolve_gs
implicit none

allocate(resolve_gs_density(N_Lattice_points))
allocate(save_td_density(N_Lattice_points))
resolve_gs_density=density
save_td_density=0.d0

open(td_gs_energy_diff_file,file=trim(adjustl(td_gs_energy_diff_filename)),form='formatted',status='replace',action='write')
write(td_gs_energy_diff_file,'(a)') "#time, GS energy, TD energy, Diff"

end subroutine init_resolve_gs

subroutine generate_Vtd(it,sw)

!Input variables:     
!   sw - A switch, which controls the addition of the explicitly time-dependent component of
!        the potential (i.g. laser). Normally it should be set to 1.0d0. However, it can be set to
!        0.0d0 or any other constant if needed.  
!   it - Current iteration 
integer    :: it
real*8     :: sw
integer    :: i,i1,i2,i3,j,k
real*8     :: ramp,pulse(3),t,mrd,sf
complex*16 :: wlap_x

!allocate(cphi1(N_Lattice_points))
t=it*time_step
ramp=1.d0
if((ramp_time>0.d0).AND.(t<ramp_time)) ramp=t/ramp_time

pulse=1.d0

if(using_v_laser1) then
  if (laser_envelope_type1=='gaussian') then
    if(laser_pulse_width1>0) then
      pulse(1)=exp(-((t-laser_pulse_shift1)/laser_pulse_width1)**2)
      if(abs(pulse(1))<1d-20) pulse(1)=0.d0
    endif
    time_factor(1)=pulse(1)*sin(laser_frequency1*(t-laser_pulse_shift1)+laser_phase1)
  endif   
  if (laser_envelope_type1=='fermi') then
    pulse(1)=1.0d0-1.0d0/(1.0d0+exp((t-laser_envelope_up_point1)/laser_envelope_up_steepness1))
    time_factor(1)=pulse(1)*sin(laser_frequency1*(t-laser_envelope_up_point1)+laser_phase1)
  endif 
  if (laser_envelope_type1=='doublefermi') then
    pulse(1)=1.0d0-1.0d0/(1.0d0+exp((t-laser_envelope_up_point1)/laser_envelope_up_steepness1))
    pulse(1)=pulse(1)/(1.0d0+exp((t-laser_envelope_down_point1)/laser_envelope_down_steepness1))
    time_factor(1)=pulse(1)*sin(laser_frequency1*(t-laser_envelope_up_point1)+laser_phase1)
  endif 
  factor_laser1=time_factor(1)*ramp*sw
endif

if(using_v_laser2) then
  if (laser_envelope_type2=='gaussian') then
    if(laser_pulse_width2>0) then
      pulse(2)=exp(-((t-laser_pulse_shift2)/laser_pulse_width2)**2)
      if(abs(pulse(2))<1d-20) pulse(2)=0.d0
    endif
    time_factor(2)=pulse(2)*sin(laser_frequency2*(t-laser_pulse_shift2)+laser_phase2)
  endif   
  if (laser_envelope_type2=='fermi') then
    pulse(2)=1.0d0-1.0d0/(1.0d0+exp((t-laser_envelope_up_point2)/laser_envelope_up_steepness2))
    time_factor(2)=pulse(2)*sin(laser_frequency2*(t-laser_envelope_up_point2)+laser_phase2)
  endif 
  if (laser_envelope_type2=='doublefermi') then
    pulse(2)=1.0d0-1.0d0/(1.0d0+exp((t-laser_envelope_up_point2)/laser_envelope_up_steepness2))
    pulse(2)=pulse(2)/(1.0d0+exp((t-laser_envelope_down_point2)/laser_envelope_down_steepness2))
    time_factor(2)=pulse(2)*sin(laser_frequency2*(t-laser_envelope_up_point2)+laser_phase2)
  endif 
  factor_laser2=time_factor(2)*ramp*sw
endif

if(using_v_laser3) then
  if (laser_envelope_type3=='gaussian') then
    if(laser_pulse_width3>0) then
      pulse(3)=exp(-((t-laser_pulse_shift3)/laser_pulse_width3)**2)
      if(abs(pulse(3))<1d-20) pulse(3)=0.d0
    endif
    time_factor(3)=pulse(3)*sin(laser_frequency3*(t-laser_pulse_shift3)+laser_phase3)
  endif   
  if (laser_envelope_type3=='fermi') then
    pulse(3)=1.0d0-1.0d0/(1.0d0+exp((t-laser_envelope_up_point3)/laser_envelope_up_steepness3))
    time_factor(3)=pulse(3)*sin(laser_frequency3*(t-laser_envelope_up_point3)+laser_phase3)
  endif 
  if (laser_envelope_type3=='doublefermi') then
    pulse(3)=1.0d0-1.0d0/(1.0d0+exp((t-laser_envelope_up_point3)/laser_envelope_up_steepness3))
    pulse(3)=pulse(3)/(1.0d0+exp((t-laser_envelope_down_point3)/laser_envelope_down_steepness3))
    time_factor(3)=pulse(3)*sin(laser_frequency3*(t-laser_envelope_up_point3)+laser_phase3)
  endif 
  factor_laser3=time_factor(3)*ramp*sw
endif


sf=1.0d0
if (suppress_field_upon_ion_motion) then
  if (.not.field_suppression_on) then
    mrd=max_abs_rel_displacement_ions(Position,Position_init,closest_ion_init)
    if (mrd>field_suppression_trd) then
      field_suppression_start_time=t
      field_suppression_on=.true.
      write(log_file,*) 'field_suppression_start_time : ',field_suppression_start_time
    endif 
  endif 
  if (field_suppression_on) then
    sf=exp(-abs((t-field_suppression_start_time)/field_suppression_timescale)**field_suppression_power)
    factor_laser1=factor_laser1*sf
    factor_laser2=factor_laser2*sf
    factor_laser3=factor_laser3*sf 
    factor_static_ef=factor_static_ef*sf
  endif  
endif 

if (using_v_ext) then
  factor_static_ef=ramp*sw
endif

if (using_v_step) then
 V_td = ramp*V_steppot
end if

if ((using_v_laser1).and.(using_v_laser2).and.(using_v_laser3).and.(using_v_ext)) then
V_td=factor_laser1*V_laser1+factor_laser2*V_laser2+factor_laser3*V_laser3+factor_static_ef*V_ext
endif
if ((.not.using_v_laser1).and.(using_v_laser2).and.(using_v_laser3).and.(using_v_ext)) then
V_td=factor_laser2*V_laser2+factor_laser3*V_laser3+factor_static_ef*V_ext
endif
if ((using_v_laser1).and.(.not.using_v_laser2).and.(using_v_laser3).and.(using_v_ext)) then
V_td=factor_laser1*V_laser1+factor_laser3*V_laser3+factor_static_ef*V_ext
endif
if ((using_v_laser1).and.(using_v_laser2).and.(.not.using_v_laser3).and.(using_v_ext)) then
V_td=factor_laser1*V_laser1+factor_laser2*V_laser2+factor_static_ef*V_ext
endif
if ((using_v_laser1).and.(using_v_laser2).and.(using_v_laser3).and.(.not.using_v_ext)) then
V_td=factor_laser1*V_laser1+factor_laser2*V_laser2+factor_laser3*V_laser3
endif
if ((.not.using_v_laser1).and.(.not.using_v_laser2).and.(using_v_laser3).and.(using_v_ext)) then
V_td=factor_laser3*V_laser3+factor_static_ef*V_ext
endif
if ((.not.using_v_laser1).and.(using_v_laser2).and.(.not.using_v_laser3).and.(using_v_ext)) then
V_td=factor_laser2*V_laser2+factor_static_ef*V_ext
endif
if ((.not.using_v_laser1).and.(using_v_laser2).and.(using_v_laser3).and.(.not.using_v_ext)) then
V_td=factor_laser2*V_laser2+factor_laser3*V_laser3
endif
if ((using_v_laser1).and.(.not.using_v_laser2).and.(.not.using_v_laser3).and.(using_v_ext)) then
V_td=factor_laser1*V_laser1+factor_static_ef*V_ext
endif
if ((using_v_laser1).and.(.not.using_v_laser2).and.(using_v_laser3).and.(.not.using_v_ext)) then
V_td=factor_laser1*V_laser1+factor_laser3*V_laser3
endif
if ((using_v_laser1).and.(using_v_laser2).and.(.not.using_v_laser3).and.(.not.using_v_ext)) then
V_td=factor_laser1*V_laser1+factor_laser2*V_laser2
endif
if ((.not.using_v_laser1).and.(.not.using_v_laser2).and.(.not.using_v_laser3).and.(using_v_ext)) then
V_td=factor_static_ef*V_ext 
endif
if ((.not.using_v_laser1).and.(.not.using_v_laser2).and.(using_v_laser3).and.(.not.using_v_ext)) then
V_td=factor_laser3*V_laser3
endif
if ((.not.using_v_laser1).and.(using_v_laser2).and.(.not.using_v_laser3).and.(.not.using_v_ext)) then
V_td=factor_laser2*V_laser2 
endif
if ((using_v_laser1).and.(.not.using_v_laser2).and.(.not.using_v_laser3).and.(.not.using_v_ext)) then

do i=1,N_Lattice_points
  V_td(i)=factor_laser1*V_laser1(i) 
enddo  

endif
if ((.not.using_v_laser1).and.(.not.using_v_laser2).and.(.not.using_v_laser3).and.&
  (.not.using_v_ext).and.(.not.using_v_step).and.(.not.using_v_fromfile)) then
V_td=0.0d0
endif  

if(using_v_laser1) laser_xyz_t_iteration(1)=factor_laser1*E_laser1
if(using_v_laser2) laser_xyz_t_iteration(2)=factor_laser2*E_laser2
if(using_v_laser3) laser_xyz_t_iteration(3)=factor_laser3*E_laser3

 ! V_laser1 V_laser2 V_laser3 is set in subroutine setup_lattice as  x, y, z operators
if(using_v_fromfile) then ! cody 
   if ((it <= laser_xyz_t_number).and.(it >0)) then
	  laser_xyz_t_iteration(1) = laser_xyz_t(2,it)
	  laser_xyz_t_iteration(2) = laser_xyz_t(3,it)
	  laser_xyz_t_iteration(3) = laser_xyz_t(4,it)
	  do i=1,N_Lattice_points
        V_td(i)=laser_xyz_t_iteration(1)*V_laser1(i) + laser_xyz_t_iteration(2)*V_laser2(i) + laser_xyz_t_iteration(3)*V_laser3(i)
      enddo
	  write(log_file,'(A,3E15.8)') ' Eext=', laser_xyz_t_iteration(1) , laser_xyz_t_iteration(2) , laser_xyz_t_iteration(3) 
   else
      laser_xyz_t_iteration(1)=0.d0
	  laser_xyz_t_iteration(2)=0.d0
	  laser_xyz_t_iteration(3)=0.d0
      V_td=0.0d0
	  write(log_file,*) ' Eext= 0.0 0.0 0.0'
   endif
   
endif

! cody  I think this should be moved as the projectile potential need only be updated ever step
if (use_projectile) then
call add_projectile_potential(V_td,sw)
endif

end subroutine generate_Vtd

subroutine generate_Vtd_noLaser(it,sw)
!Input variables:     
!   sw - A switch, which controls the addition of the explicitly time-dependent component of
!        the potential (i.g. laser). Normally it should be set to 1.0d0. However, it can be set to
!        0.0d0 or any other constant if needed.  
!   it - Current iteration 
integer    :: it
real*8     :: sw
integer    :: i,i1,i2,i3,j,k
real*8     :: ramp,t

t=it*time_step
ramp=1.d0
if((ramp_time>0.d0).AND.(t<ramp_time)) ramp=t/ramp_time

V_td=0.d0

if (using_v_step) then
 V_td = ramp*V_steppot
end if

if (use_projectile) then
call add_projectile_potential(V_td,sw)
endif

end subroutine generate_Vtd_noLaser


subroutine taylor_time_step_fd_velocity(it,sw,A)
  integer :: k,n,it,i
  real*8  :: sw,A(3)
  complex*16 :: tc_n

  call generate_Vtd_noLaser(it,sw) ! just in case there is something else
  
  do k=1,N_orbitals
    orbital_index=k
    !$omp parallel do default(shared) private (i)
    do i=1,N_Lattice_points    
      Phi_c(i)=Psi_c(i,k)
    enddo  
    !$omp end parallel do     
    
    if(spin_polarized) then
      if(k<N_orbitals_down+1) then
        spin_down=.TRUE.
        spin_up=.FALSE.
      else
        spin_up=.TRUE.
        spin_down=.FALSE.
      endif
    endif  
    do n=1,N_taylor
      call Hamiltonian_wavefn_c_fd_velocity(it,sw,Phi_c,H_Phi_c,A) ! velocity gauge
      !$omp parallel do default(shared) private (i)
      do i=1,N_Lattice_points  
        Phi_c(i)=H_Phi_c(i)
      enddo  
      !$omp end parallel do
      tc_n=tc(n)
      !$omp parallel do default(shared) private (i)
      do i=1,N_Lattice_points  
        Psi_c(i,k)=Psi_c(i,k)+tc_n*Phi_c(i)
      enddo  
      !$omp end parallel do 
    enddo
  enddo
end subroutine taylor_time_step_fd_velocity


subroutine taylor_time_step_no_pot(it,sw)
  integer :: k,n,it,i
  real*8  :: sw
  complex*16 :: tc_n

  do k=1,N_orbitals
    orbital_index=k
    !$omp parallel do default(shared) private (i)
    do i=1,N_Lattice_points    
      Phi_c(i)=Psi_c(i,k)
    enddo  
    !$omp end parallel do     
    
    if(spin_polarized) then
      if(k<N_orbitals_down+1) then
        spin_down=.TRUE.
        spin_up=.FALSE.
      else
        spin_up=.TRUE.
        spin_down=.FALSE.
      endif
    endif  
    do n=1,N_taylor
      call Hamiltonian_wavefn_c_no_pot(it,sw,Phi_c,H_Phi_c)
      !$omp parallel do default(shared) private (i)
      do i=1,N_Lattice_points  
        Phi_c(i)=H_Phi_c(i)
      enddo  
      !$omp end parallel do
      tc_n=tc(n)
      !$omp parallel do default(shared) private (i)
      do i=1,N_Lattice_points  
        Psi_c(i,k)=Psi_c(i,k)+tc_n*Phi_c(i)
      enddo  
      !$omp end parallel do 
    enddo
  enddo
end subroutine taylor_time_step_no_pot


subroutine taylor_time_step_allin1(it,sw)
  integer :: k,n,it,i,grid,i1,i2,i3
  real*8  :: sw
  complex*16 :: tc_n
  complex*16 :: phi3d(N_Lattice_min(1)-Nd-1:N_Lattice_max(1)+Nd, &
   N_Lattice_min(2)-Nd-1:N_Lattice_max(2)+Nd,N_Lattice_min(3)-Nd-1:N_Lattice_max(3)+Nd)
  complex*16 :: hphi2(N_Lattice_points),totalpotential(N_Lattice_points),phi(N_Lattice_points)
  real*8     :: ss1,s1,hs1,hss1
  
  phi=0.d0
  !Precompute some constants
  ss1=1/Grid_Step(1)**2
  s1=1/Grid_Step(1)
  hss1=-h2m*ss1
  hs1=s1
  if ((Grid_Step(1)/=Grid_Step(2)).and.(Grid_Step(1)/=Grid_Step(3))) then
    write(log_file,*) "grid steps must be equal with propagator=taylor_all"
	stop
  end if
  
  call generate_Vtd(it,sw)
  if(using_cap) then
    totalpotential=V_l_pp+V_Hartree+V_Exchange+V_td+sw*zi*captotal
  else
    totalpotential=V_l_pp+V_Hartree+V_Exchange+V_td
  end if
  
  write(log_file,*) "taylor all in one time step"
  !$omp parallel do default(shared) private (k,n,grid,i1,i2,i3,i,phi,phi3d,hphi2,V_nl_pp_c)
  do k=1,N_orbitals
    orbital_index=k
    phi(:)=Psi_c(:,k)
    if(spin_polarized) then
      if(k<N_orbitals_down+1) then
        spin_down=.TRUE.
        spin_up=.FALSE.
      else
        spin_up=.TRUE.
        spin_down=.FALSE.
      endif
    endif  
    do n=1,N_taylor
      !call Hamiltonian_wavefn_c(it,sw,Phi_c,H_Phi_c)
	  phi3d=0.d0
	  hphi2=0.d0
	  do grid=1,N_lattice_points
        i1=Lattice(1,grid)
        i2=Lattice(2,grid)
        i3=Lattice(3,grid)
        phi3d(i1,i2,i3)=phi(grid)
      enddo
	  do i=1,N_Lattice_points
        i1=Lattice(1,i); i2=Lattice(2,i); i3=Lattice(3,i)
        hphi2(i)=(3*fd_coeff_second_derivative(0)*phi3d(i1,i2,i3)+ &
        fd_coeff_second_derivative(1)*(phi3d(i1+1,i2,i3)+phi3d(i1-1,i2,i3)+phi3d(i1,i2+1,i3)+ &
                                       phi3d(i1,i2-1,i3)+phi3d(i1,i2,i3+1)+phi3d(i1,i2,i3-1))+ &
        fd_coeff_second_derivative(2)*(phi3d(i1+2,i2,i3)+phi3d(i1-2,i2,i3)+phi3d(i1,i2+2,i3)+ &
                                       phi3d(i1,i2-2,i3)+phi3d(i1,i2,i3+2)+phi3d(i1,i2,i3-2))+ &
        fd_coeff_second_derivative(3)*(phi3d(i1+3,i2,i3)+phi3d(i1-3,i2,i3)+phi3d(i1,i2+3,i3)+ &
                                       phi3d(i1,i2-3,i3)+phi3d(i1,i2,i3+3)+phi3d(i1,i2,i3-3))+ &
        fd_coeff_second_derivative(4)*(phi3d(i1+4,i2,i3)+phi3d(i1-4,i2,i3)+phi3d(i1,i2+4,i3)+ &
                                       phi3d(i1,i2-4,i3)+phi3d(i1,i2,i3+4)+phi3d(i1,i2,i3-4)))*hss1
      end do
	  V_nl_pp_c=0.d0
	  !call Nonlocal_pseudo_potential_c(phi,V_nl_pp_c)
	  phi=hphi2+V_nl_pp_c+totalpotential*phi
      Psi_c(:,k)=Psi_c(:,k)+tc(n)*phi(:)
    enddo
  enddo
  !$omp end parallel do


end subroutine taylor_time_step_allin1

subroutine taylor_time_step_allin1_3d(it,sw)
  integer :: k,n,it,i,grid,i1,i2,i3
  real*8  :: sw
  complex*16 :: tc_n
  complex*16 :: phi3d(N_Lattice_min(1)-Nd-1:N_Lattice_max(1)+Nd, &
                      N_Lattice_min(2)-Nd-1:N_Lattice_max(2)+Nd, &
					  N_Lattice_min(3)-Nd-1:N_Lattice_max(3)+Nd)
  complex*16 :: hphi2(N_Lattice_min(1)-Nd-1:N_Lattice_max(1)+Nd, &
                      N_Lattice_min(2)-Nd-1:N_Lattice_max(2)+Nd, &
					  N_Lattice_min(3)-Nd-1:N_Lattice_max(3)+Nd)
  complex*16 :: totalpotential(N_Lattice_min(1)-Nd-1:N_Lattice_max(1)+Nd, &
                      N_Lattice_min(2)-Nd-1:N_Lattice_max(2)+Nd, &
					  N_Lattice_min(3)-Nd-1:N_Lattice_max(3)+Nd)
  complex*16 :: phi00(N_Lattice_min(1)-Nd-1:N_Lattice_max(1)+Nd, &
                      N_Lattice_min(2)-Nd-1:N_Lattice_max(2)+Nd, &
					  N_Lattice_min(3)-Nd-1:N_Lattice_max(3)+Nd)
  complex*16 :: Vnlpp(N_Lattice_min(1)-Nd-1:N_Lattice_max(1)+Nd, &
                      N_Lattice_min(2)-Nd-1:N_Lattice_max(2)+Nd, &
					  N_Lattice_min(3)-Nd-1:N_Lattice_max(3)+Nd)
  real*8     :: ss1,s1,hs1,hss1
  
  integer    :: tmplmax,tmplmin
  
  phi=0.d0
  !Precompute some constants
  ss1=1/Grid_Step(1)**2
  s1=1/Grid_Step(1)
  hss1=-h2m*ss1
  hs1=s1
  if ((Grid_Step(1)/=Grid_Step(2)).and.(Grid_Step(1)/=Grid_Step(3))) then
    write(log_file,*) "grid steps must be equal with propagator=taylor_all"
	stop
  end if
  
  call generate_Vtd(it,sw)
  totalpotential=0.d0
  tmplmax=0
  tmplmin=999
  do grid=1,N_lattice_points
    i1=Lattice(1,grid)
	if(tmplmax<i1) tmplmax=i1
	if(tmplmin>i1) tmplmin=i1
    i2=Lattice(2,grid)
    i3=Lattice(3,grid)
    if(using_cap) then
      totalpotential(i1,i2,i3)=V_l_pp(grid)+V_Hartree(grid)+V_Exchange(grid)+V_td(grid)+sw*zi*captotal(grid)
	else
      totalpotential(i1,i2,i3)=V_l_pp(grid)+V_Hartree(grid)+V_Exchange(grid)+V_td(grid)
	end if
  end do
  
  write(log_file,*) "taylor all in one time step"
  write(log_file,*) tmplmax,tmplmin,N_Lattice_min(1),N_Lattice_max(1)
  do k=1,N_orbitals
    orbital_index=k
    phi3d=0.d0
	phi00=0.d0
	do grid=1,N_lattice_points
        i1=Lattice(1,grid)
        i2=Lattice(2,grid)
        i3=Lattice(3,grid)
        phi3d(i1,i2,i3)=Psi_c(grid,k)
		phi00(i1,i2,i3)=Psi_c(grid,k)
    enddo
    if(spin_polarized) then
      if(k<N_orbitals_down+1) then
        spin_down=.TRUE.
        spin_up=.FALSE.
      else
        spin_up=.TRUE.
        spin_down=.FALSE.
      endif
    endif  
    do n=1,N_taylor
      !call Hamiltonian_wavefn_c(it,sw,Phi_c,H_Phi_c)

	  hphi2=0.d0
	  do i3=N_Lattice_min(3)-1,N_Lattice_max(3)-1
      do i2=N_Lattice_min(2)-1,N_Lattice_max(2)-1
	  do i1=N_Lattice_min(1)-1,N_Lattice_max(1)-1
        hphi2(i1,i2,i3)=(3*fd_coeff_second_derivative(0)*phi3d(i1,i2,i3)+ &
        fd_coeff_second_derivative(1)*(phi3d(i1+1,i2,i3)+phi3d(i1-1,i2,i3)+phi3d(i1,i2+1,i3)+ &
                                       phi3d(i1,i2-1,i3)+phi3d(i1,i2,i3+1)+phi3d(i1,i2,i3-1))+ &
        fd_coeff_second_derivative(2)*(phi3d(i1+2,i2,i3)+phi3d(i1-2,i2,i3)+phi3d(i1,i2+2,i3)+ &
                                       phi3d(i1,i2-2,i3)+phi3d(i1,i2,i3+2)+phi3d(i1,i2,i3-2))+ &
        fd_coeff_second_derivative(3)*(phi3d(i1+3,i2,i3)+phi3d(i1-3,i2,i3)+phi3d(i1,i2+3,i3)+ &
                                       phi3d(i1,i2-3,i3)+phi3d(i1,i2,i3+3)+phi3d(i1,i2,i3-3))+ &
        fd_coeff_second_derivative(4)*(phi3d(i1+4,i2,i3)+phi3d(i1-4,i2,i3)+phi3d(i1,i2+4,i3)+ &
                                       phi3d(i1,i2-4,i3)+phi3d(i1,i2,i3+4)+phi3d(i1,i2,i3-4)))*hss1
      end do
	  end do
	  end do
	  Vnlpp=0.d0
	  !call Nonlocal_pseudo_potential_3d_array(phi3d,Vnlpp)
	  phi3d=hphi2+Vnlpp+totalpotential*phi3d
      phi00=phi00+tc(n)*phi3d
    enddo
	do grid=1,N_lattice_points
        i1=Lattice(1,grid)
        i2=Lattice(2,grid)
        i3=Lattice(3,grid)
		Psi_c(grid,k)=phi00(i1,i2,i3)
    enddo
  enddo
  


end subroutine taylor_time_step_allin1_3d

! a working version of taylor all in 1 propagation
!subroutine taylor_time_step_allin1(it,sw)
!  integer :: k,n,it,i,grid,i1,i2,i3
!  real*8  :: sw
!  complex*16 :: tc_n
!  complex*16 :: phi3d(N_Lattice_min(1)-Nd-1:N_Lattice_max(1)+Nd, &
!   N_Lattice_min(2)-Nd-1:N_Lattice_max(2)+Nd,N_Lattice_min(3)-Nd-1:N_Lattice_max(3)+Nd)
!  complex*16 :: hphi2(N_Lattice_points),totalpotential(N_Lattice_points)
!  real*8     :: ss1,s1,hs1,hss1
!  
!  !Precompute some constants
!  ss1=1/Grid_Step(1)**2
!  s1=1/Grid_Step(1)
!  hss1=-h2m*ss1
!  hs1=s1
!  if ((Grid_Step(1)/=Grid_Step(2)).and.(Grid_Step(1)/=Grid_Step(3))) then
!    write(log_file,*) "grid steps must be equal with propagator=taylor_all"
!	stop
!  end if
!  
!  call generate_Vtd(it,sw)
!  if(using_cap) then
!    totalpotential=V_l_pp+V_Hartree+V_Exchange+V_td+sw*zi*captotal
!  else
!    totalpotential=V_l_pp+V_Hartree+V_Exchange+V_td
!  end if
!  
!  write(log_file,*) "taylor all in one time step"
!  
!  do k=1,N_orbitals
!    orbital_index=k
!    Phi_c(:)=Psi_c(:,k)
!    if(spin_polarized) then
!      if(k<N_orbitals_down+1) then
!        spin_down=.TRUE.
!        spin_up=.FALSE.
!      else
!        spin_up=.TRUE.
!        spin_down=.FALSE.
!      endif
!    endif  
!    do n=1,N_taylor
!      !call Hamiltonian_wavefn_c(it,sw,Phi_c,H_Phi_c)
!	  phi3d=0.d0
!	  hphi2=0.d0
!	  do grid=1,N_lattice_points
!        i1=Lattice(1,grid)
!        i2=Lattice(2,grid)
!        i3=Lattice(3,grid)
!        phi3d(i1,i2,i3)=Phi_c(grid)
!      enddo
!	  do i=1,N_Lattice_points
!        i1=Lattice(1,i); i2=Lattice(2,i); i3=Lattice(3,i)
!        hphi2(i)=(3*fd_coeff_second_derivative(0)*phi3d(i1,i2,i3)+ &
!        fd_coeff_second_derivative(1)*(phi3d(i1+1,i2,i3)+phi3d(i1-1,i2,i3)+phi3d(i1,i2+1,i3)+ &
!                                       phi3d(i1,i2-1,i3)+phi3d(i1,i2,i3+1)+phi3d(i1,i2,i3-1))+ &
!        fd_coeff_second_derivative(2)*(phi3d(i1+2,i2,i3)+phi3d(i1-2,i2,i3)+phi3d(i1,i2+2,i3)+ &
!                                       phi3d(i1,i2-2,i3)+phi3d(i1,i2,i3+2)+phi3d(i1,i2,i3-2))+ &
!        fd_coeff_second_derivative(3)*(phi3d(i1+3,i2,i3)+phi3d(i1-3,i2,i3)+phi3d(i1,i2+3,i3)+ &
!                                       phi3d(i1,i2-3,i3)+phi3d(i1,i2,i3+3)+phi3d(i1,i2,i3-3))+ &
!        fd_coeff_second_derivative(4)*(phi3d(i1+4,i2,i3)+phi3d(i1-4,i2,i3)+phi3d(i1,i2+4,i3)+ &
!                                       phi3d(i1,i2-4,i3)+phi3d(i1,i2,i3+4)+phi3d(i1,i2,i3-4)))*hss1
!      end do
!	  call Nonlocal_pseudo_potential_c(Phi_c,V_nl_pp_c)
!	  Phi_c=hphi2+V_nl_pp_c+totalpotential*Phi_c
!      Psi_c(:,k)=Psi_c(:,k)+tc(n)*Phi_c(:)
!    enddo
!  enddo
!
!
!end subroutine taylor_time_step_allin1

!! Old version of calculate_rho_grid
!subroutine calculate_rho_grid
!  real*8   :: x
!  integer            :: j,k
!  do j=1,N_lattice_points
!    density(j)=0.d0
!    if(spin_polarized) then
!      density_down_new(j)=0.d0
!      density_up_new(j)=0.d0
!    endif
!    do k=1,N_orbitals
!      x=(real(Psi_c(j,k))**2+imag(Psi_c(j,k))**2)*Occupation(k)
!      if(spin_polarized) then
!        if(k<=N_orbitals_down) then
!          density_down_new(j)=density_down_new(j)+x
!        else
!          density_up_new(j)=density_up_new(j)+x
!        endif
!      else
!        density(j)=density(j)+x
!      endif
!    enddo
!  enddo
!  if(spin_polarized) then
!    density_up=density_up_new
!    density_down=density_down_new
!    density=density_down_new+density_up_new
!  endif
!end subroutine calculate_rho_grid

subroutine calculate_rho_grid
  real*8             :: x,occ_k,totocc
  integer            :: j,k
  
  if(debug_output_level >= 2) write(log_file,*) "call to calculate_rho_grid"

if(spin_polarized) then
  !$omp parallel workshare
  density_down_new=0.0d0
  density_up_new=0.0d0
  !$omp end parallel workshare
  do k=1,N_orbitals_down
    occ_k=Occupation(k)
    !$omp parallel do &
    !$omp default(shared) &
    !$omp private (j)
    do j=1,N_lattice_points
      density_down_new(j)=density_down_new(j)+(real(Psi_c(j,k))**2+imag(Psi_c(j,k))**2)*occ_k
    enddo
    !$omp end parallel do
  enddo
  do k=N_orbitals_down+1,N_orbitals
    occ_k=Occupation(k)
    !$omp parallel do &
    !$omp default(shared) &
    !$omp private (j) 
    do j=1,N_lattice_points
      density_up_new(j)=density_up_new(j)+(real(Psi_c(j,k))**2+imag(Psi_c(j,k))**2)*occ_k
    enddo
    !$omp end parallel do
  enddo
  !$omp parallel workshare
  density_up=density_up_new
  density_down=density_down_new
  !$omp end parallel workshare
  !$omp parallel workshare
  density=density_down_new+density_up_new
  !$omp end parallel workshare
else
  occ_k=Occupation(1)
  !$omp parallel do &
  !$omp default(shared) &
  !$omp private (j)
  do j=1,N_lattice_points
    density(j)=(real(Psi_c(j,1))**2+imag(Psi_c(j,1))**2)*occ_k
  enddo
  !$omp end parallel do
  do k=2,N_orbitals
		if((tddft_type==3).AND.(k==N_orbitals)) then
		  occ_k=1.d0
		else  
		  occ_k=Occupation(k)   
		endif
    !$omp parallel do &
    !$omp default(shared) &
    !$omp private (j)
    do j=1,N_lattice_points
      density(j)=density(j)+(real(Psi_c(j,k))**2+imag(Psi_c(j,k))**2)*occ_k
    enddo
    !$omp end parallel do
  enddo
endif

  totocc=0.d0
  totocc=totocc+sum(density(:))*grid_volume
  if((totocc > 20000).OR.isnan(totocc)) then
    write(log_file,*) "total occupation ",totocc
	write(log_file,*) "calculation is exploding"
	stop_tddft_calc=.TRUE.
  end if
  if((totocc < 1.0d-8)) then
    write(log_file,*) "total occupation ",totocc
	write(log_file,*) "system is completely ionized"
	stop_tddft_calc=.TRUE.
  end if
  if(debug_output_level >= 2) write(log_file,*) "End call to calculate_rho_grid"
end subroutine calculate_rho_grid

subroutine calculate_rho_grid_MPI
  real*8             :: x,occ_k,totocc
  integer            :: j,k
  
  density=0.d0
  
if(spin_polarized) then

  density_down_new=0.0d0
  density_up_new=0.0d0
  do k=1,N_orbitals_down
    if(MPItask_orbital_map(k)==MPI_proc_rank) then
      occ_k=Occupation(k)
      do j=1,N_lattice_points
        density_down_new(j)=density_down_new(j)+(real(Psi_c(j,k))**2+imag(Psi_c(j,k))**2)*occ_k
      enddo
	endif
  enddo
  do k=N_orbitals_down+1,N_orbitals
    if(MPItask_orbital_map(k)==MPI_proc_rank) then
      occ_k=Occupation(k)
      do j=1,N_lattice_points
        density_up_new(j)=density_up_new(j)+(real(Psi_c(j,k))**2+imag(Psi_c(j,k))**2)*occ_k
      enddo
	endif
  enddo
  density_up=density_up_new
  density_down=density_down_new
  density=density_down_new+density_up_new

else

  do k=1,N_orbitals
    if(MPItask_orbital_map(k)==MPI_proc_rank) then
      occ_k=Occupation(k)   
      do j=1,N_lattice_points
        density(j)=density(j)+(real(Psi_c(j,k))**2+imag(Psi_c(j,k))**2)*occ_k
      enddo
	  
      if(MPI_debug==99) then
	    write(log_file,*) k,"d_sum=",sum((real(Psi_c(:,k))**2+imag(Psi_c(:,k))**2)*occ_k)*Grid_volume
	  end if
	  
	endif
  enddo

endif

	!sum density back into master
	if(spin_polarized) then
	  density_down_new=density_down
	  density_up_new=density_up
	  !call MPI_Reduce(density_down_new,density_down,N_Lattice_points,MPI_DOUBLE_PRECISION &
	  !                 &,MPI_SUM,0,taylor_time_communicator,MPI_ierror)
	  !call MPI_Reduce(density_up_new  ,density_up  ,N_Lattice_points,MPI_DOUBLE_PRECISION &
	  !                 &,MPI_SUM,0,taylor_time_communicator,MPI_ierror)
	  call MPI_Allreduce(density_down_new,density_down,N_Lattice_points,MPI_DOUBLE_PRECISION &
	                   &,MPI_SUM,taylor_time_communicator,MPI_ierror)
	  if(MPI_ierror/=0) write(log_file,*) "MPI_ierror",MPI_ierror," at Location ID: ext100"
	  call MPI_Allreduce(density_up_new  ,density_up  ,N_Lattice_points,MPI_DOUBLE_PRECISION &
	                   &,MPI_SUM,taylor_time_communicator,MPI_ierror)
	  if(MPI_ierror/=0) write(log_file,*) "MPI_ierror",MPI_ierror," at Location ID: ext200"
      density=density_down+density_up
	else
	  full_density_save=density
	  !call MPI_Reduce(full_density_save,density,N_Lattice_points,MPI_DOUBLE,MPI_SUM,0,taylor_time_communicator,MPI_ierror)
	  call MPI_Allreduce(full_density_save,density,N_Lattice_points,MPI_DOUBLE,MPI_SUM,taylor_time_communicator,MPI_ierror)
	  if(MPI_ierror/=0) write(log_file,*) "MPI_ierror",MPI_ierror," at Location ID: ext300"
    endif

	
end subroutine calculate_rho_grid_MPI

SUBROUTINE Total_Energy_grid_c(it)
  integer :: i,orbital,p1,p2,p5,p,it
  real*8  :: su1,su2,su,over,orbital_energy_components(7),cp(7),w,overall=0.d0
  complex*16 :: pc
  logical :: need_offdiag_elem_check
  integer :: noff,j
  complex*16 :: Hio
  real*8     :: aver_dE

  Energy=0.d0
  if (mod(it,orb_en_comp_output_frequency)==0) then
    write(orbital_energy_components_file,'(1x,i6)',advance='no') it
    write(orbital_energy_components_file,'(1x,e19.12)',advance='no') it*time_step
  endif
  overall=0.d0
  do orbital=1,N_orbitals
    orbital_index=orbital
    Phi_c=Psi_c(:,orbital)
    if(spin_polarized) then
      if(orbital<N_orbitals_down+1) then
        spin_down=.TRUE.
        spin_up=.FALSE.
      else
        spin_up=.TRUE.
        spin_down=.FALSE.
      endif
    endif    
    call Hamiltonian_wavefn_c(Phi_c,H_Phi_c)

    su1=0.0d0
    over=0.0d0
    if (mod(it,orb_en_comp_output_frequency)==0) then
      cp(1:7)=0.0d0
      !$omp parallel do &
      !$omp default(shared) &
      !$omp private (i, w, pc) &
      !$omp reduction(+: over) &
      !$omp reduction(+: cp) &
      !$omp reduction(+: su1)
      do i=1,N_lattice_points
        pc=conjg(Phi_c(i))
        w=conjg(Phi_c(i))*Phi_c(i)
        su1=su1+pc*H_Phi_c(i)
        over=over+w
        cp(2)=cp(2)+w*V_l_pp(i)
        cp(3)=cp(3)+w*V_hartree(i)
        cp(4)=cp(4)+w*V_exchange(i)
        cp(5)=cp(5)+pc*V_nl_pp_c(i)
        cp(6)=cp(6)+pc*T_Phi_c(i)
        cp(7)=cp(7)+w*V_td(i)
      enddo
      !$omp end parallel do
      
      overall=overall+over*occupation(orbital)*grid_volume
      
      cp(1)=sum(cp(2:7))
      orbital_energy_components(1:7)=cp(1:7)/over
      write(orbital_energy_components_file,'(1x,e19.12)',advance='no') over*occupation(orbital)*grid_volume
      do i=1,1+min(6,orb_en_comp_output_level)
        write(orbital_energy_components_file,'(1x,e19.12)',advance='no') orbital_energy_components(i)
      enddo
    else
      !$omp parallel do &
      !$omp default(shared) &
      !$omp private (i) &
      !$omp reduction(+: su1)
      do i=1,N_lattice_points
        su1=su1+conjg(Phi_c(i))*H_Phi_c(i)
      enddo
      !$omp end parallel do
    endif

    Sp_Energy(orbital)=su1*Grid_Volume
    Energy=Energy+Occupation(orbital)*Sp_energy(orbital)

  enddo
  
  do p5=1,(N_orbitals+4)/5
    p1=5*(p5-1)+1
    p2=5*p5 ; if ( p2 > N_orbitals ) p2=N_orbitals
    write(log_file,'(1x,5(i3,f12.4,2x))') (p,Sp_energy(p),p=p1,p2)
  enddo

    if(mod(it,orb_en_comp_output_frequency)==0) write(orbital_energy_components_file,'(1x,e19.12)',advance='no') overall
  
  ! now done by Hamiltonian_density if(.NOT.spin_polarized) call Exchange_Correlation_Energy
  if (use_projectile) call ion_projectile_energy
  call Hartree_Energy
  write(log_file,*)'sp      ',Energy
  if (mod(it,orb_en_comp_output_frequency)==0) write(orbital_energy_components_file,'(1x,e19.12)',advance='no') Energy
  write(log_file,*)'Ha      ',E_Hartree
  write(log_file,*)'ii      ',E_Ion_ion
  if (use_projectile) write(log_file,*)'i-proj  ',E_Ion_Projectile
  write(log_file,*)'xc      ',E_Exchange
  write(log_file,*)'Ha+xc   ',E_Hartree+E_Exchange
  Energy=Energy+E_Exchange+E_Hartree+E_Ion_Ion
  if (use_projectile) Energy=Energy+E_Ion_Projectile
  
  Energy_current_iteration=Energy
  
  if(mod(it,orb_en_comp_output_frequency)==0) then
      write(orbital_energy_components_file,'(1x,e19.12)',advance='no') E_Hartree
      write(orbital_energy_components_file,'(1x,e19.12)',advance='no') E_Ion_ion
      write(orbital_energy_components_file,'(1x,e19.12)',advance='no') E_Exchange
      write(orbital_energy_components_file,'(1x,e19.12)',advance='no') E_Hartree+E_Exchange
      if (use_projectile) write(orbital_energy_components_file,'(1x,e19.12)',advance='no') E_Ion_Projectile
      write(orbital_energy_components_file,'(1x,e19.12)',advance='no') Energy
  end if
  
  if(mod(it,orb_en_comp_output_frequency)==0) write(orbital_energy_components_file,*)
  if(mod(it,orb_en_comp_output_frequency)==0) flush(orbital_energy_components_file)
  
end subroutine Total_Energy_grid_c


SUBROUTINE SP_Energy_grid_c_SIMPLE(it)
  integer :: i,orbital,p1,p2,p5,p,it
  real*8  :: su1,su2,su,over,orbital_energy_components(7),cp(7),w,overall=0.d0
  complex*16 :: pc
  logical :: need_offdiag_elem_check
  integer :: noff,j
  complex*16 :: Hio
  real*8     :: aver_dE,e_kin,e_pot

  Energy=0.d0
  do orbital=1,N_orbitals
    orbital_index=orbital
    Phi_c=Psi_c(:,orbital)
    if(spin_polarized) then
      if(orbital<N_orbitals_down+1) then
        spin_down=.TRUE.
        spin_up=.FALSE.
      else
        spin_up=.TRUE.
        spin_down=.FALSE.
      endif
    endif    
    
	
    call Kinetic_c(Phi_c,T_phi_c) 
	!call Nonlocal_pseudo_potential_c(Phi_c,V_nl_pp_c)
	e_kin=SUM(conjg(Phi_c)*T_phi_c)*grid_volume
	e_pot=SUM(conjg(Phi_c)*V_full_pot*Phi_c)*grid_volume
	write(log_file,*) orbital,e_kin,e_pot
	call Hamiltonian_wavefn_c(Phi_c,H_Phi_c)
    su1=0.0d0

      do i=1,N_lattice_points
        su1=su1+conjg(Phi_c(i))*H_Phi_c(i)
      enddo


    Sp_Energy(orbital)=su1*Grid_Volume

  enddo
  
  do p5=1,(N_orbitals+4)/5
    p1=5*(p5-1)+1
    p2=5*p5 ; if ( p2 > N_orbitals ) p2=N_orbitals
    write(log_file,'(1x,5(i3,f12.4,2x))') (p,Sp_energy(p),p=p1,p2)
  enddo



end subroutine SP_Energy_grid_c_SIMPLE

SUBROUTINE Total_Energy_grid_c_MPI(it)
  integer :: i,orbital,p1,p2,p5,p,it
  real*8  :: su1,su2,su,over,orbital_energy_components(7),cp(7),w,overall=0.d0
  complex*16 :: pc
  logical :: need_offdiag_elem_check
  integer :: noff,j
  complex*16 :: Hio
  real*8     :: aver_dE

  Energy=0.d0

  do orbital=1,N_orbitals
    Energy=Energy+Occupation(orbital)*sp_energy_save(orbital)
  enddo
  
  do p5=1,(N_orbitals+4)/5
    p1=5*(p5-1)+1
    p2=5*p5 ; if ( p2 > N_orbitals ) p2=N_orbitals
    write(log_file,'(1x,5(i3,f12.4,2x))') (p,sp_energy_save(p),p=p1,p2)
  enddo

  ! now done by Hamiltonian_density  call Exchange_Correlation_Energy
  if (use_projectile) call ion_projectile_energy
  call Hartree_Energy
  write(log_file,*)'sp ',Energy
  !if (mod(it,orb_en_comp_output_frequency)==0) write(orbital_energy_components_file,'(1x,e19.12)',advance='no') Energy
  write(log_file,*)'Ha ',E_Hartree
  write(log_file,*)'ii ',E_Ion_ion
  if (use_projectile) write(log_file,*)'i-proj  ',E_Ion_Projectile
  write(log_file,*)'xc ',E_Exchange
  write(log_file,*)'Ha+xc ',E_Hartree+E_Exchange
  !write(821261,'(F10.4,)') it*time_step,Energy,E_Hartree,E_Ion_ion,E_Exchange
  Energy=Energy+E_Exchange+E_Hartree+E_Ion_Ion
  if (use_projectile) Energy=Energy+E_Ion_Projectile
  
  Energy_current_iteration=Energy
  
end subroutine Total_Energy_grid_c_MPI

SUBROUTINE Orthogonalization_Psi_c(N_o_min,N_o_max)
  ! Gram-Schmidt orthogonalization
  integer :: orbital,i,N_o_min,N_o_max
  real*8  :: s
  complex*16  :: overlap

  do orbital=N_o_min,N_o_max
!    if(orbital>N_o_min) then
      do i=N_o_min,orbital-1
        overlap=sum(conjg(Psi_c(:,i))*Psi_c(:,orbital))*Grid_Volume
        Psi_c(:,orbital)=Psi_c(:,orbital)-overlap*Psi_c(:,i)
      enddo
!    endif
    s=sum(abs(Psi_c(:,orbital))**2)*Grid_Volume
    Psi_c(:,orbital)=Psi_c(:,orbital)/sqrt(s)
  enddo
END SUBROUTINE Orthogonalization_Psi_c

subroutine timings_taylor
implicit none
  real*8 :: ct
  
  write(log_file,*) "----------------Total CPU time spent----------------"
  if(add_projector_cap) then
    ct=ctime_projector_cap
    write(log_file,'(a,f12.2,a,f12.4,a)') "Adding projector cap::",ct," s ",ct/3600.d0," hr"
  end if
  
  ct=ctime_propagator
  write(log_file,*) "Applying the time propagator::",ct," s ",ct/3600.d0," hr"

end subroutine timings_taylor

SUBROUTINE do_output_td_current_density_slices(iter,curtime)
implicit none
integer :: iter
integer :: i,j,k,m,ind
character(255) :: fname1
character(7)   :: ch7
complex*16, allocatable :: Psi2(:,:)
real*8         :: curr3Darray(3,N_Lattice(1),N_Lattice(2),N_Lattice(3)),curtime

!First we compute the current density

if (non_local_current) then
  if (using_injection) then
     allocate(psi2(N_lattice_points,1))
     do j=1,N_lattice_points
      psi2(j,1)=phi_source(j)
     enddo
    call GetCurrentDensity(psi2, Grid_point, (/0.D0,0.D0,0.D0/))
     deallocate(psi2)
  else
    call GetCurrentDensity(Psi_c, Grid_point, (/0.D0,0.D0,0.D0/))
  endif
else
call compute_td_current_density()
endif

 do k=1,N_Lattice(3)
   do j=1,N_Lattice(2)
     do i=1,N_Lattice(1)
	   ind=Lattice_inv_xyz(i,j,k)
	   do m=1,3
	     curr3Darray(m,i,j,k)=current_density(m,ind)
	   end do
	 end do
   end do
 end do
 
 write(ch7,'(i7.7)') iter
   write(fname1,'(a,a,a)') "current_sliceXY_",ch7,".dat"
   open(199,file=trim(adjustl(fname1)),form='formatted',status='replace',action='write')
   write(199,'(a,f15.5,a)')" #time= ",curtime, &
    "   xgrid(i),ygrid(j),sum(curr3Darray(1,i,j,:))*grid_step(3),sum(curr3Darray(2,i,j,:))*grid_step(3)"
   do j=1,N_Lattice(2)
     do i=1,N_Lattice(1)
	     write(199,'(2f12.3,2es16.7e3)') xgrid(i),ygrid(j), &
		   sum(curr3Darray(1,i,j,:))*grid_step(3),sum(curr3Darray(2,i,j,:))*grid_step(3)
	 end do
   end do
   close(199)

   write(fname1,'(a,a,a)') "current_sliceXZ_",ch7,".dat"
   open(199,file=trim(adjustl(fname1)),form='formatted',status='replace',action='write')
   write(199,'(a,f15.5,a)')" #time= ",curtime,&
     "  xgrid(i),zgrid(k),sum(curr3Darray(1,i,:,k))*grid_step(2),sum(curr3Darray(3,i,:,k))*grid_step(2)"
   do k=1,N_Lattice(3)
     do i=1,N_Lattice(1)
	     write(199,'(2f12.3,2es16.7e3)') xgrid(i),zgrid(k),&
		   sum(curr3Darray(1,i,:,k))*grid_step(2),sum(curr3Darray(3,i,:,k))*grid_step(2)
	 end do
   end do
   close(199)
   
   write(fname1,'(a,a,a)') "current_sliceYZ_",ch7,".dat"
   open(199,file=trim(adjustl(fname1)),form='formatted',status='replace',action='write')
   write(199,'(a,f15.5,a)')" #time= ",curtime,&
    "  ygrid(j),zgrid(k),sum(curr3Darray(2,:,j,k))*grid_step(1),sum(curr3Darray(3,:,j,k))*grid_step(1)"
   do k=1,N_Lattice(3)
     do j=1,N_Lattice(2)
	     write(199,'(2f12.3,2es16.7e3)') ygrid(j),zgrid(k),&
		   sum(curr3Darray(2,:,j,k))*grid_step(1),sum(curr3Darray(3,:,j,k))*grid_step(1)
	 end do
   end do
   close(199)
   
   write(fname1,'(a,a,a)') "current_lineX_",ch7,".dat"
   open(199,file=trim(adjustl(fname1)),form='formatted',status='replace',action='write')
   write(199,'(a,f15.5,a)')" #time= ",curtime,"  xgrid(i),sum(curr3Darray(1,i,:,:))*grid_step(2)*grid_step(3)"
     do i=1,N_Lattice(1)
	     write(199,'(f12.3,es16.7e3)') xgrid(i),sum(curr3Darray(1,i,:,:))*grid_step(2)*grid_step(3)
	 end do
   close(199)
   
   
end SUBROUTINE do_output_td_current_density_slices

subroutine do_output_td_line_current_orbital(iter,curtime)
implicit none
integer :: iter
integer :: i,j,k,m,ind,orb
character(255) :: fname1
character(7)   :: ch7
complex*16, allocatable :: Psi2(:,:)
real*8         :: curr3Darray(3,N_Lattice(1),N_Lattice(2),N_Lattice(3)),curtime

!First we compute the current density

  allocate(psi2(N_lattice_points,1))
  
   write(ch7,'(i7.7)') iter
   write(fname1,'(a,a,a)') "orb_current_lineX_",ch7,".dat"
   open(199,file=trim(adjustl(fname1)),form='formatted',status='replace',action='write')
   write(199,'(a,f15.5,a)')" #time= ",curtime,"  FOR EACH:: sum(curr3Darray(1,i,:,:))*grid_step(2)*grid_step(3)"
   write(199,'(a)',advance='no') "#orb   "
   write(199,'(a,f12.3)',advance='no') "C_X=",xgrid(N_Lattice(1)/2)
   do i=1,N_Lattice(1),output_td_line_current_orbital_stride
     write(199,'(a,f12.3)',advance='no') "C_X=",xgrid(i)
   end do
   write(199,*)
  do orb=1,N_orbitals
    psi2(:,1)=Psi_c(:,orb)
    if (non_local_current) then
      call GetCurrentDensity(psi2, Grid_point, (/0.D0,0.D0,0.D0/))
    endif

     do k=1,N_Lattice(3)
       do j=1,N_Lattice(2)
         do i=1,N_Lattice(1)
    	   ind=Lattice_inv_xyz(i,j,k)
    	   do m=1,3
    	     curr3Darray(m,i,j,k)=current_density(m,ind)
    	   end do
    	 end do
       end do
     end do
	 
     write(199,'(i7)',advance='no') orb
	 write(199,'(es16.7e3)',advance='no') sum(curr3Darray(1,N_Lattice(1)/2,:,:))*grid_step(2)*grid_step(3)
     do i=1,N_Lattice(1),output_td_line_current_orbital_stride
	     write(199,'(es16.7e3)',advance='no') sum(curr3Darray(1,i,:,:))*grid_step(2)*grid_step(3)
	 end do	 
	 write(199,*)
  end do
  
  close(199)

end subroutine do_output_td_line_current_orbital

subroutine do_output_td_xyslice_current_orbital(iter,curtime)
implicit none
integer :: iter
integer :: i,j,k,m,ind,orb
character(255) :: fname1
character(7)   :: ch7
complex*16, allocatable :: Psi2(:,:)
real*8         :: curr3Darray(3,N_Lattice(1),N_Lattice(2),N_Lattice(3),N_orbitals),curtime

!First we compute the current density

   allocate(psi2(N_lattice_points,1))
  
   write(ch7,'(i7.7)') iter
   write(fname1,'(a,a,a)') "orb_current_xyslice_",ch7,".dat"
   open(199,file=trim(adjustl(fname1)),form='formatted',status='replace',action='write')
   write(199,'(a,f15.5,a)')" #time= ",curtime,"  FOR EACH:: sum(curr3Darray(1,i,j,:,k))*grid_step(3)"
   write(199,'(a)',advance='no') "#         X          Y"
   do i=1,N_orbitals
     write(199,'(a,i4.4,a,i4.4,a)',advance='no') "  orb",i,"x   orb",i,"y "
   end do
   write(199,*)
  do orb=1,N_orbitals
    psi2(:,1)=Psi_c(:,orb)
    if (non_local_current) then
      call GetCurrentDensity(psi2, Grid_point, (/0.D0,0.D0,0.D0/))
    endif

     do k=1,N_Lattice(3)
       do j=1,N_Lattice(2)
         do i=1,N_Lattice(1)
    	   ind=Lattice_inv_xyz(i,j,k)
    	   do m=1,3
    	     curr3Darray(m,i,j,k,orb)=current_density(m,ind)
    	   end do
    	 end do
       end do
     end do
  end do
  do j=1,N_Lattice(2),2
    do i=1, N_Lattice(1),2
	  write(199,'(2f11.2)',advance='no') xgrid(i),ygrid(j)
      do orb=1,N_orbitals
	     write(199,'(2es11.2e3)',advance='no') sum(curr3Darray(1,i,j,:,orb))*grid_step(3),&
		   sum(curr3Darray(2,i,j,:,orb))*grid_step(3)
	  end do	 
	 write(199,*)
    end do
  end do
  close(199)

end subroutine do_output_td_xyslice_current_orbital

subroutine do_td_current_atom_sum(iter)
implicit none
integer :: iter,j,k,idx(3)
real*8  :: r1,distmin,d1
  if(iter==0) then
    ! open input files
	open(td_current_atom_sum_file_x,file=trim(adjustl(td_current_atom_sum_filename_x)),action='write',status='replace')
	open(td_current_atom_sum_file_y,file=trim(adjustl(td_current_atom_sum_filename_y)),action='write',status='replace')
	open(td_current_atom_sum_file_z,file=trim(adjustl(td_current_atom_sum_filename_z)),action='write',status='replace')
    allocate(atom_closest_gridpoint(3,N_total_atom))
	do j=1,N_total_atom
	  ! get closest grid point in x y z
	  idx=0
	  distmin=9.d9
      do k=1,N_Lattice(3)
	    d1=abs(zgrid(k)-Position(3,j))
	    if(d1<distmin) then
		  distmin=d1
		  idx(3)=k
		end if
	  end do
	  distmin=9.d9
      do k=1,N_Lattice(2)
	    d1=abs(ygrid(k)-Position(2,j))
	    if(d1<distmin) then
		  distmin=d1
		  idx(2)=k
		end if
	  end do
	  distmin=9.d9
      do k=1,N_Lattice(1)
	    d1=abs(xgrid(k)-Position(1,j))
	    if(d1<distmin) then
		  distmin=d1
		  idx(1)=k
		end if
	  end do
	  atom_closest_gridpoint(:,j)=idx(:)
	  ! double check
	  k=Lattice_inv_xyz(idx(1),idx(2),idx(3))
	  d1=sqrt(grid_point(1,k)**2+grid_point(2,k)**2+grid_point(3,k)**2)
	  if(d1>sqrt(grid_step(1)**2+grid_step(2)**2+grid_step(3)**2)) then
	    write(*,*) "Atom center match gridpoint failure"
		write(*,*) d1," > ",sqrt(grid_step(1)**2+grid_step(2)**2+grid_step(3)**2)
		write(*,*)  Position(1:3,j)
		write(*,*)  grid_point(1:3,k)
	  endif
	end do
  else
    td_current_atom_sum=0.d0
	do j=1,N_Lattice_points
    
	end do
  end if

end subroutine do_td_current_atom_sum

subroutine do_td_current_plane_sum(iter)
implicit none
integer :: iter,j,k,i44,idx(3),k1,k2,k3,nptscnt,j1,j2,j3,s1,s2,s3,m1,m2,m3
real*8  :: r1,distmin,d1,g1,v1(3),xyz_gp(3),xyz_tp(3)
character(7)   :: ch7
character(255) :: fname1
  if(iter==0) then
    ! open input files
	

	allocate(td_current_plane_use(N_Lattice(1),N_Lattice(2)))
	td_current_plane_use=.FALSE.
    k3=N_Lattice(3)/2
	nptscnt=0
	do k1=1,N_Lattice(1)
	  do k2=1,N_Lattice(2)
	    j=Lattice_inv_xyz(k1,k2,k3)
		if(Density(j)>td_current_plane_cutoff) then
		  td_current_plane_use(k1,k2)=.TRUE.
		  nptscnt=nptscnt+1
		  write(ch7,'(i7.7)') nptscnt
		  write(fname1,'(a,a,a)') trim(adjustl(td_current_plane_sum_basename_z)),ch7(1:7),'.txt'
		  write(*,'(a,2F10.3,a)') "pt file ",grid_point(1,j),grid_point(2,j),trim(adjustl(fname1))
	      open(td_current_plane_sum_file_z,file=trim(adjustl(fname1)),action='write',status='replace')
		  write(td_current_plane_sum_file_z,'(a,2F10.4)') "# ",grid_point(1,j),grid_point(2,j)
		  close(td_current_plane_sum_file_z)
		end if
	  end do
	end do
	! determine td_current_plane_n_grid_needed
	! go 5 sigma
	r1=5.d0*output_td_current_atom_sum_beta
	td_current_plane_n_grid_needed=(r1/grid_step(1))+1
	write(*,*) "sum current at ",nptscnt," points"
	write(*,*) "with gaussian sig=",output_td_current_atom_sum_beta
	write(*,*) "td_current_plane_n_grid_needed=",td_current_plane_n_grid_needed
  else
    k3=N_Lattice(3)/2
	nptscnt=0
	do k1=1,N_Lattice(1)
	  do k2=1,N_Lattice(2)
	    if(td_current_plane_use(k1,k2)) then
		  nptscnt=nptscnt+1
		  j=Lattice_inv_xyz(k1,k2,k3)
		  xyz_gp(:)=grid_point(:,j)
		  s1=k1-td_current_plane_n_grid_needed
		  s2=k2-td_current_plane_n_grid_needed
		  s3=k3-td_current_plane_n_grid_needed
		  j1=k1+td_current_plane_n_grid_needed
		  j2=k2+td_current_plane_n_grid_needed
		  j3=k3+td_current_plane_n_grid_needed
		  if(s1<1) s1=1
		  if(s2<1) s2=1
		  if(s3<1) s3=1
		  if(j1>N_Lattice(1)) j1=N_Lattice(1)
		  if(j2>N_Lattice(2)) j2=N_Lattice(2)
		  if(j3>N_Lattice(3)) j3=N_Lattice(3)
		  v1=0.d0
		  do m1=s1,j1
		    xyz_tp(1)=xgrid(m1)
		    do m2=s2,j2
			  xyz_tp(2)=ygrid(m2)
		      do m3=s3,j3
			    i44=Lattice_inv_xyz(m1,m2,m3)
			    xyz_tp(3)=zgrid(m3)
			    d1=sqrt(sum((xyz_gp(:)-xyz_tp(:))**2))
			    g1=exp(-(d1/output_td_current_atom_sum_beta)**2)
				v1(:)=v1(:)+g1*current_density(:,i44)
		      end do 
		    end do 
		  end do
		  write(ch7,'(i7.7)') nptscnt
		  write(fname1,'(a,a,a)') trim(adjustl(td_current_plane_sum_basename_z)),ch7(1:7),'.txt'
	      open(td_current_plane_sum_file_z,file=trim(adjustl(fname1)),position="append",action='write',status='OLD')
		  write(td_current_plane_sum_file_z,'(F10.4,3ES17.8E3)') iter*time_step,v1(1:3)
		  close(td_current_plane_sum_file_z)
		endif
	  end do
	end do
  end if

end subroutine do_td_current_plane_sum

end Module Taylor_extended