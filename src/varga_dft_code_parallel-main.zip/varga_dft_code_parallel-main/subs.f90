MODULE WORKPROCS
  USE PARAMETERS
  implicit none

CONTAINS

subroutine sinc_basis(N,a,b,xr,wr,t)
  integer        :: i,j,N,m,k
  real*8         :: a,b,wt,h,xr(N),wr(N),t(N,N),f(0:N), &
&                   xx,w(0:N)

  m=min(5,N)
  h=(b-a)/(1.d0*(N-1))
  do i=1,N
    xr(i)=a+(i-1)*h
    wr(i)=1.d0/h
  end do
  f(0)=0.d0
  f(1)=0.d0
  do i=2,n
    xx=dble(i)
    f(i)=f(i-1)+dlog(xx)
  end do
    t=0.d0

  w=0.d0
  do k=1,m
    do j=k,m
      w(k)=w(k)+dexp(f(m)-f(j)-f(m-j))/2.d0**m
    end do
  end do
  do k=1,m
    w(0)=w(0)-12.d0/pi**2*(-1)**k*w(k)/k**2
  end do
   
  do i=1,n
    t(i,i)=-pi**2/(3.d0*h**2)*w(0)
    do k=1,m
      if(i+k.le.n) then
        t(i,i+k)=2.d0*(-1)**(k+1)/(k**2*h**2)*w(k)
        t(i+k,i)=2.d0*(-1)**(k+1)/(k**2*h**2)*w(k)
      endif
    end do    
  end do

end subroutine sinc_basis

  
function sinc(x)
implicit none
double precision :: x,pi,y,sinc
  pi=4.d0*atan(1.d0)
  y=pi*x
  if(y/=0.d0) then
    sinc=sin(y)/y  
  else
    sinc=1.d0
  endif
end function sinc


subroutine sin_cardinal(N,a0,b0,xr,wr,t)
  integer :: i,j,N
  real*8  :: x,a,b,wt,a0,b0,xr(N),wr(N),t(N,N)

  a=a0*dfloat(N+1)/dfloat(N-1)
  b=b0*dfloat(N+1)/dfloat(N-1)

  do i=1,N
    x=a+i*(b-a)/(1.d0*(N+1))
    xr(i)=x
    wr(i)=dfloat(N+1)/(b-a)
  end do
  do i=1,N
    x=a+i*(b-a)/(1.d0*(N+1))
    do j=1,N
      wt=sincar(x,j,N,a,b,2)
      t(i,j)=wt
    end do
  end do
end subroutine sin_cardinal

function sincar(x,i,N,a,b,id)
  integer :: k,N,i,id
  real*8  :: x,su,wi,wj,d,a,b,sincar

  su=0.d0
  do k=1,N
    d=k*pi/(1.d0*(N+1))
    if(id.eq.0) wi=sin(pi*k*(x-a)/(b-a))*sqrt(2.d0/(b-a))
    if(id.eq.1) wi=cos(pi*k*(x-a)/(b-a))*sqrt(2.d0/(b-a))*pi*k/(b-a)
    if(id.eq.2) wi=-sin(pi*k*(x-a)/(b-a))*sqrt(2.d0/(b-a))*(pi*k/(b-a))**2
    wj=sin(i*d)*sqrt(2.d0/(b-a))
    su=su+wi*wj
  end do
  sincar=su*sqrt((b-a)/(1.d0*(N+1)))/(sqrt((N+1)/(b-a)))
end function sincar

subroutine finite_diff(N,a,b,xr,wr,t)
  integer                            :: i,j,N
  real*8                             :: a,b,wt,h,xr(N),wr(N),t(N,N)

  h=(b-a)/(1.d0*(N-1))
  do i=1,N
    xr(i)=a+(i-1)*h
    wr(i)=h
  end do
    t=0.d0
    do i=1,N
      t(i,i)=-205.d0/72.d0/h**2
      if(i.ne.1) then
        t(i,i-1)=8.d0/5.d0/h**2
        t(i-1,i)=8.d0/5.d0/h**2
      endif
      if(i.gt.2) then
        t(i,i-2)=-1.d0/5.d0/h**2
        t(i-2,i)=-1.d0/5.d0/h**2
      endif
      if(i.gt.3) then
        t(i,i-3)=8.d0/315.d0/h**2
        t(i-3,i)=8.d0/315.d0/h**2
      endif
      if(i.gt.4) then
        t(i,i-4)=-1.d0/560.d0/h**2
        t(i-4,i)=-1.d0/560.d0/h**2
      endif
    end do
end subroutine finite_diff

!subroutine finite_diff_first_derivative(N,a,b,xr,wr,t)
!  integer                            :: i,j,N
!  real*8                             :: a,b,wt,h,xr(N),wr(N),t(N,N)

!  h=(b-a)/(1.d0*(N-1))
!  do i=1,N
!    xr(i)=a+(i-1)*h
!    wr(i)=h
!  end do
!    t=0.d0
!    do i=1,N
!      t(i,i)=-205.d0/72.d0/h**2
!      if(i.ne.1) then
!        t(i,i-1)=8.d0/5.d0/h**2
!        t(i-1,i)=8.d0/5.d0/h**2
!      endif
!      if(i.gt.2) then
!        t(i,i-2)=-1.d0/5.d0/h**2
!        t(i-2,i)=-1.d0/5.d0/h**2
!      endif
!      if(i.gt.3) then
!        t(i,i-3)=8.d0/315.d0/h**2
!        t(i-3,i)=8.d0/315.d0/h**2
!      endif
!      if(i.gt.4) then
!        t(i,i-4)=-1.d0/560.d0/h**2
!        t(i-4,i)=-1.d0/560.d0/h**2
!      endif
!    end do
!end subroutine finite_diff_first_derivative

!     Spherical harmonics

      FUNCTION Ylm(x,y,z,lm)

      real(8),intent(IN) :: x,y,z
      integer,intent(IN) :: lm
      real(8) :: rrrr
      real(8) :: Ylm

      select case( lm )

      case(1)  ; Ylm=1.d0
      case(2)  ; Ylm=y
      case(3)  ; Ylm=z
      case(4)  ; Ylm=x
      case(5)  ; Ylm=sqrt(3.d0)*x*y                     ! lm=5  (2 -2)
      case(6)  ; Ylm=sqrt(3.d0)*y*z                     ! lm=6  (2 -1)
      case(7)  ; Ylm=(2*z*z-x*x-y*y)/2.d0               ! lm=7  (2 0)
      case(8)  ; Ylm=sqrt(3.d0)*x*z                     ! lm=8  (2 1)
      case(9)  ; Ylm=sqrt(3.d0/4.d0)*(x*x-y*y)          ! lm=9  (2 2)
      case(10) ; Ylm=sqrt(5.d0/8.d0)*y*(3*x*x-y*y)      ! lm=10 (3 -3)
      case(11) ; Ylm=sqrt(15.d0)*x*y*z                  ! lm=11 (3 -2)
      case(12) ; Ylm=sqrt(3.d0/8.d0)*y*(4*z*z-x*x-y*y)  ! lm=12 (3 -1)
      case(13) ; Ylm=z*(2*z*z-3*x*x-3*y*y)/2.d0         ! lm=13 (3 0)
      case(14) ; Ylm=sqrt(3.d0/8.d0)*x*(4*z*z-x*x-y*y)  ! lm=14 (3 1)
      case(15) ; Ylm=sqrt(15.d0/4.d0)*z*(x*x-y*y)       ! lm=15 (3 2)
      case(16) ; Ylm=sqrt(5.d0/8.d0)*x*(x*x-3*y*y)      ! lm=16 (3 3)

! for Hartree routine

      case(17)
         rrrr=(x**2+y**2+z**2)**2
         Ylm=rrrr*sqrt(35.d0)/2.d0*x*y*(x**2-y**2)
      case(18)
         rrrr=(x**2+y**2+z**2)**2
         Ylm=rrrr*sqrt(35.d0/8.d0)*y*z*(3*x**2-y**2)
      case(19)
         rrrr=(x**2+y**2+z**2)**2
         Ylm=rrrr*sqrt(5.d0)/2.d0*x*y*(7*z**2-1)
      case(20)
         rrrr=(x**2+y**2+z**2)**2
         Ylm=rrrr*sqrt(5.d0/8.d0)*y*(7*z**3-3*z)
      case(21)
         rrrr=(x**2+y**2+z**2)**2
         Ylm=rrrr*(35*z**4-30*z**2+3.d0)/8.d0
      case(22)
         rrrr=(x**2+y**2+z**2)**2
         Ylm=rrrr*sqrt(5.d0/8.d0)*x*(7*z**3-3*z)
      case(23)
         rrrr=(x**2+y**2+z**2)**2
         Ylm=rrrr*sqrt(5.d0)/4.d0*(7*z**2-1)*(x**2-y**2)
      case(24)
         rrrr=(x**2+y**2+z**2)**2
         Ylm=rrrr*sqrt(35.d0/8.d0)*z*x*(x**2-3*y**2)
      case(25)
         rrrr=(x**2+y**2+z**2)**2
         Ylm=rrrr*sqrt(35.d0)/8.d0*(x**4+y**4-6*x**2*y**2)

      end select

      END FUNCTION Ylm

       SUBROUTINE lubksb_c(a,n,np,indx,b)
       INTEGER n,np,indx(n)
       complex*16 a(np,np),b(n)
       INTEGER i,ii,j,ll
       complex*16 sum
       ii=0
       do 12 i=1,n
         ll=indx(i)
         sum=b(ll)
         b(ll)=b(i)
         if (ii.ne.0)then
           do 11 j=ii,i-1
             sum=sum-a(i,j)*b(j)
11         continue
         else if (sum.ne.(0.d0,0.d0)) then
           ii=i
         endif
         b(i)=sum
12     continue
       do 14 i=n,1,-1
         sum=b(i)
         do 13 j=i+1,n
           sum=sum-a(i,j)*b(j)
13       continue
         b(i)=sum/a(i,i)
14     continue
       return
       END SUBROUTINE lubksb_c

       SUBROUTINE ludcmp_c(a,n,np,indx,d)
       INTEGER n,np,indx(n),Ndim
       REAL*8 d,TINY
       COMPLEX*16 a(np,np),sum,du
       PARAMETER (Ndim=5000,TINY=1.0d-20)
       INTEGER i,imax,j,k
       REAL*8 aamax,vv(ndim),dum
       d=1.d0
       do 12 i=1,n
         aamax=0.d0
         do 11 j=1,n
           if (abs(a(i,j)).gt.aamax) aamax=abs(a(i,j))
 11      continue
         if (aamax.eq.0.d0) pause 'singular matrix in ludcmp'
         vv(i)=1.d0/aamax
 12    continue
       do 19 j=1,n
         do 14 i=1,j-1
           sum=a(i,j)
           do 13 k=1,i-1
             sum=sum-a(i,k)*a(k,j)
 13        continue
           a(i,j)=sum
 14      continue
         aamax=0.d0
         do 16 i=j,n
           sum=a(i,j)
           do 15 k=1,j-1
             sum=sum-a(i,k)*a(k,j)
 15        continue
           a(i,j)=sum
           dum=vv(i)*abs(sum)
           if (dum.ge.aamax) then
             imax=i
             aamax=dum
           endif
 16      continue
         if (j.ne.imax)then
           do 17 k=1,n
             du=a(imax,k)
             a(imax,k)=a(j,k)
             a(j,k)=du
 17        continue
           d=-d
           vv(imax)=vv(j)
         endif
         indx(j)=imax
         if(a(j,j).eq.(0.d0,0.d0)) a(j,j)=TINY
         if(j.ne.n)then
           du=1.d0/a(j,j)
           do 18 i=j+1,n
             a(i,j)=a(i,j)*du
 18        continue
         endif
 19    continue
       return
       END SUBROUTINE ludcmp_c

       SUBROUTINE lubksb_r(a,n,np,indx,b)
       INTEGER n,np,indx(n)
       real*8 a(np,np),b(n)
       INTEGER i,ii,j,ll
       real*8 sum
       ii=0
       do 12 i=1,n
         ll=indx(i)
         sum=b(ll)
         b(ll)=b(i)
         if (ii.ne.0)then
           do 11 j=ii,i-1
             sum=sum-a(i,j)*b(j)
11         continue
         else if (sum.ne.0.d0) then
           ii=i
         endif
         b(i)=sum
12     continue
       do 14 i=n,1,-1
         sum=b(i)
         do 13 j=i+1,n
           sum=sum-a(i,j)*b(j)
13       continue
         b(i)=sum/a(i,i)
14     continue
       return
       END SUBROUTINE lubksb_r


       SUBROUTINE ludcmp_r(a,n,np,indx,d)
       INTEGER n,np,indx(n),Ndim
       REAL*8 d,TINY
       real*8 a(np,np),sum,du
       PARAMETER (Ndim=5000,TINY=1.0d-20)
       INTEGER i,imax,j,k
       REAL*8 aamax,vv(ndim),dum
       d=1.d0
       do 12 i=1,n
         aamax=0.d0
         do 11 j=1,n
           if (abs(a(i,j)).gt.aamax) aamax=abs(a(i,j))
 11      continue
         if (aamax.eq.0.d0) pause 'singular matrix in ludcmp'
         vv(i)=1.d0/aamax
 12    continue
       do 19 j=1,n
         do 14 i=1,j-1
           sum=a(i,j)
           do 13 k=1,i-1
             sum=sum-a(i,k)*a(k,j)
 13        continue
           a(i,j)=sum
 14      continue
         aamax=0.d0
         do 16 i=j,n
           sum=a(i,j)
           do 15 k=1,j-1
             sum=sum-a(i,k)*a(k,j)
 15        continue
           a(i,j)=sum
           dum=vv(i)*abs(sum)
           if (dum.ge.aamax) then
             imax=i
             aamax=dum
           endif
 16      continue
         if (j.ne.imax)then
           do 17 k=1,n
             du=a(imax,k)
             a(imax,k)=a(j,k)
             a(j,k)=du
 17        continue
           d=-d
           vv(imax)=vv(j)
         endif
         indx(j)=imax
         if(a(j,j).eq.0.d0) a(j,j)=TINY
         if(j.ne.n)then
           du=1.d0/a(j,j)
           do 18 i=j+1,n
             a(i,j)=a(i,j)*du
 18        continue
         endif
 19    continue
       return
       END SUBROUTINE ludcmp_r

subroutine inv_c(a,n,ai)
implicit none
  integer      :: n,i
  complex*16   :: a(n,n),ai(n,n)
  integer      :: indx(n)
  real*8       :: d

  ai=0.d0
  do i=1,n
    ai(i,i)=1.d0
  end do
  call ludcmp_c(a,n,n,indx,d)
  do i=1,n
    call lubksb_c(a,n,n,indx,ai(1,i))
  end do

end subroutine inv_c


subroutine inv_r(a,n,ai)
implicit none
  integer      :: n,i
  real*8       :: a(n,n),ai(n,n)
  integer      :: indx(n)
  real*8       :: d

  ai=0.d0
  do i=1,n
    ai(i,i)=1.d0
  end do
  call ludcmp_r(a,n,n,indx,d)
  do i=1,n
    call lubksb_r(a,n,n,indx,ai(1,i))
  end do

end subroutine inv_r

      SUBROUTINE indexx(n,arr,indx)
      INTEGER n,indx(n),M,NSTACK
      REAL*8 arr(n)
      PARAMETER (M=7,NSTACK=50)
      INTEGER i,indxt,ir,itemp,j,jstack,k,l,istack(NSTACK)
      REAL*8 a
      do 11 j=1,n
        indx(j)=j
11    continue
      jstack=0
      l=1
      ir=n
1     if(ir-l.lt.M)then
        do 13 j=l+1,ir
          indxt=indx(j)
          a=arr(indxt)
          do 12 i=j-1,1,-1
            if(arr(indx(i)).le.a)goto 2
            indx(i+1)=indx(i)
12        continue
          i=0
2         indx(i+1)=indxt
13      continue
        if(jstack.eq.0)return
        ir=istack(jstack)
        l=istack(jstack-1)
        jstack=jstack-2
      else
        k=(l+ir)/2
        itemp=indx(k)
        indx(k)=indx(l+1)
        indx(l+1)=itemp
        if(arr(indx(l+1)).gt.arr(indx(ir)))then
          itemp=indx(l+1)
          indx(l+1)=indx(ir)
          indx(ir)=itemp
        endif
        if(arr(indx(l)).gt.arr(indx(ir)))then
          itemp=indx(l)
          indx(l)=indx(ir)
          indx(ir)=itemp
        endif
        if(arr(indx(l+1)).gt.arr(indx(l)))then
          itemp=indx(l+1)
          indx(l+1)=indx(l)
          indx(l)=itemp
        endif
        i=l+1
        j=ir
        indxt=indx(l)
        a=arr(indxt)
3       continue
          i=i+1
        if(arr(indx(i)).lt.a)goto 3
4       continue
          j=j-1
        if(arr(indx(j)).gt.a)goto 4
        if(j.lt.i)goto 5
        itemp=indx(i)
        indx(i)=indx(j)
        indx(j)=itemp
        goto 3
5       indx(l)=indx(j)
        indx(j)=indxt
        jstack=jstack+2
        if(jstack.gt.NSTACK)pause 'NSTACK too small in indexx'
        if(ir-i+1.ge.j-l)then
          istack(jstack)=ir
          istack(jstack-1)=i
          ir=j-1
        else
          istack(jstack)=j-1
          istack(jstack-1)=l
          l=i
        endif
      endif
      goto 1
      END subroutine indexx

subroutine per_cos_fit(N,grid1,grid2,grid3,V,L,func,N_new,grid1_new,grid2_new,grid3_new,func_new)
! func(x,y,z)  where x,y,z are grid points stored in grid
! is fitted with per_cos functions in a box of dimension L(1)xL(2)x(3)
! the function func is then represented on a new grid
  implicit none
  integer                       :: N(3),N_new(3)
  double precision              :: L(3),V
  double precision              :: grid1(N(1)),grid2(N(2)),grid3(N(3)),func(N(1)*N(2)*N(3))
  double precision              :: grid1_new(N_new(1)),grid2_new(N_new(2)),grid3_new(N_new(3))
  double precision              :: func_new(N_new(1)*N_new(2)*N_new(3))
  double precision,allocatable  :: bf1(:,:),bf2(:,:),bf3(:,:),cb(:)
  integer                       :: i,j,K(3),i1,i2,i3,j1,j2,j3
  double precision              :: x,V_new

  do i=1,3
    if((-1)**N(i)>0) then
      k(i)=N(i)+1
    else
      k(i)=N(i)
    endif
  end do
  allocate(bf1(N(1),K(1)),bf2(N(2),K(2)),bf3(N(3),K(3)),cb(K(1)*K(2)*K(3)))
  cb=0.d0
  do j=-(K(1)-1)/2,(K(1)-1)/2
    do i=1,N(1)
      bf1(i,(K(1)-1)/2+1+j)=per_cos(grid1(i),j,K(1),-0.5d0*L(1),0.5d0*L(1),0)
    end do
  end do
  do j=-(K(2)-1)/2,(K(2)-1)/2
    do i=1,N(2)
      bf2(i,(K(2)-1)/2+1+j)=per_cos(grid2(i),j,K(2),-0.5d0*L(2),0.5d0*L(2),0)
    end do
  end do
  do j=-(K(3)-1)/2,(K(3)-1)/2
    do i=1,N(3)
      bf3(i,(K(3)-1)/2+1+j)=per_cos(grid3(i),j,K(3),-0.5d0*L(3),0.5d0*L(3),0)
    end do
  end do

  j=0
  do j1=1,K(1)
    do j2=1,K(2)
      do j3=1,K(3)
        j=j+1
        i=0
        do i1=1,N(1)
          do i2=1,N(2)
            do i3=1,N(3)
              i=i+1
              cb(j)=cb(j)+V*bf1(i1,j1)*bf2(i2,j2)*bf3(i3,j3)*func(i)
            end do
          end do
        end do
      end do
    end do
  end do
  deallocate(bf1,bf2,bf3)

  allocate(bf1(N_new(1),K(1)),bf2(N_new(2),K(2)),bf3(N_new(3),K(3)))

  do j=-(K(1)-1)/2,(K(1)-1)/2
    do i=1,N_new(1)
      x=grid1_new(i)
      bf1(i,(K(1)-1)/2+1+j)=per_cos(x,j,K(1),-0.5d0*L(1),0.5d0*L(1),0)
    end do
  end do
  do j=-(K(2)-1)/2,(K(2)-1)/2
    do i=1,N_new(2)
      x=grid2_new(i)
      bf2(i,(K(2)-1)/2+1+j)=per_cos(x,j,K(2),-0.5d0*L(2),0.5d0*L(2),0)
    end do
  end do
  do j=-(K(3)-1)/2,(K(3)-1)/2
    do i=1,N_new(3)
      x=grid3_new(i)
      bf3(i,(K(3)-1)/2+1+j)=per_cos(x,j,K(3),-0.5d0*L(3),0.5d0*L(3),0)
    end do
  end do

  V_new=K(1)*K(2)*K(3)/(L(1)*L(2)*L(3))
  func_new=0.d0
  j=0
  do j1=1,K(1)
    do j2=1,K(2)
      do j3=1,K(3)
        j=j+1
        i=0
        do i1=1,N_new(1)
          do i2=1,N_new(2)
            do i3=1,N_new(3)
              i=i+1
              func_new(i)=func_new(i)+bf1(i1,j1)*bf2(i2,j2)*bf3(i3,j3)*cb(j)*V_new
            end do
          end do
        end do
      end do
    end do
  end do



end subroutine per_cos_fit








function per_cos(x,j,N,a,b,id)
  implicit none
  real*8,parameter               :: Pi=3.141592653589793d0
  real*8                         :: per_cos,x,xj,su,pj,pm,L,a,b
  integer                        :: j,N,K,m,id

  K=(N-1)/2
  L=b-a
  su=0.d0
  xj=(a+b)/2.d0+j*L/dfloat(N)
  do m=1,N
  if(id.eq.0)  su=su+cos(2.d0*pi*(m-K-1)/L*(x-xj))
  if(id.eq.1)  su=su-sin(2.d0*pi*(m-K-1)/L*(x-xj))*(m-K-1)*2.d0*pi/L
  if(id.eq.2)  su=su-cos(2.d0*pi*(m-K-1)/L*(x-xj))*((m-K-1)*2.d0*pi/L)**2
  end do
  per_cos=su/dfloat(N)
end function per_cos



      END MODULE WORKPROCS



      function ran2(idum)

        implicit real*8(a-h,o-z)
        parameter (m=714025,ia=1366,ic=150889,rm=1.4005112d-6)
        common /com1 /iy,ir(97)
        data iff /0/
        if(idum.lt.0.or.iff.eq.0)then
          iff=1
          idum=mod(ic-idum,m)
          do 11 j=1,97
            idum=mod(ia*idum+ic,m)
            ir(j)=idum
            11      continue
            idum=mod(ia*idum+ic,m)
            iy=idum
          endif
          j=1+(97*iy)/m
          if(j.gt.97.or.j.lt.1)pause
          iy=ir(j)
          ran2=iy*rm
          idum=mod(ia*idum+ic,m)
          ir(j)=idum
          return
        end function ran2

SUBROUTINE inv_complex(A,N,AI)
  integer                :: N,retval,lwork
  integer,allocatable    :: ipiv(:)
  complex*16             :: A(N,N),AI(N,N),temp(1)
  complex*16,allocatable :: work(:)

  AI=A
  allocate(ipiv(N))
  call zgetrf(N,N,AI,N,ipiv,retval)
  call zgetri(N,AI,N,ipiv,temp,-1,retval)
  lwork=int(temp(1))
  allocate(work(lwork))
  call zgetri(N,AI,N,ipiv,work,lwork,retval)
  deallocate(ipiv,work)
  END SUBROUTINE inv_complex




subroutine calc_ylm(x,y,z,rr,l,ylm)
!
!  spherical harmonics and d/dx,d/dy,d/dz derivatives of
!  ylm(0,:) spherical harmonics
!  ylm(1,:) d/dx ylm
!  ylm(2,:) d/dy ylm
!  ylm(3,:) d/dz ylm
!  note the result has to be multiplied with sqrt((2*l+1)/(4*pi))/r^l
!  only implemented up to l=3
  implicit none
  double precision :: x,y,z,rr
  double precision :: ylm(0:3,7)
  integer          :: l
  double precision :: r_i, xy, xz, yz, x2, y2, z2, xyz, r2
  double precision :: c1, c2, c3, c4, c5, c6
  
  r_i = 1.d0/rr
  c1 = sqrt(3.d0/8.d0)
  c2 = sqrt(15.d0/4.d0)
  c3 = sqrt(15.d0)
  c4 = sqrt(5.d0/8.d0)
  c5 = sqrt(3.d0)
!
!     l = 0 s orbital
!
if (l .eq. 0) then
  ylm=0.d0
  ylm(0,1)=1.d0
!
!     l = 1 p orbital
!
else if (l .eq. 1) then

!     --- px, py, pz orbitals
  ylm(0,1) = y
  ylm(0,2) = z
  ylm(0,3) = x

!     --- derivatives of px,py,pz
  xy = -r_i*x*y
  xz = -r_i*x*z
  yz = -r_i*y*z

  ylm(1,3)=r_i*(1.d0-x*x) 
  ylm(2,3)=xy
  ylm(3,3)=xz 
  ylm(1,1)=xy
  ylm(2,1)=r_i*(1.d0-y*y)
  ylm(3,1)=yz 
  ylm(1,2)=xz
  ylm(2,2)=yz
  ylm(3,2)=r_i*(1.d0-z*z)
!
!     l = 2  d orbital
!                        
else if (l .eq. 2) then
  x2 = x*x
  y2 = y*y
  z2 = z*z
  xyz = -2.d0*c5*r_i*x*y*z

!     five d orbitals -- dxy, dyz, dxz, dz2, dx2-y2 
  ylm(0,1) = c5*x*y
  ylm(0,2) = c5*y*z
  ylm(0,4) = c5*z*x
!  ylm(0,3) = 1.5d0*z2-0.5d0
  ylm(0,3) = (2*z*z-x*x-y*y)/2.d0

  ylm(0,5) = c5*(x2-y2)*0.5d0

!     derivatives of the five d orbitals -- dxy, dyz, dxz, dz2, dx2-y2 
  ylm(1,1) = c5*r_i*y*(1.d0-2.d0*x2) 
  ylm(2,1) = c5*r_i*x*(1.d0-2.d0*y2) 
  ylm(3,1) = xyz

  ylm(1,2) = xyz
  ylm(2,2) = c5*r_i*z*(1.d0-2.d0*y2) 
  ylm(3,2) = c5*r_i*y*(1.d0-2.d0*z2) 

  ylm(1,4) = c5*r_i*z*(1.d0-2.d0*x2) 
  ylm(2,4) = xyz
  ylm(3,4) = c5*r_i*x*(1.d0-2.d0*z2) 

  ylm(1,3) = -3.d0*r_i*x*z2 
  ylm(2,3) = -3.d0*r_i*y*z2 
  ylm(3,3) =  3.d0*r_i*z*(1.d0-z2) 

  ylm(1,5) = c5*r_i*x*(1.d0-x2+y2) 
  ylm(2,5) = -c5*r_i*y*(1.d0+x2-y2) 
  ylm(3,5) = -c5*r_i*z*(x2-y2) 

!
!     l = 3  f orbital
!
else if (l .eq. 3) then
  c6 = 3.d0*r_i
  x2 = x*x
  y2 = y*y
  z2 = z*z
  r2 = rr*rr
  xy = r_i*x*y
  xz = r_i*x*z
  yz = r_i*y*z

!     seven f orbitals -- fz(5z^2-3r^2),fx(5z^2-r^2),fy(5z^2-r^2),
!     fz(x^2-y^2),fxyz,fx(x^2-3y^2),fy(y^2-3x^2)
  ylm(0,1) = c4*y*(y2-3.d0*x2)
  ylm(0,2) = c3*x*y*z
  ylm(0,3) = c1*y*(4.d0*z2-x2-y2)
  ylm(0,4) = 0.5d0*z*(2.d0*z2-3.d0*x2-3.d0*y2)
  ylm(0,5) = c1*x*(4.d0*z2-x2-y2)
  ylm(0,6) = c2*z*(x2-y2)
  ylm(0,7) = c4*x*(x2-3.d0*y2)

  ylm(1,4) = 0.5d0*3.d0*xz*(1.d0-5.d0*z2)
  ylm(2,4) = 0.5d0*3.d0*yz*(1.d0-5.d0*z2)
  ylm(3,4) = 0.5d0*c6*(z2-1.d0)*(1.d0-5.d0*z2) 

  ylm(1,5) = c1*r_i*(5.d0*z2-1.d0+x2*(1.d0-15.d0*z2))
  ylm(2,5) = c1*xy*(1.d0-15.d0*z2)
  ylm(3,5) = c1*xz*(11.d0-15.d0*z2)

  ylm(1,3) = c1*xy*(1.d0-15.d0*z2)
  ylm(2,3) = c1*r_i*(5.d0*z2-1.d0+y2*(1.d0-15.d0*z2))
  ylm(3,3) = c1*yz*(11.d0-15.d0*z2)

  ylm(1,6) = c2*xz*(2.d0-3.d0*(x2-y2))
  ylm(2,6) = -c2*yz*(2.d0+3.d0*(x2-y2))
  ylm(3,6) = c2*r_i*(1.d0-3.d0*z2)*(x2-y2)

  ylm(1,2) = c3*yz*(1.d0-3.d0*x2)
  ylm(2,2) = c3*xz*(1.d0-3.d0*y2)
  ylm(3,2) = c3*xy*(1.d0-3.d0*z2)

  ylm(1,7) = c4*c6*(x2-y2-x2*(x2-3.d0*y2))
  ylm(2,7) = c4*3.d0*xy*(3.d0*y2-x2-2.d0)
  ylm(3,7) = c4*3.d0*xz*(3.d0*y2-x2)

  ylm(1,1) = c4*3.d0*xy*(3.d0*x2-y2-2.d0)
  ylm(2,1) = c4*c6*(y2-x2-y2*(y2-3.d0*x2))
  ylm(3,1) = c4*3.d0*yz*(3.d0*x2-y2)
endif
end subroutine calc_ylm








