module libxc_stuff
  use, intrinsic :: iso_c_binding
  use xc_f03_lib_m
  USE MOD_GLOBAL 

  implicit none

  type(xc_f03_func_t) :: libxc_p_ex, libxc_p_cor
  integer :: xc_family_type1=0,xc_family_type2=0
  integer, parameter :: XC_FLAGS_EXC = 1
  logical :: libxc_func_has_Exc
  
CONTAINS

!===================================================================
subroutine gen_exc_cor_libxc
  ! libxc_p_ex, libxc_p_cor  from MOD_GLOBAL.
  real*8, parameter :: DoubleRy=2.d0*Ry
  double precision :: dens_AU(N_lattice_points)
  double precision :: sigma(N_lattice_points)
  real*8            :: grid_volume_AU,grid_step_AU(3)
  double precision :: grad_dens(3,N_lattice_points),vsig_grad_dens(3,N_lattice_points)
  double precision,dimension(N_lattice_points) :: exc_x, vrho_x, vsigma_x
  double precision,dimension(N_lattice_points) :: exc_c, vrho_c, vsigma_c
  double precision,dimension(N_lattice_points) :: v_sig_tot,v_sig_div
  logical :: is_gga
  integer :: np_c

  np_c = N_lattice_points
  
  grid_step_AU = grid_step / a_B
  grid_volume_AU = grid_volume / (a_B**3)
  dens_AU = density * a_B**3
  
  is_gga = (xc_family_type1 == 2 .or. xc_family_type2 == 2)
  
  if (is_gga) then
      call gradient_real(dens_AU, grad_dens, grid_step_AU)
      sigma(:) = grad_dens(1,:)**2 + grad_dens(2,:)**2 + grad_dens(3,:)**2
  end if
  
  vrho_x = 0.0; vrho_c = 0.0; vsigma_x = 0.0; vsigma_c = 0.0
  exc_x = 0.0; exc_c = 0.0
  
  if(libxc_func_has_Exc) then
    if (xc_family_type1==1) call xc_f03_lda_exc_vxc(libxc_p_ex, np_c, dens_AU, exc_x, vrho_x)
    if (xc_family_type1==2) call xc_f03_gga_exc_vxc(libxc_p_ex, np_c, dens_AU, sigma, exc_x, vrho_x, vsigma_x)
    if (xc_family_type2==1) call xc_f03_lda_exc_vxc(libxc_p_cor, np_c, dens_AU, exc_c, vrho_c)
    if (xc_family_type2==2) call xc_f03_gga_exc_vxc(libxc_p_cor, np_c, dens_AU, sigma, exc_c, vrho_c, vsigma_c)
  else ! libxc_func_has_Exc=false. No Exc
    if (xc_family_type1==1) call xc_f03_lda_vxc(libxc_p_ex, np_c, dens_AU, vrho_x)
    if (xc_family_type1==2) call xc_f03_gga_vxc(libxc_p_ex, np_c, dens_AU, sigma, vrho_x, vsigma_x)
    if (xc_family_type2==1) call xc_f03_lda_vxc(libxc_p_cor, np_c, dens_AU, vrho_c)
    if (xc_family_type2==2) call xc_f03_gga_vxc(libxc_p_cor, np_c, dens_AU, sigma, vrho_c, vsigma_c)
  end if  
  
  if(is_gga) then
  
    v_sig_tot = vsigma_x + vsigma_c
    vsig_grad_dens(1,:) = grad_dens(1,:) * v_sig_tot(:)
    vsig_grad_dens(2,:) = grad_dens(2,:) * v_sig_tot(:)
    vsig_grad_dens(3,:) = grad_dens(3,:) * v_sig_tot(:)
    call divergence_real(vsig_grad_dens, v_sig_div, grid_step_AU)
  
    V_Exchange = (vrho_x + vrho_c) - 2.0d0 * v_sig_div

  else 
  
    V_Exchange = (vrho_x + vrho_c)
	
  end if
  
  if(libxc_func_has_Exc) then
    E_exchange = SUM(dens_AU * (exc_x + exc_c - V_Exchange)) * grid_volume_AU
	E_exchange = E_exchange * DoubleRy
  else
    E_exchange=0.d0
  end if
  
  V_Exchange = V_Exchange * DoubleRy
  
end subroutine gen_exc_cor_libxc

!===================================================================
subroutine init_xc
  ! libxc_p_ex, libxc_p_cor from MOD_GLOBAL.
  integer(c_int) :: func_id_c, spin_state_c
  integer        :: family1,family2,kind1,kind2
  logical        :: has_Exc1,has_Exc2=.FALSE.

  family1=0; kind1=0; has_Exc1=.FALSE.
  family2=0; kind2=0; has_Exc2=.FALSE.
  
  if(spin_polarized) then
    write(log_file,*) " spin_polarized not available with libxc yet"
    stop
  end if
  write(log_file,*) "******************************** "
  write(log_file,*) "Initializing Libxc functionals..."
  write(log_file,*) " See: https://libxc.gitlab.io/functionals/ "
  family1=0; family2=2; kind1=0; kind2=0
  
  func_id_c = xc_lib_ex_num
  spin_state_c = XC_UNPOLARIZED
  call xc_f03_func_init(libxc_p_ex, func_id_c, spin_state_c)
  write(log_file,*) "Exchange part:"
  call print_libxc_info(libxc_p_ex,family1,kind1,has_Exc1) 
  
  if(xc_lib_cor_num>0) then
    func_id_c = xc_lib_cor_num
    call xc_f03_func_init(libxc_p_cor, func_id_c, spin_state_c)
    write(log_file,*) "Correlation part:"
    call print_libxc_info(libxc_p_cor,family2,kind2,has_Exc2) 
  end if
  write(log_file,*) "******************************** "
  
  if(kind1<1) then
    write(log_file,*) "Unrecognized functional options for xc_lib_ex_num"
    stop
  end if
  
  if(family1<1 .OR. family1>2) then
    write(log_file,*) "only LDA or GGA functionals allowed"
	stop
  end if
  
  if(kind1 /=1 .AND. kind1/=3) then
      write(log_file,*) "xc_lib_ex_num must be an exchange or exchange-correlation functional"
	  write(log_file,*) "kind =",kind1
  	  stop
  end if
  
  if(kind1==3) then ! ex_functional is an exchange-correlation functional so don't worry about correlation part
  
    ! check that a correlation functional was not specified by the user in error
	
	if(family2>0) then
      write(log_file,*) "xc_lib_ex_num is an exchange-correlation functional"
	  write(log_file,*) "xc_lib_cor_num should not be used or set to 0 ?????"
  	  stop
	end if
	xc_family_type2=0
	
  else ! exchange functional and correlation functional specified. make sure corr func is good.
    if(family2<1 .OR. family2>2) then
      write(log_file,*) "only LDA or GGA functionals allowed"
  	  stop
    end if
	
    if(kind2 /=2 ) then
      write(log_file,*) "xc_lib_cor_num must be a correlation functional"
	  write(log_file,*) "kind =",kind2
  	  stop
    end if
	

  
  end if
  
  xc_family_type1=family1
  xc_family_type2=family2
  
  if (kind1 == 3) then ! Combined XC functional
    libxc_func_has_Exc = has_Exc1
  else ! Separate X and C functionals
    libxc_func_has_Exc = (has_Exc1 .AND. has_Exc2)
  end if
  
  if(libxc_func_has_Exc) then
    write(log_file,*) "E_exchange will be calculated"
  else
    write(log_file,*) "E_exchange will NOT be calculated"
  end if
  
  if(kind2<1) then
    if(kind1==3) then ! kind1 is an exchange-correlation functional
	  write(log_file,*) "Using combined exchange-correlation functional"
	else
      write(log_file,*) "if xc_lib_cor_num=0 then xc_lib_ex_num must be an exchange-correlation functional"
	  stop
	end if
	
  end if
  
end subroutine init_xc

!===================================================================
subroutine print_libxc_info(xc_func,family_type,kind_ID,has_Exc)
  
  ! Arguments
  integer,intent(out) :: family_type,kind_ID
  type(xc_f03_func_t), intent(in) :: xc_func
  logical,intent(out) :: has_Exc

  ! Local Variables
  type(xc_f03_func_info_t) :: xc_info
  !type(xc_f03_reference_t), allocatable :: references(:)
  character(len=256), allocatable :: doi_string
  character(len=120) :: kind, family
  integer :: i_ref,flags

  xc_info = xc_f03_func_get_info(xc_func)

  select case(xc_f03_func_info_get_kind(xc_info))
    case (XC_EXCHANGE); write(kind, '(a)') 'an exchange functional'                          ; kind_ID = 1
    case (XC_CORRELATION); write(kind, '(a)') 'a correlation functional'                     ; kind_ID = 2
    case (XC_EXCHANGE_CORRELATION); write(kind, '(a)') 'an exchange-correlation functional'  ; kind_ID = 3
    case (XC_KINETIC); write(kind, '(a)') 'a kinetic energy functional'                      ; kind_ID = 4
    case default; write(kind, '(a)') 'of unknown kind'                                       ; kind_ID = 0
  end select
  
  select case (xc_f03_func_info_get_family(xc_info))
    case (XC_FAMILY_LDA); write(family,'(a)') "LDA" ; family_type=1
    case (XC_FAMILY_GGA); write(family,'(a)') "GGA" ; family_type=2
    case (XC_FAMILY_HYB_GGA); write(family,'(a)') "Hybrid GGA"  ; family_type=12
    case (XC_FAMILY_MGGA); write(family,'(a)') "Meta-GGA"  ; family_type=3
    case (XC_FAMILY_HYB_MGGA); write(family,'(a)') "Hybrid Meta-GGA"  ; family_type=13
    case default; write(family,'(a)') "unknown"  ; family_type=0
  end select
  

  write(log_file,'("  Functional ID ", i0, " (''", a, "'') is ", a, ", family: ''", a, "''")') &
    xc_f03_func_info_get_number(xc_info), trim(xc_f03_func_info_get_name(xc_info)), &
    trim(kind), trim(family)
    
  !references = xc_f03_func_info_references(xc_info)
  !do i_ref = 1, size(references)
  !    ! CORRECTED: xc_f03_reference_doi is a SUBROUTINE, not a function
  !    call xc_f03_reference_doi(references(i_ref), doi_string)
  !    write(*,'("   Ref: ",a)') trim(doi_string)
  !end do
  
  flags = xc_f03_func_info_get_flags(xc_info)

  if ((iand(flags, XC_FLAGS_EXC) /= 0)) then
      write(log_file,*) "This functional supports Exc"
  	  has_Exc=.TRUE.
  else
      write(log_file,*) "This functional does NOT support Exc"
  	  has_Exc=.FALSE.
  end if

end subroutine print_libxc_info

END MODULE libxc_stuff