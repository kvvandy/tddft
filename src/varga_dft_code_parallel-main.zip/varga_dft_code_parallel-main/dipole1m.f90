PROGRAM dipole_moment1

! 1D version

! using generalized yabana damping function
! #include "dft_common_uses.h"
! USE dftwork_info,         ONLY : print_license

IMPLICIT NONE

  REAL*8, DIMENSION(:),ALLOCATABLE ::Dp1
  real*8,allocatable  :: alpha_R(:),alpha_I(:)
  integer              :: N_time,N_energy
  real*8               :: dE,dt,x,S,t,tt,hw,f
  REAL			:: df ! generalized damping function
  integer              :: i,k,n,m, ierr,tmp
  complex*16           :: zalpha,zi
  COMPLEX*16	       :: zalpha1

  real(8),parameter    :: E2=14.4d0, H2M=3.81d0, a_B=0.529177d0
  real(8),parameter    :: Ry=13.6058d0, Pi=3.141592653589793d0
  REAL, PARAMETER      :: hbar=0.658211899d0, plank=4.135667E-15 !eV*sec
  REAL,  PARAMETER      :: timescale=1.0E-15 ! femto
  REAL, PARAMETER :: a=0.0
  INTEGER, PARAMETER   :: No=3 !must be odd integer>1, controls order of df expansion

! TYPE(dft_error_type)                  :: error 

  zi=(0.d0,1.d0)
  dE=0.01d0

  N_energy=3000
  allocate(alpha_r(0:N_energy),alpha_i(0:N_energy),STAT=ierr)
  IF (ierr /= 0) PRINT*, "alphas : Allocation failed"

  PRINT*, "Ready to open dp_x.dat"
  open(1,file='dp_x.dat')       ! Input file
  PRINT*, "opened dp_x.dat file....."
  !  read(1,*)
    read(1,*) N_time, dt, f    ! numb of time points, dt, perturbation constant
    print*,'N_time=',N_time,'dt=',dt,'f=',f
    allocate(Dp1(0:N_time),STAT=ierr)
    IF (ierr /= 0) PRINT*, "Dp1 : Allocation failed"

    Dp1=0.d0 !initialize Dp3

  PRINT*, "sizeof Dp1 is: ", SHAPE(Dp1)
  DO i=1,N_time   
    READ(1,*)x,Dp1(i),tmp
!    READ(1,FMT=10)x,Dp1(i)
!      PRINT*,x,Dp1(i)
  END DO

!10  FORMAT(2(F13.7,2X))
!100  FORMAT(3(F13.7,2X))

  PRINT*, "Read and allocated Dp1"
  close(1)

! Fourier Transform

!dt=0.00167892031
 dt=dt/hbar

      TT = dt*N_time  ! total time interval
      print*, 'TT', TT
  PRINT*, "Starting fourier integral"

!$OMP PARALLEL
!$OMP DO
      do m=0,N_energy
         hw=m*dE ; zalpha=(0.d0,0.d0); zalpha1=zalpha;
         do n=1,N_time
            t=n*dt ; df=0.0
           DO k=2, No
             df=df+((-1)**(k+1))*(k+(-1)**k)*(t/TT)**k
           END DO
           df=df*(2/(No-1))+1.0
		zalpha1=zalpha1+exp(zi*hw*t)*(Dp1(n)-a)*df
         end do
         zalpha=(1.d0)*(zalpha1)*E2/F*dt  !no longer Averaging complex polarizability
         alpha_R(m)=real(zalpha,8)    ! Real part
         alpha_I(m)=imag(zalpha)      ! Imaginary part
      end do
!$OMP END DO
!$OMP END PARALLEL

!  PRINT*, "Opening alpha files"  
! Alpha
      OPEN(1,file='alpha1r.dat')
      OPEN(2,file='alpha1i.dat')
  PRINT*, "Computing linear response function"
        do n=0,N_energy
           S=2*n*dE/(Pi*a_B*E2**2)*alpha_I(n)
            write(1,*) n*dE, alpha_R(n)
            WRITE(2,*) n*dE, S !absorption cross-section
         end do
  PRINT*,"Energy resolution (delta)E=",plank/(2*Pi*TT*timescale)
  PRINT*, "Spectral response is written to alha1r.dat and alpha1i.dat"
      close(1)
      close(2)
  PRINT*, "Program dipole has finished normally"
END PROGRAM
