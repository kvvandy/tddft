Module mask_volkov
  USE MOD_GLOBAL
  USE PSEUDOPOTENTIAL
  USE TAYLOR_EXTENDED
implicit none

include 'fftw3.f'

  integer*8              :: volkov_N_points=0
  integer                :: N_Volk(3)
  real*8                 :: R_A(3),R_C(3),maskinit(3),fftfactor
  integer                :: td_density_counter_volkov
  integer*8              :: plan_volkov_Forward,plan_volkov_Backward
  integer,parameter      :: dirnF_FFT=FFTW_FORWARD
  integer,parameter      :: dirnR_FFT=FFTW_BACKWARD
  !complex*16             :: taylor_coeff(N_taylor)
  ! vector potential
  real*8                 :: A_vec(3),A_vec_int(3),A_vec_2_int(3),DeltaA(3)
  real*8                 :: A_vec_int_prev(3),A_vec_2_int_prev(3),DeltaA2(3)
  real*8                 :: vtimestep  
  
  ! arrays of size volkov_N_points
  real*4,allocatable     :: volkov_grid_point(:,:)
  real*4,allocatable     :: volkov_k_vec(:,:)
  real*4,allocatable     :: sing_prec_rearranged_dvolkov(:)
  complex*16,allocatable :: Psi_volkov(:,:,:,:)
  complex*16,allocatable :: Phi_Volkov(:,:,:),Phi_Volkov2(:,:,:)
  integer,allocatable    :: Lattice_V(:,:)
  integer,allocatable    :: bw_volkov_mapping(:,:,:)
  
  ! arrays of size less than volkov_N_points
  real*8,allocatable     :: volkov_grid_x(:),volkov_grid_y(:),volkov_grid_z(:)
  real*8,allocatable     :: volkov_k_x(:),volkov_k_y(:),volkov_k_z(:)

  !  CAP like absorbing of WF
  real*8,allocatable     :: volkov_abs_x(:),volkov_abs_y(:),volkov_abs_z(:)

  
! arrays of size N_lattice_points
  real*8,allocatable       :: mask(:)
  integer,allocatable      :: fd_volkov_mapping3(:,:)
  integer*8,allocatable    :: fd_volkov_mapping(:)
  
  real*8,parameter         :: convertT2AU=1.d0/0.02418884326505
  real*8,parameter         :: convertL2AU=1.d0/0.52917721092
  
  contains

!    BAD  BAD
! subroutine get_xaxis(xaxis,newaxis,npts)
!implicit none
!integer          :: npts,i
!real*8           :: xaxis(npts),newaxis(npts)
!real*8           :: pa1,pa2,pa3,x
!
!  pa1=xaxis(1)
!  pa2=xaxis(npts)
!
!  write(log_file,*) 'Assign axis ',pa1,pa2,pa2-pa1
!  if(mod(npts,2)) then
!     do i=0,npts-1
!       if(i.le.npts/2) then
!         x=2.d0*3.14159265359*i/(pa2-pa1)
!       else
!         x=2.d0*3.14159265359*(i-npts)/(pa2-pa1)
!       endif
!       newaxis(i+1)=x
!     end do
!  else
!     do i=0,npts-1
!       if(i.lt.npts/2) then
!         x=2.d0*3.14159265359*i/(pa2-pa1)
!       else
!         x=2.d0*3.14159265359*(i-npts)/(pa2-pa1)
!       endif
!       newaxis(i+1)=x
!     end do  
!  end if
!  
!end subroutine get_xaxis

subroutine get_xaxis(xaxis,newaxis,npts,gridspace)
implicit none
integer          :: npts,i
real*8           :: xaxis(npts),newaxis(npts)
real*8           :: pa1,pa2,pa3,x,boxs,gridspace

  newaxis=0.d0
  
  pa1=xaxis(1)
  pa2=xaxis(npts)
  write(log_file,*) 'Assign axis ',pa1," to ",pa2
  boxs=npts*gridspace
  !write(*,*) 'total period',pa2-pa1
!  if(mod(npts,2)) then
!     do i=0,npts-1
!       if(i.le.npts/2) then
!         x=2.d0*3.14159265359*i/boxs!(pa2-pa1)
!       else
!         x=2.d0*3.14159265359*(i-npts)/boxs!(pa2-pa1)
!       endif
!       newaxis(i+1)=x
!     end do
!  else
     do i=0,npts-1
       if(i.lt.npts/2) then
         x=2.d0*3.14159265358979323846264338d0*i/boxs!(pa2-pa1)

       else
         x=2.d0*3.14159265358979323846264338d0*(i-npts)/boxs!(pa2-pa1)

       endif
       newaxis(i+1)=x
     end do  
!  end if
end subroutine get_xaxis
  

SUBROUTINE init_Volkov

  call init_Mask_Volkov_latt
  call init_Volkov_mask
  
  call dfftw_plan_dft_3d(plan_volkov_Forward ,N_Volk(1),N_Volk(2),N_Volk(3),Phi_Volkov,Phi_Volkov,dirnF_FFT,FFTW_ESTIMATE)
  call dfftw_plan_dft_3d(plan_volkov_Backward,N_Volk(1),N_Volk(2),N_Volk(3),Phi_Volkov,Phi_Volkov,dirnR_FFT,FFTW_ESTIMATE)
   
  DeltaA=0.d0
  DeltaA2=0.d0
  A_vec=0.d0
  A_vec_int=0.d0
  A_vec_2_int=0.d0
  vtimestep=mask_func_freq
  vtimestep=time_step*vtimestep
  A_vec_int_prev=0.d0
  A_vec_2_int_prev=0.d0
  fftfactor=1.d0/volkov_N_points
  td_density_counter_volkov=0

   open(3301,file="volkov_dp_x.dat",status="replace")
   open(3302,file="volkov_dp_y.dat",status="replace")
   open(3303,file="volkov_dp_z.dat",status="replace")
   write(3301,*) '# DPMx:Time   DPM_all    DPM_individual_orbitals...'
   write(3302,*) '# DPMy:Time   DPM_all    DPM_individual_orbitals...'
   write(3303,*) '# DPMz:Time   DPM_all    DPM_individual_orbitals...'
END SUBROUTINE init_Volkov

subroutine clean_up_volkov
implicit none
  
  call dfftw_destroy_plan(plan_volkov_Forward)
  call dfftw_destroy_plan(plan_volkov_Backward)
  
  deallocate(volkov_grid_point)
  deallocate(fd_volkov_mapping,fd_volkov_mapping3)
  deallocate(Lattice_V,Psi_volkov,Phi_Volkov,Phi_Volkov2)
  deallocate(volkov_grid_x,volkov_grid_y,volkov_grid_z)
  deallocate(volkov_k_x,volkov_k_y,volkov_k_z)
  deallocate(sing_prec_rearranged_dvolkov)
  
   close(3301)
   close(3302)
   close(3303) 
  
end subroutine clean_up_volkov

  
SUBROUTINE init_Mask_Volkov_latt
implicit none
 integer     :: i,nvx,nvy,nvz,j,k,l,m,l1,l2,l3,fdlatt
 integer*8   :: idx
 real*8      :: rs_max_x,rs_max_y,rs_max_z,vcapbgn(3)
 real*8      :: vgridx,vgridy,vgridz,v1,vmemreq,v2,v3,fd_lat_max(3)

 ! initialize large grid
 ! make sure that large grid has points that coincide with regular grid.
 write(log_file,*) 'Initialize Mask function and Volkov Basis'
 write(log_file,*) 'volkov_distance1=',volkov_distance(1)
 write(log_file,*) 'volkov_distance2=',volkov_distance(2)
 write(log_file,*) 'volkov_distance3=',volkov_distance(3)
 write(log_file,*) 'volkov_mask_depth=',volkov_mask_depth
 
 vgridx=xgrid(1) ! X grid
 do i=1,999999 
   vgridx=vgridx-grid_step(1)
   if(abs(vgridx)> volkov_distance(1) ) then
     exit
   end if
 end do
 v1=vgridx
 do i=1,999999 
   if(v1>volkov_distance(1)) then
     nvx=i
	 exit
   end if
   v1=v1+grid_step(1)
 end do
 vgridy=ygrid(1) ! y grid
 do i=1,999999 
   vgridy=vgridy-grid_step(2)
   if(abs(vgridy)> volkov_distance(2) ) then
     exit
   end if
 end do
 v1=vgridy
 do i=1,999999 
   if(v1>volkov_distance(2)) then
     nvy=i
	 exit
   end if
   v1=v1+grid_step(2)
 end do
 vgridz=zgrid(1) ! Z grid points
 do i=1,999999 
   vgridz=vgridz-grid_step(3)
   if(abs(vgridz)> volkov_distance(3) ) then
     exit
   end if
 end do
 v1=vgridz
 do i=1,999999 
   if(v1>volkov_distance(3)) then
     nvz=i
	 exit
   end if
   v1=v1+grid_step(3)
 end do
 volkov_N_points=nvx*nvy*nvz
 write(log_file,*) 'volkov basis ',nvx,nvy,nvz
 write(log_file,*) ' a total of ',volkov_N_points,' points'
 !  using 2 phi orbitals for calculations
 vmemreq=volkov_N_points*16*(N_orbitals+2+0.5)/1000000
 write(log_file,*) '-- Wavefunction will require',vmemreq,' MB'
 vmemreq=volkov_N_points*4/1000000 
 write(log_file,*) '-- Density Files will require',vmemreq,' MB' 
 vmemreq=volkov_N_points*12*2/1000000 ! xyz and kvec 
 write(log_file,*) '-- grid coordinates will require',vmemreq,' MB' 
 
 N_Volk(1)=nvx
 N_Volk(2)=nvy
 N_Volk(3)=nvz
 
 allocate(volkov_grid_point(3,volkov_N_points))
 !allocate(volkov_k_vec(3,volkov_N_points))
 allocate(fd_volkov_mapping(N_lattice_points))
 allocate(fd_volkov_mapping3(3,N_lattice_points))
 allocate(bw_volkov_mapping(N_Volk(1),N_Volk(2),N_Volk(3)))
 
 allocate(Lattice_V(3,volkov_N_points))
 allocate(Psi_volkov(N_Volk(1),N_Volk(2),N_Volk(3),N_orbitals))
 allocate(Phi_volkov(N_Volk(1),N_Volk(2),N_Volk(3)))
 allocate(Phi_volkov2(N_Volk(1),N_Volk(2),N_Volk(3)))
 allocate(volkov_grid_x(N_Volk(1)),volkov_grid_y(N_Volk(2)),volkov_grid_z(N_Volk(3)))
 allocate(volkov_k_x(N_Volk(1)),volkov_k_y(N_Volk(2)),volkov_k_z(N_Volk(3)))
 allocate(volkov_abs_x(N_Volk(1)),volkov_abs_y(N_Volk(2)),volkov_abs_z(N_Volk(3)))
 allocate(sing_prec_rearranged_dvolkov(volkov_N_points))
 fd_lat_max(1)=abs(xgrid(1))
 fd_lat_max(2)=abs(ygrid(1))
 fd_lat_max(3)=abs(zgrid(1))
 fd_volkov_mapping=0
 fd_volkov_mapping3=0
 bw_volkov_mapping=0
 idx=0

 do i=1,N_Volk(1)
   volkov_grid_x(i)=vgridx+(grid_step(1)*(i-1))
 end do
 do i=1,N_Volk(2)
   volkov_grid_y(i)=vgridy+(grid_step(2)*(i-1))
 end do
 do i=1,N_Volk(3)
   volkov_grid_z(i)=vgridz+(grid_step(3)*(i-1))
 end do
 do i=1,N_Volk(1)
   v1=volkov_grid_x(i)
   do j=1,N_Volk(2)
     v2=volkov_grid_y(j)
	 do k=1,N_Volk(3)
	   v3=volkov_grid_z(k)
	   idx=idx+1
	   volkov_grid_point(1,idx)=v1
	   volkov_grid_point(2,idx)=v2
	   volkov_grid_point(3,idx)=v3
	   Lattice_V(1,idx)=i
	   Lattice_V(2,idx)=j
	   Lattice_V(3,idx)=k
	   
	   if(abs(v1)<fd_lat_max(1)+0.01d0) then
	     if(abs(v2)<fd_lat_max(2)+0.01d0) then
           if(abs(v3)<fd_lat_max(3)+0.01d0) then
             ! generate mapping 
			 m=0
!			 do l=1,N_lattice_points
!			   if(abs(v1-grid_point(1,l))<0.00001) then
!                 if(abs(v2-grid_point(2,l))<0.00001) then
!				   if(abs(v3-grid_point(3,l))<0.00001) then
!				     fd_volkov_mapping(l)=idx
!					 fd_volkov_mapping3(1,l)=i
!					 fd_volkov_mapping3(2,l)=j
!					 fd_volkov_mapping3(3,l)=k
!					 m=idx
!				   end if
!				 end if
!			   end if
!			 end do
             do l1=1,N_Lattice(1)
			   if(abs(v1-xgrid(l1))<0.00001) then
                 do l2=1,N_Lattice(2)
				   if(abs(v2-ygrid(l2))<0.00001) then
                     do l3=1,N_Lattice(3)
                       if(abs(v3-zgrid(l3))<0.00001) then
					     fdlatt=Lattice_inv_xyz(l1,l2,l3)
    				     fd_volkov_mapping(fdlatt)=idx
    					 fd_volkov_mapping3(1,fdlatt)=i
    					 fd_volkov_mapping3(2,fdlatt)=j
    					 fd_volkov_mapping3(3,fdlatt)=k
    					 m=idx
                         bw_volkov_mapping(i,j,k)=fdlatt						 
					   end if
			         end do    
                   end if					 
			     end do     
               end if			   
			 end do
			 if(m.eq.0) then
			   write(*,'(a,3f15.5)') 'bad mapping volkov point:',v1,v2,v3
			   write(log_file,'(a,3f15.5)') 'bad mapping volkov point:',v1,v2,v3
			   stop
			 end if			 
		   end if
		 end if
	   end if
	   
	 end do
   end do
   if(mod(i,50)==0) write(log_file,*) 'did Xpoint ',i,'/',nvx
 end do
 
 ! get k axis
  call get_xaxis(volkov_grid_x,volkov_k_x,N_Volk(1),grid_step(1))
  call get_xaxis(volkov_grid_y,volkov_k_y,N_Volk(2),grid_step(1))
  call get_xaxis(volkov_grid_z,volkov_k_z,N_Volk(3),grid_step(1))
  open(3323,file="volkov_grid_Angstroms.dat",status="replace")
  write(3323,*) 'X axis Volkov basis in real and k-space. Units Angstroms'
  do i=1,N_Volk(1)
    write(3323,'(i5,2f15.5)') i,volkov_grid_x(i),volkov_k_x(i)
  end do

  write(3323,*) 'Y axis Volkov basis in real and k-space,  Units Angstroms'
  do i=1,N_Volk(2)
    write(3323,'(i5,2f15.5)') i,volkov_grid_y(i),volkov_k_y(i)
  end do

  write(3323,*) 'Z axis Volkov basis in real and k-space,  Units Angstroms'
  do i=1,N_Volk(3)
    write(3323,'(i5,2f15.5)') i,volkov_grid_z(i),volkov_k_z(i)
  end do
  close(3323)

  write(*,*) 'Volkov X grid ',volkov_grid_x(1),volkov_grid_x(N_Volk(1))
  write(*,*) 'Volkov Y grid ',volkov_grid_y(1),volkov_grid_y(N_Volk(2))
  write(*,*) 'Volkov Z grid ',volkov_grid_z(1),volkov_grid_z(N_Volk(3))
  write(log_file,*) 'Volkov X grid ',volkov_grid_x(1),volkov_grid_x(N_Volk(1))
  write(log_file,*) 'Volkov Y grid ',volkov_grid_y(1),volkov_grid_y(N_Volk(2))
  write(log_file,*) 'Volkov Z grid ',volkov_grid_z(1),volkov_grid_z(N_Volk(3))  
  ! make array for absorbing the wave function
  volkov_abs_x=1.d0
  volkov_abs_y=1.d0
  volkov_abs_z=1.d0
  vcapbgn(1)=volkov_grid_x(N_Volk(1))-volkov_capdist_x
  vcapbgn(2)=volkov_grid_y(N_Volk(2))-volkov_capdist_y
  vcapbgn(3)=volkov_grid_z(N_Volk(3))-volkov_capdist_z
  write(812,*) '#X axis Volkov absorbing function'
  do i=1,N_Volk(1)
    if(volkov_grid_x(i)>vcapbgn(1)) then
      volkov_abs_x(i)=exp(-1*volkov_capparm*((volkov_grid_x(i)-vcapbgn(1))/(volkov_grid_x(N_Volk(1))-vcapbgn(1)))**2)
    else if(volkov_grid_x(i)<-vcapbgn(1)) then
	  volkov_abs_x(i)=exp(-1*volkov_capparm*((volkov_grid_x(i)+vcapbgn(1))/(volkov_grid_x(1)+vcapbgn(1)))**2)
	end if
	write(812,'(2es26.16)') volkov_grid_x(i),volkov_abs_x(i)
  end do  
  write(812,*) '#Y axis Volkov absorbing function'
  do i=1,N_Volk(2)
    if(volkov_grid_y(i)>vcapbgn(2)) then
      volkov_abs_y(i)=exp(-1*volkov_capparm*((volkov_grid_y(i)-vcapbgn(2))/(volkov_grid_y(N_Volk(2))-vcapbgn(2)))**2)
    else if(volkov_grid_y(i)<-vcapbgn(2)) then
	  volkov_abs_y(i)=exp(-1*volkov_capparm*((volkov_grid_y(i)+vcapbgn(2))/(volkov_grid_y(1)+vcapbgn(2)))**2)
	end if
	write(812,'(2es26.16)') volkov_grid_y(i),volkov_abs_y(i)
  end do    
  write(812,*) '#Z axis Volkov absorbing function'
  do i=1,N_Volk(3)
    if(volkov_grid_z(i)>vcapbgn(3)) then
      volkov_abs_z(i)=exp(-1*volkov_capparm*((volkov_grid_z(i)-vcapbgn(3))/(volkov_grid_z(N_Volk(3))-vcapbgn(3)))**2)
    else if(volkov_grid_z(i)<-vcapbgn(3)) then
	  volkov_abs_z(i)=exp(-1*volkov_capparm*((volkov_grid_z(i)+vcapbgn(3))/(volkov_grid_z(1)+vcapbgn(3)))**2)
	end if
	write(812,'(2es26.16)') volkov_grid_z(i),volkov_abs_z(i)
  end do     
  
  ! convert to AU
  volkov_grid_x=volkov_grid_x*convertL2AU
  volkov_grid_y=volkov_grid_y*convertL2AU
  volkov_grid_z=volkov_grid_z*convertL2AU
  call get_xaxis(volkov_grid_x,volkov_k_x,N_Volk(1),grid_step(1))
  call get_xaxis(volkov_grid_y,volkov_k_y,N_Volk(2),grid_step(1))
  call get_xaxis(volkov_grid_z,volkov_k_z,N_Volk(3),grid_step(1))
  open(3323,file="volkov_grid_Atomic.dat",status="replace")
  write(3323,*) 'X axis Volkov basis in real and k-space. ATOMIC UNITS'
  do i=1,N_Volk(1)
    write(3323,'(i5,2f15.5)') i,volkov_grid_x(i),volkov_k_x(i)
  end do

  write(3323,*) 'Y axis Volkov basis in real and k-space,  ATOMIC UNITS'
  do i=1,N_Volk(2)
    write(3323,'(i5,2f15.5)') i,volkov_grid_y(i),volkov_k_y(i)
  end do

  write(3323,*) 'Z axis Volkov basis in real and k-space,   ATOMIC UNITS'
  do i=1,N_Volk(3)
    write(3323,'(i5,2f15.5)') i,volkov_grid_z(i),volkov_k_z(i)
  end do  
  
  write(*,'(a,2f15.7)') 'Volkov X grid in Bohr ',volkov_grid_x(1),volkov_grid_x(N_Volk(1))
  write(*,'(a,2f15.7)') 'Volkov Y grid in Bohr ',volkov_grid_y(1),volkov_grid_y(N_Volk(2))
  write(*,'(a,2f15.7)') 'Volkov Z grid in Bohr ',volkov_grid_z(1),volkov_grid_z(N_Volk(3))
  close(3323)
  

end SUBROUTINE init_Mask_Volkov_latt

SUBROUTINE init_Volkov_split_op
implicit none
   integer  :: i,n,i1,i2,i3,k
   real*8   :: au_xgrid(N_Lattice(1)),au_ygrid(N_Lattice(2)),au_zgrid(N_Lattice(3))
  
  write(log_file,*) "allocate vso_kphi vso_rphi phi_c2"
  allocate(vso_kphi(N_Lattice(1),N_Lattice(2),N_Lattice(3)))
  allocate(vso_rphi(N_Lattice(1),N_Lattice(2),N_Lattice(3)))
  allocate(phi_c2(N_lattice_points))
  vso_rphi=0.d0
  vso_kphi=0.d0
  phi_c2=0.d0
  
  write(log_file,*) "setup fftw3 plans"
  
  call dfftw_plan_dft_3d(plan_volkov_Forward ,N_Lattice(1),N_Lattice(2),N_Lattice(3),phi_c,phi_c,dirnF_FFT,FFTW_ESTIMATE)
  call dfftw_plan_dft_3d(plan_volkov_Backward,N_Lattice(1),N_Lattice(2),N_Lattice(3),phi_c,phi_c,dirnR_FFT,FFTW_ESTIMATE) 
  
  A_vec=0.d0
  fftfactor=1.d0/dfloat(N_lattice_points)
  td_density_counter_volkov=0	
  au_xgrid=xgrid*convertL2AU
  au_ygrid=ygrid*convertL2AU
  au_zgrid=zgrid*convertL2AU
  allocate(volkov_k_x(N_Lattice(1)),volkov_k_y(N_Lattice(2)),volkov_k_z(N_Lattice(3)))
  ! get k axis
  !call get_xaxis(au_xgrid,volkov_k_x,N_Lattice(1),grid_step(1)*convertL2AU)
  !call get_xaxis(au_ygrid,volkov_k_y,N_Lattice(2),grid_step(2)*convertL2AU)
  !call get_xaxis(au_zgrid,volkov_k_z,N_Lattice(3),grid_step(3)*convertL2AU) 
  call get_xaxis(xgrid,volkov_k_x,N_Lattice(1),grid_step(1))
  call get_xaxis(ygrid,volkov_k_y,N_Lattice(2),grid_step(2))
  call get_xaxis(zgrid,volkov_k_z,N_Lattice(3),grid_step(3))
  write(log_file,*) "get fft axis for x y z grids of size"
  write(log_file,*) N_Lattice(1),N_Lattice(2),N_Lattice(3)
  
  if(propagator=="split_v_krk") then ! need vso_kpsi
      write(log_file,*) " allocate vso_kpsi"
	  allocate(vso_kpsi(N_Lattice(1),N_Lattice(2),N_Lattice(3),N_orbitals))
      vso_kpsi=0.d0
      do n=1,N_orbitals
    	do i3=1,N_Lattice(3)
    	  do i2=1,N_Lattice(2)
    	    do i1=1,N_Lattice(1)
              i=Lattice_inv_xyz(i1,i2,i3)
        	  if(i<1 .OR. i>N_Lattice_points ) then
        	    write(*,*) "lattice value <1 or >N_Lattice_points ",i,i1,i2,i3
        		stop
        	  end if
              vso_rphi(i1,i2,i3)=Psi_c(i,n)
    	    end do
    	  end do 
    	end do
		write(55500000+n*10000+0,'(2es30.16e3)')  Psi_c(:,n)
    	write(log_file,*) "mapped orbital ",n," for FFT, norm=",sum(real(conjg(vso_rphi)*vso_rphi))*grid_volume
    	call dfftw_execute_dft(plan_volkov_Forward,vso_rphi,vso_kphi)
    	vso_kphi=vso_kphi*sqrt(fftfactor)
    	vso_kpsi(:,:,:,n)=vso_kphi(:,:,:)
      end do
  end if
  

  
end SUBROUTINE init_Volkov_split_op

subroutine volkov_split_timestep_krk(iter)
implicit none
  integer   :: i,n,i1,i2,i3,iter,maxele
  complex*16 :: term1,phase2,potxyz
  complex*16 :: allpotentials
  real*8     :: maxv1
  
  write(log_file,*) A_vec
  
  !   debug
!      do n=1,N_orbitals
!    	do i3=1,N_Lattice(3)
!    	  do i2=1,N_Lattice(2)
!    	    do i1=1,N_Lattice(1)
!              i=Lattice_inv_xyz(i1,i2,i3)
!        	  if(i<1 .OR. i>N_Lattice_points ) then
!        	    write(*,*) "lattice value <1 or >N_Lattice_points ",i,i1,i2,i3
!        		stop
!        	  end if
!              vso_rphi(i1,i2,i3)=Psi_c(i,n)
!    	    end do
!    	  end do 
!    	end do
!    	write(log_file,*) "mapped orbital ",n," for FFT, norm=",sum(real(conjg(vso_rphi)*vso_rphi))*grid_volume
!    	call dfftw_execute_dft(plan_volkov_Forward,vso_rphi,vso_kphi)
!    	vso_kphi=vso_kphi*sqrt(fftfactor)
!    	vso_kpsi(:,:,:,n)=vso_kphi(:,:,:)
!      end do  
  
  !
  do n=1,N_orbitals

	write(log_file,'(i2,a,i6,2es28.15e3)') n," max ele ",debugmaxele,real(Psi_c(debugmaxele,n)),imag(Psi_c(debugmaxele,n))
	vso_kphi(:,:,:)=vso_kpsi(:,:,:,n)
	
	do i3=1,N_Lattice(3)
	  do i2=1,N_Lattice(2)
	    do i1=1,N_Lattice(1)
	      term1=(volkov_k_x(i1)**2+volkov_k_y(i2)**2+volkov_k_z(i3)**2)&
		  +(2*volkov_k_x(i1)*A_vec(1))&
		  +(2*volkov_k_y(i2)*A_vec(2))&
		  +(2*volkov_k_z(i3)*A_vec(3))&
		  +(A_vec(1)**2+A_vec(2)**2+A_vec(3)**2)
	      phase2=-zi*h2m*time_step*mysteryconstant/(hbar*2.d0)
		  !phase2=-zi*0.5d0*time_step*convertT2AU/(2.d0*convertL2AU**2)
          vso_kphi(i1,i2,i3)=vso_kphi(i1,i2,i3)*exp(term1*phase2)          
        end do
      end do
    end do

	call dfftw_execute_dft(plan_volkov_Backward,vso_kphi,vso_rphi)
    vso_rphi=vso_rphi*sqrt(fftfactor)
	do i3=1,N_Lattice(3)
	  do i2=1,N_Lattice(2)
	    do i1=1,N_Lattice(1)
			Phi_c(Lattice_inv_xyz(i1,i2,i3))=vso_rphi(i1,i2,i3)
        end do
      end do
    end do
	
    write(log_file,'(i2,a,i6,2es28.15e3)') n," max eleK",debugmaxele,real(Phi_c(debugmaxele)),imag(Phi_c(debugmaxele))
!	if(imag(Phi_c(debugmaxele))<0.00425078488990019d0) then
!	  write(log_file,*)"mysteryconstant overshot at",mysteryconstant
!	  mysteryconstant=mysteryconstant+debugmaxeleinc
!	  debugmaxeleinc=debugmaxeleinc/10.d0
!	  write(log_file,*)"new debugmaxeleinc",debugmaxeleinc
!	end if
	!!write(88800000+n*10000+iter*100+0,'(2es30.16e3)')  Phi_c
	! non-local psuedopotential is stupid, so we have to use taylor
	call taylor_expV_phi(n,1.d0,1)
	
	write(log_file,'(i2,a,i6,2es28.15e3)') n," max eleV",debugmaxele,real(Phi_c(debugmaxele)),imag(Phi_c(debugmaxele))
	
	!!write(88800000+n*10000+iter*100+1,'(2es30.16e3)')  Phi_c
	do i3=1,N_Lattice(3)
	  do i2=1,N_Lattice(2)
	    do i1=1,N_Lattice(1)
			vso_rphi(i1,i2,i3)=Phi_c(Lattice_inv_xyz(i1,i2,i3))
        end do
      end do
    end do
	
	call dfftw_execute_dft(plan_volkov_Forward,vso_rphi,vso_kphi)
	vso_kphi=vso_kphi*sqrt(fftfactor)

	do i3=1,N_Lattice(3)
	  do i2=1,N_Lattice(2)
	    do i1=1,N_Lattice(1)
	      term1=(volkov_k_x(i1)**2+volkov_k_y(i2)**2+volkov_k_z(i3)**2)&
		  +(2*volkov_k_x(i1)*A_vec(1))&
		  +(2*volkov_k_y(i2)*A_vec(2))&
		  +(2*volkov_k_z(i3)*A_vec(3))&
		  +(A_vec(1)**2+A_vec(2)**2+A_vec(3)**2)
		  ! h2m in AU is 0.5
	      phase2=-zi*h2m*time_step*mysteryconstant/(hbar*2.d0)
		  !phase2=-zi*0.5d0*time_step*convertT2AU/(2.d0*convertL2AU**2)
          vso_kphi(i1,i2,i3)=vso_kphi(i1,i2,i3)*exp(term1*phase2)          
        end do
      end do
    end do

	vso_kpsi(:,:,:,n)=vso_kphi(:,:,:)
	
	! map back to Psi_c
	call dfftw_execute_dft(plan_volkov_Backward,vso_kphi,vso_rphi)
	vso_rphi=vso_rphi*sqrt(fftfactor)
	do i3=1,N_Lattice(3)
	  do i2=1,N_Lattice(2)
	    do i1=1,N_Lattice(1)
		   ! ------------------------------------------------------------
		    ! debug1 change back
			Psi_c(Lattice_inv_xyz(i1,i2,i3),n)=vso_rphi(i1,i2,i3)
        end do
      end do
    end do
	!!write(88800000+n*10000+iter*100+2,'(2es30.16e3)')  Psi_c(:,n)
	!write(log_file,'(i2,a,i6,2es28.15e3)') n," max eleK",debugmaxele,real(Psi_c(debugmaxele,n)),imag(Psi_c(debugmaxele,n))
  end do

end subroutine volkov_split_timestep_krk

subroutine volkov_split_timestep_rkr(iter)
implicit none
  integer   :: i,n,i1,i2,i3,iter
  complex*16 :: term1,phase2


  do n=1,N_orbitals
    Phi_c(:)=Psi_c(:,n)
	!write(99900000+n*10000+iter*100+0,'(2es30.16e3)')  Phi_c
	! 1/2 taylor time step
	call taylor_expV_phi(n,0.5d0,1)
	!write(99900000+n*10000+iter*100+1,'(2es30.16e3)')  Phi_c
	do i3=1,N_Lattice(3)
	  do i2=1,N_Lattice(2)
	    do i1=1,N_Lattice(1)
			vso_rphi(i1,i2,i3)=Phi_c(Lattice_inv_xyz(i1,i2,i3))
        end do
      end do
    end do
	
	call dfftw_execute_dft(plan_volkov_Forward,vso_rphi,vso_kphi)
	vso_kphi=vso_kphi*sqrt(fftfactor)

	do i3=1,N_Lattice(3)
	  do i2=1,N_Lattice(2)
	    do i1=1,N_Lattice(1)
	      term1=(volkov_k_x(i1)**2+volkov_k_y(i2)**2+volkov_k_z(i3)**2)&
		  +(2*volkov_k_x(i1)*A_vec(1))&
		  +(2*volkov_k_y(i2)*A_vec(2))&
		  +(2*volkov_k_z(i3)*A_vec(3))&
		  +(A_vec(1)**2+A_vec(2)**2+A_vec(3)**2)
		  ! h2m in AU is 0.5
	      phase2=-zi*0.5*time_step*convertT2AU
          vso_kphi(i1,i2,i3)=vso_kphi(i1,i2,i3)*exp(term1*phase2)          
        end do
      end do
    end do

	call dfftw_execute_dft(plan_volkov_Backward,vso_kphi,vso_rphi)
    vso_rphi=vso_rphi*sqrt(fftfactor)

	do i3=1,N_Lattice(3)
	  do i2=1,N_Lattice(2)
	    do i1=1,N_Lattice(1)
			Phi_c(Lattice_inv_xyz(i1,i2,i3))=vso_rphi(i1,i2,i3)
        end do
      end do
    end do	
	!write(99900000+n*10000+iter*100+2,'(2es30.16e3)')  Phi_c
	! 1/2 taylor time step
	call taylor_expV_phi(n,0.5d0,1)	
	!write(99900000+n*10000+iter*100+3,'(2es30.16e3)')  Phi_c
	Psi_c(:,n)=Phi_c(:)
  end do
  
end subroutine volkov_split_timestep_rkr
  
subroutine taylor_expV_phi(orb,scalef,smode)
implicit none
  integer :: n,orb,i,smode
  complex*16 :: taylor_coeff(N_taylor),scalef_c,tc_n
  real*8     :: scalef
  
  scalef_c=scalef
  taylor_coeff=0.d0
  do i=1,N_taylor
    taylor_coeff(i)=(-zi*scalef_c*time_step/hbar)**i
    do n=1,i
      taylor_coeff(i)=taylor_coeff(i)/dfloat(n)
    enddo
  enddo
  !write(log_file,*)'tc2',taylor_coeff
    phi_c2=phi_c
    if(spin_polarized) then
      if(orb<N_orbitals_down+1) then
        spin_down=.TRUE.
        spin_up=.FALSE.
      else
        spin_up=.TRUE.
        spin_down=.FALSE.
      endif
    endif  
    do n=1,N_taylor
      if(smode==1) then
	    call V_wavefn_c_noLaser
	  else
	    write(log_file,*) "unrecognized mode for taylor_expV_phi(orb,scalef,smode)"
        stop
      end if
      do i=1,N_Lattice_points  
        Phi_c(i)=H_Phi_c(i)
      enddo
	  tc_n=taylor_coeff(n)
      do i=1,N_Lattice_points
        phi_c2(i)=phi_c2(i)+tc_n*Phi_c(i)
      enddo  
    enddo  
  phi_c=phi_c2
end subroutine taylor_expV_phi




SUBROUTINE init_Volkov_mask
implicit none
  integer    :: i,l,j,k
  real*8     :: RA,RC,maskv1,fd_lat_max(3),arg1
  
  allocate(mask(N_lattice_points))
!  volkov_mask_grid=1.d0
!  
! fd_lat_max(1)=abs(xgrid(1))
! fd_lat_max(2)=abs(ygrid(1))
! fd_lat_max(3)=abs(zgrid(1))
! do l=1,N_lattice_points
!   
!   do i=1,3
!     RA=fd_lat_max(i)
!	 RC=fd_lat_max(i)-volkov_mask_depth
!     maskv1=1.d0
!	 if(grid_point(i,l)>RC) then
!       arg1=(grid_point(i,l)-RC)*3.1415926535897932384d0/(2*(RA-RC))
!	   maskv1=1.d0 - (sin(arg1)**2)
!	 else if (grid_point(i,l)<-RC) then
!       arg1=(grid_point(i,l)-RC)*3.1415926535897932384d0/(2*(RA-RC))
!	   maskv1=1.d0 - (sin(arg1)**2)	   
!	 !end if 
!	 !allow for x y z mask
!	 end if
!	 volkov_mask_grid(l)=volkov_mask_grid(l)*maskv1
!   end do
! end do  

   ! mask function
 write(log_file,*) 'Initialize Mask'  
  ! mask end and start, not bigger than max real space grid!
  !R_A(1)=abs(grid_point(1,1))!+grid_step(1)
  R_A(1)=abs(xgrid(1))
  R_C(1)=R_A(1)-volkov_mask_depth
 write(log_file,'(a,f10.3,a,f10.3)') 'Mask_X: Max RSG=',R_A(1),' Mask R_Cx=',R_C(1) 
  !R_A(2)=abs(grid_point(2,1))!+grid_step(2)
  R_A(2)=abs(ygrid(1))
  R_C(2)=R_A(2)-volkov_mask_depth
 write(log_file,'(a,f10.3,a,f10.3)') 'Mask_Y: Max RSG=',R_A(2),' Mask R_Cy=',R_C(2)  
  !R_A(3)=abs(grid_point(2,1))!+grid_step(2)
  R_A(3)=abs(zgrid(1))
  R_C(3)=R_A(3)-volkov_mask_depth
 write(log_file,'(a,f10.3,a,f10.3)') 'Mask_Z: Max RSG=',R_A(3),' Mask R_Cz=',R_C(3)  
  mask=0.d0
 do l=1,N_lattice_points
   do i=1,3
	 maskinit(i)=1.d0
     if(grid_point(i,l)>R_C(i)) then
         arg1=(grid_point(i,l)-R_C(i))*3.1415926535897932384d0/(2*(R_A(i)-R_C(i)))
	     maskinit(i)=1.d0 - (sin(arg1)**2)
	 else if (grid_point(i,l)<-R_C(i)) then
         arg1=(grid_point(i,l)+R_C(i))*3.1415926535897932384d0/(2*(R_A(i)-R_C(i)))
	     maskinit(i)=1.d0 - (sin(arg1)**2)	 
	 end if
	 
	 
   end do
   mask(l)=maskinit(1)*maskinit(2)*maskinit(3)
 end do
 open(3323,file="volkov_mask.dat",status="replace")
 do i=1,N_lattice_points
   write(3323,'(3f8.3,f15.8)') grid_point(1,i),grid_point(2,i),grid_point(3,i),mask(i)
 end do
 close(3323)
 write(log_file,*) "Mask stored in file volkov_mask.dat"
 open(3323,file="volkov_mask_xy.dat",status="replace")
 do i=1,N_Lattice(1)
   do j=1,N_Lattice(2)
     k=N_Lattice(3)/2
     write(3323,'(3f8.3,f15.8)') xgrid(i),ygrid(j),zgrid(k),mask(Lattice_inv_xyz(i,j,k))
   end do
 end do
 close(3323)
 write(log_file,*) "Mask stored in file volkov_mask.dat and volkov_mask_xy.dat"

 
END SUBROUTINE init_Volkov_mask

subroutine volkov_Avec_update
implicit none
  integer    :: i
  real*8     :: convertE2AU
  
  ! 1 = 51.4220652 V/A
  ! 1 = 2.418884326505(16)×10−17 s	= .02418884326505(16) fs	
  convertE2AU=1.d0/(51.4220652)
  do i=1,3
    A_vec(i)=A_vec(i)+laser_xyz_t_iteration(i)*time_step*convertE2AU*convertT2AU
    A_vec_int(i)=A_vec_int(i)+A_vec(i)*time_step*convertT2AU
    A_vec_2_int(i)=A_vec_2_int(i)+A_vec(i)**2*time_step*convertT2AU
  end do
  write(log_file,'(a,3f12.7,a,3f12.7)') 'E(V/A)=',laser_xyz_t_iteration(1:3),' A(AU)=',A_Vec(1:3)
end subroutine volkov_Avec_update

subroutine volkov_time_step(it)
implicit none
  integer     :: it,i,j,k1,k2,k3,ind
  complex*16  :: swap1,swap2
  real*8      :: phase1,vnorm1,vnorm2,vnumele1,mvalue,getdp
  real*8      :: VDPMx,VDPMy,VDPMz,VDPall(3,N_orbitals)
  character(255) :: fnameVDC
  character(7)   :: ch7
  
  ! FFTW is best at handling sizes of the form 2^a3^b5^c7^d11^e13^f
  ! , where e+f is either 0 or 1, and the other exponents are arbitrary
  
  vnumele1=0.d0
  swap1=0.d0
  swap2=0.d0
  phase1=0.d0
  getdp=0.d0
  
  if(volkov_save_dens.AND.(mod(it,volkov_save_dens_freq)==0)) then
	sing_prec_rearranged_dvolkov=0.d0
  end if
   
  do i=1,3
	  DeltaA(i)=A_vec_int(i)-A_vec_int_prev(i)
	  DeltaA2(i)=A_vec_2_int(i)-A_vec_2_int_prev(i)	
  end do
  write(log_file,'(a,i7,f16.8)') ' VOLKOV:',it,it*time_step
  write(log_file,'(a,3f12.7)') ' VOLKOV: deltaA=',DeltaA(1:3)
  ! apply propagator
  do i=1,N_orbitals 
    !Phi_Volkov2=Psi_volkov(:,:,:,i)
    do k1=1,N_Volk(1)
      do k2=1,N_Volk(2)
        do k3=1,N_Volk(3)
		! units !  time==fs  k==1/Angstrom  DeltaA==V*fs/Angstrom
          phase1=(vtimestep*convertT2AU*(volkov_k_x(k1)**2 + volkov_k_y(k2)**2 + volkov_k_z(k3)**2 ))
          phase1=phase1-(2.d0*volkov_k_x(k1)*DeltaA(1))
  		  phase1=phase1-(2.d0*volkov_k_y(k2)*DeltaA(2))
  		  phase1=phase1-(2.d0*volkov_k_z(k3)*DeltaA(3))
  		  phase1=phase1+DeltaA2(1)+DeltaA2(2)+DeltaA2(3)
     	  !Psi_Volkov(k1,k2,k3,i)=Psi_Volkov(k1,k2,k3,i)*exp(-zi*0.5d0*phase1)
          Phi_Volkov2(k1,k2,k3)=Psi_Volkov(k1,k2,k3,i)*exp(-zi*0.5d0*phase1)
        end do
      end do
    end do
	!Psi_volkov(:,:,:,i)=Phi_Volkov2
	!--------------
	!write(*,'(a,i2,2es26.16)') 'max coeff ',i,maxval(real(Phi_Volkov)),maxval(real(Phi_Volkov2))
	!--------------
	Phi_Volkov=0.d0
	call dfftw_execute_dft(plan_volkov_Backward,Phi_Volkov2,Phi_Volkov)
	!--------------
	!write(*,'(a,i2,2es26.16)') 'max coeff ',i,maxval(real(Phi_Volkov)),maxval(real(Phi_Volkov2))
	!--------------
	! length gauge  and  absorb wave function at boundary

    do k1=1,N_Volk(1)
      do k2=1,N_Volk(2)
        do k3=1,N_Volk(3)
		  phase1=A_Vec(1)*volkov_grid_x(k1)
		  phase1=phase1+ A_Vec(2)*volkov_grid_y(k2)
		  phase1=phase1+ A_Vec(3)*volkov_grid_z(k3)
     	  Phi_Volkov2(k1,k2,k3)=Phi_Volkov(k1,k2,k3)*exp(-zi*phase1)*volkov_abs_x(k1)*volkov_abs_y(k2)*volkov_abs_z(k3) 		  
          !vnorm1=vnorm1+conjg(Phi_Volkov(k1,k2,k3))*Phi_Volkov(k1,k2,k3)
		end do
      end do
    end do
	
	Phi_Volkov=Phi_Volkov2
    VDPMx=0.d0
	VDPMy=0.d0
	VDPMz=0.d0
	!--------------
	!write(*,'(a,i2,2es26.16)') 'max coeff ',i,maxval(real(Phi_Volkov)),maxval(real(Phi_Volkov2))
	!--------------
	! mask
	vnorm1=0.d0
	vnorm2=0.d0
	do j=1,N_lattice_points
	  mvalue=mask(j)
	  swap1=mvalue*Psi_c(j,i)+ mvalue*Phi_Volkov(fd_volkov_mapping3(1,j),fd_volkov_mapping3(2,j),fd_volkov_mapping3(3,j))
	  mvalue=1.d0-mask(j)
	  swap2=mvalue*Psi_c(j,i)+ mvalue*Phi_Volkov(fd_volkov_mapping3(1,j),fd_volkov_mapping3(2,j),fd_volkov_mapping3(3,j))
	  Psi_c(j,i)=swap1
	  Phi_Volkov2(fd_volkov_mapping3(1,j),fd_volkov_mapping3(2,j),fd_volkov_mapping3(3,j))=swap2
	  vnorm1=vnorm1+real(conjg(swap1)*swap1)
	  vnorm1=vnorm1+2*real(conjg(swap1)*swap2)
	  VDPMx=VDPMx+real(conjg(swap1)*grid_point(1,j)*swap1)
	  VDPMx=VDPMx+2*real(conjg(swap1)*grid_point(1,j)*swap2)
	  VDPMy=VDPMy+real(conjg(swap1)*grid_point(2,j)*swap1)
	  VDPMy=VDPMy+2*real(conjg(swap1)*grid_point(2,j)*swap2)
	  VDPMz=VDPMz+real(conjg(swap1)*grid_point(3,j)*swap1)
	  VDPMz=VDPMz+2*real(conjg(swap1)*grid_point(3,j)*swap2)
	end do

	
	
	
	!--------------
	!write(*,'(a,i2,es26.16)') 'max coeff ',i,maxval(real(Phi_Volkov))
	!--------------
	! save density if desired 

	if(volkov_save_dens.AND.(mod(it,volkov_save_dens_freq)==0)) then
	  write(fnameVDC,'(a,i7.7,a)') 'volkov_2D_Coarse_dens_',it,'.dat'
	  open(414,file=trim(adjustl(fnameVDC)),form='formatted',status='replace',action='write')

      ind=0
      do k3=1,N_Volk(3)
        do k2=1,N_Volk(2)
          do k1=1,N_Volk(1)
            ind=ind+1
			getdp=0.d0
			getdp=conjg(Phi_Volkov2(k1,k2,k3))*Phi_Volkov2(k1,k2,k3)
            if (bw_volkov_mapping(k1,k2,k3)>0) then
			  getdp=getdp+ &
			    conjg(Psi_c(bw_volkov_mapping(k1,k2,k3),i))*Psi_c(bw_volkov_mapping(k1,k2,k3),i)
			  getdp=getdp+ &
			    2*real(conjg(Phi_Volkov2(k1,k2,k3))*Psi_c(bw_volkov_mapping(k1,k2,k3),i))
			end if
			sing_prec_rearranged_dvolkov(ind)=sing_prec_rearranged_dvolkov(ind)+getdp
            if((mod(k1,2)==0).AND.(mod(k2,2)==0).AND.(k3==N_Volk(3)/2)) then
			  write(414,'(2f10.2,f20.10)') volkov_grid_x(k1),volkov_grid_y(k2),getdp
			end if			
          enddo
        enddo
      enddo	  
	  close(414)
	end if
	Phi_Volkov=0.d0
	! velocity gauge
    do k1=1,N_Volk(1)
      do k2=1,N_Volk(2)
        do k3=1,N_Volk(3)
		  VDPMx=VDPMx+real(conjg(Phi_Volkov2(k1,k2,k3))*volkov_grid_x(k1)*Phi_Volkov2(k1,k2,k3))
		  VDPMy=VDPMy+real(conjg(Phi_Volkov2(k1,k2,k3))*volkov_grid_y(k2)*Phi_Volkov2(k1,k2,k3))
		  VDPMz=VDPMz+real(conjg(Phi_Volkov2(k1,k2,k3))*volkov_grid_z(k3)*Phi_Volkov2(k1,k2,k3))
		  vnorm2=vnorm2+conjg(Phi_Volkov2(k1,k2,k3))*Phi_Volkov2(k1,k2,k3)
		  phase1=A_Vec(1)*volkov_grid_x(k1)
		  phase1=phase1+ A_Vec(2)*volkov_grid_y(k2)
		  phase1=phase1+ A_Vec(3)*volkov_grid_z(k3)
     	  Phi_Volkov(k1,k2,k3)=Phi_Volkov2(k1,k2,k3)*exp(zi*phase1)            		  
        end do
      end do
    end do
	! normalization 
	vnorm1=vnorm1*grid_volume
	vnorm2=vnorm2*grid_volume
	vnumele1=vnumele1+vnorm1+vnorm2
	write(log_file,'(a,i4,a,f18.12,a,f18.12)') ' VOLKOV: orbital',i,' normV=',vnorm2,' normTOT=',vnorm1+vnorm2	
	
	! save dipole moment for each orbital  VDPall(3,N_orbitals)
	VDPall(1,i)=VDPMx*grid_volume
	VDPall(2,i)=VDPMy*grid_volume
	VDPall(3,i)=VDPMz*grid_volume
	
	!--------------
	!write(*,'(a,i2,2es26.16)') 'max coeff ',i,maxval(real(Phi_Volkov)),maxval(real(Phi_Volkov2))
	!--------------
	Phi_Volkov2=0.d0
	call dfftw_execute_dft(plan_volkov_Forward,Phi_Volkov,Phi_Volkov2)
	!--------------
	!write(*,'(a,i2,2es26.16)') 'max coeff ',i,maxval(real(Phi_Volkov)),maxval(real(Phi_Volkov2))
	!--------------
	!   ! OLD WAY  was to add Fourier components back
    do k1=1,N_Volk(1)
      do k2=1,N_Volk(2)
        do k3=1,N_Volk(3)
		  !Psi_volkov(k1,k2,k3,i)=Psi_volkov(k1,k2,k3,i) + Phi_Volkov2(k1,k2,k3)*fftfactor
		  Psi_volkov(k1,k2,k3,i)= Phi_Volkov2(k1,k2,k3)*fftfactor
        end do
      end do
    end do   	
	!--------------
	!write(*,'(a,i2,es26.16)') 'max coeff Psi ',i,maxval(real(Psi_Volkov(:,:,:,i)))
	!--------------	
  end do
  A_vec_int_prev=A_vec_int
  A_vec_2_int_prev=A_vec_2_int
  write(log_file,'(a,f18.12)') ' VOLKOV: sum of elec in volkov region = ',vnumele1
  
  if(volkov_save_dens.AND.(mod(it,volkov_save_dens_freq)==0)) then
	call output_td_density_volkov(it)
	
!	write(fnameVDC,'(a,i7.7,a)') 'volkov_2D_Coarse_dens_',it,'.dat'
!	open(414,file=trim(adjustl(fnameVDC)),form='formatted',status='replace',action='write')
!      do k3=1,N_Volk(3)
!        do k2=1,N_Volk(2)
!          do k1=1,N_Volk(1)
!            ind=ind+1
!            if((mod(k1,2)==0).AND.(mod(k2,2)==0).AND.(k3==N_Volk(3)/2)) then
!			  getdp=0.d0
!			  getdp=sing_prec_rearranged_dvolkov(ind)
!			  write(414,'(2es15.3,es15.3)') volkov_grid_x(k1),volkov_grid_y(k2),getdp
!			end if
!          enddo
!        enddo
!      enddo	  	
!	close(414)
  end if
  
  ! write dipole moment to file
  do j=1,3 
    write(3300+j,'(f10.5,es26.16)',advance='no') it*time_step,sum(VDPall(j,:))
    do i=1,N_orbitals-1
      write(3300+j,'(es26.16)',advance='no') VDPall(j,i)
    end do
    write(3300+j,'(es26.16)') VDPall(j,N_orbitals)
  end do

end subroutine volkov_time_step

! cody
SUBROUTINE output_td_density_volkov(iter)
!This subroutine saves electron density of volkov as bov format
integer :: iter,td_volkov_density_file
integer :: i,j,k,ind,pl,fnl,dk1,dk2,dk3,k1min,k2min,k3min,k1max,k2max,k3max
character(255) :: fname1,fname2
character(5)   :: ch5
character(16)  :: str1,str2,str3

td_volkov_density_file=3323
!k1min=N_Lattice_min(1)
!k1max=N_Lattice_max(1)
!k2min=N_Lattice_min(2)
!k2max=N_Lattice_max(2)
!k3min=N_Lattice_min(3)
!k3max=N_Lattice_max(3)
k1min=1
k1max=N_Volk(1)
k2min=1
k2max=N_Volk(2)
k3min=1
k3max=N_Volk(3)

dk1=(k1max-k1min+1)
dk2=(k2max-k2min+1)
dk3=(k3max-k3min+1)

!Bov format (bricks of data) which can easily be read by VisIt software.
!It is fast and reasonable in terms of disk space. Works only in the
!case of rectangular box
    write(ch5,'(i5.5)') td_density_counter_volkov
    write(fname1,'(a,a,a,a)') 'volkov_dens',ch5(1:5),'.dat'
    write(fname2,'(a,a,a,a)') 'volkov_dens',ch5(1:5),'.bov'
    fnl=len_trim(fname1)
    !First write the density into a data file, which is of binary form.
    !Note that the density data is rearranged as z,y,x --> x,y,z (C-like
    !storage of array elements)  and converted to single precision before
    !saving it to disk (single precision is used to reduce disk usage).
    !Rearrangement must be done using an auxiliary array
    !(called sing_prec_rearranged_dvolkov) because the data cannot be
    !simply written into the binary file by making an appropriate do-loop
    !(writing an entire array at once and writing it step-by-step gives
    !different result in fortran when it is a binary file).
    open(td_volkov_density_file,file=fname1,form='unformatted',status='replace')
    write(td_volkov_density_file) sing_prec_rearranged_dvolkov
    close(td_volkov_density_file)
    !Now create a header file corresponding to the above datafile. The header file
    !is in ascii text form
    open(td_volkov_density_file,file=fname2,status='replace')
    write(td_volkov_density_file,'(1x,a,1x,es23.15)') 'TIME:',iter*time_step
    write(td_volkov_density_file,'(1x,a,1x,a)') 'DATA_FILE:',fname1(1:fnl)
    write(td_volkov_density_file,'(1x,a,3(1x,i6))') 'DATA_SIZE:',dk1,dk2,dk3
    write(td_volkov_density_file,'(1x,a)') 'DATA_FORMAT:  FLOAT'
    write(td_volkov_density_file,'(1x,a)') 'VARIABLE:  density'
    write(td_volkov_density_file,'(1x,a)') 'DATA_ENDIAN:  LITTLE'
    write(td_volkov_density_file,'(1x,a)') 'CENTERING:  zonal'
    write(td_volkov_density_file,'(1x,a,3(1x,es23.15))') 'BRICK_ORIGIN:',volkov_grid_x(k1min),volkov_grid_y(k2min),volkov_grid_z(k3min)
    write(td_volkov_density_file,'(1x,a,3(1x,es23.15))') 'BRICK_SIZE:', &
        volkov_grid_x(k1max)-volkov_grid_x(k1min),volkov_grid_y(k2max)-volkov_grid_y(k2min),volkov_grid_z(k3max)-volkov_grid_z(k3min)
    write(td_volkov_density_file,'(1x,a)') 'BYTE_OFFSET: 4'
    close(td_volkov_density_file)

td_density_counter_volkov=td_density_counter_volkov+1

END SUBROUTINE output_td_density_volkov



end module mask_volkov