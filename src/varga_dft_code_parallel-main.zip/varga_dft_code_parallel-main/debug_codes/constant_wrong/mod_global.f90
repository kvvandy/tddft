MODULE MOD_GLOBAL
  USE PARAMETERS
  USE omp_lib
  USE mod_array
  implicit none

  TYPE :: memory_usage_item
    character(255) :: variable_name
    integer        :: memory_usage
  END TYPE memory_usage_item

  integer :: n_basis_cache
  real*8  :: radial_fine_grid
  logical :: cache_basis

  logical :: recalc_kpoint,use_high_energy_wp

  !Variables used with OpenMP
  integer num_threads, thread_id, num_procs_avail

  integer, dimension(3) :: nkv !number of kpoints for monkhorst_pack mesh

  integer,parameter :: ngm=20,lexp=2

  integer                              :: orbital_index,orb_num
  integer                              :: N_Species,N_orbitals,N_total_orbitals,N_total_atom,N_atom_image
  integer                              :: z_atom(N_elements),elem(0:N_elements) !     index of atoms
  integer                              :: N_lattice(3) !     number of grid points in each direction
  integer                              :: N_lattice_min(3),N_lattice_max(3)
  integer                              :: N_lattice_points !     total number of grid points
  integer,dimension(:),allocatable     :: atom_index,aind,image_index
  integer,dimension(:),allocatable     :: n_points_x_plane,n_points_y_plane,n_points_z_plane
  !If possible we want to use 2-byte integers for array Lattice
  integer,parameter :: shortkind = SELECTED_INT_KIND(4)  !ensures minimum range of -9999:9999
  integer(shortkind),dimension(:,:),allocatable   :: Lattice
  integer,dimension(:,:,:),allocatable :: Lattice_inv_xyz,Lattice_inv_yzx,Lattice_inv_zxy

  real*8,dimension(:),allocatable :: Density,old_Density,new_density,atomic_density,Rho_bg
  real*8,dimension(:),allocatable :: VH_bg,VH,xgrid,ygrid,zgrid,V_bias_pot
  real*8,dimension(:),allocatable :: V_Hartree,V_Exchange,VEH,V_nl_pp,V_l_pp

  real*8                                  :: Energy,Grid_step(3),R_size(3),Grid_Volume,x0,a0
  real*8,dimension(:),allocatable         :: Sp_Energy,Occupation,H_Phi,Phi,T_Phi
  real*8, dimension(:,:),allocatable      :: grad_density
  real*8,dimension(:,:),allocatable       :: Psi,Grid_point,Position,Position_init,Position_atom,Position_image
  real*8,dimension(:,:),allocatable       :: Position_prev
  real*8,dimension(:,:,:),allocatable     :: wphi,wlap_r(:,:)
  real*8, dimension(:,:), allocatable     :: C_basis
  complex*16,dimension(:,:),allocatable   :: V_opt_pot,cf_basis
  complex*16,dimension(:,:,:),allocatable :: wphi_c
  integer                                 :: excitation_jump
  character(8)          ::     optics_key
  character(4)  :: dir
  character(4)  :: field_dir
  character(20) :: process, Hyp_Info
  character(4)  :: XC_in
  real(8) :: hw(2)
  character(6) :: CG_Solver
  integer                            :: ng,isg      ! isg: Gaussian for the ghost
  integer                            :: N_diag      ! number of basis states (contracted)
  integer,dimension(:),allocatable   :: N_ao        ! number of basis states per atom
  integer,dimension(:),allocatable   :: l_max_basis ! maximum orbital momentum used for a given  atom
  integer,dimension(:,:),allocatable :: N_ao_l      ! number of basis states per atom per angular momentum
  real*8,dimension(:),allocatable    :: gauss_p     ! Gaussian parameters for the basis
  real*8,dimension(:),allocatable    :: wf_rad      ! max wave function radius

  integer                                :: min_basis_size_for_cg
  integer                                :: N_ao_max,N_empty,N_iteration_cg,N_iteration_cg_gen
  logical                                :: default_N_empty=.true.
  integer,dimension(:,:),allocatable     :: basis_atom,basis_atom_inv,atom_pairs
  integer,dimension(:,:,:,:),allocatable :: basis_ind
  real*8                                 :: bg_beta,rwf_sm,cap_parameter,cap_buffer
  real*8,dimension(:,:),allocatable :: phi_cap,cap_m_phi,cap_m 
  complex*16,dimension(:),allocatable :: cphi
  real*8,dimension(:),allocatable        :: eval,emx
  real*8,dimension(:,:),allocatable      :: hmx,omx,vmx,hm,om,evec,hm1,hm2,om0,wm
  real*8,dimension(:,:,:),allocatable    :: atom_occ
  real*8,dimension(:,:,:,:),allocatable  :: c_exp

  real*8,dimension(:),allocatable :: dp,dp_regression_data,transport_run_5_regression_data
  real*8,dimension(:),allocatable :: transport_run_3_4_regression_data

  ! kpoint arrays
  real*8, dimension(:,:), allocatable :: evalk
  complex*16, dimension(:,:,:), allocatable :: evecz,hm1k,om1k

  logical :: contracted,singleatom,potint_analytic,periodic,transport,output_full_td_density,fd_p_full,dendiv_output,output_gs_orb_density,output_orb_current,output_orb_density,no_scf_density
  logical :: output_td_psi !Jorge
  logical :: output_coordinate_map  !Jorge
  logical :: output_orbitals,output_orbitals2
  logical :: init_random !shenglai 
  logical :: grid_calculation,continuation,box,check_convergence,output_hs_mat,periodic_2d,fermi_energy_search,complexbasis
  logical :: output_plot,output_plot_time,output_mr_density_slice,output_mr_orbital_charge,use_fine_grid,plot_bands
  logical :: spin_polarized,spin_up,spin_down,use_brandons_changes,output_full_td_current_density,output_full_td_sp_energy,non_local_current
  logical :: output_tr_mat,check_convergence_td,save_lattice_view
  integer                                   :: N_orbitals_up,N_orbitals_down
  double precision,dimension(:),allocatable :: V_Exchange_up,V_exchange_down
  double precision,dimension(:),allocatable :: density_up,density_down,box_basis_regression_data
  double precision,dimension(:),allocatable :: density_up_new,density_down_new
  double precision,dimension(:,:),allocatable :: current_density,current_density_up,current_density_down

  character*255 :: pp_path,bf_path,gs_path,structure_input_filename,control_input_filename
  character*255 :: td_density_output_format,td_current_density_output_format,large_file_format,td_total_3D_potential_output_format,propagator

  integer    :: N_fine_grid(3),num_AO_setup_iterations_for_grid
  real(8)    :: fine_grid_spacing
  real*8,dimension(:,:),allocatable   :: uf1,uf2,uf3

  integer :: td_density_counter=0
  integer :: td_density_counter_source=0 ! cody
  integer :: td_current_density_counter=0
  integer :: td_sp_energy_counter=0 !shenglai
  integer :: td_psi_counter=0 !Arthur
  integer :: td_pot_counter=0 !Arthur
  integer :: tot_td_pot_output_freq !Arthur
  logical :: output_tot_td_pot !Arthur
  integer :: output_inner_product_frequency !Arthur
  logical :: output_inner_product !Arthur 
  logical :: output_inner_product_s2=.FALSE. !cody 2nd style for outputing inner products
  logical :: output_inner_product_virtual=.FALSE. !cody  include unoccupied orbitals in output_inner_product_s2
  logical :: load_virtual_orbitals=.FALSE. ! cody        load N_empty orbitals from psi.dat 
  
  real(4),dimension(:),allocatable   :: sing_prec_rearranged_density,sing_prec_rearranged_current_density,sing_prec_rearranged_potential
  real(4),dimension(:),allocatable   :: rearranged_arr_real4
  complex(4),dimension(:),allocatable  :: rearranged_arr_complex4 
  real*8                            :: vdw_stretch_x, vdw_stretch_y, vdw_stretch_z
  real*8                            :: boundary_space_xL,boundary_space_xR  !specifies the distance between
  real*8                            :: boundary_space_yL,boundary_space_yR  !the leftmost/rightmost atoms and the
  real*8                            :: boundary_space_zL,boundary_space_zR  !simulation box boundaries
  integer                           :: N_atom_L,N_atom_C,N_atom_R,N_box,run_type,tddft_type,N_time_steps,time1
  integer                           :: N_scf_iter_max ! number of scf iterations
  integer                           :: N_non_scf_iter_max !Arthur's notes: number of iterations without scf
  integer                           :: N_opt          ! number of optimization iterations
  integer                           :: box_basis_type ! 1=atomic orbitals, 2=box orbitals
  integer                           :: grid_type      ! 1=finite difference, 2=Lagrange
  integer,allocatable               :: Nx_box(:),N_box_basis(:),box_atom(:),box_opt(:)
  integer,allocatable               :: N_box_basis_contracted(:)
  real*8                            :: time_step,E_fermi,V_bias
  integer                           :: N_gc(3)
  real*8,dimension(:),allocatable   :: xr1,wr1,xr2,wr2,xr3,wr3
  real*8,dimension(:),allocatable   :: V_ext,V_laser1,V_laser2,V_laser3,xmr,V_td,V_steppot
  real*8,dimension(:,:),allocatable :: tm1,tm2,tm3

  double precision,allocatable  :: contracted_basis(:,:,:)
  integer,allocatable           :: box_ind_contracted(:,:)

  integer :: gs_data_output_frequency,td_data_output_frequency
  integer :: td_density_output_frequency,td_current_density_output_frequency,td_sp_energy_output_frequency,td_orb_current_output_frequency
  integer :: td_orbital_output_frequency,orbital_output_num
  integer :: orbital_up_output_num,orbital_down_output_num
  integer :: atomic_movement_frequency,moldyn_output_frequency,orb_en_comp_output_frequency
  integer :: lanczos_update_frequency,num_lanczos_vec 
  integer :: psi_output_frequency   !Arthur
  integer :: restart_update_frequency=-1 ! cody
  integer :: restart_update_iter ! cody
!  integer :: restart_last_file_written ! cody    gives the iteration the last update
  logical :: write_restart=.FALSE.  ! cody  
  logical :: keep_all_restart=.FALSE.  ! cody    flag to not overwrite restart files (keep them all)
  logical :: resume_from_restart_taylor=.FALSE.  ! cody   use to resume from restart info
  
 ! Possible values for orb_en_comp_output_level:
 ! 0 - Occupation and energy of each orbital
 ! 1 - The above and the local pseudopotential energy of each orbit
 ! 2 - The above and the hartree energy of each orbit
 ! 3 - The above and the exchange energy of each orbit
 ! 4 - The above and the nonlocal pseudopotential energy of each orbit
 ! 5 - The above and the kinetic energy of each orbit
 ! 6 - The above and the time dependent potential energy of each orbit
 ! 7+ - All of the above
  integer                            :: orb_en_comp_output_level
  integer                            :: box_type ! 1=rectangular box, 2=sphere
  integer,dimension(:),allocatable   :: int_points,mr,user_set_xmr
  integer,dimension(:,:),allocatable :: Ind_basis
  real*8                             :: box_radius
  real*8,dimension(:,:),allocatable  :: Psi_basis_r
  real*8,dimension(:,:),allocatable  :: Psi_basis_i

! compressed ind_basis arrays
  integer, dimension(:), allocatable :: ind_basis_n    ! dimension n_total_atom
  integer, dimension(:,:,:), allocatable :: ind_basis_indx  ! (2, ~400, n_total_atom)

  !map_block_size controls the size of cubic blocks, which the whole grid is split into.
  !This variable markedly affects the overall performance. Warning: the value of
  !map_block_size must be the same for both the ground state and time-dependent runs.
  integer :: map_block_size
  !map_subblock_size controls the size of a subblock. Each block is split into
  !subblocks of size map_subblock_size x map_subblock_size x map_subblock_size
  integer :: map_subblock_size

  logical                         :: using_v_ext,using_v_laser1,using_v_laser2,using_v_laser3,using_v_step,using_injection
  logical                         :: using_cap,cap_exist(3),add_projector_cap,transport_cap,cap_to_edge,huge_cap_edge,keep_density_in_cap_constant
  logical                         :: save_cap  
  logical                         :: using_opt_pot,move_atoms,use_average_atomic_mass
  logical :: move_all_atoms
  logical,dimension(:),allocatable   :: atom_movable
  character(255) :: moldyn_type
  integer                            :: N_BohmianPart
  real*8,dimension(:,:),allocatable  :: PosBohmianPart,PosBohmianPart_prev
  integer                            :: bmd_seed
  logical                            :: generate_bmd_seed
  integer                            :: bmd_n_walker_steps
  real(8)                            :: bmd_walker_step
  logical                            :: bmd_walker_step_supplied
  
 
  logical     :: suppress_field_upon_ion_motion
  real*8      :: field_suppression_timescale,field_suppression_power
  real*8      :: field_suppression_start_time !this is internal variable (cannot be read from file)
  real*8      :: field_suppression_trd   !threshhold relative displacement for field suppression
  logical     :: field_suppression_on    !internal flag (cannot be read from file)
  integer,dimension(:),allocatable :: closest_ion_init 
  
  integer   :: E_ext_direction=1 ! default x direction
  real*8 :: E_ext,E_laser1,E_laser2,E_laser3,gs_laser_switch(3),ramp_time,V_step,V_step_end,buffer,source_type
  character(255) :: laser_envelope_type1,laser_envelope_type2,laser_envelope_type3
  real*8 :: T_sin_sq1,T_sin_sq2,T_sin_sq3,omega_sin_sq1,omega_sin_sq2,omega_sin_sq3,f_sin_sq1,f_sin_sq2,f_sin_sq3
  real*8 :: laser_frequency1,laser_pulse_width1,laser_frequency2,laser_pulse_width2
  real*8 :: laser_frequency3,laser_pulse_width3,laser_phase1,laser_phase2,laser_phase3
  real*8 :: laser_pulse_shift1,laser_pulse_shift2,laser_pulse_shift3
  real*8 :: laser_envelope_up_point1,laser_envelope_up_point2,laser_envelope_up_point3
  real*8 :: laser_envelope_up_steepness1,laser_envelope_up_steepness2,laser_envelope_up_steepness3
  real*8 :: laser_envelope_down_point1,laser_envelope_down_point2,laser_envelope_down_point3
  real*8 :: laser_envelope_down_steepness1,laser_envelope_down_steepness2,laser_envelope_down_steepness3
  real*8 :: time_factor(3)
  real*8 :: factor_laser1=0.0d0
  real*8 :: factor_laser2=0.0d0
  real*8 :: factor_laser3=0.0d0  
  real*8 :: factor_static_ef=0.0d0
  real*8 :: laser1_start_x,laser1_end_x,laser1_start_y,laser1_end_y,laser1_start_z,laser1_end_z
  real*8 :: laser2_start_x,laser2_end_x,laser2_start_y,laser2_end_y,laser2_start_z,laser2_end_z
  real*8 :: laser3_start_x,laser3_end_x,laser3_start_y,laser3_end_y,laser3_start_z,laser3_end_z
  ! add in field from external file
  real*8,dimension(:,:),allocatable  :: laser_xyz_t ! cody: read (laser) external field xyz from file 
  real*8  :: laser_xyz_t_iteration(3)     ! external field from file for current iteration
  character(255) :: laser_xyz_filename ! cody: name for xyz external field information
  logical :: using_v_fromfile=.FALSE.  ! cody: flag to use xyz external field information
  integer :: laser_xyz_t_number        ! number of data points for which xyz external field is present
  ! real*8  :: laser1_diss_TOD,laser2_diss_TOD,laser3_diss_TOD ! cody: disspersion 3rd order
  ! real*8  :: laser1_diss_FOD,laser2_diss_FOD,laser3_diss_FOD ! cody: disspersion 3rd order
  
  logical :: calculate_forces !compute forces on ions after ground state is done (works only for grid)
  logical :: print_ion_forces=.FALSE. ! cody print forces on ions to file 
  
  logical :: use_projectile,use_vdw,damping_vdw
  real*8  :: projectile_v0
  real*8  :: projectile_x,projectile_y,projectile_z
  real*8  :: projectile_x_prev,projectile_y_prev,projectile_z_prev
  real*8  :: projectile_x0,projectile_y0,projectile_z0
  real*8  :: projectile_nx,projectile_ny,projectile_nz
  real*8  :: projectile_nx0,projectile_ny0,projectile_nz0
  real*8  :: projectile_vx,projectile_vy,projectile_vz
  real*8  :: projectile_mass    !user input in atomic units of mass (carbon =12.0), but the program
                                !converts it to eV*fs^2/A^2
  real*8  :: projectile_invmass !in A^2/(eV*fs^2)
  real*8  :: projectile_charge  !in elementary charges (proton=+1, electron=-1)
  real*8  :: projectile_energy,projectile_energy0  !in eV
  real*8  :: projectile_potential_soft_param
  real(8) :: projectile_f(3)
  logical :: output_projectile_trajectory
  logical :: add_projectile_to_gs=.FALSE.
  logical :: print_dipole_moment_projectile=.FALSE.
  
  !defines how frequently off-diagonal matrix elements of the Hamiltonian should
  !be monitored and how many extreme values reported
  integer :: offdiag_elem_check_frequency
  integer :: num_large_offdiag_elem_reported
  !lode and lodeind will be used for storing a few largest off-diagonal elements
  !and the indicies of the associated orbitals
  complex*8,allocatable  :: lode(:)
  integer,allocatable :: lodeind(:,:)

  !Checkpointing
  logical  :: use_checkpoint
  integer  :: checkpoint_save_frequency

  ! Complex absorbing potential
  real*8                          :: cap_left,cap_right,cap_left1,cap_right1,cap_left2,cap_right2,cap_left3,cap_right3
  real*8,dimension(:),allocatable :: captotal
  integer :: injection_x1,injection_x2,injection_y1,injection_y2,injection_z1,injection_z2
  real*8  :: injection_E
  ! Wave packet propagation
  real*8 :: wp_width(3),wp_momentum(3),wp_center(3)

  ! Controls for mixing
  integer :: mixer_type,mixer_hist,mixer_ninit,mixer_nkick
  real*8  :: mixer_beta,mixer_weight,mixer_ibeta,mixer_kbeta
  real*8  :: mixer_beta_min, mixer_beta_max, mixer_a0
  real(8) :: mixer_dyn_f1, mixer_dyn_f2
  logical :: mixer_abeta, mixer_dynamic
  ! SCF loop break condition
  real*8  :: ediff, pdiff

  logical :: output_dipole_moment

  !Optical absorption (linear response)
  integer :: dipole_direction
  real*8  :: exp_kick_strength,exp_kick_radius
  real*8  :: exp_kick_center_x,exp_kick_center_y,exp_kick_center_z
  logical :: dip_mom_region_inf
  real*8  :: dip_mom_region_radius
  real*8  :: dip_mom_region_center_x,dip_mom_region_center_y,dip_mom_region_center_z
  real*8  :: dpm_stretch_x,dpm_stretch_y,dpm_stretch_z
  integer :: dp_nxb,dp_nyb,dp_nzb
  real*8,allocatable :: dp_xb(:),dp_yb(:),dp_zb(:)
  real*8,allocatable :: dp_sectioned(:,:,:)

  ! Periodic
  real*8,allocatable,dimension(:) :: Phi_r,Phi_i,T_Phi_r,T_Phi_i,V_nl_pp_r,V_nl_pp_i,H_Phi_r,H_Phi_i
  complex*16,allocatable          :: wkin_p(:),wphi_p(:,:,:),wlap_p(:,:),Phi_p(:),Psi_p(:,:,:)

  ! K points
  integer                           :: N_k_points
  real*8,allocatable,dimension(:,:) :: K_vec,Sp_Energy_periodic,Occupation_periodic

  complex*16,allocatable            :: H_Phi_c(:),Phi_c(:),Psi_c(:,:),Vpot(:),T_Phi_c(:),V_nl_pp_c(:)
  complex*16,allocatable            :: Phi_wp(:),Phi_o_wp(:),test(:,:)

  integer                           :: ln1=2,ln2=2,ln3=2
  logical                           :: nl_pp_just_created=.true.

  ! used in single point source injection cody and shenglai
  complex*16,allocatable            :: Phi_source(:) ! injected 
  complex*16,allocatable            :: Phi_source_previous(:) 
  real*8,allocatable                :: Phi_source_density(:), Phi_source_density_previous(:) ! output density and track convergence of injected orbital   
  logical                           :: output_source_td_density=.FALSE.
  logical                           :: inject_source_nonsingular=.FALSE.  
  integer                           :: output_source_td_dens_frequency=50
  integer                           :: source_check_congerg_freq=10
  real*8                            :: source_converg_value1=1.0d-5,source_converg_value2=1.0d-8
  
  
 ! Declaration of variables used in calculation of forces and in molecular dynamics
 real*8,dimension(:,:),allocatable :: force,atom_velocity
 real*8                            :: av_kin_energy_ions,tot_kin_energy_ions
 real*8                            :: temperature_ions
 !md_damping_coeff (if nonzero) specifies the strength of damping (i.e. friction) for
 !ionic motion. This number should be equal to the fraction of velocity lost during a single
 !time step. Thus, the allowed range for md_damping_coeff is [0,1)
 !Damping may be used in order to do geometry optimization in time-dependent calculations
 real*8   :: md_damping_coeff
 !save_trajectory determines whether ion trajectories should be saved in xyz-file
 logical                          :: save_trajectory
 !trajectory_output_frequency defines the writing frequency into trajectory_file
 integer                          :: trajectory_output_frequency
 
 ! Possible values for moldyn_output_level:
 ! 0 - none
 ! 1 - iter, time, temperature, coordinates
 ! 2 - iter, time, temperature, tot.kin.energy, laser.electric.field, coordinates
 ! 3 - iter, time, temperature, tot.kin.energy, laser.electric.field, coordinates,
 !     coordinate of the center of mass, velocity of the center of mass,
 !     velocities, forces
 integer                          :: moldyn_output_level
 real(8)                          :: total_mass_of_all_atoms
 real(8),dimension(:),allocatable :: atomic_mass

  ! total memory tracked by print memory (in mb)
  integer*8 :: memtot=0

  integer :: ion_velocity_init_seed
  logical :: input_initial_velocity !Arthur
  integer :: boosted_orbital !shenglai
  logical :: boost=.false. !shenglai
  character(1) :: kpoint_type

  ! cody    optimization grid routine 
  integer :: N_opt_grid_steps=10
  real(8) :: opt_grid_step_size=0.02  ! step size parameter in Angstrom
  real(8) :: opt_grid_force_k=1        ! force parameter in eV/Angstrom
  
  !cody mask function in 3d with volkov propagation
   ! input 
  logical            :: use_mask_volkov=.FALSE.,volkov_save_dens=.FALSE.
  real*8             :: volkov_distance(3)=(/0.d0,0.d0,0.d0/) ! set in control file with volkov_distance1=100.d0 volkov_distance2=100.d0 etc. 
  real*8             :: volkov_mask_depth=5.d0
  !integer*8          :: FFTplanF,FFTplanR ! FFTW3 plans
  integer            :: mask_func_freq=50,volkov_save_dens_freq
  real*8             :: volkov_capparm=50.d0
  real*8             :: volkov_capdist_x=15.d0,volkov_capdist_y=15.d0,volkov_capdist_z=15.d0
  
  ! cody        split operator volkov method
  logical            :: use_split_op_volkov=.FALSE.
  complex*16,allocatable   :: vso_kpsi(:,:,:,:),vso_kphi(:,:,:),vso_rphi(:,:,:)
  complex*16,allocatable   :: phi_c2(:)
  real*8   :: mysteryconstant,maxv1clc,debugmaxeleinc
  integer  :: debugmaxele
  
CONTAINS

SUBROUTINE convert_to_lowercase(string)
  integer          :: i
  character(len=*) :: string
  character        :: the_char

  do i=1,len(string)
    the_char=string(i:i)
    if((iachar(the_char)>=iachar("A")).AND.(iachar(the_char)<=iachar("Z"))) then
      the_char=achar(iachar(the_char)+(iachar('a')-iachar('A')))
    endif
    string(i:i)=the_char
  enddo
END SUBROUTINE convert_to_lowercase

FUNCTION check_trailing_slash(string)
  integer          :: i,length
  character(len=*) :: string
  character*255    :: check_trailing_slash

  length=len(trim(adjustl(string)))
  i=index(trim(adjustl(string)),'/',.TRUE.)
  if(i==length) then
    write(check_trailing_slash,'(a)')trim(adjustl(string))
  else
    write(check_trailing_slash,'(2a)')trim(adjustl(string)),'/'
  endif
END FUNCTION check_trailing_slash

FUNCTION timestamp()
  character(8)  :: the_date
  character(10) :: time
  character(5)  :: zone
  character*255 :: timestamp

  call date_and_time(the_date,time,zone)
  write(timestamp,'(a,2x,a,2x,a)')the_date,time,zone
END FUNCTION timestamp

SUBROUTINE sort(values)
  ! Sort the values
  integer :: swapped,i,num_values
  real*8  :: difference,difference_threshold,temp,values(:)
  logical :: ascending_order

  ascending_order=.FALSE.
  difference_threshold=1.d-5

  num_values=size(values)
  swapped=1
  do while(swapped==1)
    swapped=0
    do i=1,(num_values-1)
      if(ascending_order) then
        difference=values(i)-values(i+1)
      else
        difference=values(i+1)-values(i)
      endif
      if(difference>difference_threshold) then
        temp=values(i)
        values(i)=values(i+1)
        values(i+1)=temp
        swapped=1
      endif
    enddo
  enddo
END SUBROUTINE sort

subroutine printmem(note,n,s)
  ! note should explain what the allocation is or where to find it
  ! n is the number of elements allocated
  ! s is number of bytes per element
  character(len=*) :: note
  integer          :: n,s
  real*8           :: mem

  mem = dfloat(n) / 1048576.d0
  mem = mem * dfloat(s)
  memtot=memtot+mem

if(mem<0) write(memory_log_file,*)"!!! mem<0 in printmem; n,s,note = ",n,s,trim(adjustl(note))
  write(memory_log_file,'(3a,F16.4,a)')"memory: ",trim(adjustl(note)),": ",mem," MB"
end subroutine printmem

subroutine printmemtot()
  write(memory_log_file,*) 'memtot: ',memtot
end subroutine printmemtot

END MODULE MOD_GLOBAL
