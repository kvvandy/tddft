Module Taylor_extended
  USE MOD_GLOBAL
  USE PSEUDOPOTENTIAL
  use moldynamics
  USE HAMILTON
implicit none



Contains

subroutine Nonlocal_pseudo_potential_c(phi,Vphi)
!This subroutine evaluates the action of the nonlocal 
!pseudopotential on a complex-valued orbital phi. The result
!is returned in Vphi
complex*16 :: phi(N_Lattice_points),Vphi(N_Lattice_points)
!Local variables
integer    :: j,it,grid,lm,atom
real*8     :: r1,r2,r3,kr,wi1,wi2,wr1,wr2
complex*16 :: uV_Psi((L_max+1)**2)
real*8     :: f((L_max+1)**2)
complex*16 :: ctemp

!$omp parallel do default(shared) private (j)
do j=1,N_Lattice_points
  Vphi(j)=(0.d0,0.d0)
enddo
!$omp end parallel do
nl_pp_just_created=.false.

do atom=1,N_total_atom
  it=atom_index(atom)
  if(z_atom(it).ne.0) then
    uV_Psi=(0.d0,0.d0)
    !$omp parallel do default(shared) &
    !$omp private (j, grid, lm) &
    !$omp reduction(+: uV_Psi)
    do j=1,num_ps_points(atom)
      grid=ps_grid(j,atom)
      do lm=1,(Max_L_pp(it)+1)**2
        if(abs(uVu(lm,it)).gt.pp_uVu_epsilon) then
          uV_Psi(lm)=uV_Psi(lm)+uV(lm,j,atom)*phi(grid)
        endif
      enddo     
    enddo
    !$omp end parallel do

    do lm=1,(Max_L_pp(it)+1)**2
      if(abs(uVu(lm,it)).gt.pp_uVu_epsilon) f(lm)=Grid_Volume/uVu(lm,it)
    enddo

    !This loop cannot be omp-parallelized as the value of index variable grid might be repeated
    do j=1,num_ps_points(atom)
      grid=ps_grid(j,atom)
      ctemp=(0.d0,0.d0)
      !Summation over the points inside the supercell
      do lm=1,(Max_L_pp(it)+1)**2
        if(abs(uVu(lm,it)).gt.pp_uVu_epsilon) ctemp=ctemp+uV(lm,j,atom)*f(lm)*uV_Psi(lm)
      enddo
      Vphi(grid)=Vphi(grid)+ctemp
    enddo
  endif
enddo
end subroutine Nonlocal_pseudo_potential_c


subroutine add_projectile_potential(matr,sw)
real*8  :: matr(N_lattice_points),sw
integer :: i
real*8  :: x,y,z,ff
ff=E2*sw*projectile_charge
!$omp parallel do &
!$omp default(shared) &
!$omp private (i, x, y, z)
do i=1,N_lattice_points
  x=Grid_Point(1,i)-projectile_x
  y=Grid_Point(2,i)-projectile_y
  z=Grid_Point(3,i)-projectile_z
  matr(i)=matr(i)-ff/sqrt(x**2+y**2+z**2+projectile_potential_soft_param**2)
enddo
!$omp end parallel do
end subroutine add_projectile_potential

subroutine Hamiltonian_wavefn_c(it,sw,phi,Hphi)
!Calculates the action of time-dependent Hamiltonian on a complex-valued orbital phi
!Input variables:     
!   sw - A switch, which controls the addition of the explicitly time-dependent component of
!        the potential (i.g. laser). Normally it should be set to 1.0d0. However, it can be set to
!        0.0d0 or any other constant if needed.  
!   it - Current iteration 
!  phi - A linear array containing the orbital |phi>
!Output variables:
! Hphi - A linear array containing H|phi>
integer    :: it
real*8     :: sw
complex*16 :: phi(N_lattice_points),Hphi(N_lattice_points)
!complex*16,dimension(:),allocatable :: cphi1
!Local variables:
integer    :: i,i1,i2,i3,j,k
real*8     :: ramp,pulse(3),t,mrd,sf
complex*16 :: wlap_x

!allocate(cphi1(N_Lattice_points))
t=it*time_step
ramp=1.d0
if((ramp_time>0.d0).AND.(t<ramp_time)) ramp=t/ramp_time

pulse=1.d0

if(using_v_laser1) then
  if (laser_envelope_type1=='gaussian') then
    if(laser_pulse_width1>0) then
      pulse(1)=exp(-((t-laser_pulse_shift1)/laser_pulse_width1)**2)
      if(abs(pulse(1))<1d-20) pulse(1)=0.d0
    endif
    time_factor(1)=pulse(1)*sin(laser_frequency1*(t-laser_pulse_shift1)+laser_phase1)
  endif   
  if (laser_envelope_type1=='fermi') then
    pulse(1)=1.0d0-1.0d0/(1.0d0+exp((t-laser_envelope_up_point1)/laser_envelope_up_steepness1))
    time_factor(1)=pulse(1)*sin(laser_frequency1*(t-laser_envelope_up_point1)+laser_phase1)
  endif 
  if (laser_envelope_type1=='doublefermi') then
    pulse(1)=1.0d0-1.0d0/(1.0d0+exp((t-laser_envelope_up_point1)/laser_envelope_up_steepness1))
    pulse(1)=pulse(1)/(1.0d0+exp((t-laser_envelope_down_point1)/laser_envelope_down_steepness1))
    time_factor(1)=pulse(1)*sin(laser_frequency1*(t-laser_envelope_up_point1)+laser_phase1)
  endif 
  factor_laser1=time_factor(1)*ramp*sw
endif

if(using_v_laser2) then
  if (laser_envelope_type2=='gaussian') then
    if(laser_pulse_width2>0) then
      pulse(2)=exp(-((t-laser_pulse_shift2)/laser_pulse_width2)**2)
      if(abs(pulse(2))<1d-20) pulse(2)=0.d0
    endif
    time_factor(2)=pulse(2)*sin(laser_frequency2*(t-laser_pulse_shift2)+laser_phase2)
  endif   
  if (laser_envelope_type2=='fermi') then
    pulse(2)=1.0d0-1.0d0/(1.0d0+exp((t-laser_envelope_up_point2)/laser_envelope_up_steepness2))
    time_factor(2)=pulse(2)*sin(laser_frequency2*(t-laser_envelope_up_point2)+laser_phase2)
  endif 
  if (laser_envelope_type2=='doublefermi') then
    pulse(2)=1.0d0-1.0d0/(1.0d0+exp((t-laser_envelope_up_point2)/laser_envelope_up_steepness2))
    pulse(2)=pulse(2)/(1.0d0+exp((t-laser_envelope_down_point2)/laser_envelope_down_steepness2))
    time_factor(2)=pulse(2)*sin(laser_frequency2*(t-laser_envelope_up_point2)+laser_phase2)
  endif 
  factor_laser2=time_factor(2)*ramp*sw
endif

if(using_v_laser3) then
  if (laser_envelope_type3=='gaussian') then
    if(laser_pulse_width3>0) then
      pulse(3)=exp(-((t-laser_pulse_shift3)/laser_pulse_width3)**2)
      if(abs(pulse(3))<1d-20) pulse(3)=0.d0
    endif
    time_factor(3)=pulse(3)*sin(laser_frequency3*(t-laser_pulse_shift3)+laser_phase3)
  endif   
  if (laser_envelope_type3=='fermi') then
    pulse(3)=1.0d0-1.0d0/(1.0d0+exp((t-laser_envelope_up_point3)/laser_envelope_up_steepness3))
    time_factor(3)=pulse(3)*sin(laser_frequency3*(t-laser_envelope_up_point3)+laser_phase3)
  endif 
  if (laser_envelope_type3=='doublefermi') then
    pulse(3)=1.0d0-1.0d0/(1.0d0+exp((t-laser_envelope_up_point3)/laser_envelope_up_steepness3))
    pulse(3)=pulse(3)/(1.0d0+exp((t-laser_envelope_down_point3)/laser_envelope_down_steepness3))
    time_factor(3)=pulse(3)*sin(laser_frequency3*(t-laser_envelope_up_point3)+laser_phase3)
  endif 
  factor_laser3=time_factor(3)*ramp*sw
endif


sf=1.0d0
if (suppress_field_upon_ion_motion) then
  if (.not.field_suppression_on) then
    mrd=max_abs_rel_displacement_ions(Position,Position_init,closest_ion_init)
    if (mrd>field_suppression_trd) then
      field_suppression_start_time=t
      field_suppression_on=.true.
      write(log_file,*) 'field_suppression_start_time : ',field_suppression_start_time
    endif 
  endif 
  if (field_suppression_on) then
    sf=exp(-abs((t-field_suppression_start_time)/field_suppression_timescale)**field_suppression_power)
    factor_laser1=factor_laser1*sf
    factor_laser2=factor_laser2*sf
    factor_laser3=factor_laser3*sf 
    factor_static_ef=factor_static_ef*sf
  endif  
endif 

if (using_v_ext) then
  factor_static_ef=ramp*sw
endif

if (using_v_step) then
 V_td = ramp*V_steppot
end if

if ((using_v_laser1).and.(using_v_laser2).and.(using_v_laser3).and.(using_v_ext)) then
!$omp parallel workshare
V_td=factor_laser1*V_laser1+factor_laser2*V_laser2+factor_laser3*V_laser3+factor_static_ef*V_ext
!$omp end parallel workshare
endif
if ((.not.using_v_laser1).and.(using_v_laser2).and.(using_v_laser3).and.(using_v_ext)) then
!$omp parallel workshare
V_td=factor_laser2*V_laser2+factor_laser3*V_laser3+factor_static_ef*V_ext
!$omp end parallel workshare
endif
if ((using_v_laser1).and.(.not.using_v_laser2).and.(using_v_laser3).and.(using_v_ext)) then
!$omp parallel workshare
V_td=factor_laser1*V_laser1+factor_laser3*V_laser3+factor_static_ef*V_ext
!$omp end parallel workshare
endif
if ((using_v_laser1).and.(using_v_laser2).and.(.not.using_v_laser3).and.(using_v_ext)) then
!$omp parallel workshare
V_td=factor_laser1*V_laser1+factor_laser2*V_laser2+factor_static_ef*V_ext
!$omp end parallel workshare
endif
if ((using_v_laser1).and.(using_v_laser2).and.(using_v_laser3).and.(.not.using_v_ext)) then
!$omp parallel workshare
V_td=factor_laser1*V_laser1+factor_laser2*V_laser2+factor_laser3*V_laser3
!$omp end parallel workshare
endif
if ((.not.using_v_laser1).and.(.not.using_v_laser2).and.(using_v_laser3).and.(using_v_ext)) then
!$omp parallel workshare
V_td=factor_laser3*V_laser3+factor_static_ef*V_ext
!$omp end parallel workshare
endif
if ((.not.using_v_laser1).and.(using_v_laser2).and.(.not.using_v_laser3).and.(using_v_ext)) then
!$omp parallel workshare
V_td=factor_laser2*V_laser2+factor_static_ef*V_ext
!$omp end parallel workshare
endif
if ((.not.using_v_laser1).and.(using_v_laser2).and.(using_v_laser3).and.(.not.using_v_ext)) then
!$omp parallel workshare
V_td=factor_laser2*V_laser2+factor_laser3*V_laser3
!$omp end parallel workshare
endif
if ((using_v_laser1).and.(.not.using_v_laser2).and.(.not.using_v_laser3).and.(using_v_ext)) then
!$omp parallel workshare
V_td=factor_laser1*V_laser1+factor_static_ef*V_ext
!$omp end parallel workshare
endif
if ((using_v_laser1).and.(.not.using_v_laser2).and.(using_v_laser3).and.(.not.using_v_ext)) then
!$omp parallel workshare
V_td=factor_laser1*V_laser1+factor_laser3*V_laser3
!$omp end parallel workshare
endif
if ((using_v_laser1).and.(using_v_laser2).and.(.not.using_v_laser3).and.(.not.using_v_ext)) then
!$omp parallel workshare
V_td=factor_laser1*V_laser1+factor_laser2*V_laser2
!$omp end parallel workshare
endif
if ((.not.using_v_laser1).and.(.not.using_v_laser2).and.(.not.using_v_laser3).and.(using_v_ext)) then
!$omp parallel workshare
V_td=factor_static_ef*V_ext 
!$omp end parallel workshare
endif
if ((.not.using_v_laser1).and.(.not.using_v_laser2).and.(using_v_laser3).and.(.not.using_v_ext)) then
!$omp parallel workshare
V_td=factor_laser3*V_laser3
!$omp end parallel workshare
endif
if ((.not.using_v_laser1).and.(using_v_laser2).and.(.not.using_v_laser3).and.(.not.using_v_ext)) then
!$omp parallel workshare
V_td=factor_laser2*V_laser2 
!$omp end parallel workshare
endif
if ((using_v_laser1).and.(.not.using_v_laser2).and.(.not.using_v_laser3).and.(.not.using_v_ext)) then
!$omp parallel do default(shared) private (i)
do i=1,N_Lattice_points
  V_td(i)=factor_laser1*V_laser1(i) 
enddo  
!$omp end parallel do
endif
if ((.not.using_v_laser1).and.(.not.using_v_laser2).and.(.not.using_v_laser3).and.(.not.using_v_ext).and.(.not.using_v_step).and.(.not.using_v_fromfile)) then
!$omp parallel workshare
V_td=0.0d0
!$omp end parallel workshare
endif  

if(using_v_laser1) laser_xyz_t_iteration(1)=factor_laser1*E_laser1
if(using_v_laser2) laser_xyz_t_iteration(2)=factor_laser2*E_laser2
if(using_v_laser3) laser_xyz_t_iteration(3)=factor_laser3*E_laser3

 ! V_laser1 V_laser2 V_laser3 is set in subroutine setup_lattice as  x, y, z operators
if(using_v_fromfile) then ! cody 
   if (it <= laser_xyz_t_number) then
	  laser_xyz_t_iteration(1) = laser_xyz_t(2,it)
	  laser_xyz_t_iteration(2) = laser_xyz_t(3,it)
	  laser_xyz_t_iteration(3) = laser_xyz_t(4,it)
      !$omp parallel do default(shared) private (i)
	  do i=1,N_Lattice_points
        V_td(i)=laser_xyz_t_iteration(1)*V_laser1(i) + laser_xyz_t_iteration(2)*V_laser2(i) + laser_xyz_t_iteration(3)*V_laser3(i)
      enddo
	  !$omp end parallel do
	  write(log_file,'(A,3E15.8)') ' Eext=', laser_xyz_t_iteration(1) , laser_xyz_t_iteration(2) , laser_xyz_t_iteration(3) 
   else
      laser_xyz_t_iteration(1)=0.d0
	  laser_xyz_t_iteration(2)=0.d0
	  laser_xyz_t_iteration(3)=0.d0
      !$omp parallel workshare
      V_td=0.0d0
      !$omp end parallel workshare
	  write(log_file,*) ' Eext= 0.0 0.0 0.0'
   endif
   
endif

! cody  I think this should be moved as the projectile potential need only be updated ever step
if (use_projectile) then
call add_projectile_potential(V_td,sw)
endif

if(grid_type==1) call Kinetic_c(phi,T_phi_c)
if(grid_type==2) call lf_Kinetic_c(phi,T_phi_c)   
if(grid_type==3) call lf_Kinetic_fast_c(phi,T_phi_c)   

call Nonlocal_pseudo_potential_c(phi,V_nl_pp_c)  

if((spin_polarized).and.(spin_down)) then
  if(using_cap) then
    !$omp parallel workshare
    Hphi=V_nl_pp_c+T_Phi_c+(V_l_pp+V_Hartree+V_Exchange_down+V_td+sw*zi*captotal)*phi
    !$omp end parallel workshare
  else
    !$omp parallel workshare
    Hphi=V_nl_pp_c+T_Phi_c+(V_l_pp+V_Hartree+V_Exchange_down+V_td)*phi
    !$omp end parallel workshare
  endif
  endif
  if((spin_polarized).and.(spin_up)) then
  if(using_cap) then
    !$omp parallel workshare
    Hphi=V_nl_pp_c+T_Phi_c+(V_l_pp+V_Hartree+V_Exchange_up+V_td+sw*zi*captotal)*phi
    !$omp end parallel workshare
  else
    !$omp parallel workshare
    Hphi=V_nl_pp_c+T_Phi_c+(V_l_pp+V_Hartree+V_Exchange_up+V_td)*phi
    !$omp end parallel workshare
  endif
  endif
  if(.not.spin_polarized) then
  if((using_cap).and.(.not.add_projector_cap)) then
    !$omp parallel do default(shared) private (i)
    do i=1,N_Lattice_points      
      Hphi(i)=V_nl_pp_c(i)+T_Phi_c(i)+(V_l_pp(i)+V_Hartree(i)+V_Exchange(i)+V_td(i)+sw*zi*captotal(i))*phi(i)
   enddo
  else if((using_cap).and.(add_projector_cap)) then
  ! Cap does not absorb ground state orbitals --shenglai
    cphi=0
    do i=1,N_orbitals
       cphi=cphi+(captotal*dot_product(Psi(:,i),phi)*Psi(:,i)+dot_product(phi_cap(:,i)-cap_m_phi(:,i),phi)*Psi(:,i))*Grid_volume
    enddo
   do i=1,N_Lattice_points
      Hphi(i)=V_nl_pp_c(i)+T_Phi_c(i)+(V_l_pp(i)+V_Hartree(i)+V_Exchange(i)+V_td(i)+sw*zi*captotal(i))*phi(i)-sw*zi*cphi(i)
  enddo
  else
    !$omp parallel do default(shared) private (i)
    do i=1,N_Lattice_points     
      Hphi(i)=V_nl_pp_c(i)+T_Phi_c(i)+(V_l_pp(i)+V_Hartree(i)+V_Exchange(i)+V_td(i))*phi(i)
    enddo  
    !$omp end parallel do
  endif
endif
!deallocate(cphi)
end subroutine Hamiltonian_wavefn_c



subroutine V_wavefn_c_noLaser
implicit none
  integer :: i
  real*8  :: sw=1.d0
  V_td=0.d0
  if (use_projectile) then
    call add_projectile_potential(V_td,sw)
  endif  
  
  call Nonlocal_pseudo_potential_c(Phi_c,V_nl_pp_c)
  H_Phi_c=0.d0
if((spin_polarized).and.(spin_down)) then
  if(using_cap) then
    !$omp parallel workshare
    H_Phi_c=V_nl_pp_c+(V_l_pp+V_Hartree+V_Exchange_down+V_td+sw*zi*captotal)*Phi_c
    !$omp end parallel workshare
  else
    !$omp parallel workshare
    H_Phi_c=V_nl_pp_c+(V_l_pp+V_Hartree+V_Exchange_down+V_td)*Phi_c
    !$omp end parallel workshare
  endif
  endif
  if((spin_polarized).and.(spin_up)) then
  if(using_cap) then
    !$omp parallel workshare
    H_Phi_c=V_nl_pp_c+(V_l_pp+V_Hartree+V_Exchange_up+V_td+sw*zi*captotal)*Phi_c
    !$omp end parallel workshare
  else
    !$omp parallel workshare
    H_Phi_c=V_nl_pp_c+(V_l_pp+V_Hartree+V_Exchange_up+V_td)*Phi_c
    !$omp end parallel workshare
  endif
  endif
  if(.not.spin_polarized) then
  if((using_cap).and.(.not.add_projector_cap)) then
    !$omp parallel do default(shared) private (i)
    do i=1,N_Lattice_points      
      H_Phi_c(i)=V_nl_pp_c(i)+(V_l_pp(i)+V_Hartree(i)+V_Exchange(i)+V_td(i)+sw*zi*captotal(i))*Phi_c(i)
   enddo
  else if((using_cap).and.(add_projector_cap)) then
  ! removed
   write(*,*) "if((using_cap).and.(add_projector_cap)) removed"
   stop
  else
    !$omp parallel do default(shared) private (i)
    do i=1,N_Lattice_points     
      H_Phi_c(i)=V_nl_pp_c(i)+(V_l_pp(i)+V_Hartree(i)+V_Exchange(i)+V_td(i))*Phi_c(i)
    enddo  
    !$omp end parallel do
  endif
endif
  
end subroutine V_wavefn_c_noLaser

subroutine lf_kinetic_fast_c(phi,Tphi)
!Evaluates the action of the kinetic energy operator on a complex
!orbital phi. This is a fast Lagrange function version. The result is returned in Tphi. 
complex*16 :: phi(N_lattice_points),Tphi(N_lattice_points)
integer    :: i,i1,i2,i3,j1,j2,j3
complex*16 :: t

Tphi=(0.d0,0.d0)
!$omp parallel do default(shared) &
!$omp private (i, i1, i2, i3, j1, j2, j3, t)
do i=1,N_Lattice_points
  i1=Lattice(1,i)+1; i2=Lattice(2,i)+1; i3=Lattice(3,i)+1
  t=(0.d0,0.d0)   
  do j1=max(1,i1-N_gc(1)),min(i1+N_gc(1),N_Lattice(1))
        t=t+tm1(j1,i1)*phi(Lattice_inv_xyz(j1,i2,i3))
  enddo
  do j2=max(1,i2-N_gc(2)),min(i2+N_gc(2),N_Lattice(2))
        t=t+tm2(j2,i2)*phi(Lattice_inv_yzx(j2,i3,i1))
  enddo
  do j3=max(1,i3-N_gc(3)),min(i3+N_gc(3),N_Lattice(3))
        t=t+tm3(j3,i3)*phi(Lattice_inv_zxy(j3,i1,i2))
  enddo
  Tphi(i)=t  
enddo
!$omp end parallel do
end subroutine lf_kinetic_fast_c

subroutine lf_kinetic_c(phi,Tphi)
!Evaluates the action of the kinetic energy operator on a complex
!orbital phi. This is a Lagrange function version. The result is returned in Tphi. 
complex*16 :: phi(N_lattice_points),Tphi(N_lattice_points)
integer    :: i,i1,i2,i3,j1,j2,j3
complex*16 :: t

!$omp parallel do default(shared) &
!$omp private (i, i1, i2, i3, j1, j2, j3, t)
do i=1,N_Lattice_points
  i1=Lattice(1,i)+1; i2=Lattice(2,i)+1; i3=Lattice(3,i)+1
  t=(0.d0,0.d0)
  do j1=1,N_Lattice(1)
    t=t+tm1(j1,i1)*phi(Lattice_inv_xyz(j1,i2,i3))
  enddo
  do j2=1,N_Lattice(2)
    t=t+tm2(j2,i2)*phi(Lattice_inv_yzx(j2,i3,i1))
  enddo
  do j3=1,N_Lattice(3)
    t=t+tm3(j3,i3)*phi(Lattice_inv_zxy(j3,i1,i2))
  enddo
  Tphi(i)=t
enddo
!$omp end parallel do
end subroutine lf_kinetic_c

SUBROUTINE kinetic_c(phi,Tphi)
!Evaluates the action of the kinetic energy operator on a complex
!orbital phi. The result is returned in Tphi. 
complex*16 :: phi(N_lattice_points),Tphi(N_lattice_points) 
integer  :: i1,i2,i3,grid

!$omp parallel do &
!$omp default(shared) &
!$omp private (grid, i1, i2, i3)
do grid=1,N_lattice_points
  i1=Lattice(1,grid)
  i2=Lattice(2,grid)
  i3=Lattice(3,grid)
  wphi_c(i1,i2,i3)=phi(grid)
enddo
!$omp end parallel do
call laplacian_c(wphi_c,Tphi)
end subroutine kinetic_c

subroutine split_propagator_grid(iter)
implicit none
  integer :: iter,i,k,n,maxele
  complex*16 :: tc(N_taylor),Phi_c2(N_Lattice_points),tc2(N_taylor),Phi_T(N_Lattice_points)
  real*8     :: maxv1
  
  do i=1,N_taylor
    tc(i)=(-zi*time_step/hbar)**i
    do k=1,i
      tc(i)=tc(i)/k
    enddo
  enddo
  do i=1,N_taylor
    tc2(i)=(-zi*0.5d0*time_step/hbar)**i
    do k=1,i
      tc2(i)=tc2(i)/k
    enddo
  enddo  
  
  do n=1,N_orbitals
    Phi_c=Psi_c(:,n)
	Phi_c2=Phi_c

    maxv1=0.d0
	do i=1,N_Lattice_points
	  if(abs(Psi_c(i,n))>maxv1) then
	    maxv1=abs(Psi_c(i,n))
		maxele=i
	  end if
	end do	
	
    write(log_file,'(i2,a,i6,2es28.15e3)') n," max ele ",maxele,real(Phi_c(maxele)),imag(Phi_c(maxele))
	
	!write(77700000+n*10000+iter*100+0,'(2es30.16e3)')  Phi_c
	do i=1,N_taylor
	  call Kinetic_c(Phi_c2,Phi_T)
      Phi_c2=Phi_T
	  Phi_c=Phi_c+tc2(i)*Phi_c2
	end do
    Phi_c2=Phi_c
	
    write(log_file,'(i2,a,i6,2es28.15e3)') n," max eleK",maxele,real(Phi_c(maxele)),imag(Phi_c(maxele))
	!write(77700000+n*10000+iter*100+1,'(2es30.16e3)')  Phi_c
	do i=1,N_taylor
	  call V_wavefn_c_noLaser
      Phi_c=H_Phi_c
	  Phi_c2=Phi_c2+tc(i)*Phi_c
	end do	
	Phi_c=Phi_c2
	
    write(log_file,'(i2,a,i6,2es28.15e3)') n," max eleV",maxele,real(Phi_c(maxele)),imag(Phi_c(maxele))
	!write(77700000+n*10000+iter*100+2,'(2es30.16e3)')  Phi_c
	do i=1,N_taylor
	  call Kinetic_c(Phi_c2,Phi_T)
      Phi_c2=Phi_T
	  Phi_c=Phi_c+tc2(i)*Phi_c2
	end do
	
    write(log_file,'(i2,a,i6,2es28.15e3)') n," max eleK",maxele,real(Phi_c(maxele)),imag(Phi_c(maxele))
	!write(77700000+n*10000+iter*100+3,'(2es30.16e3)')  Phi_c
	Psi_c(:,n)=Phi_c
  end do
  
  

end subroutine split_propagator_grid

end Module Taylor_extended