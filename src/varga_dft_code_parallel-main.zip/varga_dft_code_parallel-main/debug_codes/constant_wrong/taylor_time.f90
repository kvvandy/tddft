MODULE  TAYLOR_TIME
  USE MOD_GLOBAL
  USE PSEUDOPOTENTIAL
  USE HAMILTON
  USE MASK_VOLKOV
  use moldynamics
  use taylor_extended
  implicit none
  real*8                          :: E_wp,Norm_wp
  real*8,dimension(:),allocatable :: density_wp(:)
  complex*16                      :: tc(N_taylor)
  real*8,allocatable              :: o_t(:,:),h_t(:,:),psi_t(:,:),psi_tt(:,:),eig_val(:),eig_vec(:,:),b_t(:,:),psi_st(:,:)
  real*8,allocatable              :: h_r(:,:),h_0(:,:)
  complex*16,allocatable          :: c_proj(:,:)
  integer                         :: n_orbitals_t  
  INTEGER, DIMENSION (1)          :: seed = (/3/)
  real*8   :: PREV_ENE
  
  integer :: td_NL_counter
 ! real(4),dimension(:),allocatable,::sing_prec_rearranged_potential

  !variables for lanczos propagation
!  real*8,dimension(:),allocatable :: Dp
  integer                         :: n_lanczos,n_lanczos_basis
  complex*16,allocatable          :: c(:),q(:,:,:),q2(:,:),z(:),l_prop(:,:,:),lanczos_basis(:,:)
  complex*16,allocatable          :: l_basis_prop(:,:),proj_basis(:),cv_basis(:)
  complex*16,allocatable          :: am(:,:),bm(:,:),zo(:,:),cb(:),q_l(:,:)
  complex*16, allocatable         :: h_lanczos(:,:),o_lanczos(:,:),oi_lanczos(:,:)
  real*8, parameter           :: cap0=0.2d0


CONTAINS

subroutine gs_init(icase)
USE RADIAL_BASIS
  implicit none
  integer      :: i,j,orbital,k,icase,ii,j1,j2,ii2,l
  real*8       :: fk,norm
  complex*16   :: su
  complex*16,allocatable   :: proj(:),cv(:),pt(:,:)

  n_lanczos=num_lanczos_vec

  !small cleanup
  if(allocated(z)) deallocate(z)

allocate(c(n_lattice_points),z(n_lattice_points),q2(n_lattice_points,0:n_lanczos+1))
!n_orbitals_t=n_lanczos*n_orbitals
n_orbitals_t=n_orbitals*n_lanczos
allocate(psi_t(n_lattice_points,n_orbitals_t),h_t(n_orbitals_t,n_orbitals_t))
allocate(eig_val(n_orbitals_t),eig_vec(n_orbitals_t,n_orbitals_t))
allocate(o_t(n_orbitals_t,n_orbitals_t),b_t(n_orbitals_t,n_orbitals_t))
allocate(proj(n_orbitals_t),cv(n_orbitals_t),pt(n_orbitals_t,n_orbitals_t))
allocate(c_proj(n_orbitals_t,n_orbitals))
allocate(h_r(n_orbitals_t,n_orbitals_t))
allocate(h_0(n_orbitals_t,n_orbitals_t))

  CALL RANDOM_SEED (PUT=seed)

    k=0
    do i=1,n_orbitals
      Phi_c(:)=Psi(:,i)
      do j=1,n_lanczos
         !Arthur's notes: Hamiltonian_wavefn is for real but Phi_c,H_Phi_c complex??
         !call Hamiltonian_wavefn(Phi,H_Phi) !uhhh?
         call Hamiltonian_wavefn_c(0,1.d0,Phi_c,H_Phi_c)
         k=k+1
         !Arthur's notes: explicitly cast complex as real
         do l=1,n_lattice_points
            Psi_t(l,k)=REAL(phi_c(l))
         end do
         norm=sum(H_Phi_c(:)**2)*grid_volume
         Phi_c(:)=h_Phi_c(:)/sqrt(norm)
      end do
   end do

  call  diag_orbitals(0)
  
  fk=0.01d0
!  icase=1

  !Arthur's notes: if icase=1,2, or 3 give psi kick in direction x,y, or z respectively.
  !if icase=-1 no kick
  if(icase.NE.-1) then
     do i=1,n_orbitals_t
        do j=1,i
           su=(0.d0,0.d0)
           do k=1,N_lattice_points
              su=su+Psi_t(k,j)*Psi_t(k,i)*exp(zi*fk*grid_point(icase,k))*grid_volume
           end do
           pt(i,j)=su
           pt(j,i)=pt(i,j)
        end do
     end do
  else if(icase.EQ.-1) then
     do i=1,n_orbitals_t
        do j=1,i
           su=(0.d0,0.d0)
           do k=1,N_lattice_points
              su=su+Psi_t(k,j)*Psi_t(k,i)*grid_volume
           end do
           pt(i,j)=su
           pt(j,i)=pt(i,j)
        end do
     end do
  end if

  do orbital=1,N_orbitals

    do i=1,n_orbitals_t
      c_proj(i,orbital)=sum(Psi_t(:,i)*Psi(:,orbital))*grid_volume
    end do

    do i=1,n_orbitals_t
      su=(0.d0,0.d0)
      do k=1,n_orbitals_t    
        su=su+pt(i,k)*c_proj(k,orbital)
      end do
      cv(i)=su
    end do
    c_proj(:,orbital)=cv(:)
  end do

  call calc_wf

deallocate(proj,cv,pt)

end subroutine gs_init

subroutine calc_wf
  implicit none
  integer     :: i,k,orbital

  do orbital=1,N_orbitals
    Psi_c(:,orbital)=(0.d0,0.d0)
    do k=1,n_orbitals_t    
      do i=1,N_lattice_points
        Psi_c(i,orbital)=Psi_c(i,orbital)+c_proj(k,orbital)*Psi_t(i,k)
      end do
    end do     
  enddo

end subroutine calc_wf

subroutine diag_orbitals(it)
USE MOD_GLOBAL
USE HAMILTON
implicit none
integer             :: i,j,k,iter,it,orbital,nn,kk,l,m
complex*16          :: su
complex*16,allocatable :: cv(:)
real*8              :: norm
!real*8,allocatable  :: v_time(:)

allocate(cv(n_orbitals_t))
allocate(psi_tt(n_lattice_points,n_orbitals_t),psi_st(n_lattice_points,n_orbitals_t))
!allocate(v_time(N_lattice_points))


psi_st=psi_t
nn=1
kk=4
if(it==0) then
  nn=10
  kk=4
endif

do iter=1,nn
   do j=1,kk
      call conjugate_gradient_t(it)
      call orthogonalization_t
   end do

   ! calculate the matrix elements 
   do i=1,n_orbitals_t
      Phi_c(:)=Psi_t(:,i)
      call Hamiltonian_wavefn_c(it,1.d0,Phi_c,H_Phi_c)
      do j=1,i
         h_t(i,j)=sum(Psi_t(:,j)*H_Phi_c(:))*grid_volume
         h_t(j,i)=h_t(i,j)
         o_t(i,j)=sum(Psi_t(:,j)*Phi_c(:))*grid_volume
         o_t(j,i)=o_t(i,j)
      end do
   end do

   call diag3(h_t,o_t,n_orbitals_t,n_orbitals_t,eig_val,eig_vec)
   do i=1,n_orbitals_t
      write(6,*)i,eig_val(i)
   end do
   write(6,*)

   Psi_tt=Psi_t
   Psi_t=0.d0
   do i=1,n_orbitals_t
      do j=1,n_orbitals_t
         Psi_t(:,i)=Psi_t(:,i)+eig_vec(j,i)*Psi_tt(:,j)
      end do
   end do
   
end do


  do i=1,n_orbitals_t
    do j=1,n_orbitals_t
      b_t(i,j)=sum(Psi_t(:,i)*Psi_st(:,j))*grid_volume
    end do
  end do

  do orbital=1,N_orbitals
    do i=1,n_orbitals_t
      su=(0.d0,0.d0)
      do k=1,n_orbitals_t    
        su=su+b_t(i,k)*c_proj(k,orbital)
      end do
      cv(i)=su
    end do
    c_proj(:,orbital)=cv(:)
  end do

  call calc_wf

  do i=1,n_orbitals_t
    Phi_c(:)=Psi_t(:,i)
    call Hamiltonian_wavefn_c(it,1.d0,Phi_c,H_Phi_c)
    do j=1,i
      h_t(i,j)=sum(Psi_t(:,j)*H_Phi_c(:))*grid_volume
      h_t(j,i)=h_t(i,j)
      o_t(i,j)=sum(Psi_t(:,j)*Phi_c(:))*grid_volume
      o_t(j,i)=o_t(i,j)
    end do
  end do

!  v_time=0.d0
!  if(use_projectile) then
!     call add_projectile_potential(v_time,1.d0)
!  end if

  do i=1,n_orbitals_t
    Phi_c(:)=Psi_t(:,i)
    H_Phi_c=(V_exchange+V_hartree)*Phi_c
!    H_Phi_c=(V_exchange+V_hartree+v_time)*Phi_c
    do j=1,i
      h_r(i,j)=sum(Psi_t(:,j)*H_Phi_c(:))*grid_volume
      h_r(j,i)=h_r(i,j)
    end do
 end do

  h_0=h_t-h_r

!  deallocate(v_time)
  deallocate(cv)
  deallocate(psi_tt,psi_st)
end subroutine diag_orbitals

subroutine gs_time_step(it,lanc)
USE MOD_GLOBAL
USE HAMILTON
implicit none
integer             :: i,j,k,orbital,it
complex*16          :: su
complex*16,allocatable :: cv(:)
complex*16,allocatable :: am(:,:),bm(:,:),zo(:,:)
complex*16,allocatable :: l_prop(:,:)
logical             :: lanc
real*8              :: norm
!real*8,allocatable  :: v_time(:)
allocate(cv(n_orbitals_t),am(n_orbitals_t,n_orbitals_t),bm(n_orbitals_t,n_orbitals_t),zo(n_orbitals_t,n_orbitals_t),l_prop(n_orbitals_t,n_orbitals_t))
!allocate(v_time(N_lattice_points))
! calculate the matrix elements 

!v_time=0.d0
!if(use_projectile) then
!   call add_projectile_potential(v_time,1.d0)
!end if

  do i=1,n_orbitals_t
    Phi_c(:)=Psi_t(:,i)
!    H_Phi_c=(V_exchange+V_hartree+v_time)*Phi_c
    H_Phi_c=(V_exchange+V_hartree)*Phi_c
    do j=1,i
      h_r(i,j)=sum(Psi_t(:,j)*H_Phi_c(:))*grid_volume
      h_r(j,i)=h_r(i,j)
    end do
  end do

  h_t=h_0+h_r



!  do i=1,n_orbitals_t
!    Phi_c(:)=Psi_t(:,i)
!    call Hamiltonian_wavefn_c(it,1.d0,Phi_c,H_Phi_c)
!    do j=1,i
!      h_t(i,j)=sum(Psi_t(:,j)*H_Phi_c(:))*grid_volume
!      h_t(j,i)=h_t(i,j)
!      o_t(i,j)=sum(Psi_t(:,j)*Phi_c(:))*grid_volume
!      o_t(j,i)=o_t(i,j)
!    end do
!  end do

  am=o_t-0.5d0*zi*h_t*time_step/hbar
  zo=o_t+0.5d0*zi*h_t*time_step/hbar 
  
  call inv_c(zo,n_orbitals_t,bm)

  l_prop(:,:)=matmul(bm,am)

  do orbital=1,N_orbitals
    do i=1,n_orbitals_t
      su=(0.d0,0.d0)
      do k=1,n_orbitals_t    
        su=su+l_prop(i,k)*c_proj(k,orbital)
      end do
      cv(i)=su
    end do
    c_proj(:,orbital)=cv(:)
  end do

  call calc_wf

deallocate(cv,am,bm,zo,l_prop)!,v_time)

end subroutine gs_time_step

subroutine generate_orbitals
USE MOD_GLOBAL
USE HAMILTON
implicit none
integer             :: i,j,k,orbital,it
real*8              :: rnum
real*8,allocatable  :: alpha(:),beta(:) 
logical             :: lanc

allocate(alpha(0:n_lanczos),beta(0:n_lanczos))

do i=1,n_orbitals
   Phi_c(:)=Psi(:,i)
   call Hamiltonian_wavefn_c(it,1.d0,Phi_c,H_Phi_c)
   write(6,*)i,sum(Psi(:,i)*H_Phi_c(:))*grid_volume/(sum(Psi(:,i)*Phi_c(:))*grid_volume)
end do

k=0

do orbital=1,n_orbitals
   
   alpha=0.d0; beta=0.d0
   
   c(:)=Psi(:,orbital)
   
   q2(:,0)=(0.d0,0.d0)
   z(:)=(0.d0,0.d0)
   q2(:,1)=c/sqrt(sum(c*c))/sqrt(grid_volume)
   
   do j=1,n_lanczos
      
      Phi(:)=q2(:,j)
      call Hamiltonian_wavefn(Phi,H_Phi)
      z=H_Phi
      
      alpha(j)=sum(q2(:,j)*z(:))*grid_volume
      z(:)=z(:)-alpha(j)*q2(:,j)-beta(j-1)*q2(:,j-1)
      beta(j)=sqrt(sum(z*z))*sqrt(grid_volume)
      q2(:,j+1)=z(:)/beta(j)
   end do
   do j=1,n_lanczos
      k=k+1
      do i=1,n_lattice_points
         !        CALL RANDOM_NUMBER(rnum)
         Psi_t(i,k)=q2(i,j)
      end do
   end do
end do
write(6,*)'ok2'

!  call orthogonalization_t

! calculate the matrix elements 
do i=1,n_orbitals_t
   Phi_c(:)=Psi_t(:,i)
   call Hamiltonian_wavefn_c(it,1.d0,Phi_c,H_Phi_c)
   do j=1,i
      h_t(i,j)=sum(Psi_t(:,j)*H_Phi_c(:))*grid_volume
      h_t(j,i)=h_t(i,j)
      o_t(i,j)=sum(Psi_t(:,j)*Phi_c(:))*grid_volume
    o_t(j,i)=o_t(i,j)
    write(661,*)i,j
    write(661,*)o_t(i,j),h_t(i,j)
 end do
end do


!  write(6,*)'ok3'
   call diag3(h_t,o_t,n_orbitals_t,n_orbitals_t,eig_val,eig_vec)
!   call diag(h_t,n_orbitals_t,eig_val,eig_vec)
  do i=1,n_orbitals_t
     write(6,*)i,eig_val(i)
   end do
   
   allocate(psi_tt(n_lattice_points,n_orbitals_t))   

   Psi_tt=Psi_t
   Psi_t=0.d0
   do i=1,n_orbitals_t
     do j=1,n_orbitals_t
       Psi_t(:,i)=Psi_t(:,i)+eig_vec(j,i)*Psi_tt(:,j)
     end do
   end do

!   write(6,*)'ok4'
   
   deallocate(psi_tt,alpha,beta)
    
end subroutine generate_orbitals

  subroutine conjugate_gradient_t(it)
    !     conjugate gradient minimization to diagonalize the Hamiltonian
    implicit none

    integer                                :: orbital,iteration,i,it,k,j,l,m
    real*8                                 :: Phi_H_Phi,gamma,beta_Phi,&
         &                                                   beta_beta,beta_H_Phi,&
         &                                                   Phi0_Phi0,Phi0_H_Phi0,&
         &                                                   delta,A,B,C,omega,&
         &                                                   overlap
    real*8, dimension(:),allocatable   :: alpha,beta,Phi0,H_Phi0

    allocate(alpha(N_lattice_points),beta(N_lattice_points), &
         &         Phi0(N_lattice_points),H_Phi0(N_Lattice_points))

    do orbital=1,N_orbitals_t

       Phi_c=Psi_t(:,orbital)

       !Arthur's notes: do explicit casting from complex to real
       do k=1,N_lattice_points
          Phi0(k)=REAL(Phi_c(k))
       end do

       call Hamiltonian_wavefn_c(it,1.d0,Phi_c,H_Phi_c)

       !Arthur's notes: do explicit casting from complex to real
       do k=1,N_lattice_points
          H_Phi0(k)=REAL(H_Phi_c(k))
       end do

       !Arthur's notes: do explicit casting from complex to real
       Phi0_H_Phi0=REAL(sum(Phi_c*H_Phi_c))*Grid_Volume

!       Phi0_H_Phi0=0.d0
!       do k=1,N_lattice_points
!          Phi0_H_Phi0=Phi0_H_Phi0+REAL(Phi_c(k)*H_Phi_c(k))*Grid_Volume
!       end do

       Phi0_Phi0=1
       delta=Phi0_H_Phi0

       !Arthur's notes: N_iteration_cg was N_iteration; are these the same?
       do iteration=1,N_iteration_cg
          
          alpha=2*(H_Phi0-delta*Phi0)
          
          
          do i=1,orbital-1
             alpha=alpha-Psi_t(:,i)*sum(Psi_t(:,i)*alpha)*Grid_Volume
          end do
          gamma=sum(alpha*alpha)*Grid_Volume
          if(iteration.eq.1) beta=-alpha
          if(iteration.gt.1) beta=-alpha+gamma/overlap*beta
          overlap=gamma
          beta_Phi=sum(Phi0*beta)*Grid_Volume
          beta_beta=sum(beta*beta)*Grid_Volume
          beta_H_Phi=sum(H_Phi0*beta)*Grid_Volume

          !Arthur's notes: casting from real to complex should be fine
          Phi_c=beta
          call Hamiltonian_wavefn_c(it,1.d0,Phi_c,H_Phi_c)

          !Arthur's notes: do explicit casting from complex to real
          do k=1,N_lattice_points
             alpha(k)=REAL(H_Phi_c(k))
          end do

          !Arthur's notes: do explicit casting from complex to real
          Phi_H_Phi=REAL(sum(Phi_c*H_Phi_c))*Grid_Volume

          A = Phi_H_Phi*beta_Phi  - beta_H_Phi*beta_beta
          B = Phi_H_Phi*Phi0_Phi0   - Phi0_H_Phi0*beta_beta
          C = beta_H_Phi*Phi0_Phi0 - Phi0_H_Phi0*beta_Phi
          omega=(-B+sqrt(B*B-4*A*C))/(2*A)

          !Arthur's notes: do explicit casting from complex to real
          do k=1,N_lattice_points
             Phi0(k) = Phi0(k)   +omega*REAL(Phi_c(k))
             H_Phi0(k) = H_Phi0(k) +omega*REAL(H_Phi_c(k))
          end do

          Phi0_Phi0   =sum(Phi0*Phi0)*Grid_Volume
          Phi0_H_Phi0 =sum(Phi0*H_Phi0)*Grid_Volume
          delta=Phi0_H_Phi0/Phi0_Phi0

       end do

       Phi0_Phi0=sum(Phi0*Phi0)*Grid_Volume

       Psi_t(:,orbital)=Phi0/sqrt(Phi0_Phi0)

    end do

    deallocate(alpha,beta,Phi0,H_Phi0)

  end subroutine conjugate_gradient_t




  SUBROUTINE Orthogonalization_t
    !     Gram-Schmidt orthogonalization
    implicit none

    integer                                     :: orbital,i
    real*8                                      :: s
    real*8                                  :: overlap

    do orbital=1,N_orbitals_t
       do i=1,orbital-1
          overlap=sum(Psi_t(:,i)*Psi_t(:,orbital))*Grid_Volume
          Psi_t(:,orbital)=Psi_t(:,orbital)-overlap*Psi_t(:,i)
       end do
       s=sum(abs(Psi_t(:,orbital))**2)*Grid_Volume
       Psi_t(:,orbital)=Psi_t(:,orbital)/sqrt(s)
    end do

  end subroutine Orthogonalization_t

subroutine lanczos_time_init
USE MOD_GLOBAL
  implicit none

  n_lanczos=num_lanczos_vec

  n_lanczos_basis=n_lanczos*n_orbitals

  allocate(q_l(n_lattice_points,0:n_lanczos+1))
  allocate(q(n_lattice_points,0:n_lanczos+1,n_orbitals),c(n_lattice_points),z(n_lattice_points))
  allocate(l_prop(n_lanczos,n_lanczos,n_orbitals))

  allocate(lanczos_basis(n_lattice_points,n_lanczos_basis))
  allocate(h_lanczos(n_lanczos_basis,n_lanczos_basis))
  allocate(o_lanczos(n_lanczos_basis,n_lanczos_basis))
  allocate(oi_lanczos(n_lanczos_basis,n_lanczos_basis))

  allocate(l_basis_prop(n_lanczos_basis,n_lanczos_basis),proj_basis(n_lanczos_basis),cv_basis(n_lanczos_basis),cb(n_lanczos_basis))
  
  allocate(am(n_lanczos_basis,n_lanczos_basis))
  allocate(bm(n_lanczos_basis,n_lanczos_basis))
  allocate(zo(n_lanczos_basis,n_lanczos_basis))


end subroutine lanczos_time_init

subroutine lanczos_time_step(it,lanc)
USE MOD_GLOBAL
USE HAMILTON
implicit none
integer             :: i,j,k,orbital,it
real*8              :: alpha(0:n_lanczos),beta(0:n_lanczos)
complex*16          :: cv(n_lanczos),su,proj(n_lanczos),a_proj(n_lanczos)
real*8              :: ev(n_lanczos),bv(n_lanczos),a(n_lanczos,n_lanczos)
logical             :: lanc

do orbital=1,n_orbitals
  
  c(:)=Psi_c(:,orbital)

  if(lanc) then

    ev=0.d0; bv=0.d0; a=0.d0; beta=0.d0
  
    q(:,0,orbital)=(0.d0,0.d0)
    z(:)=(0.d0,0.d0)
    q(:,1,orbital)=c/sqrt(sum(Conjg(c)*c))/sqrt(grid_volume)

    do j=1,n_lanczos

      Phi_c(:)=q(:,j,orbital)
      call Hamiltonian_wavefn_c(it,1.d0,Phi_c,H_Phi_c)
      z=H_Phi_c

      alpha(j)=sum(Conjg(q(:,j,orbital))*z(:))*grid_volume
      z(:)=z(:)-alpha(j)*q(:,j,orbital)-beta(j-1)*q(:,j-1,orbital)
      beta(j)=sqrt(sum(Conjg(z)*z))*sqrt(grid_volume)
      q(:,j+1,orbital)=z(:)/beta(j)
    end do
  
    a=0.d0
    do i=1,n_lanczos
      ev(i)=alpha(i)
      if(i.ne.n_lanczos) bv(i+1)=beta(i)
      a(i,i)=1.d0
    end do

    call tqli(ev,bv,n_lanczos,n_lanczos,a)

    do i=1,n_lanczos
      do j=1,n_lanczos
        su=(0.d0,0.d0)
        do k=1,n_lanczos    
          su=su+a(i,k)*exp(-zi*time_step*ev(k)/hbar)*a(j,k)
        end do
        l_prop(i,j,orbital)=su
      end do      
    end do

  endif


  do i=1,n_lanczos
    proj(i)=sum(conjg(q(:,i,orbital))*c(:))*grid_volume
  end do
  write(50,*)sum(proj(:)**2)

  do i=1,n_lanczos
    su=(0.d0,0.d0)
    do k=1,n_lanczos    
      su=su+l_prop(i,k,orbital)*proj(k)
    end do
    cv(i)=su
  end do

  do i=1,N_lattice_points
    su=(0.d0,0.d0)
    do k=1,n_lanczos    
      su=su+q(i,k,orbital)*cv(k)
    end do
    c(i)=su
  end do
  Psi_c(:,orbital)=c(:)
end do

    
end subroutine lanczos_time_step

subroutine lanczos_cn_time_step(it,lanc)
USE MOD_GLOBAL
USE HAMILTON
implicit none
integer                :: i,j,k,orbital,it
real*8,allocatable     :: alpha(:),beta(:)
complex*16             :: su
complex*16,allocatable :: cv(:),proj(:),a_proj(:)
real*8,allocatable     :: ev(:),bv(:),a(:,:)
logical                :: lanc
complex*16,allocatable :: am(:,:),bm(:,:),zo(:,:) 
complex*16,allocatable :: o_l(:,:),h_l(:,:)

allocate(alpha(0:n_lanczos),beta(0:n_lanczos))
allocate(cv(n_lanczos),proj(n_lanczos),a_proj(n_lanczos))
allocate(ev(n_lanczos),bv(n_lanczos),a(n_lanczos,n_lanczos))
allocate(am(n_lanczos,n_lanczos),bm(n_lanczos,n_lanczos),zo(n_lanczos,n_lanczos))
allocate(o_l(n_lanczos,n_lanczos),h_l(n_lanczos,n_lanczos))

do orbital=1,n_orbitals
  
  c(:)=Psi_c(:,orbital)

  if(lanc) then

    ev=0.d0; bv=0.d0; a=0.d0; beta=0.d0
  
    q(:,0,orbital)=(0.d0,0.d0)
    z(:)=(0.d0,0.d0)
    q(:,1,orbital)=c/sqrt(sum(Conjg(c)*c))/sqrt(grid_volume)

    do j=1,n_lanczos

      Phi_c(:)=q(:,j,orbital)
      call Hamiltonian_wavefn_c(it,1.d0,Phi_c,H_Phi_c)
      z=H_Phi_c

      alpha(j)=sum(Conjg(q(:,j,orbital))*z(:))*grid_volume
      z(:)=z(:)-alpha(j)*q(:,j,orbital)-beta(j-1)*q(:,j-1,orbital)
      beta(j)=sqrt(sum(Conjg(z)*z))*sqrt(grid_volume)
      q(:,j+1,orbital)=z(:)/beta(j)
    end do

  endif
  
! calculate the matrix elements in the Lanczos basis
    do i=1,n_lanczos
      Phi_c(:)=q(:,i,orbital)
      call Hamiltonian_wavefn_c(it,1.d0,Phi_c,H_Phi_c)
      do j=1,i
        h_l(i,j)=sum(Conjg(q(:,j,orbital))*H_Phi_c(:))*grid_volume
        h_l(j,i)=Conjg(h_l(i,j))
        o_l(i,j)=sum(Conjg(q(:,j,orbital))*Phi_c(:))*grid_volume
        o_l(j,i)=Conjg(o_l(i,j))
      end do
    end do   
  


  am=o_l-0.5d0*zi*h_l*time_step/hbar
  zo=o_l+0.5d0*zi*h_l*time_step/hbar 
  
  call inv_c(zo,n_lanczos,bm)

  l_prop(:,:,orbital)=matmul(bm,am)

  

  do i=1,n_lanczos
    proj(i)=sum(conjg(q(:,i,orbital))*c(:))*grid_volume
  end do
  write(50,*)sum(proj(:)**2)

  do i=1,n_lanczos
    su=(0.d0,0.d0)
    do k=1,n_lanczos    
      su=su+l_prop(i,k,orbital)*proj(k)
    end do
    cv(i)=su
  end do

  do i=1,N_lattice_points
    su=(0.d0,0.d0)
    do k=1,n_lanczos    
      su=su+q(i,k,orbital)*cv(k)
    end do
    c(i)=su
  end do
  Psi_c(:,orbital)=c(:)

end do

deallocate(alpha,beta)
deallocate(cv,proj,a_proj)
deallocate(ev,bv,a)
deallocate(am,bm,zo)
deallocate(o_l,h_l)

end subroutine lanczos_cn_time_step

subroutine taylor_time_init
USE BOX_AB
integer :: i,k
real*8  :: x,y,z,t,a_0,p0x,p0y,p0z
integer :: k1min,k1max,k2min,k2max,k3min,k3max

do i=1,N_taylor
tc(i)=(-zi*time_step/hbar)**i
do k=1,i
 tc(i)=tc(i)/k
enddo
enddo

write(log_file,*)'tc',tc

if(allocated(H_Phi_c)) deallocate(H_Phi_c)
if(allocated(Phi_c)) deallocate(Phi_c)
if(allocated(V_nl_pp_c)) deallocate(V_nl_pp_c)
if(allocated(T_Phi_c)) deallocate(T_Phi_c)
if(allocated(vpot)) deallocate(vpot)
if(allocated(wphi_c)) deallocate(wphi_c)

allocate(H_phi_c(N_lattice_points),Phi_c(N_lattice_points))
allocate(Vpot(N_lattice_points),T_Phi_c(N_lattice_points),V_nl_pp_c(N_Lattice_points))
!$omp parallel do default(shared) private (i)
do i=1,N_Lattice_points  
  V_nl_pp_c(i)=(0.d0,0.d0)
enddo    
!$omp end parallel do 
k1min=N_Lattice_min(1)
k1max=N_Lattice_max(1)
k2min=N_Lattice_min(2)
k2max=N_Lattice_max(2)
k3min=N_Lattice_min(3)
k3max=N_Lattice_max(3)
allocate(wphi_c(k1min-Nd-1:k1max+Nd,k2min-Nd-1:k2max+Nd,k3min-Nd-1:k3max+Nd))
wphi_c=cmplx(0.0d0,0.0d0,8)
td_NL_counter=0
if (boost) call boost_wavefunction
! time propagation of wave packet
if(tddft_type==3) then
allocate(Phi_wp(N_Lattice_points),density_wp(N_lattice_points),Phi_o_wp(N_lattice_points))
! initialize wave packet
a_0=wp_width(1)
p0x=wp_momentum(1)
p0y=wp_momentum(2)
p0z=wp_momentum(3)
t=0.d0
write(log_file,*)'Wave_packet momentum',wp_momentum
write(log_file,*)'Wave_packet center',wp_center
do i=1,N_lattice_points
  x=grid_point(1,i)-wp_center(1)
  y=grid_point(2,i)-wp_center(2)
  z=grid_point(3,i)-wp_center(3)
  Phi_wp(i)=Gauss_wave_packet_3d(x,y,z,t,a_0,p0x,p0y,p0z)
end do
  if(use_high_energy_wp) then

  else
    write(log_file,*)'initial wave_packet norm',sum(abs(Phi_wp)**2)*grid_volume
    Phi_c=Phi_wp
    call Hamiltonian_wavefn_c(0,1.d0,Phi_c,H_Phi_c)
    write(log_file,*)'initial wave_packet energy',sum(Conjg(Phi_c)*H_Phi_c)*Grid_Volume
  endif
endif

  write(log_file,*) "Propagator set to ",trim(adjustl(propagator))

end subroutine taylor_time_init

subroutine taylor_time_step_wave_packet(it)
  ! This only propagates a gaussian wave packet
  USE BOX_MODUL
  USE BOX_AB
  integer    :: k,n,it,j,j1,j2,orbital,kk,i
  complex*16 :: s

  ! Time step
  Phi_c=Phi_wp
  do n=1,N_taylor
    if(periodic) then
      call Hamiltonian_wavefn_periodic(1)
    else
      call Hamiltonian_wavefn_c(it,1.d0,Phi_c,H_Phi_c)
    endif
    Phi_c=H_Phi_c
    Phi_wp(:)=Phi_wp(:)+tc(n)*Phi_c(:)
  enddo

  ! Density
  do k=1,N_lattice_points
    density_wp(k)=real(Phi_wp(k))**2+imag(Phi_wp(k))**2
  enddo
  if(mod(it,td_data_output_frequency)==0) call plot_wp(it)

  ! Projection of occupied states
  Phi_o_wp=(0.d0,0.d0)
  do orbital=1,N_orbitals
    Phi_c=(0.d0,0.d0)
    do j=1,N_diag
      j1=basis_atom(1,j)
      j2=basis_atom(2,j)
      do k=1,int_points(j2)
        kk=Ind_basis(k,j2)
        Phi_c(kk)=Phi_c(kk)+cf_basis(j,orbital)*Psi_basis_r(k,j)
      enddo
    enddo
    s=sum(Phi_wp*Conjg(Phi_c))*grid_volume
    Phi_o_wp=Phi_o_wp+s*Phi_c
  enddo
  Phi_wp=Phi_wp-Phi_o_wp
  s=sum(Conjg(Phi_wp)*Phi_wp)*grid_volume
  Phi_wp=Phi_wp/sqrt(s)

!  check orthogonality
!
!  do orbital=1,N_orbitals
!    Phi_c=(0.d0,0.d0)
!    do j=1,N_diag
!      j1=basis_atom(1,j)
!      j2=basis_atom(2,j)
!      do k=1,int_points(j2)
!        kk=Ind_basis(k,j2)
!        Phi_c(kk)=Phi_c(kk)+cf_basis(j,orbital)*Psi_basis_r(k,j)
!      end do
!    end do
!    s=sum(Phi_wp*Conjg(Phi_c))*grid_volume
!    write(log_file,*)'ortho?',orbital,s
!  end do


! this is time consuming and not really needed...
  Phi_c=Phi_wp
  if(periodic) then
    call Hamiltonian_wavefn_periodic(1)
  else
    call Hamiltonian_wavefn_c(it,1.d0,Phi_c,H_Phi_c)
  endif

  norm_wp=sum(abs(Phi_wp)**2)*grid_volume
  E_wp=sum(Conjg(Phi_c)*H_Phi_c)*grid_volume/norm_wp
end subroutine taylor_time_step_wave_packet


subroutine taylor_time_step(it,sw)
  integer :: k,n,it,i
  real*8  :: sw
  complex*16 :: tc_n

  do k=1,N_orbitals
    orbital_index=k
    !$omp parallel do default(shared) private (i)
    do i=1,N_Lattice_points    
      Phi_c(i)=Psi_c(i,k)
    enddo  
    !$omp end parallel do     
    
    if(spin_polarized) then
      if(k<N_orbitals_down+1) then
        spin_down=.TRUE.
        spin_up=.FALSE.
      else
        spin_up=.TRUE.
        spin_down=.FALSE.
      endif
    endif  
    do n=1,N_taylor
      call Hamiltonian_wavefn_c(it,sw,Phi_c,H_Phi_c)
      !$omp parallel do default(shared) private (i)
      do i=1,N_Lattice_points  
        Phi_c(i)=H_Phi_c(i)
      enddo  
      !$omp end parallel do
      tc_n=tc(n)
      !$omp parallel do default(shared) private (i)
      do i=1,N_Lattice_points  
        Psi_c(i,k)=Psi_c(i,k)+tc_n*Phi_c(i)
      enddo  
      !$omp end parallel do 
    enddo
  enddo
end subroutine taylor_time_step


subroutine taylor_time_evolution
  select case (tddft_type)
    case(1)
      write(log_file,*)'tddft_type: time_propagation_optical_absorbtion'
      call taylor_time_evolution_optical_absorbtion
    case(2)
      write(log_file,*)'tddft_type: time_propagation_laser'
      call taylor_time_evolution_laser
    case(3)
      write(log_file,*)'tddft_type: time_propagation_wave_packet'
      call time_propagation_wave_packet_grid
    case(4)
      write(log_file,*)'tddft_type: taylor_time_evolution_projectile'
      call taylor_time_evolution_projectile
    case(5)
      write(log_file,*)'tddft_type: taylor_time_source_injection'
      call source_prop
    case default
      write(log_file,*)'no tddft_type is defined'
      stop
  end select
end subroutine taylor_time_evolution


subroutine taylor_time_evolution_projectile
  integer :: i,restart_last_i
  real*4  :: t1,t2
  real*8  :: s,dipolemoment
  real*8  :: energy_init_elec,energy_final_elec,energy_init_ions,energy_final_ions
  logical :: lanc=.true.

  if(box_basis_type==0) then
    allocate(Psi_c(N_lattice_points,N_orbitals))
  else
    write(log_file,*)"ERROR: box_basis_type/=0 in taylor_time_evolution_projectile"
    stop
  endif
  Psi_c=Psi

  projectile_energy0=projectile_energy
  if (use_projectile) then
    write(log_file,*)'Parameters of the projectile'
    write(log_file,*)'particle mass [in eV*fs^2/Ang^2]: ',projectile_mass
    write(log_file,*)'particle mass [in gram/mol]: ',projectile_mass/mass_convfactor
    write(log_file,*)'particle charge [in elem. charges]: ',projectile_charge
    write(log_file,*)'point of start (x0,y0,z0) [Ang]: '
    write(log_file,*) '  ',projectile_x0,projectile_y0,projectile_z0
    write(log_file,*)'initial velocity (vx0,vy0,vz0) [Ang/fs]: '
    write(log_file,*) '  ',projectile_vx,projectile_vy,projectile_vz
    write(log_file,*)'initial speed [Ang/fs]: ',projectile_v0
    write(log_file,*)'initial speed [fraction of speed of light]: ',projectile_v0/c_light
    write(log_file,*)'initial energy [eV]: ',projectile_energy0
    write(log_file,*)'initial energy [fraction of particle rest energy]: ', &
                    projectile_energy0/(projectile_mass*c_squared)
    write(log_file,*)'initial de Broglie wavelength [Ang]: ', &
                      hbar*2*pi/(projectile_mass*projectile_v0)
                    !Relativistic expression:
                    !!(hbar*2*pi/projectile_mass)*sqrt(1/projectile_v0**2-1/c_squared)
    write(log_file,*)'initial direction (nx,ny,nz) [unit vector]:  '
    write(log_file,*) '  ',projectile_nx,projectile_ny,projectile_nz
    write(log_file,*)'projectile potential softening parameter: ',projectile_potential_soft_param
  else
     write(log_file,*)'Initial parameters of the projectile: projectile not used in this run'
  endif
  call taylor_time_init
  if(propagator=="lanczos".OR.propagator=="lanczos_cn") call lanczos_time_init
  if(propagator=="lanczos_gs") call gs_init(-1)
  call calculate_rho_grid

  ! cody for restart, load Psi_C, ionX, ionV, Projectile_info, and iteration number
  restart_last_i=1
  if( resume_from_restart_taylor == .TRUE.) then  
     if(propagator=="lanczos".OR.propagator=="lanczos_cn".OR.propagator=="lanczos_gs") then
	    write(log_file,*) 'Read restart has not been tested with lanczos propagators!'
		stop
	 end if
     call restart_file_read_elec(restart_last_i)
	 write(log_file,*) 'Read in Psi_c from Restart'
	 if(use_projectile) then
	    call restart_file_read_proj(restart_last_i)
		write(log_file,*) 'Read in projectile info from Restart'
		write(log_file,*) 'Current projectile velocity direction (vx,vy,vz):'
        write(log_file,*) '  ',projectile_vx,projectile_vy,projectile_vz
		write(log_file,*) 'Current projectile position (x,y,z):'
        write(log_file,*) '  ',projectile_x,projectile_y,projectile_z
	 end if
	 if(move_atoms) then
	    call restart_file_read_ion(restart_last_i)
		 write(log_file,*) 'Read in ion positions from Restart'
   	    call calculate_rho_grid
        call Hamiltonian_density
        call background()
        if ((use_fine_grid).or.(grid_type>1)) then
          call lf_create_pseudo_potential()
        else
          call create_pseudo_potential() 
        endif
        call local_pseudo_potential()  
        call ion_ion_energy()
        call calculate_force()
	 end if
	 write(log_file,*) 'last iteration written to restart was ',restart_last_i
	 ! increment the iteration so as not to repeat that timestep
	 restart_last_i=restart_last_i+1
  end if
  
  call print_orbital_energy_components_header
  call Total_Energy_grid_c(0)
  write(log_file,*)'Starting Energy',Energy
  write(log_file,*)'number of electrons',sum(density)*grid_volume

  if( resume_from_restart_taylor == .FALSE.) then ! do not initialize if loading restart info
     if(use_projectile) call advance_projectile(0)
     if(move_atoms) call make_atom_movement(0)
  end if

  if(output_full_td_density) call output_td_density(0)
  if(output_full_td_current_density) call output_td_current_density(0)
  if(output_orbitals) call save_complex_orbitals(0)
  if(output_orbitals2) call save_complex_orbitals2(0)

  
  
  !Jorge output_td_psi is a flag to enable the output of psi
  if (output_td_psi) call output_Psi_c(0) 
  
  if(output_inner_product) call print_projection_file_header !Arthur
  if(output_inner_product) call update_projection_file(0) !Arthur

  
  do i=restart_last_i,n_time_steps
    if(use_projectile) then
      call advance_projectile(i)
      write(log_file,'(1x,a,3f18.10)') 'projectile coordinates: ', &
                                       projectile_x,projectile_y,projectile_z
      write(log_file,*) 'projectile energy: ',projectile_energy
    endif

    if(propagator=="lanczos".OR.propagator=="lanczos_gs".OR.propagator=="lanczos_cn") then
       lanc=.true.
       if(mod(i,lanczos_update_frequency)/=0) lanc=.false.
       if(i==1) lanc=.true.
    end if

    if(mod(i,lanczos_update_frequency)==0.and.propagator=="lanczos_gs") call diag_orbitals(i)    

    call CPU_TIME(t1)
    !arthur's notes: can choose between lanczos, lanczos_gs, or taylor
    !Intention: phase out either lanczos or lanczos_gs after benchmarks
    if(propagator=="lanczos") then
       call lanczos_time_step(i,lanc)
    else if(propagator=="lanczos_gs") then
       call gs_time_step(i,lanc)
    else if(propagator=="lanczos_cn") then
       call lanczos_cn_time_step(i,lanc)
    else if(propagator=="taylor") then
       call taylor_time_step(i,1.d0)
    endif
    call CPU_TIME(t2); write(timing_file,*)'time1',trim(adjustl(propagator)),t2-t1
    call calculate_rho_grid
    call Hamiltonian_density
    call Total_Energy_grid_c(i)
    !if(mod(i,td_data_output_frequency)==0) then
    !  call plot(i)
    !  call plot_time(i)
    !endif
    ! If enabled, append this time step's density to a file
    if(output_full_td_density.AND.(mod(i,td_density_output_frequency)==0)) then
        call output_td_density(i)
    endif
    ! If enabled, append this time step's current density to a file
    if(output_full_td_current_density.AND.(mod(i,td_current_density_output_frequency)==0)) then
      call output_td_current_density(i)
    endif
    ! If enabled, append this time step's orbitals to files
    if(output_orbitals.AND.(mod(i,td_orbital_output_frequency)==0)) then
        call save_complex_orbitals(i)
    endif  
    if(output_orbitals2.AND.(mod(i,td_orbital_output_frequency)==0)) then
        call save_complex_orbitals2(i)
    endif     
    if(move_atoms) then
      call make_atom_movement(i)
    endif
    if (move_atoms) write(log_file,*)'i(kinet)',tot_kin_energy_ions
    write(log_file,*)i*time_step,sum(Density)*grid_volume,Energy
    if (i==1) then
      energy_init_elec=energy
      energy_init_ions=tot_kin_energy_ions
    endif
    if (i==n_time_steps) then
      energy_final_elec=energy
      energy_final_ions=tot_kin_energy_ions
    endif

!     write(*,*) '=========  i',i,'  =============='
!     write(*,*) 't=',i*time_step
!     write(*,*) 'projectile_x=',projectile_x
!     write(*,*) 'projectile_invmass=',projectile_invmass
!     write(*,*) '1/atomic_mass(1)=',1/atomic_mass(1)
!     write(*,*) 'projectile_f(1)=',projectile_f(1)
!     write(*,*) 'projectile_f(2)=',projectile_f(2)
!     write(*,*) 'projectile_f(3)=',projectile_f(3)
!     write(*,*) 'force(1,1)=',force(1,1)
!     write(*,*) 'force(2,1)=',force(2,1)
!     write(*,*) 'force(3,1)=',force(3,1)
     write(log_file,*)
     
     !Arthur: output Psi_c and a structure file in dft.inp format
     !Jorge output_td_psi is a flag to enable the output of psi
     if ((output_td_psi).AND.(mod(i,psi_output_frequency)==0))  then     
        call output_Psi_c(i)     
     end if
     
     !Arthur: output projections between psi_c and psi
     if((output_inner_product).AND.(mod(i,output_inner_product_frequency)==0)) then
        call update_projection_file(i) !Arthur
     end if

	 ! cody write restart file
     if( write_restart == .TRUE.) then
        restart_update_iter= restart_update_iter + 1
        if ( restart_update_iter >= restart_update_frequency) then
           restart_update_iter=0
	 	   write(log_file,*) 'Write restart files for iteration ',i
	 	   call restart_file_update_elec(i)
	 	   if(move_atoms) then
	 	     call restart_file_update_ion(i)
	 	  end if
		  if(use_projectile) then
		     call restart_file_update_proj(i)
		  end if
        end if
     end if
	 
	 ! print dipole moment -> print_dipole_moment_projectile
	 if( print_dipole_moment_projectile == .TRUE.) then
	   dipolemoment=dipole_moment(1)
	   write(log_file,*) ' DIPOLE_MOMENT_X=',dipolemoment
	   dipolemoment=dipole_moment(2)
	   write(log_file,*) ' DIPOLE_MOMENT_Y=',dipolemoment
	   dipolemoment=dipole_moment(3)
	   write(log_file,*) ' DIPOLE_MOMENT_Z=',dipolemoment	 
	 end if
        
  enddo

  write(log_file,*) 'Energy transfer data [all values in eV]'
  write(log_file,*) 'Initial electronic energy:         ',energy_init_elec
  write(log_file,*) 'Initial kin. energy of ions:       ',energy_init_ions
  write(log_file,*) 'Final electronic energy:           ',energy_final_elec
  write(log_file,*) 'Final kin. energy of ions:         ',energy_final_ions
  write(log_file,*) 'Change in electronic energy:       ',energy_final_elec-energy_init_elec
  write(log_file,*) 'Change in kin. energy of ions:     ',energy_final_ions-energy_init_ions
  write(log_file,*) 'Total amount of energy transferred:', &
       energy_final_elec+energy_final_ions-energy_init_elec-energy_init_ions
  if (use_projectile) then
    write(log_file,*) 'Initial projectile energy:         ',projectile_energy0
    s=1/sqrt(projectile_vx**2+projectile_vy**2+projectile_vz**2)
    projectile_nx=projectile_vx*s
    projectile_ny=projectile_vy*s
    projectile_nz=projectile_vz*s
    write(log_file,*) 'Final projectile energy:           ',projectile_energy
    write(log_file,*) 'Change in projectile energy:       ',projectile_energy-projectile_energy0
    write(log_file,*) 'Initial projectile velocity direction (nx,ny,nz) [unit vector]:'
    write(log_file,*) '  ',projectile_nx0,projectile_ny0,projectile_nz0
    write(log_file,*) 'Final projectile velocity direction (nx,ny,nz) [unit vector]:'
    write(log_file,*) '  ',projectile_nx,projectile_ny,projectile_nz
  endif
  write(log_file,*)
end subroutine taylor_time_evolution_projectile


subroutine advance_projectile(iter)
!Advances projectile position based on classical Newtonian mechanics
integer  :: iter
real(8)  :: pos_x,pos_y,pos_z,vx,vy,vz

if (iter>1) then
  !If second or more iteration then use the usual Verlet algoritm
  pos_x=projectile_x
  projectile_x=2*pos_x-projectile_x_prev+projectile_invmass*projectile_f(1)*time_step**2
  projectile_vx=(1.5d0*projectile_x-2*pos_x+0.5d0*projectile_x_prev)/time_step
  projectile_x_prev=pos_x
  pos_y=projectile_y
  projectile_y=2*pos_y-projectile_y_prev+projectile_invmass*projectile_f(2)*time_step**2
  projectile_vy=(1.5d0*projectile_y-2*pos_y+0.5d0*projectile_y_prev)/time_step
  projectile_y_prev=pos_y
  pos_z=projectile_z
  projectile_z=2*pos_z-projectile_z_prev+projectile_invmass*projectile_f(3)*time_step**2
  projectile_vz=(1.5d0*projectile_z-2*pos_z+0.5d0*projectile_z_prev)/time_step
  projectile_z_prev=pos_z
endif
if (iter==1) then
  !If first iteration then calculate forces on projectile using Taylor expansion
  pos_x=projectile_x
  vx=projectile_vx
  projectile_x=pos_x+vx*time_step+0.5d0*projectile_invmass*projectile_f(1)*time_step**2
  projectile_vx=vx+projectile_invmass*projectile_f(1)*time_step
  projectile_x_prev=pos_x
  pos_y=projectile_y
  vy=projectile_vy
  projectile_y=pos_y+vy*time_step+0.5d0*projectile_invmass*projectile_f(2)*time_step**2
  projectile_vy=vy+projectile_invmass*projectile_f(2)*time_step
  projectile_y_prev=pos_y
  pos_z=projectile_z
  vz=projectile_vz
  projectile_z=pos_z+vz*time_step+0.5d0*projectile_invmass*projectile_f(3)*time_step**2
  projectile_vz=vz+projectile_invmass*projectile_f(3)*time_step
  projectile_z_prev=pos_z
endif
projectile_energy=0.5d0*projectile_mass*(projectile_vx**2+projectile_vy**2+projectile_vz**2)
!Calculate force. This call is done even if it is the zero-th order iteration
call compute_force_on_projectile(projectile_f)

end subroutine advance_projectile


subroutine compute_force_on_projectile(f)
!This subroutine computes force on projectile. The force is the sum of two
!terms. One comes from ion charges, the other comes from the electron density.
!It is assumed that array density contains freshly calculated electron density
!when the this subroutine is called.
real(8)  :: f(3)
real(8)  :: dx,dy,dz,r,s,w
integer  :: i,ai
real(8)  :: f_debug(3)

f(1:3)=0.0d0

s=projectile_charge/E2
!force due to ions
!$omp parallel do if(N_total_atom > 400) &
!$omp default(shared) &
!$omp private (i, dx, dy, dz, r, w, ai) &
!$omp reduction(+: f)
do i=1,N_total_atom
  ai=atom_index(i)
  if (z_atom(ai)/=0) then
    dx=projectile_x-Position(1,i)
    dy=projectile_y-Position(2,i)
    dz=projectile_z-Position(3,i)
    r=sqrt(dx**2+dy**2+dz**2+projectile_potential_soft_param**2)
    w=Charge_pp(ai)*s/r**3
    f(1)=f(1)+w*dx
    f(2)=f(2)+w*dy
    f(3)=f(3)+w*dz
  endif
enddo
!$omp end parallel do

write(*,*) 'force on projectile due to ions, x :',f(1)
write(*,*) 'force on projectile due to ions, y :',f(2)
write(*,*) 'force on projectile due to ions, z :',f(3)

f_debug=0.0
s=-projectile_charge*grid_volume/E2
!force due to electron density
!$omp parallel do &
!$omp default(shared) &
!$omp private (i, dx, dy, dz, r, w) &
!$omp reduction(+: f, f_debug)
do i=1,N_lattice_points
  dx=projectile_x-Grid_Point(1,i)
  dy=projectile_y-Grid_Point(2,i)
  dz=projectile_z-Grid_Point(3,i)
  r=sqrt(dx**2+dy**2+dz**2+projectile_potential_soft_param**2)
  w=s*density(i)/r**3
  f(1)=f(1)+w*dx
  f(2)=f(2)+w*dy
  f(3)=f(3)+w*dz
  f_debug(1)=f_debug(1)+w*dx
  f_debug(2)=f_debug(2)+w*dy
  f_debug(3)=f_debug(3)+w*dz
enddo
!$omp end parallel do
write(*,*) 'force on projectile due to electrons, x :',f_debug(1)
write(*,*) 'force on projectile due to electrons, y :',f_debug(2)
write(*,*) 'force on projectile due to electrons, z :',f_debug(3)

end subroutine compute_force_on_projectile

!Arthur: Why does this subroutine still exist?
SUBROUTINE time_propagation_wave_packet_grid_old
  integer :: i,nt,k,j,iter,it,jm,im,m,kk
  real*4  :: t1,t2


  ! EMPTY BOX

!  if(box_basis_type==0) then
!    allocate(Psi_c(N_lattice_points,N_orbitals))
!  else
!    write(log_file,*)"ERROR: box_basis_type/=0 in taylor_time_evolution_laser"
!  endif
!  Psi_c=Psi

!  call taylor_time_init
!  call calculate_rho_grid
!  write(log_file,*)'number of electrons',sum(density)*grid_volume

!  call hamiltonian_density

!  if(output_full_td_density) call output_td_density(0)
!  if(output_full_td_current_density) call output_td_current_density(0)
  do i=1,n_time_steps
    call CPU_TIME(t1)
    call taylor_time_step_wave_packet(i)
    call CPU_TIME(t2); write(timing_file,*)'time1 taylor',t2-t1
!    call calculate_rho_grid
!    call Hamiltonian_density
!    call Total_Energy_grid_c(i)
!    if(mod(i,td_data_output_frequency)==0) then
!      call plot(i)
!      call plot_time(i)

!      ! If enabled, append this time step's density to a file
!      if(output_full_td_density.AND.(mod(i,td_density_output_frequency)==0)) then
!        call output_td_density(i)
!      endif
!      ! If enabled, append this time step's current density to a file
!      if(output_full_td_current_density.AND.(mod(it,td_current_density_output_frequency)==0)) then
!        call output_td_current_density(i)
!      endif
!    endif
!    write(log_file,*)i*time_step,sum(Density)*grid_volume,Energy
  enddo
END SUBROUTINE time_propagation_wave_packet_grid_old

subroutine time_propagation_wave_packet_grid
  integer :: i,j,k
  real*4  :: t1,t2
  complex*16 :: wtest
  real*8,dimension(:),allocatable         :: Occ_aux  !!! VK temporary array for fixing the issue with WP orbital
  logical :: lanc
  call taylor_time_init
  if(propagator=="lanczos") call lanczos_time_init

  if(box_basis_type==0) then
    allocate(Psi_c(N_lattice_points,N_orbitals))
  else
    write(log_file,*)"ERROR: box_basis_type/=0 in time_propagation_wave_packet_grid"
  endif
    
  
  
  !!!!VK
  ! This is adds a new orbital to hold the wavepacket

  allocate(occ_aux(N_orbitals))
  do i=1,N_orbitals
    Occ_aux(i)=Occupation(i)
  end do
  deallocate(occupation,sp_energy)
  
  
  ! Add a new orbital to hold the wavepacket  
  N_orbitals=N_orbitals+1
    
  allocate(sp_energy(N_orbitals),occupation(N_orbitals))

  do i=1,N_orbitals-1
    Occupation(i)=occ_aux(i)
  end do
  Occupation(N_orbitals)=1.d0

!!!VK
!!!!   End of allocation of orbital for wavepacket    
  
  if(allocated(psi_c)) deallocate(psi_c)
  allocate(psi_c(N_lattice_points,N_orbitals))
  
  do i=1,N_orbitals-1
    do j=1,N_lattice_points
      Psi_c(j,i)=cmplx(Psi(j,i),0.d0,8)
    enddo
  enddo
  
  ! Initialize the orbital for the wavepacket
  if(use_high_energy_wp) then
    do i=1,N_lattice_points
    psi_c(i,N_orbitals)=Gauss_wave_packet_3d_as(grid_point(1,i)-wp_center(1),grid_point(2,i)-wp_center(2), &
	    grid_point(3,i)-wp_center(3),0.d0,wp_width(1),wp_width(2),wp_width(3),0.d0,wp_momentum(2),wp_momentum(3))
    enddo     

    Phi_c(:)=psi_c(:,N_orbitals)
    orbital_index=N_orbitals
    write(log_file,*)'initial wave_packet norm',sum(abs(Phi_c)**2)*grid_volume
    call Hamiltonian_wavefn_c(0,1.d0,Phi_c,H_Phi_c)
    write(log_file,*)'initial wave_packet energy',sum(Conjg(Phi_c)*H_Phi_c)*Grid_Volume



  else
    do i=1,N_lattice_points
    psi_c(i,N_orbitals)=Gauss_wave_packet_3d_as(grid_point(1,i)-wp_center(1),grid_point(2,i)-wp_center(2), &
	    grid_point(3,i)-wp_center(3),0.d0,wp_width(1),wp_width(2),wp_width(3),wp_momentum(1),wp_momentum(2),wp_momentum(3))
    enddo     
  endif
  write(log_file,*)'width',wp_width
  write(log_file,*)'center',wp_center
  write(log_file,*)'momentum',wp_momentum


  ! Density
  do k=1,N_lattice_points
     density_wp(k)=real(psi_c(k,N_orbitals))**2+imag(psi_c(k,N_orbitals))**2   
  enddo
  call plot_wp(i)


  open(666,file="wp_3d.3D")
  write(666,*)"x y z density_wp"
	do k=1,N_lattice_points
	  density_wp(k)=real(psi_c(k,N_orbitals))**2+imag(psi_c(k,N_orbitals))**2
	  if(abs(density_wp(k))<1d-20) density_wp(k)=0.d0
	  write(666,'(4ES16.8)')grid_point(1,k),grid_point(2,k),grid_point(3,k),density_wp(k)
  enddo		  
  close(666)
         
  call calculate_rho_grid
  call print_orbital_energy_components_header
  call Total_Energy_grid_c(0)
  write(log_file,*)'Starting Energy',Energy
  
!	call Hamiltonian_density
  write(log_file,*)'number of electrons',sum(density)*grid_volume

  if(move_atoms) call make_atom_movement(0)

  if(output_full_td_density) call output_td_density(0)
  if(output_full_td_current_density) call output_td_current_density(0)
  if(output_orbitals) call save_complex_orbitals(0)  
  if(output_orbitals2) call save_complex_orbitals2(0)  
  
  !Jorge output_td_psi is a flag to enable the output of psi
  if (output_td_psi) call output_Psi_c(0) 
  
  if(output_inner_product) call print_projection_file_header !Arthur
  if(output_inner_product) call update_projection_file(0) !Arthur  
     
  do i=1,n_time_steps
    write(timing_file,*)"time_propagation_wave_packet_grid: starting iteration ",i

    if(propagator=="lanczos") then
       lanc=.true.
       if(mod(i,lanczos_update_frequency)/=0) lanc=.false.
       if(i==1) lanc=.true.
    end if

    call CPU_TIME(t1)
    if(propagator=="lanczos") then
       call lanczos_time_step(i,lanc)
    else if(propagator=="taylor") then
       call taylor_time_step(i,1.d0)
    endif
    call CPU_TIME(t2); write(timing_file,*)"time_propagation_wave_packet_grid: call to",&
         trim(adjustl(propagator)),"taylor_time_step",t2-t1

    if(mod(i,td_data_output_frequency)==0) then 
       ! Density
       do k=1,N_lattice_points
          density_wp(k)=real(psi_c(k,N_orbitals))**2+imag(psi_c(k,N_orbitals))**2
       enddo
       call plot_wp(i)
       
       do k=1,N_lattice_points
          wtest=Gauss_wave_packet_3d_as(grid_point(1,k)-wp_center(1),grid_point(2,k)-wp_center(2), &
               grid_point(3,k)-wp_center(3),i*time_step,wp_width(1),wp_width(2),wp_width(3),wp_momentum(1),wp_momentum(2),wp_momentum(3))
          density_wp(k)=real(wtest)**2+imag(wtest)**2
       enddo
       call plot_wpa(i)
       



		endif
    
    call CPU_TIME(t1)
    call calculate_rho_grid
    call CPU_TIME(t2); write(timing_file,*)"time_propagation_wave_packet_grid: call to calculate_rho_grid",t2-t1
    
    call CPU_TIME(t1)
    call Hamiltonian_density
    call CPU_TIME(t2); write(timing_file,*)"time_propagation_wave_packet_grid: call to Hamiltonian_density",t2-t1
    
    call CPU_TIME(t1)
    call Total_Energy_grid_c(i)
    call CPU_TIME(t2); write(timing_file,*)"time_propagation_wave_packet_grid: call to Total_Energy_grid_c",t2-t1
    
    if((i==1).OR.(mod(i,td_data_output_frequency)==0)) then
      call CPU_TIME(t1)
      call plot(i)
      call CPU_TIME(t2); write(timing_file,*)"time_propagation_wave_packet_grid: call to plot",t2-t1
      
      call CPU_TIME(t1)
      call plot_time(i)
      call CPU_TIME(t2); write(timing_file,*)"time_propagation_wave_packet_grid: call to plot_time",t2-t1
    endif
    ! If enabled, append this time step's density to a file
    if(output_full_td_density.AND.(mod(i,td_density_output_frequency)==0)) then
      call CPU_TIME(t1)
      call output_td_density(i)
      call CPU_TIME(t2); write(timing_file,*)"time_propagation_wave_packet_grid: call to output_td_density",t2-t1
    endif
    ! If enabled, append this time step's current density to a file
    if(output_full_td_current_density.AND.(mod(i,td_current_density_output_frequency)==0)) then
      call CPU_TIME(t1)
      call output_td_current_density(i)
      call CPU_TIME(t2); write(timing_file,*)"taylor_time_evolution_laser: call to output_td_current_density",t2-t1
    endif 
    ! If enabled, append this time step's orbitals to files
    if(output_orbitals.AND.(mod(i,td_orbital_output_frequency)==0)) then
        call save_complex_orbitals(i)
    endif     
    if(output_orbitals2.AND.(mod(i,td_orbital_output_frequency)==0)) then
        call save_complex_orbitals2(i)
    endif     
    if(move_atoms) then
      call CPU_TIME(t1)
      call make_atom_movement(i)
      call CPU_TIME(t2); write(timing_file,*)"time_propagation_wave_packet_grid: call to make_atom_movement",t2-t1
    endif
    write(log_file,*)i*time_step,sum(Density)*grid_volume,Energy
    
  !Arthur: output Psi_c and a structure file in dft.inp format
    !Jorge output_td_psi is a flag to enable the output of psi
    if ((output_td_psi).AND.(mod(i,psi_output_frequency)==0)) then
       call output_Psi_c(i) 
    end if

    !Arthur: output projections between psi_c and psi                                                     
    if((output_inner_product).AND.(mod(i,output_inner_product_frequency)==0)) then
       call update_projection_file(i) !Arthur 
    end if
    
 enddo
  
  
end subroutine time_propagation_wave_packet_grid

subroutine taylor_time_evolution_laser
  integer :: i,j,restart_last_i
  real*4  :: t1,t2,kick_strength
  real(8) :: ds(3),dpm(3)
  logical :: lanc=.true.
  !Open files for dipole moment data (time vs. dp), and write the appropriate header for analysis with the program "optprop".
  !Note, the parameter kick_strength may need to be revised; it is a constant factor used in optprop.
  kick_strength=0.01d0
  write(log_file,*)'dipole_direction=',dipole_direction,kind(dipole_direction)
  if ((dipole_direction==1) .OR. (dipole_direction==0)) then
    open(dipole_x_file,file=trim(adjustl(dipole_x_filename)),action='write',status='replace')
    write(dipole_x_file,'(1x,i7,2(1x,es16.8))') N_time_steps,time_step,kick_strength
  endif
  if ((dipole_direction==2).OR. (dipole_direction==0)) then
    open(dipole_y_file,file=trim(adjustl(dipole_y_filename)),action='write',status='replace')
    write(dipole_y_file,'(1x,i7,2(1x,es16.8))') N_time_steps,time_step,kick_strength
  endif
  if ((dipole_direction==3) .OR. (dipole_direction==0)) then
    open(dipole_z_file,file=trim(adjustl(dipole_z_filename)),action='write',status='replace')
    write(dipole_z_file,'(1x,i7,2(1x,es16.8))') N_time_steps,time_step,kick_strength
  endif

  if(box_basis_type==0) then
    allocate(Psi_c(N_lattice_points,N_orbitals))
  else
    write(log_file,*)"ERROR: box_basis_type/=0 in taylor_time_evolution_laser"
  endif

! calculate matric elements for projectored CAP --shenglai
if (add_projector_cap) then
  allocate(cap_m(N_orbitals,N_orbitals),phi_cap(N_Lattice_points,N_orbitals),cap_m_phi(N_Lattice_points,N_orbitals),cphi(N_lattice_points))
cap_m=0.d0
phi_cap=0.d0
cap_m_phi=0.d0
  do i=1,N_orbitals
     phi_cap(:,i)=Psi(:,i)*captotal
    do j=1,N_orbitals
      cap_m(i,j)=dot_product(Psi(:,i),captotal*Psi(:,j))*Grid_Volume
      cap_m_phi(:,i)=cap_m_phi(:,i)+cap_m(i,j)*Psi(:,j)
    enddo
  enddo
  deallocate(cap_m)
endif
    
!  Psi_c=Psi
  do i=1,N_orbitals
    do j=1,N_lattice_points
      Psi_c(j,i)=cmplx(Psi(j,i),0.d0,8)
    enddo
  enddo
! if (boost) call boost_wavefunction

  call taylor_time_init
  if(propagator=="lanczos".OR.propagator=="lanczos_cn") call lanczos_time_init
  if(propagator=="lanczos_gs") call gs_init(-1)

  !  cody    mask function and volkov propagation
  if(use_mask_volkov) then
    call init_Volkov
  end if

  
  ! cody for restart, load Psi_C, ionX, ionV, and iteration number
  restart_last_i=1
  if( resume_from_restart_taylor == .TRUE.) then  
     if(propagator=="lanczos".OR.propagator=="lanczos_cn".OR.propagator=="lanczos_gs") then
	    write(log_file,*) 'Read restart has not been tested with lanczos propagators!'
		stop
	 end if
     call restart_file_read_elec(restart_last_i)
	 write(log_file,*) 'Read in Psi_c from Restart'
	 if(move_atoms) then
	    call restart_file_read_ion(restart_last_i)
		 write(log_file,*) 'Read in ion positions from Restart'
   	    call calculate_rho_grid
        call Hamiltonian_density
        call background()
        if ((use_fine_grid).or.(grid_type>1)) then
          call lf_create_pseudo_potential()
        else
          call create_pseudo_potential() 
        endif
        call local_pseudo_potential()  
        call ion_ion_energy()
        call calculate_force()
	 end if
	 write(log_file,*) 'last iteration written to restart was ',restart_last_i
	 ! increment the iteration so as not to repeat that timestep
	 restart_last_i=restart_last_i+1
  end if

  !if (boost) call boost_wavefunction

  if (.not.allocated(wlap_p)) allocate(wlap_p(3,N_Lattice_points))
  wlap_p= (0.D0, 0.D0)   
  if (output_orb_density) then
     do i=1,N_orbitals
      density=0.d0
      do j=1,N_lattice_points
      density(j)=(real(Psi_c(j,i))**2+imag(Psi_c(j,i))**2)*Occupation(i)
      enddo
     call output_td_density(0)
    enddo
    density=0.d0
  endif
  call calculate_rho_grid
  call Hamiltonian_density
  call print_orbital_energy_components_header
  call Total_Energy_grid_c(0)
  write(log_file,*)'Starting Energy',Energy

  write(log_file,*)'number of electrons',sum(density)*grid_volume

  ! do not initialize if restarting
  if((move_atoms).AND.( resume_from_restart_taylor == .FALSE.)) call make_atom_movement(0)
  ds(1)=dipole_moment(1)
  ds(2)=dipole_moment(2)
  ds(3)=dipole_moment(3)
  write(log_file,*) 'Initial dipole moment: ',ds(1),ds(2),ds(3)

  if(output_full_td_density) call output_td_density(0)
  if(output_full_td_current_density) call output_td_current_density(0)
  if(output_orbitals) call save_complex_orbitals(0)  
  if(output_orbitals2) call save_complex_orbitals2(0)
  if(output_full_td_sp_energy) call output_td_SP_energy()
  if(output_inner_product) call print_projection_file_header !Arthur
  if(output_inner_product) call update_projection_file(0) !Arthur
  
  !Jorge output_td_psi is a flag to enable the output of psi
     if (output_td_psi) call output_Psi_c(0)
  
  if((propagator=="split_v_krk")&
   .OR.(propagator=="split_v_rkr")) then
    call init_Volkov_split_op
  end if  
  
  ! debug1          9507176418
  mysteryconstant=0.950717641768289d0
   debugmaxeleinc=0.000000001d0
    maxv1clc=0.d0
	do i=1,N_Lattice_points
	  if(abs(Psi_c(i,1))>maxv1clc) then
	    maxv1clc=abs(Psi_c(i,1))
		debugmaxele=i
	  end if
	end do
  
  do i=restart_last_i,n_time_steps

     if(propagator=="lanczos".OR.propagator=="lanczos_gs".OR.propagator=="lanczos_cn") then
        lanc=.true.
        if(mod(i,lanczos_update_frequency)/=0) lanc=.false.
        if(i==1) lanc=.true.
     end if

    if(mod(i,lanczos_update_frequency)==0.and.propagator=="lanczos_gs") call diag_orbitals(i)

    write(timing_file,*) trim(adjustl(propagator)),"time_evolution_laser: starting iteration ",i
    call CPU_TIME(t1)
    !Arthur's notes: can choose between lanczos, lanczos_gs, taylor
    !intention: phase out lanczos or lanczos_gs after benchmark tests
	
    if(propagator=="lanczos") then
       call lanczos_time_step(i,lanc)
    else if(propagator=="lanczos_gs") then
       call gs_time_step(i,lanc)
    else if(propagator=="lanczos_cn") then
       call lanczos_cn_time_step(i,lanc)
    else if(propagator=="taylor") then	
       call taylor_time_step(i,1.d0)
	else if(propagator=="split_v_krk") then
	   !call volkov_Avec_update
	   call volkov_split_timestep_krk(i)
	else if(propagator=="split_v_rkr") then
	   !call volkov_Avec_update
	   call volkov_split_timestep_rkr(i)
	else if(propagator=="split_grid") then
	   call split_propagator_grid(i)
	else if(propagator=="split_cap") then
	   write(*,*) "not yet available"
	   stop
    end if

!	mysteryconstant=mysteryconstant-debugmaxeleinc
	write(log_file,*) "new mysteryconstant=",mysteryconstant
	do j=1,N_lattice_points
      Phi_c(j)=Psi_c(j,1)
    enddo
	!!write(99900000+i*100+0,'(2es30.16e3)')  Phi_c
	write(log_file,*) "ENERGY_DIFF=",Energy-PREV_ENE
	PREV_ENE=Energy
    !  cody   
    if(use_mask_volkov) then
      call volkov_Avec_update
	  if(mod(i,mask_func_freq)==0) then
        call volkov_time_step(i)
      end if
	
	end if  	
	
	
    call CPU_TIME(t2); write(timing_file,*)trim(adjustl(propagator)),"time_evolution_laser: call to",trim(adjustl(propagator)),"_time_step",t2-t1
    
    call CPU_TIME(t1)
    call calculate_rho_grid
    call CPU_TIME(t2); write(timing_file,*)trim(adjustl(propagator)),"taylor_time_evolution_laser: call to calculate_rho_grid",t2-t1

    call CPU_TIME(t1)
    call Hamiltonian_density
    call CPU_TIME(t2); write(timing_file,*)"taylor_time_evolution_laser: call to Hamiltonian_density",t2-t1
    
    call CPU_TIME(t1)
    call Total_Energy_grid_c(i)
    call CPU_TIME(t2); write(timing_file,*)trim(adjustl(propagator)),"time_evolution_laser: call to Total_Energy_grid_c",t2-t1
    
    if((i==1).OR.(mod(i,td_data_output_frequency)==0)) then
      call CPU_TIME(t1)
      call plot(i)
      call CPU_TIME(t2); write(timing_file,*)trim(adjustl(propagator)),"time_evolution_laser: call to plot",t2-t1
      
      call CPU_TIME(t1)
      call plot_time(i)
      call CPU_TIME(t2); write(timing_file,*)trim(adjustl(propagator)),"time_evolution_laser: call to plot_time",t2-t1
    endif
    ! If enabled, append this time step's density to a file
    if(output_full_td_density.AND.(mod(i,td_density_output_frequency)==0)) then
      call CPU_TIME(t1)
      call output_td_density(i)
      call CPU_TIME(t2); write(timing_file,*)trim(adjustl(propagator)),"time_evolution_laser: call to output_td_density",t2-t1
    endif
    ! If enabled, append this time step's current density to a file
    if(output_full_td_current_density.AND.(mod(i,td_current_density_output_frequency)==0)) then
      call CPU_TIME(t1)
      time1=i
      call output_td_current_density(i)
      call CPU_TIME(t2); write(timing_file,*)trim(adjustl(propagator)),"time_evolution_laser: call to output_td_current_density",t2-t1
    endif
    if ((.not.output_full_td_current_density).AND.output_orb_current.AND.(mod(i,td_orb_current_output_frequency)==0)) then
      call CPU_TIME(t1)
      time1=i
      call output_td_current_density(i)
      call CPU_TIME(t2); write(timing_file,*)trim(adjustl(propagator)),"time_evolution_laser: call to output_td_orb_current_density",t2-t1
   endif
    if(output_full_td_sp_energy.AND.(mod(i,td_sp_energy_output_frequency)==0)) then
      call output_td_SP_energy()
    endif !shenglai
    ! If enabled, append this time step's orbitals to files
    if(output_orbitals.AND.(mod(i,td_orbital_output_frequency)==0)) then
        call save_complex_orbitals(i)
    endif   
    if(output_orbitals2.AND.(mod(i,td_orbital_output_frequency)==0)) then
        call save_complex_orbitals2(i)
    endif     
    if(move_atoms) then
      call CPU_TIME(t1)
      call make_atom_movement(i)
      call CPU_TIME(t2); write(timing_file,*)trim(adjustl(propagator)),"time_evolution_laser: call to make_atom_movement",t2-t1
    endif
    write(log_file,*)i*time_step,sum(Density)*grid_volume,Energy

    selectcase(dipole_direction)
      case(1)
        dpm(1)=dipole_moment(1)-ds(1)
        write(dipole_x_file,'(2ES16.8)')i*time_step,dpm(1)
      case(2)
        dpm(2)=dipole_moment(2)-ds(2)
        write(dipole_y_file,'(2ES16.8)')i*time_step,dpm(2)
      case(3)
        dpm(3)=dipole_moment(3)-ds(3)
        write(dipole_z_file,'(2ES16.8)')i*time_step,dpm(3)
      case(0)
        dpm(1)=dipole_moment(1)-ds(1)
        write(dipole_x_file,'(2ES16.8)')i*time_step,dpm(1)
        dpm(2)=dipole_moment(2)-ds(2)
        write(dipole_y_file,'(2ES16.8)')i*time_step,dpm(2)
        dpm(3)=dipole_moment(3)-ds(3)
        write(dipole_z_file,'(2ES16.8)')i*time_step,dpm(3)
    endselect
    
    !Arthur: output Psi_c and a structure file in dft.inp format
    !Jorge output_td_psi is a flag to enable the output of psi
     if ((output_td_psi).AND.(mod(i,psi_output_frequency)==0)) then
        call output_Psi_c(i) 
     end if

    !Arthur: output projections between psi_c and psi                                                       
    if((output_inner_product).AND.(mod(i,output_inner_product_frequency)==0)) then
       call update_projection_file(i) !Arthur                                                               
    end if     
    
	! cody write restart file
    if( write_restart == .TRUE.) then
       restart_update_iter= restart_update_iter + 1
       if ( restart_update_iter >= restart_update_frequency) then
          restart_update_iter=0
		  write(log_file,*) 'Write restart files for iteration ',i
		  call restart_file_update_elec(i)
		  if(move_atoms) then
		     call restart_file_update_ion(i)
		  end if
       end if
    end if
	
	
	
  enddo
  close(dipole_x_file)
  close(dipole_y_file)
  close(dipole_z_file)
  
  !  cody   
  if(use_mask_volkov) then
    call clean_up_volkov
  end if  
  
end subroutine taylor_time_evolution_laser

subroutine taylor_time_evolution_optical_absorbtion
integer                 :: i,k,n,j,i1,i2,i3,k1,k2
real*8                  :: N_e
real*8                  :: ds(3),x,y,z,coord,dist2,sphrad2,dpm(3)
integer                 :: direc
real*8                  :: chargel,charger,chargem,mesl,mesr
real*4                  :: t1,t2
logical                 :: lanc
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

if(.NOT.using_opt_pot) then
  write(log_file,*)"ERROR: using_opt_pot=false in taylor_time_evolution_optical_absorbtion"
  stop
endif

if(box_basis_type==0) then
  allocate(Psi_c(N_lattice_points,N_orbitals))
else
  write(log_file,*)"ERROR: box_basis_type/=0 in taylor_time_evolution_optical_absorbtion"
  stop
endif
!$omp parallel workshare
Psi_c=Psi
!$omp end parallel workshare

call taylor_time_init
if(propagator=="lanczos".OR.propagator=="lanczos_cn") call lanczos_time_init
call calculate_rho_grid

call print_orbital_energy_components_header
call Total_Energy_grid_c(0)
  write(log_file,*)'Starting Energy',Energy
  !	call Hamiltonian_density
  write(log_file,*)'number of electrons',sum(density)*grid_volume

!$omp parallel workshare
N_e=sum(Density)*grid_volume
!$omp end parallel workshare
write(log_file,*)'number of electrons',N_e

!If dipole_direction=0 we compute all dipole components, otherwise we compute
!x- (dipole_direction=1), y- (dipole_direction=2), or z-component (dipole_direction=3)
allocate(dp_regression_data(0:3*N_time_steps))
do direc=1,3

  if ((dipole_direction/=0).and.(direc/=dipole_direction)) cycle
  if (direc==1) then 
    open(optical_abs1_file,file=trim(adjustl(optical_abs_xx_filename)),action='write',status='replace')
    open(optical_abs2_file,file=trim(adjustl(optical_abs_xy_filename)),action='write',status='replace')
    open(optical_abs3_file,file=trim(adjustl(optical_abs_xz_filename)),action='write',status='replace')
  endif
  if (direc==2) then
    open(optical_abs1_file,file=trim(adjustl(optical_abs_yx_filename)),action='write',status='replace')
    open(optical_abs2_file,file=trim(adjustl(optical_abs_yy_filename)),action='write',status='replace')
    open(optical_abs3_file,file=trim(adjustl(optical_abs_yz_filename)),action='write',status='replace')
  endif
  if (direc==3) then
    open(optical_abs1_file,file=trim(adjustl(optical_abs_zx_filename)),action='write',status='replace')
    open(optical_abs2_file,file=trim(adjustl(optical_abs_zy_filename)),action='write',status='replace')
    open(optical_abs3_file,file=trim(adjustl(optical_abs_zz_filename)),action='write',status='replace')
  endif
  write(optical_abs1_file,*)'#',N_time_steps,time_step,exp_kick_strength
  write(optical_abs2_file,*)'#',N_time_steps,time_step,exp_kick_strength
  write(optical_abs3_file,*)'#',N_time_steps,time_step,exp_kick_strength
  !$omp parallel workshare
  Psi_c=Psi
  !$omp end parallel workshare
  call calculate_rho_grid
  ds(1)=dipole_moment(1)
  ds(2)=dipole_moment(2)
  ds(3)=dipole_moment(3)
  write(log_file,*) 'Initial dipole moment: ',ds(1),ds(2),ds(3)

  !Applying the exponential kick to all orbitals.
  !The kick is applied only within a sphere of radius exp_kick_radius
  !and centered at (exp_kick_center_x, exp_kick_center_y, exp_kick_center_z)
  sphrad2=exp_kick_radius**2
  !$omp parallel do &
  !$omp default(shared) &
  !$omp private (k, i, x, y, z, dist2, coord)

  if(propagator.NE."lanczos_gs") then
     do k=1,N_orbitals
        do i=1,N_lattice_points
           x=Grid_Point(1,i)
           y=Grid_Point(2,i)
           z=Grid_Point(3,i)
           dist2=(x-exp_kick_center_x)**2+(y-exp_kick_center_y)**2+(z-exp_kick_center_z)**2
           if (dist2<sphrad2) then
              coord=Grid_Point(direc,i)
              Psi_c(i,k)=Psi(i,k)*exp(zi*exp_kick_strength*coord)
           endif
        end do
     end do
  end if
  !$omp end parallel do

  if(propagator=="lanczos_gs") call gs_init(direc)
  
  dpm(1:3)=0.d0
  if (.not.allocated(wlap_p)) then
     allocate(wlap_p(3,N_Lattice_points))
     wlap_p= (0.D0, 0.D0)
  endif
  if(output_full_td_current_density) call output_td_current_density(0)

  if(output_inner_product) call print_projection_file_header !Arthur
  if(output_inner_product) call update_projection_file(0) !Arthur

  do i=1,N_time_steps
     
     if(propagator=="lanczos".OR.propagator=="lanczos_gs".OR.propagator=="lanczos_cn") then
        lanc=.true.
        if(mod(i,lanczos_update_frequency)/=0) lanc=.false.
        if(i==1) lanc=.true.
     end if


     if(mod(i,lanczos_update_frequency)==0.and.propagator=="lanczos_gs") call diag_orbitals(i)

     

    call CPU_TIME(t1)
    !Arthur's notes: now chooses between three propagator: lanczos, lanczos_gs, taylor
    !Intended: lanczos or lanczos_gs to be phased out
    if(propagator=="lanczos") then
       call lanczos_time_step(i,lanc)
    else if(propagator=="lanczos_gs") then
       call gs_time_step(i,lanc)
    else if(propagator=="lanczos_cn") then
       call lanczos_cn_time_step(i,lanc)
    else if(propagator=="taylor") then
       call taylor_time_step(i,1.d0)
    end if
    call CPU_TIME(t2)
    write(timing_file,*)'time',trim(adjustl(propagator)),'_time_step',t2-t1
    call CPU_TIME(t1)
    call calculate_rho_grid
    call CPU_TIME(t2)
    write(timing_file,*)'time calculate_rho_grid',t2-t1

    !$omp parallel workshare
    N_e=sum(Density)*grid_volume
    !$omp end parallel workshare
    call Hamiltonian_density
    call Total_Energy_grid_c(i)
     if(output_full_td_current_density.AND.(mod(i,td_current_density_output_frequency)==0)) then
      call CPU_TIME(t1)
      time1=i
      call output_td_current_density(i)
      call CPU_TIME(t2); write(timing_file,*)trim(adjustl(propagator)),"time_evolution_laser: call to output_td_current_density",t2-t1
    endif

    write(log_file,*)'time',i*time_step,N_e,Energy

    dpm(1)=dipole_moment(1)-ds(1)
    dpm(2)=dipole_moment(2)-ds(2)
    dpm(3)=dipole_moment(3)-ds(3)

    write(optical_abs1_file,*)i*time_step,dpm(1),direc,1
    write(optical_abs2_file,*)i*time_step,dpm(2),direc,2
    write(optical_abs3_file,*)i*time_step,dpm(3),direc,3
    dp_regression_data((direc-1)*N_time_steps+i)=dpm(direc)
    
  !Arthur: output Psi_c and a structure file in dft.inp format
    !Jorge output_td_psi is a flag to enable the output of psi
     if ((output_td_psi).AND.(mod(i,psi_output_frequency)==0)) then
            call output_Psi_c(i) 
        end if
  end do

    !Arthur: output projections between psi_c and psi
    if((output_inner_product).AND.(mod(i,output_inner_product_frequency)==0)) then
       call update_projection_file(i) !Arthur                                                               
    end if

  close(optical_abs1_file)
  close(optical_abs2_file)
  close(optical_abs3_file)

  !Arthur: cleanup before restart   
  deallocate(c,q2)
  deallocate(psi_t,h_t)
  deallocate(eig_val,eig_vec)
  deallocate(o_t,b_t)
  deallocate(c_proj)
  deallocate(h_r)
  deallocate(h_0)

end do
end subroutine taylor_time_evolution_optical_absorbtion

SUBROUTINE Total_Energy_grid_c(it)
  integer :: i,orbital,p1,p2,p5,p,it
  real*8  :: su1,su2,su,over,orbital_energy_components(7),cp(7),w,overall=0.d0
  complex*16 :: pc
  logical :: need_offdiag_elem_check
  integer :: noff,j
  complex*16 :: Hio
  real*8     :: aver_dE

  need_offdiag_elem_check=.false.
  if ((it>0).and.(mod(it,offdiag_elem_check_frequency)==0)) then
    need_offdiag_elem_check=.true.
    noff=min(num_large_offdiag_elem_reported,N_orbitals*(N_orbitals-1)/2)
    if (.not.allocated(lode)) allocate(lode(noff),lodeind(2,noff))
    lode(1:noff)=cmplx(0.0d0,0.0d0,8)
  endif

  Energy=0.d0
  if (mod(it,orb_en_comp_output_frequency)==0) then
    write(orbital_energy_components_file,'(1x,i6)',advance='no') it
    write(orbital_energy_components_file,'(1x,e19.12)',advance='no') it*time_step
  endif
  overall=0.d0
  do orbital=1,N_orbitals
    orbital_index=orbital
    Phi_c=Psi_c(:,orbital)
    if(spin_polarized) then
      if(orbital<N_orbitals_down+1) then
        spin_down=.TRUE.
        spin_up=.FALSE.
      else
        spin_up=.TRUE.
        spin_down=.FALSE.
      endif
    endif    
    call Hamiltonian_wavefn_c(it,1.d0,Phi_c,H_Phi_c)

    su1=0.0d0
    over=0.0d0
    if (mod(it,orb_en_comp_output_frequency)==0) then
      cp(1:7)=0.0d0
      !$omp parallel do &
      !$omp default(shared) &
      !$omp private (i, w, pc) &
      !$omp reduction(+: over) &
      !$omp reduction(+: cp) &
      !$omp reduction(+: su1)
      do i=1,N_lattice_points
        pc=conjg(Phi_c(i))
        w=conjg(Phi_c(i))*Phi_c(i)
        su1=su1+pc*H_Phi_c(i)
        over=over+w
        cp(2)=cp(2)+w*V_l_pp(i)
        cp(3)=cp(3)+w*V_hartree(i)
        cp(4)=cp(4)+w*V_exchange(i)
        cp(5)=cp(5)+pc*V_nl_pp_c(i)
        cp(6)=cp(6)+pc*T_Phi_c(i)
        cp(7)=cp(7)+w*V_td(i)
      enddo
      !$omp end parallel do
      
      overall=overall+over*occupation(orbital)*grid_volume
      
      cp(1)=sum(cp(2:7))
      orbital_energy_components(1:7)=cp(1:7)/over
      write(orbital_energy_components_file,'(1x,e19.12)',advance='no') over*occupation(orbital)*grid_volume
      do i=1,1+min(6,orb_en_comp_output_level)
        write(orbital_energy_components_file,'(1x,e19.12)',advance='no') orbital_energy_components(i)
      enddo
    else
      !$omp parallel do &
      !$omp default(shared) &
      !$omp private (i) &
      !$omp reduction(+: su1)
      do i=1,N_lattice_points
        su1=su1+conjg(Phi_c(i))*H_Phi_c(i)
      enddo
      !$omp end parallel do
    endif

    Sp_Energy(orbital)=su1*Grid_Volume
    Energy=Energy+Occupation(orbital)*Sp_energy(orbital)

    if (need_offdiag_elem_check) then
      do i=1,orbital-1
        Hio=cmplx(0.0d0,0.0d0,8)
        do j=1,N_lattice_points
          Hio=Hio+conjg(Psi_c(j,i))*H_Phi_c(j)
        enddo
        Hio=Hio*Grid_Volume
        do j=1,noff
          if (abs(Hio)>abs(lode(j))) then
            lode(j+1:noff)=lode(j:noff-1)
            lode(j)=Hio
            lodeind(:,j+1:noff)=lodeind(:,j:noff-1)
            lodeind(1,j)=i
            lodeind(2,j)=orbital
            exit
          endif
        enddo
      enddo
    endif

  enddo
  
  do p5=1,(N_orbitals+4)/5
    p1=5*(p5-1)+1
    p2=5*p5 ; if ( p2 > N_orbitals ) p2=N_orbitals
    write(log_file,'(1x,5(i3,f12.4,2x))') (p,Sp_energy(p),p=p1,p2)
  enddo

    if(mod(it,orb_en_comp_output_frequency)==0) write(orbital_energy_components_file,'(1x,e19.12)',advance='no') overall
  
  if(.NOT.spin_polarized) call Exchange_Correlation_Energy
  if (use_projectile) call ion_projectile_energy
  call Hartree_Energy
  write(log_file,*)'sp      ',Energy
  if (mod(it,orb_en_comp_output_frequency)==0) write(orbital_energy_components_file,'(1x,e19.12)',advance='no') Energy
  write(log_file,*)'Ha      ',E_Hartree
  write(log_file,*)'ii      ',E_Ion_ion
  if (use_projectile) write(log_file,*)'i-proj  ',E_Ion_Projectile
  write(log_file,*)'xc      ',E_Exchange
  write(log_file,*)'Ha+xc   ',E_Hartree+E_Exchange
  Energy=Energy+E_Exchange+E_Hartree+E_Ion_Ion
  if (use_projectile) Energy=Energy+E_Ion_Projectile
  
  if(mod(it,orb_en_comp_output_frequency)==0) then
      write(orbital_energy_components_file,'(1x,e19.12)',advance='no') E_Hartree
      write(orbital_energy_components_file,'(1x,e19.12)',advance='no') E_Ion_ion
      write(orbital_energy_components_file,'(1x,e19.12)',advance='no') E_Exchange
      write(orbital_energy_components_file,'(1x,e19.12)',advance='no') E_Hartree+E_Exchange
      if (use_projectile) write(orbital_energy_components_file,'(1x,e19.12)',advance='no') E_Ion_Projectile
      write(orbital_energy_components_file,'(1x,e19.12)',advance='no') Energy
  end if
  
  if (need_offdiag_elem_check) then
    if (N_orbitals<2) then
      aver_dE=1.0d0
    else
      aver_dE=(maxval(Sp_energy)-minval(Sp_energy))/(N_orbitals-1)
    endif
    write(offdiag_elem_file,*) 'iter ',it
    write(offdiag_elem_file,*) 'time ',it*time_step
    do j=1,noff
      write(offdiag_elem_file,'(1x,i4,2(2x,i5),2(2x,d23.16))') &
                j,lodeind(1,j),lodeind(2,j),abs(lode(j)),abs(lode(j))/aver_dE
    enddo
  endif
  
  if(mod(it,orb_en_comp_output_frequency)==0) write(orbital_energy_components_file,*)
  if(mod(it,orb_en_comp_output_frequency)==0) flush(orbital_energy_components_file)

  !Arthur: output total potential at current time step
  if ((output_tot_td_pot).AND.(mod(it,tot_td_pot_output_freq)==0)) then
     call output_td_3D_total_potential(it) 
  end if
  
end subroutine Total_Energy_grid_c


subroutine output_largest_offdiag_elem()
integer  i
end subroutine output_largest_offdiag_elem


!! Old version of calculate_rho_grid
!subroutine calculate_rho_grid
!  real*8   :: x
!  integer            :: j,k
!  do j=1,N_lattice_points
!    density(j)=0.d0
!    if(spin_polarized) then
!      density_down_new(j)=0.d0
!      density_up_new(j)=0.d0
!    endif
!    do k=1,N_orbitals
!      x=(real(Psi_c(j,k))**2+imag(Psi_c(j,k))**2)*Occupation(k)
!      if(spin_polarized) then
!        if(k<=N_orbitals_down) then
!          density_down_new(j)=density_down_new(j)+x
!        else
!          density_up_new(j)=density_up_new(j)+x
!        endif
!      else
!        density(j)=density(j)+x
!      endif
!    enddo
!  enddo
!  if(spin_polarized) then
!    density_up=density_up_new
!    density_down=density_down_new
!    density=density_down_new+density_up_new
!  endif
!end subroutine calculate_rho_grid

subroutine calculate_rho_grid
  real*8             :: x,occ_k
  integer            :: j,k

if(spin_polarized) then
  !$omp parallel workshare
  density_down_new=0.0d0
  density_up_new=0.0d0
  !$omp end parallel workshare
  do k=1,N_orbitals_down
    occ_k=Occupation(k)
    !$omp parallel do &
    !$omp default(shared) &
    !$omp private (j)
    do j=1,N_lattice_points
      density_down_new(j)=density_down_new(j)+(real(Psi_c(j,k))**2+imag(Psi_c(j,k))**2)*occ_k
    enddo
    !$omp end parallel do
  enddo
  do k=N_orbitals_down+1,N_orbitals
    occ_k=Occupation(k)
    !$omp parallel do &
    !$omp default(shared) &
    !$omp private (j) 
    do j=1,N_lattice_points
      density_up_new(j)=density_up_new(j)+(real(Psi_c(j,k))**2+imag(Psi_c(j,k))**2)*occ_k
    enddo
    !$omp end parallel do
  enddo
  !$omp parallel workshare
  density_up=density_up_new
  density_down=density_down_new
  !$omp end parallel workshare
  !$omp parallel workshare
  density=density_down_new+density_up_new
  !$omp end parallel workshare
else
  if ((using_cap).and. (keep_density_in_cap_constant).and.(td_density_counter>1.d-5)) then !shenglai
   occ_k=Occupation(1)
  do j=1,N_lattice_points
    if ((grid_point(1,j)>cap_left1).and.(grid_point(1,j)<cap_right1)) then
    density(j)=(real(Psi_c(j,1))**2+imag(Psi_c(j,1))**2)*occ_k
    endif
  enddo
  !$omp end parallel do                                                                                                                                                              

  do k=2,N_orbitals
                if((tddft_type==3).AND.(k==N_orbitals)) then
                  occ_k=1.d0
                else
                  occ_k=Occupation(k)
                endif
    !$omp parallel do &                                                                                                                                                              
    !$omp default(shared) &                                                                                                                                                          
    !$omp private (j)                                                                                                                                                                
    do j=1,N_lattice_points
      if ((grid_point(1,j)>cap_left1).and.(grid_point(1,j)<cap_right1)) then
      density(j)=density(j)+(real(Psi_c(j,k))**2+imag(Psi_c(j,k))**2)*occ_k
      endif
    enddo
    !$omp end parallel do                                                                                                                                                            
  enddo
  else
  occ_k=Occupation(1)
  !$omp parallel do &
  !$omp default(shared) &
  !$omp private (j)
  do j=1,N_lattice_points
    density(j)=(real(Psi_c(j,1))**2+imag(Psi_c(j,1))**2)*occ_k
  enddo
  !$omp end parallel do
  do k=2,N_orbitals
		if((tddft_type==3).AND.(k==N_orbitals)) then
		  occ_k=1.d0
		else  
		  occ_k=Occupation(k)   
		endif
    !$omp parallel do &
    !$omp default(shared) &
    !$omp private (j)
    do j=1,N_lattice_points
      density(j)=density(j)+(real(Psi_c(j,k))**2+imag(Psi_c(j,k))**2)*occ_k
    enddo
    !$omp end parallel do
  enddo
 endif
endif
end subroutine calculate_rho_grid


function Gauss_wave_packet_3d(x,y,z,t,a,p0x,p0y,p0z)
!This function computes the value of a 3D Gausian wave packet propagating in free space.
!Parameters:
!  x,y,z [in Angstrom] - spatial coordinates of the point where the packet needs to be computed
!  t [in femtosec]    - time
!  a [in Angstrom]    - spatial width of the packet at t=0
!  p0x,p0y,p0z [in eV*fs/Angstrom] - the average momentum of the electron in the wave packet
!
!It is assumed that the following global constants have been defined
!  hbar=0.658211899d0 [eV*fs]; H2M=3.80998174348d0 [eV*Angstom^2]; ElectronMass=hbar*hbar/(2*H2M) [eV*Angstom^2]
!
!It is also possible to use atomic units for input/output of this function. In this case one needs
!to pass all input values in atomic units while the global constants must be set as follows:
!  hbar=1.0;  H2M=0.5d0;  ElectronMass=1.0d0;
real(8)            :: x,y,z,t,a,p0x,p0y,p0z
complex(8)         :: Gauss_wave_packet_3d,fx,fy,fz,dc
real(8), parameter :: invm=1/ElectronMass
real(8), parameter :: invhbar=1/hbar

dc=1.d0+2*zi*hbar*invm*t/a**2
fx=(2.d0/(pi*a**2*dc**2))**0.25d0*exp(-(x-invm*p0x*t)**2/(a**2*dc))*exp(zi*invhbar*p0x*(x-0.5d0*invm*p0x*t))
fy=(2.d0/(pi*a**2*dc**2))**0.25d0*exp(-(y-invm*p0y*t)**2/(a**2*dc))*exp(zi*invhbar*p0y*(y-0.5d0*invm*p0y*t))
fz=(2.d0/(pi*a**2*dc**2))**0.25d0*exp(-(z-invm*p0z*t)**2/(a**2*dc))*exp(zi*invhbar*p0z*(z-0.5d0*invm*p0z*t))
Gauss_wave_packet_3d=fx*fy*fz

end function Gauss_wave_packet_3d

function Gauss_wave_packet_3d_as(x,y,z,t,ax,ay,az,p0x,p0y,p0z)
!This function computes the value of a 3D Gausian wave packet propagating in free space.
!Parameters:
!  x,y,z [in Angstrom] - spatial coordinates of the point where the packet needs to be computed
!  t [in femtosec]    - time
!  ax,ay,az [in Angstrom]    - spatial width of the packet at t=0
!  p0x,p0y,p0z [in eV*fs/Angstrom] - the average momentum of the electron in the wave packet
!
!It is assumed that the following global constants have been defined
!  hbar=0.658211899d0 [eV*fs]; H2M=3.80998174348d0 [eV*Angstom^2]; ElectronMass=hbar*hbar/(2*H2M) [eV*Angstom^2]
!
!It is also possible to use atomic units for input/output of this function. In this case one needs
!to pass all input values in atomic units while the global constants must be set as follows:
!  hbar=1.0;  H2M=0.5d0;  ElectronMass=1.0d0;
real(8)            :: x,y,z,t,ax,ay,az,p0x,p0y,p0z
complex(8)         :: Gauss_wave_packet_3d_as,fx,fy,fz,dc_x,dc_y,dc_z
real(8), parameter :: invm=1/ElectronMass
real(8), parameter :: invhbar=1/hbar

dc_x=1.d0+2*zi*hbar*invm*t/ax**2
dc_y=1.d0+2*zi*hbar*invm*t/ay**2
dc_z=1.d0+2*zi*hbar*invm*t/az**2
fx=(2.d0/(pi*ax**2*dc_x**2))**0.25d0*exp(-(x-invm*p0x*t)**2/(ax**2*dc_x))*exp(zi*invhbar*p0x*(x-0.5d0*invm*p0x*t))
fy=(2.d0/(pi*ay**2*dc_y**2))**0.25d0*exp(-(y-invm*p0y*t)**2/(ay**2*dc_y))*exp(zi*invhbar*p0y*(y-0.5d0*invm*p0y*t))
fz=(2.d0/(pi*az**2*dc_z**2))**0.25d0*exp(-(z-invm*p0z*t)**2/(az**2*dc_z))*exp(zi*invhbar*p0z*(z-0.5d0*invm*p0z*t))
Gauss_wave_packet_3d_as=fx*fy*fz
end function Gauss_wave_packet_3d_as

function Gauss_wave_packet_1d(x,t,a,p0x)
!This function computes the value of a 1D Gausian wave packet propagating in free space.
!Parameters:
!  x [in Angstrom] - spatial coordinates of the point where the packet needs to be computed
!  t [in femtosec]    - time
!  a [in Angstrom]    - spatial width of the packet at t=0
!  p0x [in eV*fs/Angstrom] - the average momentum of the electron in the wave packet
!
!It is assumed that the following global constants have been defined
!  hbar=0.658211899d0 [eV*fs]; H2M=3.80998174348d0 [eV*Angstom^2]; ElectronMass=hbar*hbar/(2*H2M) [eV*Angstom^2]
!
!It is also possible to use atomic units for input/output of this function. In this case one needs
!to pass all input values in atomic units while the global constants must be set as follows:
!  hbar=1.0;  H2M=0.5d0;  ElectronMass=1.0d0;
real(8)            :: x,t,a,p0x
complex(8)         :: Gauss_wave_packet_1d,fx,dc
real(8), parameter :: invm=1/ElectronMass
real(8), parameter :: invhbar=1/hbar

dc=1.d0+2*zi*hbar*invm*t/a**2
fx=(2.d0/(pi*a**2*dc**2))**0.25d0*exp(-(x-invm*p0x*t)**2/(a**2*dc))*exp(zi*invhbar*p0x*(x-0.5d0*invm*p0x*t))
Gauss_wave_packet_1d=fx

end function Gauss_wave_packet_1d

SUBROUTINE plot_wp(it)
  integer            :: i,it,ii1,ii2,ii3
  real*8,allocatable :: wp(:,:),wp_perp(:,:),wp_par(:,:)

  i=maxval(N_lattice)
  allocate(wp(3,i),wp_perp(N_lattice(2),N_lattice(3)),wp_par(N_lattice(1),N_lattice(2)))
  wp=0.d0; wp_perp=0.d0; wp_par=0.d0

  do i=1,N_lattice_points
    ii1=Lattice(1,i)+1
    ii2=Lattice(2,i)+1
    ii3=Lattice(3,i)+1
    wp(1,ii1)=wp(1,ii1)+density_wp(i)
    wp(2,ii2)=wp(2,ii2)+density_wp(i)
    wp(3,ii3)=wp(3,ii3)+density_wp(i)
    if(ii1==120) wp_perp(ii2,ii3)=wp_perp(ii2,ii3)+density_wp(i)
    if(ii1==120) wp_par(ii1,ii2)=wp_par(ii1,ii2)+density_wp(i)
  enddo

  do i=1,N_lattice(1)
    write(wp_1d_x_file,*)xgrid(i),wp(1,i)
  enddo
  do i=1,N_lattice(2)
    write(wp_1d_y_file,*)ygrid(i),wp(2,i)
  enddo
  do i=1,N_lattice(3)
    write(wp_1d_z_file,*)zgrid(i),wp(3,i)
  enddo
  write(wp_1d_x_file,*)
  write(wp_1d_y_file,*)
  write(wp_1d_z_file,*)

  do ii3=1,N_lattice(3)
    do ii2=1,N_lattice(2)
      write(wp_2d_yz_file,*)wp_perp(ii2,ii3)
    enddo
  enddo
  write(wp_2d_yz_file,*)'it',it
  deallocate(wp,wp_perp,wp_par)
END SUBROUTINE plot_wp


SUBROUTINE plot_wpa(it)
  integer            :: i,it,ii1,ii2,ii3
  real*8,allocatable :: wp(:,:),wp_perp(:,:),wp_par(:,:)

  i=maxval(N_lattice)
  allocate(wp(3,i),wp_perp(N_lattice(2),N_lattice(3)),wp_par(N_lattice(1),N_lattice(2)))
  wp=0.d0; wp_perp=0.d0; wp_par=0.d0

  do i=1,N_lattice_points
    ii1=Lattice(1,i)+1
    ii2=Lattice(2,i)+1
    ii3=Lattice(3,i)+1
    wp(1,ii1)=wp(1,ii1)+density_wp(i)
  enddo

  do i=1,N_lattice(1)
    write(777,*)xgrid(i),wp(1,i)
  enddo
  write(777,*)

  deallocate(wp,wp_perp,wp_par)
END SUBROUTINE plot_wpa

SUBROUTINE print_orbital_energy_components_header
    integer :: orbital,nc,j,nspaces
    integer,parameter  :: reclength=20
    integer,parameter  :: backmargin=3
    character(reclength)  str1,strorb
    character(2*reclength),parameter :: spstr=' '
    
    nc = 9.d0
    nc = nc+(2+min(6,orb_en_comp_output_level))*N_orbitals
    if(use_projectile) then 
        nc=nc+1
    end if
    
    write(orbital_energy_components_file,'(2x,a2)',advance='no') '#1'
    write(orbital_energy_components_file,'(18x,a2)',advance='no') '#2'    
    do j=3,nc
        write(orbital_energy_components_file,'(1x,i19)',advance='no') j
    end do
    write(orbital_energy_components_file,*)
    
    write(orbital_energy_components_file,'(2x,a)',advance='no') '#iter'
    write(orbital_energy_components_file,'(8x,a,3x)',advance='no') '#time[fs]'

    do orbital=1,N_orbitals
        write(strorb,*) orbital
        
        write(str1,*) 'occupation',trim(adjustl(strorb))
        nspaces=reclength-backmargin-len_trim(str1)
        write(orbital_energy_components_file,'(a)',advance='no') spstr(1:nspaces)
        write(orbital_energy_components_file,'(a)',advance='no') trim(str1)
        write(orbital_energy_components_file,'(a)',advance='no') spstr(1:backmargin)
        
        write(str1,*) 'energy',trim(adjustl(strorb)),'[eV]'
        nspaces=reclength-backmargin-len_trim(str1)
        write(orbital_energy_components_file,'(a)',advance='no') spstr(1:nspaces)
        write(orbital_energy_components_file,'(a)',advance='no') trim(str1)
        write(orbital_energy_components_file,'(a)',advance='no') spstr(1:backmargin)
        
        if(orb_en_comp_output_level>=1) then
            write(str1,*) 'l_pp',trim(adjustl(strorb)),'[eV]'
            nspaces=reclength-backmargin-len_trim(str1)
            write(orbital_energy_components_file,'(a)',advance='no') spstr(1:nspaces)
            write(orbital_energy_components_file,'(a)',advance='no') trim(str1)
            write(orbital_energy_components_file,'(a)',advance='no') spstr(1:backmargin)
        end if  
        
        if(orb_en_comp_output_level>=2) then
            write(str1,*) 'hartree',trim(adjustl(strorb)),'[eV]'
            nspaces=reclength-backmargin-len_trim(str1)
            write(orbital_energy_components_file,'(a)',advance='no') spstr(1:nspaces)
            write(orbital_energy_components_file,'(a)',advance='no') trim(str1)
            write(orbital_energy_components_file,'(a)',advance='no') spstr(1:backmargin) 
        end if
        
        if(orb_en_comp_output_level>=3) then
            write(str1,*) 'exchange',trim(adjustl(strorb)),'[eV]'
            nspaces=reclength-backmargin-len_trim(str1)
            write(orbital_energy_components_file,'(a)',advance='no') spstr(1:nspaces)
            write(orbital_energy_components_file,'(a)',advance='no') trim(str1)
            write(orbital_energy_components_file,'(a)',advance='no') spstr(1:backmargin)        
        end if

        if(orb_en_comp_output_level>=4) then
            write(str1,*) 'nl_pp',trim(adjustl(strorb)),'[eV]'
            nspaces=reclength-backmargin-len_trim(str1)
            write(orbital_energy_components_file,'(a)',advance='no') spstr(1:nspaces)
            write(orbital_energy_components_file,'(a)',advance='no') trim(str1)
            write(orbital_energy_components_file,'(a)',advance='no') spstr(1:backmargin)
        end if
        
        if(orb_en_comp_output_level>=5) then
            write(str1,*) 'kinetic',trim(adjustl(strorb)),'[eV]'
            nspaces=reclength-backmargin-len_trim(str1)
            write(orbital_energy_components_file,'(a)',advance='no') spstr(1:nspaces)
            write(orbital_energy_components_file,'(a)',advance='no') trim(str1)
            write(orbital_energy_components_file,'(a)',advance='no') spstr(1:backmargin)         
        end if
            
        if(orb_en_comp_output_level>=6) then
            write(str1,*) 'timeDep',trim(adjustl(strorb)),'[eV]'
            nspaces=reclength-backmargin-len_trim(str1)
            write(orbital_energy_components_file,'(a)',advance='no') spstr(1:nspaces)
            write(orbital_energy_components_file,'(a)',advance='no') trim(str1)
            write(orbital_energy_components_file,'(a)',advance='no') spstr(1:backmargin)
        end if
    end do
    
    write(orbital_energy_components_file,'(5x,a,3x)',advance='no') 'numElectrons'
    write(orbital_energy_components_file,'(4x,a,3x)',advance='no') 'Sp_energy[eV]'
    write(orbital_energy_components_file,'(6x,a,3x)',advance='no') 'hartree[eV]'
    write(orbital_energy_components_file,'(6x,a,3x)',advance='no') 'ion_ion[eV]'
    write(orbital_energy_components_file,'(5x,a,3x)',advance='no') 'exchange[eV]'        
    write(orbital_energy_components_file,'(8x,a,3x)',advance='no') 'ha+xc[eV]'
    if(use_projectile) then
        write(orbital_energy_components_file,'(2x,a,3x)',advance='no') 'proj_energy[eV]'
    end if
    write(orbital_energy_components_file,'(2x,a,3x)',advance='no') 'totalEnergy[eV]'
    
    write(orbital_energy_components_file,*)
    flush(orbital_energy_components_file)
    
END SUBROUTINE print_orbital_energy_components_header

!Arthur
subroutine output_Psi_c(iter)
!outputs the Psi into a binary file
    integer        :: iter
    integer        :: atom,ai,pl
    character(255) :: fname1,fname2
    character(5)   :: ch5
   
    write(ch5,'(i5.5)') td_psi_counter
    
    pl=len_trim(psi_data_filename_prefix)
    write(fname1,'(a,a,a)') psi_data_filename_prefix(1:pl),ch5(1:5),'.dat'

    open(psi_data_file,file=trim(adjustl(fname1)),form='unformatted',status='replace')
    if (using_injection) then
    write(psi_data_file) Phi_source
    else
    write(psi_data_file) Psi_c(:,1:N_orbitals)
    endif
    close(psi_data_file)
    
    !output the structure at the corresponding time
    pl=len_trim(structure_output_filename_prefix)
    write(fname2,'(a,a,a)') structure_output_filename_prefix(1:pl),ch5(1:5),'.dat'
    
    open(structure_output_file,file=trim(adjustl(fname2)))
    write(structure_output_file,*) "#",iter
    write(structure_output_file,'(12x,i3,12x,i3,12x,i3,12x,i3)') N_total_atom,N_atom_L,N_atom_C,N_atom_R
    do atom=1,N_total_atom
        ai=atom_index(atom)
        write(structure_output_file,'(3(F20.14,1x))',advance='no') Position(1,atom),Position(2,atom),Position(3,atom)
        write(structure_output_file,'(i3,2x,i3)') z_atom(ai),box_atom(atom)
    end do
    if(grid_step(1)==grid_step(2) .AND. grid_step(1)==grid_step(3)) then
        write(structure_output_file,*) grid_step(1),n_lattice(1),n_lattice(2),n_lattice(3)
    else
        write(structure_output_file,*)grid_step(1),grid_step(2),grid_step(3),n_lattice(1),n_lattice(2),n_lattice(3)
    end if
    
    close(structure_output_file)
        
    td_psi_counter=td_psi_counter+1
    
end subroutine output_Psi_c

!cody
subroutine restart_file_update_elec(iter)
!outputs the Psi,iteration, into a binary file
   integer        :: iter
    character(255) :: fname1,fname2
    character(7)   :: ch7
   
   if( keep_all_restart == .TRUE.) then
      write(ch7,'(i7.7)') iter
	  write(fname1,'(a,a)') 'saved_RESTART_electronic_',ch7
	  write(fname2,'(a,a)') 'saved_RESTART_iter_',ch7
      call rename(trim(adjustl(restart_file_elecname)),trim(adjustl(fname1)))
      call rename(trim(adjustl(restart_file_itername)),trim(adjustl(fname2)))
   else 
      ! rename/move to keep a 2nd copy
      call rename(trim(adjustl(restart_file_elecname)),'backup_RESTART_electronic')
      call rename(trim(adjustl(restart_file_itername)),'backup_RESTART_iter')
   end if
 ! open all files at once to prevent possible errors from full disk
   open(restart_file_electronic,file=trim(adjustl(restart_file_elecname)),form='unformatted',status='replace',action='write')
   open(restart_file_iter,file=trim(adjustl(restart_file_itername)),status='replace',action='write')
   write(restart_file_electronic) iter
   write(restart_file_electronic) N_lattice_points
   write(restart_file_electronic) N_orbitals
   write(restart_file_electronic) Psi_c(:,1:N_orbitals)
   write(restart_file_electronic) density(:)
   write(restart_file_electronic) Occupation(1:N_orbitals)
   close(restart_file_electronic)
   write(restart_file_iter,'(i15)') iter
   close(restart_file_iter)
   
end subroutine restart_file_update_elec
  
!cody
subroutine restart_file_read_elec(iter)
!reads the Psi_c,iteration,ion positions, and ion velocities from a binary file
   integer        :: iter,iter_check,N_lat_check,N_orb_check
   
   open(restart_file_electronic,file=trim(adjustl(restart_file_elecname)),form='unformatted')
   read(restart_file_electronic) iter
   read(restart_file_electronic) N_lat_check
   read(restart_file_electronic) N_orb_check
   read(restart_file_electronic) Psi_c(:,1:N_orbitals)
   read(restart_file_electronic) density(:)
   read(restart_file_electronic) Occupation(1:N_orbitals)
   close(restart_file_electronic)
   if(N_lat_check .NE. N_lattice_points) then
      write (log_file,*) 'Lattice points do not match! ',N_lattice_points,' vs ',N_lat_check
	  stop   
   end if
   if(N_orb_check .NE. N_orbitals) then
      write (log_file,*) 'Number of orbitals do not match! ',N_orbitals,' vs ',N_orb_check
	  stop   
   end if
   open(restart_file_iter,file=trim(adjustl(restart_file_itername)))
   read(restart_file_iter,'(i15)') iter_check
   close(restart_file_iter)
   if(iter .NE. iter_check) then
      write (log_file,*) 'iterations do not match between restart files ',iter,' vs ',iter_check
	  stop
   end if
end subroutine restart_file_read_elec

!cody
subroutine restart_file_update_ion(iter)
!outputs ion positions (including previous position, and ion velocities into a binary file
   integer        :: iter
    character(255) :: fname1
    character(7)   :: ch7
   
   if( keep_all_restart == .TRUE.) then
      write(ch7,'(i7.7)') iter
	  write(fname1,'(a,a)') 'saved_RESTART_ion_',ch7
      call rename(trim(adjustl(restart_file_ionname)),trim(adjustl(fname1)))
   else 
     ! rename/move to keep a 2nd copy
     call rename(trim(adjustl(restart_file_ionname)),'backup_RESTART_ion')
   end if

   open(restart_file_ion,file=trim(adjustl(restart_file_ionname)),form='unformatted',status='replace',action='write')
   write(restart_file_ion) iter
   write(restart_file_ion) N_total_atom
   write(restart_file_ion) Position(:,:)
   write(restart_file_ion) Position_prev(:,:)
   write(restart_file_ion) atom_velocity(:,:)
   close(restart_file_ion)
end subroutine restart_file_update_ion  

!cody
subroutine restart_file_read_ion(iter)
   integer        :: iter,iter_check,N_atom_check
   open(restart_file_ion,file=trim(adjustl(restart_file_ionname)),form='unformatted')
   read(restart_file_ion) iter_check
   read(restart_file_ion) N_atom_check
   read(restart_file_ion) Position(:,:)
   read(restart_file_ion) Position_prev(:,:)
   read(restart_file_ion) atom_velocity(:,:)
   close(restart_file_ion)
   if(N_atom_check .NE. N_total_atom) then
      write (log_file,*) 'Number of atoms do not match! ',N_total_atom,' vs ',N_atom_check
	  stop   
   end if
   if(iter .NE. iter_check) then
      write (log_file,*) 'iterations do not match between restart files ',iter,' vs ',iter_check
	  stop
   end if
end subroutine restart_file_read_ion

!cody
subroutine restart_file_update_proj(iter)
!outputs projectile positions (including previous position, and ion velocities into a binary file
   integer        :: iter
    character(255) :: fname1
    character(7)   :: ch7
   
   if( keep_all_restart == .TRUE.) then
      write(ch7,'(i7.7)') iter
	  write(fname1,'(a,a)') 'saved_RESTART_projectile_',ch7
      call rename(trim(adjustl(restart_file_projname)),trim(adjustl(fname1)))
   else 
     ! rename/move to keep a 2nd copy
     call rename(trim(adjustl(restart_file_projname)),'backup_RESTART_projectile')
   end if


   open(restart_file_proj,file=trim(adjustl(restart_file_projname)),form='unformatted',status='replace',action='write')
   write(restart_file_proj) iter
   write(restart_file_proj) projectile_x
   write(restart_file_proj) projectile_y
   write(restart_file_proj) projectile_z
   write(restart_file_proj) projectile_x_prev
   write(restart_file_proj) projectile_y_prev
   write(restart_file_proj) projectile_z_prev
   write(restart_file_proj) projectile_vx
   write(restart_file_proj) projectile_vy
   write(restart_file_proj) projectile_vz
   close(restart_file_proj)
end subroutine restart_file_update_proj

!cody
subroutine restart_file_read_proj(iter)
   integer        :: iter,iter_check
   open(restart_file_proj,file=trim(adjustl(restart_file_projname)),form='unformatted')
   read(restart_file_proj) iter_check
   read(restart_file_proj) projectile_x
   read(restart_file_proj) projectile_y
   read(restart_file_proj) projectile_z
   read(restart_file_proj) projectile_x_prev
   read(restart_file_proj) projectile_y_prev
   read(restart_file_proj) projectile_z_prev
   read(restart_file_proj) projectile_vx
   read(restart_file_proj) projectile_vy
   read(restart_file_proj) projectile_vz
   close(restart_file_proj)
   if(iter .NE. iter_check) then
      write (log_file,*) 'iterations do not match between restart files of projectile',iter,' vs ',iter_check
	  stop
   end if
end subroutine restart_file_read_proj

subroutine taylor_time_step_injection(t)
  implicit none
  integer     :: n,kpoint,i,t

  kpoint=1
  
  Phi_c=Phi_source
  do n=1,N_taylor
    call Hamiltonian_wavefn_c(t,1.d0,Phi_c,H_Phi_c)
    do i=1,N_Lattice_points
      Phi_c(i)=H_Phi_c(i)
    end do
    Phi_source=Phi_source+tc(n)*Phi_c
  end do

end subroutine taylor_time_step_injection

subroutine source_prop
  implicit none
  integer  :: it,i1,i2,i3,i,ns,j,n
  double precision  :: dx(N_Lattice(1)),x0,dy(n_lattice(2)),e,norm,t1,t2
  real*8 :: sconvergence,snorm1,snorm2,dnorm1
  complex*8 :: sconvergence_c
  allocate(phi_source(n_lattice_points))
  allocate(Phi_source_density(n_lattice_points)) 
  allocate(Psi_c(N_lattice_points,N_orbitals))
  allocate(Phi_source_previous(n_lattice_points))
  allocate(Phi_source_density_previous(n_lattice_points))
  if(.not.allocated(sing_prec_rearranged_density)) allocate(sing_prec_rearranged_density(n_lattice_points))
 ! e=0.1d0
  !ns=30
  sconvergence=0.d0
  snorm1=0.d0
  snorm2=0.d0
  sconvergence_c=cmplx(0.d0,0.d0)
  phi_source=cmplx(0.d0,0.d0)
  Phi_source_previous=cmplx(0.d0,0.d0)
  Phi_source_density_previous=0.0d0
 call taylor_time_init
 if (.not.allocated(wlap_p)) allocate(wlap_p(3,N_Lattice_points))
do i=1,N_orbitals
    do j=1,N_lattice_points
      Psi_c(j,i)=cmplx(Psi(j,i),0.d0,8)
    enddo
  enddo
 call calculate_rho_grid
 call Hamiltonian_density
 write(log_file,*)'Starting Energy',Energy
write(log_file,*)'number of electrons',sum(density)*grid_volume
if(output_full_td_density) call output_td_density(0)
if(output_full_td_current_density) call output_td_current_density(0)
if (output_td_psi) call output_Psi_c(0)   
  ! it=1
     ! if(lattice(1,i)==inject_x.and.lattice(2,i)==inject_y.and.lattice(3,i)==inject_z) then
       ! phi_source(i)=exp(-zi*injection_E*it*time_step)
       ! norm=Conjg(phi_source(i))*phi_source(i)
       ! phi_source(i)=exp(-zi*e*it*time_step)/sqrt(norm)
     ! endif

  norm=0.d0
  n=0
  if(inject_source_nonsingular==.TRUE.) then
     do i=1,n_lattice_points
           if(((lattice(1,i)>=injection_x1).and.(lattice(1,i)<=injection_x2)).and.((lattice(2,i)>=injection_y1).and.(lattice(2,i)<=injection_y2)).and.((lattice(3,i)>=injection_z1).and.(lattice(3,i)<=injection_z2))) then
           n=n+1
           endif
     enddo
  else
     do i=1,n_lattice_points
           if(((lattice(1,i)==injection_x1).and.(lattice(2,i)==injection_y1).and.(lattice(3,i)==injection_z1))) then
              n=n+1
			  write(log_file,*) 'Injection at grid point ',lattice(1,i),',',lattice(2,i),',',lattice(3,i)
			  write(log_file,*) ' or ',grid_point(1,i),',',grid_point(2,i),',',grid_point(3,i)
           endif
     enddo
	 if(n==0) then
	    write(log_file,*) 'Injection at ',n,' Lattice points!'
		stop
	 endif
  endif
  write(log_file,*) 'Injection at ',n,' Lattice points '
 do it=1,n_time_steps

   ! norm=sum(Conjg(phi_source(:))*phi_source(:))*grid_volume
      norm=0.d0
      do i=1,n_lattice_points
	   ! cody   make controls more natural for injecting at a single point.
	   if(inject_source_nonsingular==.FALSE.) then
          if(((lattice(1,i)==injection_x1).and.(lattice(2,i)==injection_y1).and.(lattice(3,i)==injection_z1))) then
           phi_source(i)=exp(-zi*injection_E*it*time_step/hbar)
           norm=Conjg(phi_source(i))*phi_source(i)
           phi_source(i)=phi_source(i)/sqrt(norm)
          endif	   
	   
	   else
          if(((lattice(1,i)>=injection_x1).and.(lattice(1,i)<=injection_x2)).and.((lattice(2,i)>=injection_y1).and.(lattice(2,i)<=injection_y2)).and.((lattice(3,i)>=injection_z1).and.(lattice(3,i)<=injection_z2))) then
           phi_source(i)=exp(-zi*injection_E*it*time_step/hbar)
           norm=Conjg(phi_source(i))*phi_source(i)
           phi_source(i)=phi_source(i)/sqrt(n*norm)
          endif
	   endif
	   ! IF NORMALIZING norm=norm + Conjg(phi_source(i))*phi_source(i)
      enddo
	  ! cody normalize
      ! phi_source=phi_source/sqrt(norm)

    call taylor_time_step_injection(it)

    if(output_full_td_density.AND.(mod(it,td_density_output_frequency)==0)) then
      call CPU_TIME(t1)
      call output_td_density(it)
      call CPU_TIME(t2); write(timing_file,*)trim(adjustl(propagator)),"time_evolution_injection: call to output_td_density",t2-t1
    endif

	!cody
    if(output_source_td_density.AND.(mod(it,output_source_td_dens_frequency)==0)) then
	  dnorm1=0.d0
	  ! do not need to add grid volumne because it cancels out
	  do j=1,N_lattice_points
         Phi_source_density(j)=(real(phi_source(j))**2+imag(phi_source(j))**2)
		 dnorm1=dnorm1+Phi_source_density(j)
      enddo
	  Phi_source_density=Phi_source_density/dnorm1
	  call output_td_density_source(i)
	endif

	! cody
    if (mod(it,source_check_congerg_freq)==0) then
	  do j=1,N_lattice_points
         Phi_source_density(j)=(real(phi_source(j))**2+imag(phi_source(j))**2)
      enddo
	  ! innerproducts no need for grid volumn 
	  sconvergence_c=sum(conjg(Phi_source_previous)*Phi_source)
	  snorm1=sum(conjg(Phi_source_previous)*Phi_source_previous)
	  snorm2=sum(conjg(Phi_source)*Phi_source)
	  if((snorm1 .NE. 0.d0).AND.(snorm2 .NE. 0.d0)) sconvergence_c = sconvergence_c/sqrt(snorm1*snorm2)
	  sconvergence=conjg(sconvergence_c)*sconvergence_c

	  write(log_file,*) 'source injection convergence ',sconvergence
	  Phi_source_previous=1.d0*Phi_source
	end if

    ! If enabled, append this time step's current density to a file
    if(output_full_td_current_density.AND.(mod(it,td_current_density_output_frequency)==0)) then
      call CPU_TIME(t1)
      time1=i
      call output_td_current_density(it)
      call CPU_TIME(t2); write(timing_file,*)trim(adjustl(propagator)),"time_evolution_injeciotn: call to output_td_current_density",t2-t1
    endif
    if(mod(it,1000)==0) write(6,*)it
    if(mod(it,td_current_density_output_frequency)==0) then
      write(6,*)it

      dx=0.d0
      dy=0.d0
      do i=1,n_lattice_points
        dx(Lattice(1,i)+1)=dx(Lattice(1,i)+1)+Conjg(phi_source(i))*phi_source(i)
        dy(Lattice(2,i)+1)=dy(Lattice(2,i)+1)+Conjg(phi_source(i))*phi_source(i)
      end do
      do i=1,N_Lattice(1)
        write(source_x,*)i,dx(i)
      end do
      write(source_y,*)
      do i=1,N_Lattice(2)
        write(source_y,*)i,dy(i)
      end do
      write(source_y,*)
    endif
if ((output_td_psi).AND.(mod(it,psi_output_frequency)==0)) then
        call output_Psi_c(it)
end if
enddo

  do i=1,n_lattice_points
    write(100,*)phi_source(i)
  end do

end subroutine source_prop

! cody
SUBROUTINE output_td_density_source(iter)
!This subroutine saves electron density of phi_source as bov format
integer :: iter
integer :: i,j,k,ind,pl,fnl,dk1,dk2,dk3,k1min,k2min,k3min,k1max,k2max,k3max
character(255) :: fname1,fname2
character(5)   :: ch5
character(16)  :: str1,str2,str3
k1min=N_Lattice_min(1)
k1max=N_Lattice_max(1)
k2min=N_Lattice_min(2)
k2max=N_Lattice_max(2)
k3min=N_Lattice_min(3)
k3max=N_Lattice_max(3)
dk1=(k1max-k1min+1)
dk2=(k2max-k2min+1)
dk3=(k3max-k3min+1)

!Bov format (bricks of data) which can easily be read by VisIt software.
!It is fast and reasonable in terms of disk space. Works only in the
!case of rectangular box
    write(ch5,'(i5.5)') td_density_counter_source
    pl=len_trim(td_total_density_filename_prefix)
    write(fname1,'(a,a,a,a)') 'source',td_total_density_filename_prefix(1:pl),ch5(1:5),'.dat'
    write(fname2,'(a,a,a,a)') 'source',td_total_density_filename_prefix(1:pl),ch5(1:5),'.bov'
    fnl=len_trim(fname1)
    !First write the density into a data file, which is of binary form.
    !Note that the density data is rearranged as z,y,x --> x,y,z (C-like
    !storage of array elements)  and converted to single precision before
    !saving it to disk (single precision is used to reduce disk usage).
    !Rearrangement must be done using an auxiliary array
    !(called sing_prec_rearranged_density) because the data cannot be
    !simply written into the binary file by making an appropriate do-loop
    !(writing an entire array at once and writing it step-by-step gives
    !different result in fortran when it is a binary file).
    ind=0
    do k=N_Lattice_min(3),N_Lattice_max(3)
      do j=N_Lattice_min(2),N_Lattice_max(2)
        do i=N_Lattice_min(1),N_Lattice_max(1)
          ind=ind+1
          if (Lattice_inv_xyz(i,j,k)>0) then
            sing_prec_rearranged_density(ind)=Phi_source_density(Lattice_inv_xyz(i,j,k))
          else
            sing_prec_rearranged_density(ind)=0.0d0
          endif
        enddo
      enddo
    enddo
    open(td_total_density_file,file=fname1,form='unformatted',status='replace')
    write(td_total_density_file) sing_prec_rearranged_density
    close(td_total_density_file)
    !Now create a header file corresponding to the above datafile. The header file
    !is in ascii text form
    open(td_total_density_file,file=fname2,status='replace')
    write(td_total_density_file,'(1x,a,1x,es23.15)') 'TIME:',iter*time_step
    write(td_total_density_file,'(1x,a,1x,a)') 'DATA_FILE:',fname1(1:fnl)
    write(td_total_density_file,'(1x,a,3(1x,i6))') 'DATA_SIZE:',dk1,dk2,dk3
    write(td_total_density_file,'(1x,a)') 'DATA_FORMAT:  FLOAT'
    write(td_total_density_file,'(1x,a)') 'VARIABLE:  density'
    write(td_total_density_file,'(1x,a)') 'DATA_ENDIAN:  LITTLE'
    write(td_total_density_file,'(1x,a)') 'CENTERING:  zonal'
    write(td_total_density_file,'(1x,a,3(1x,es23.15))') 'BRICK_ORIGIN:',xgrid(k1min),ygrid(k2min),zgrid(k3min)
    write(td_total_density_file,'(1x,a,3(1x,es23.15))') 'BRICK_SIZE:', &
        xgrid(k1max)-xgrid(k1min),ygrid(k2max)-ygrid(k2min),zgrid(k3max)-zgrid(k3min)
    write(td_total_density_file,'(1x,a)') 'BYTE_OFFSET: 4'
    close(td_total_density_file)

td_density_counter_source=td_density_counter_source+1

END SUBROUTINE output_td_density_source


!Arthur
SUBROUTINE print_projection_file_header
    integer :: orbital,nc,j,nspaces
    integer,parameter  :: reclength=20
    integer,parameter  :: backmargin=3
    character(reclength)  str1,strorb1,strorb2
    character(2*reclength),parameter :: spstr=' '
    
    nc = N_orbitals*N_orbitals+2
    
    write(projection_file,'(2x,a2)',advance='no') '#1'
    write(projection_file,'(18x,a2)',advance='no') '#2'    
    do j=3,nc
        write(projection_file,'(1x,i19)',advance='no') j
    end do
    write(projection_file,*)
    
    write(projection_file,'(2x,a)',advance='no') '#iter'
    write(projection_file,'(8x,a,3x)',advance='no') '#time[fs]'

    do orbital=1,N_orbitals
       do j=1,N_orbitals
          write(strorb1,*) orbital
          write(strorb2,*) j
          
          write(str1,*) '|<',trim(adjustl(strorb1)),'(t)|',trim(adjustl(strorb2)),'(0)>|^2'
          nspaces=reclength-backmargin-len_trim(str1)
          write(projection_file,'(a)',advance='no') spstr(1:nspaces)
          write(projection_file,'(a)',advance='no') trim(str1)
          write(projection_file,'(a)',advance='no') spstr(1:backmargin)
       end do
    end do
    
    write(projection_file,*)
    flush(projection_file)
    
  END SUBROUTINE print_projection_file_header



subroutine update_projection_file(iter)
!This subroutine writes current positions, velocities, and forces
!Parameters:
! iter - iteration number (for ionic motion)
! t    - time in femtoseconds
!Parameters iter and t are printed in the first two columns
integer iter,atom,elem,j,p,ai,orbital
real(8) t,Xcm,Ycm,Zcm,Vcmx,Vcmy,Vcmz,V2,projection_squared
complex*8 :: projection

t=iter*time_step

write(projection_file,'(1x,i6)',advance='no') iter
write(projection_file,'(1x,e19.12)',advance='no') t

do orbital=1,N_orbitals
   do j=1,N_orbitals
      projection=sum(psi(:,j)*psi_c(:,orbital))*grid_volume
      projection_squared=CONJG(projection)*projection
      write(projection_file,'(1x,e19.12)',advance='no') projection_squared
   end do
end do

write(projection_file,*)
flush(projection_file)

end subroutine update_projection_file


END MODULE  TAYLOR_TIME

      SUBROUTINE tqli(d,e,n,np,z)
      INTEGER n,np
      REAL*8 d(np),e(np),z(np,np)
!     USES pythag
      INTEGER i,iter,k,l,m
      REAL*8 b,c,dd,f,g,p,r,s,pythag
      do 11 i=2,n
        e(i-1)=e(i)
11    continue
      e(n)=0.
      do 15 l=1,n
        iter=0
1       do 12 m=l,n-1
          dd=abs(d(m))+abs(d(m+1))
          if (abs(e(m))+dd.eq.dd) goto 2
12      continue
        m=n
2       if(m.ne.l)then
          if(iter.eq.30)pause 'too many iterations in tqli'
          iter=iter+1
          g=(d(l+1)-d(l))/(2.*e(l))
          r=pythag(g,1.d0)
          g=d(m)-d(l)+e(l)/(g+sign(r,g))
          s=1.
          c=1.
          p=0.
          do 14 i=m-1,l,-1
            f=s*e(i)
            b=c*e(i)
            r=pythag(f,g)
            e(i+1)=r
            if(r.eq.0.)then
              d(i+1)=d(i+1)-p
              e(m)=0.
              goto 1
            endif
            s=f/r
            c=g/r
            g=d(i+1)-p
            r=(d(i)-g)*s+2.*c*b
            p=s*r
            d(i+1)=g+p
            g=c*r-b
!     Omit lines from here ...
            do 13 k=1,n
              f=z(k,i+1)
              z(k,i+1)=s*z(k,i)+c*f
              z(k,i)=c*z(k,i)-s*f
13          continue
!     ... to here when finding only eigenvalues.
14        continue
          d(l)=d(l)-p
          e(l)=g
          e(m)=0.
          goto 1
        endif
15    continue
      return
      END

      FUNCTION pythag(a,b)
      REAL*8 a,b,pythag
      REAL*8 absa,absb
      absa=abs(a)
      absb=abs(b)
      if(absa.gt.absb)then
        pythag=absa*sqrt(1.+(absb/absa)**2)
      else
        if(absb.eq.0.)then
          pythag=0.
        else
          pythag=absb*sqrt(1.+(absa/absb)**2)
        endif
      endif
      return
      END
