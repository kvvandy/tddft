PROGRAM dipole_moment3

! 3D version

! #include "dft_common_uses.h"
! USE dftworks_info,         ONLY : print_literature

IMPLICIT NONE

  REAL*8, DIMENSION(:,:),ALLOCATABLE ::Dp3
  real*8,allocatable  :: alpha_R(:),alpha_I(:)
  integer              :: N_time
  real*8               :: dt,x,S,t,tt,hw,f
  REAL			:: df ! generalized damping function
  integer              :: i,k,n,m, ierr
  complex*16           :: zalpha
  COMPLEX*16	       :: zalpha1,zalpha2,zalpha3

  real(8),parameter    :: E2=14.4d0, H2M=3.81d0, a_B=0.529177d0
  real(8),parameter    :: Ry=13.6058d0, Pi=3.141592653589793d0
  REAL, PARAMETER      :: plank=4.135667E-15 !eV*sec
  INTEGER, PARAMETER      :: N_energy=3000 !number of energy steps
  REAL, PARAMETER      :: dE=0.01d0 !energy step
  REAL, PARAMETER      :: timescale=1.0E-15 ! femto
  INTEGER, PARAMETER   :: No=3 !must be odd integer>1, controls order of df expansion
  COMPLEX, PARAMETER   ::    zi=(0.d0,1.d0) ! sqrt(-1)

 CHARACTER (LEN=20) :: file_in, out_r, out_i, file_name !filenames
 INTEGER, PARAMETER	:: unitin=11, unitouti=12, unitoutr=13 !I/O channels
 CHARACTER (LEN=4), PARAMETER :: dat = '.dat'
 CHARACTER (LEN=12), PARAMETER :: alphar = '_alpha3r.dat',alphai = '_alpha3i.dat'

! TYPE(dft_error_type)                  :: error 


  PRINT*, 'DIPOLE computes photoabsorbtion cross-section'
  PRINT*, 'Enter input filename (*.dat), but w/o file extension:'
  READ*, file_name
  file_in=TRIM(file_name)//dat
  out_r=TRIM(file_name)//alphar
  out_i=TRIM(file_name)//alphai
  PRINT*,'Opening ',file_in, '...'
  OPEN(unitin, FILE=file_in,STATUS='OLD',ACTION='READ')

  READ(unitin,*) N_time, dt, f    ! numb of time points, dt, perturbation constant

   allocate(Dp3(0:N_time,1:3),STAT=ierr)
   IF (ierr /= 0) PRINT*, "Dp3 : Allocation failed"

  allocate(alpha_r(0:N_energy),alpha_i(0:N_energy),STAT=ierr)
  IF (ierr /= 0) PRINT*, "alphas : Allocation failed"

    Dp3=0.d0 !initialize Dp3

  PRINT*, "sizeof Dp3 is: ", SHAPE(Dp3)

  DO i=1,N_time   
    READ(unitin,FMT=10)x,Dp3(i,1),Dp3(i,2),Dp3(i,3)
10  FORMAT(4(F13.7,2X))
!      PRINT*,x,Dp3(i,:)   
  END DO

  PRINT*, "Read and allocated Dp3"
  CLOSE(unitin)

! Fourier Transform

      TT = dt*N_time
  PRINT*, "Starting fourier integral"

!$OMP PARALLEL
!$OMP DO
      do m=0,N_energy
         hw=m*dE ; zalpha=(0.d0,0.d0); zalpha1=zalpha; zalpha2=zalpha; zalpha3=zalpha
         do n=1,N_time
            t=n*dt ;  df=0.0
           DO k=2, No
             df=df+((-1)**(k+1))*(k+(-1)**k)*(t/TT)**k
           END DO
           df=df*(2/(No-1))+1.0
		zalpha1=zalpha1+exp(zi*hw*t)*Dp3(n,1)*df
		zalpha2=zalpha2+exp(zi*hw*t)*Dp3(n,2)*df
		zalpha3=zalpha3+exp(zi*hw*t)*Dp3(n,3)*df
         end do
         zalpha=(1/3.d0)*(zalpha1+zalpha2+zalpha3)*E2/F*dt  !Averaging complex polarizability
         alpha_R(m)=real(zalpha,8)    ! Real part
         alpha_I(m)=imag(zalpha)      ! Imaginary part
      end do
!$OMP END DO
!$OMP END PARALLEL

!  PRINT*, "Opening alpha files"  
! Alpha
      open(unitoutr,file=out_r)
      open(unitouti,file=out_i)
  PRINT*, "Computing linear response function"
        do N=0,N_energy
           S=2*n*dE/(Pi*a_B*E2**2)*alpha_I(n)
            write(unitoutr,*) n*dE, alpha_R(n)
            write(unitouti,*) n*dE, S
         end do
  PRINT*, "Spectral response is written to ", out_r, " and ", out_i
  PRINT*,"Energy resolution (delta)E=",plank/(2*Pi*TT*timescale)," (eV)"
      close(unitouti)
      close(unitoutr)
  PRINT*, "Program dipole has finished normally"
END PROGRAM
