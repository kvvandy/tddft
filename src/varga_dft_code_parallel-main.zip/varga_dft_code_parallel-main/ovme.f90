MODULE OVERLAPMATRIX
USE COMMON_LIBRARY
USE PARAMETERS
USE MOD_GLOBAL
  implicit none

  real*8                       :: ft_ov(Ngm,Ngm,0:2*Lexp)
  real*8                       :: ft_ke(Ngm,Ngm,0:2*Lexp)
  real*8                       :: ov(Ngm,Ngm,-lexp:lexp,-lexp:lexp)
  real*8                       :: ke(Ngm,Ngm,-lexp:lexp,-lexp:lexp)

CONTAINS

subroutine OVER(ra,la,rb,lb)
implicit none
  integer           :: la,lb,ma,mb
  real*8            :: ra(3),rb(3),rab(3)
  real*8            :: x,d,fv,dab,q,sua,sub,bfa,bfb
  complex*16        :: suov(4),suke(4)
  integer           :: i,j,iq,ia,ib,lab,mma,mmb,j1,j2
  real*8            :: xn1,xn2,w
  complex*16        :: angf(4),ang(0:2*Lexp)

  rab=ra-rb
  dab=sqrt(rab(1)**2+rab(2)**2+rab(3)**2)
  ft_ov=0.d0
  ft_ke=0.d0
  ov=0.d0
  ke=0.d0


  do lab=iabs(la-lb),la+lb
    do j2=1,Ng
      do j1=1,Ng
        xn1=1.d0/(a0*x0**(j1-1))**2
        xn2=1.d0/(a0*x0**(j2-1))**2
        ft_ov(j1,j2,lab)=q_integral(xn1,la,xn2,lb,dab,lab,0,0.d0)
        ft_ke(j1,j2,lab)=q_integral(xn1,la,xn2,lb,dab,lab,2,0.0d0)
      end do
    end do
  end do

do mb=-lb,lb
  do ma=-la,la
    mma=abs(ma)
    mmb=abs(mb)
    ang=(0.d0,0.d0)
    do lab=iabs(la-lb),la+lb
      angf(1)=4.d0*pi*zi**(lab-lb+la)*gaunt(lb,mmb,la,mma,lab)*spherical_harmonics(rab,lab,mmb-mma)
      angf(2)=4.d0*pi*zi**(lab-lb+la)*gaunt(lb,-mmb,la,mma,lab)*spherical_harmonics(rab,lab,-mmb-mma)*(-1)**mb
      angf(3)=4.d0*pi*zi**(lab-lb+la)*gaunt(lb,mmb,la,-mma,lab)*spherical_harmonics(rab,lab,mmb+mma)*(-1)**ma
      angf(4)=4.d0*pi*zi**(lab-lb+la)*gaunt(lb,-mmb,la,-mma,lab)*spherical_harmonics(rab,lab,-mmb+mma)*(-1)**(ma+mb)
      if(ma.eq.0.and.mb.eq.0) then
        ang(lab)=angf(1)
      endif
      if(ma.gt.0.and.mb.gt.0) then
        ang(lab)=0.5d0*(angf(1)+angf(2)+angf(3)+angf(4))
      endif
      if(ma.eq.0.and.mb.gt.0) then
        ang(lab)=1.d0/sqrt(2.d0)*(angf(1)+angf(2))
      endif
      if(ma.eq.0.and.mb.lt.0) then
        ang(lab)=zi/sqrt(2.d0)*(-angf(1)+angf(2))
      endif
      if(ma.gt.0.and.mb.eq.0) then
        ang(lab)=1.d0/sqrt(2.d0)*(angf(1)+angf(3))
      endif
      if(ma.lt.0.and.mb.eq.0) then
        ang(lab)=zi/sqrt(2.d0)*(angf(1)-angf(3))
      endif
      if(ma.lt.0.and.mb.lt.0) then
        ang(lab)=-0.5d0*(-angf(1)+angf(2)+angf(3)-angf(4))
      endif
      if(ma.gt.0.and.mb.lt.0) then
        ang(lab)=zi*0.5d0*(-angf(1)+angf(2)-angf(3)+angf(4))
      endif
      if(ma.lt.0.and.mb.gt.0) then
        ang(lab)=zi*0.5d0*(angf(1)+angf(2)-angf(3)-angf(4))
      endif
    end do

    do lab=iabs(la-lb),la+lb
      do ib=1,Ng
        do ia=1,Ng
          ov(ia,ib,ma,mb)=ov(ia,ib,ma,mb)+ft_ov(ia,ib,lab)*ang(lab)
          ke(ia,ib,ma,mb)=ke(ia,ib,ma,mb)+ft_ke(ia,ib,lab)*ang(lab)*h2m
        end do
      end do
    end do
  end do
end do

end subroutine OVER


function q_integral(nu1,l1,nu2,l2,d,L,m,b)
implicit none
real*8   :: x,w,a,d,fac,aa,w1,w2,q_integral,nu1,nu2,b
integer  :: n,k,l,i,l1,l2,m

w1=(2.d0*nu1/pi)**0.75d0*sqrt(4.d0*pi)*sqrt(2.d0**l1/dfa(l1))*(sqrt(2.d0*nu1))**l1/(2.d0*nu1)**(l1+1.5d0)
w2=(2.d0*nu2/pi)**0.75d0*sqrt(4.d0*pi)*sqrt(2.d0**l2/dfa(l2))*(sqrt(2.d0*nu2))**l2/(2.d0*nu2)**(l2+1.5d0)
k=l1+l2+m
a=0.25d0/nu1+0.25d0/nu2
aa=0.25d0*d**2/a+b
n=(k-l)/2
fac=1
do i=1,n
  fac=fac*i
end do
w=sqrt(0.5d0*pi)*fac*d**l*2.d0**n/((2.d0*a)**(n+l+1.5d0))*exp(-aa)*Laguerre(n,l+0.5d0,aa)
q_integral=w*w1*w2

end function q_integral

END  MODULE OVERLAPMATRIX

