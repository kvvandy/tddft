Subroutine Poisson_Solver
USE MOD_GLOBAL
implicit none
integer, parameter :: itype_scf=8
real(kind=8), dimension(:,:,:), allocatable :: rhopot, karray
real(kind=8) :: x1,x2,x3,r,r2,hgrid,xx
real(kind=8) :: ehartree,eexcu,vexcu
integer :: n01,n02,n03,m1,m2,m3,md1,md2,md3,nd1,nd2,nd3,n1,n2,n3
integer :: i1,i2,i3,i1_max,i2_max,i3_max,n1k,n2k,n3k,iproc,nproc,ierr,i
integer :: i_allocated,l1,nsp1,nsp2,nsp3,nfft1,nfft2,nfft3
integer :: ns1,ns2,ns3

n01=N_Lattice_max(1)-N_Lattice_min(1)+1
n02=N_Lattice_max(2)-N_Lattice_min(2)+1
n03=N_Lattice_max(3)-N_Lattice_min(3)+1
hgrid=Grid_Step(1)
allocate(rhopot(n01,n02,n03))

if (box_type==1) then
  do i=1,N_Lattice_points
    i1=Lattice(1,i)+1
    i2=Lattice(2,i)+1
    i3=Lattice(3,i)+1
    rhopot(i1,i2,i3)=Density(i)-Rho_bg(i)
  end do
endif

if ((box_type==2).or.(box_type==3)) then
  ns3=0
  do i3=N_Lattice_min(3),N_Lattice_max(3)
    ns3=ns3+1
    ns2=0
    do i2=N_Lattice_min(2),N_Lattice_max(2)
      ns2=ns2+1
      ns1=0
      do i1=N_Lattice_min(1),N_Lattice_max(1)
        ns1=ns1+1
        i=Lattice_inv_xyz(i1,i2,i3)
        if (i>0) then
          rhopot(ns1,ns2,ns3)=Density(i)-Rho_bg(i)
        else
          rhopot(ns1,ns2,ns3)=0.0d0
        endif
      end do
    end do
  end do
endif

!Build the Kernel for full size
!Fullsize
call Dimensions_FFT(n01,n02,n03,nfft1,nfft2,nfft3)
n1k=nfft1/2+1
n2k=nfft2/2+1
n3k=nfft3/2+1
allocate(karray(n1k,n2k,n3k),stat=i_allocated)
if (i_allocated /= 0) then
   print *,"Problem of memory allocation"
   stop
end if
call Build_Kernel(n01,n02,n03,nfft1,nfft2,nfft3,hgrid,itype_scf,karray)
call PSolver_Kernel(n01,n02,n03,nfft1,nfft2,nfft3,hgrid,karray,rhopot,ehartree)

if(box_type==1) then
  do i=1,N_Lattice_points
    i1=Lattice(1,i)+1
    i2=Lattice(2,i)+1
    i3=Lattice(3,i)+1
    VH(i)=rhopot(i1,i2,i3)
  end do
endif

if ((box_type==2).or.(box_type==3)) then
  ns3=0
  do i3=N_Lattice_min(3),N_Lattice_max(3)
    ns3=ns3+1
    ns2=0
    do i2=N_Lattice_min(2),N_Lattice_max(2)
      ns2=ns2+1
      ns1=0
      do i1=N_Lattice_min(1),N_Lattice_max(1)
        ns1=ns1+1
        i=Lattice_inv_xyz(i1,i2,i3)
        if (i>0) VH(i)=rhopot(ns1,ns2,ns3)
      end do
    end do
  end do
endif

!De-allocations
deallocate(karray)
deallocate(rhopot)

End Subroutine Poisson_Solver
