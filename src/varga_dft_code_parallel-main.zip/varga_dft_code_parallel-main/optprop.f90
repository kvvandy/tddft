program optprop
!This program computes the real and imaginary part of the complex 
!polarizability (frequency dependent), as well as the absorption 
!strength given the induced dipole moment as a function of time.
!Basically it computes the Fourier transform of the dipole moment
!multiplied by a damping factor. Usage:
!  $ optprop file1
!or
!  $ optprop file1 file2
!or
!  $ optprop file1 file2 file3 file4 
!or
!  $ optprop file1 file2 file3 file4 Emin Emax nE
!where 
!  file1 is the file where the dipole moment data is read from (default: dp.dat)
!  file2 is the file where the absorption spectrum is written (default: S.dat)
!  file3 is the file where the real part of the polarizability is written (default: alphar.dat)
!  file4 is the file where the imaginary part of the polarizability is written (default: alphai.dat)
!  Emin and Emax specify the range of energies in electronvolts (default: 0.0 eV and 25.0 eV) 
!  nE is the number of energy points in the range [Emin,Emax] (default: 2501)
!The format of the input file containing the dipole moment should 
!be the following. The first line contains three numbers: an integer 
!and two real numbers. The integer is read, but not used in the 
!program. The first real number is the time step, dt, used to tabulate 
!the dipole moment in the file (the mesh must be uniform). The second 
!real number is the strength of the delta-perturbation used in the 
!calculations of the dipole moment data. After the first line the rest 
!of the file should contain two columns of data: time and the dipole 
!moment corresponding to that time. 

implicit none
real(8),allocatable          :: t(:),dp(:),dp_damped(:)
real(8),allocatable          :: w1(:),w2(:),alphar(:),alphai(:),S(:)
integer                      :: nt,nE,i,j,nargs,errcode,dummy_int
real(8)                      :: Emin,Emax,E,dE
real(8)                      :: dt,f,tmax,dummy_r1,dummy_r2,att,tr1,tr2
integer,parameter            :: MaxFileNameLength=100
character(MaxFileNameLength) :: chbuffer,dp_file,alphar_file,alphai_file,S_file
integer                      :: iargc

!Define some constants

real(8),parameter            :: hbar=0.658211899d0  !Planck constant over 2*pi in eV*fs

!mfact1 is 1/(4*pi*eps_0), where eps_0=0.005526349868 eV/(Angstrom*V^2) - the
!electric constant
real(8),parameter            :: mfact1=14.39964415d0

!mfact2=2/(pi*0.52917720859*mfact1^2)
real(8),parameter            :: mfact2=0.005801969913d0


dp_file='dp.dat'
S_file='S.dat'
alphar_file='alphar.dat'
alphai_file='alphai.dat'
Emin=0.0d0
Emax=25.0d0
nE=2501

!Determine the number of arguments and see if they are ok 
nargs=iargc()
if (nargs==0) then
  write(*,*) 'Usage:'
  write(*,*) '  optprop dp.dat'
  write(*,*) 'or'
  write(*,*) '  optprop dp.dat S.dat'
  write(*,*) 'or'
  write(*,*) '  optprop dp.dat S.dat alphar.dat alphai.dat'
  write(*,*) 'or'
  write(*,*) '  optprop dp.dat S.dat alphar.dat alphai.dat Emin Emax Npoints'
  write(*,*) 'where'
  write(*,*) '  dp.dat - file containing the dipole moment data (input)'
  write(*,*) '  S.dat - file containing absorption strength (output)'
  write(*,*) '  alphar.dat - file containng the real part of polarizability (output)'
  write(*,*) '  alphai.dat - file containng the imaginary part of polarizability (output)'
  write(*,*) '  Emin, Emax - desired energy range (input, in eV)'
  write(*,*) '  Npoints - number of points to compute S (input)'
  stop
endif

if ((nargs/=1).and.(nargs/=2).and.(nargs/=4).and.(nargs/=7)) then
  write(*,*) 'Error: wrong number of arguments (must be 1, 2, 4, or 7)'
  stop
endif
if (nargs>=1) then
  call getarg(1,chbuffer)
  dp_file=trim(chbuffer)
endif
if (nargs>=2) then
  call getarg(2,chbuffer)
  S_file=trim(chbuffer)
endif
if (nargs>=3) then
  call getarg(3,chbuffer)
  alphar_file=trim(chbuffer)
endif
if (nargs>=4) then
  call getarg(4,chbuffer)
  alphai_file=trim(chbuffer)
endif
if (nargs>=5) then
  call getarg(5,chbuffer)
  read(chbuffer,*,iostat=errcode) Emin
  if ((errcode/=0).or.(Emin<0.0d0)) then
    write(*,*) 'Error: 5-th argument is wrong'
    stop
  endif
endif
if (nargs>=6) then
  call getarg(6,chbuffer)
  read(chbuffer,*,iostat=errcode) Emax
  if ((errcode/=0).or.(Emax<=Emin)) then
    write(*,*) 'Error: 6-th argument is wrong'
    stop
  endif
endif
if (nargs>=7) then
  call getarg(7,chbuffer)
  read(chbuffer,*,iostat=errcode) nE
  if ((errcode/=0).or.(nE<3)) then
    write(*,*) 'Error: 7-th argument is wrong'
    stop
  endif
endif

!Open file dp_file and count the number of points it contains
open(1,file=dp_file,action='read',status='old',iostat=errcode)
if (errcode/=0) then
  write(*,*) 'Error: cannot access file ',trim(dp_file)
  stop
endif
read(1,*) dummy_int,dt,f
nt=-1
do while (errcode==0)
  read(1,*,iostat=errcode) dummy_r1,dummy_r2
  nt=nt+1 
enddo

!Add a point for dp(t=0), which is zero and not stored in the file
nt=nt+1

!Check if the total number of points is not too small
if (nt<3) then
  write(*,*) 'Error: insufficient data in file ',trim(dp_file)
  stop
endif

!Allocate arrays according to the amount of data in file
allocate(t(nt),dp(nt),dp_damped(nt),w1(nt),w2(nt))

!Go to the beginning of the file and read the dipole moment in newly
!allocated arrays
rewind(1)
read(1,*) dummy_int,dt,f
tr1=dt*(1.0d0-sqrt(epsilon(1.0d0)))
tr2=dt*(1.0d0+sqrt(epsilon(1.0d0)))
t(1)=0.0d0
dp(1)=0.0d0
do i=2,nt
  read(1,*) t(i), dp(i)
  !check if the t-mesh is uniform (this is required for composite Simpson integration)
  att=abs(t(i)-t(i-1))
  if ((att<tr1.or.att>tr2)) then
    write(*,*) 'Error: nonuniform time step detected in file ',trim(dp_file)
    write(*,*) 'in line ',i
    stop
  endif
enddo
close(1)

!Invert the sign of the dipole moment, otherwise the absorption strength will be negative
!This is (probably) needed bacause the dipole moment computed by the dft code
!accounts for the negative change of electrons, which is (probably) not included
!in the definition of alpha and S.
dp(1:nt)=-dp(1:nt)

!Allocate arrays for the absorption spectrum and polarizabilities
allocate(S(nE),alphar(nE),alphai(nE))

!Compute the damped dipole moment
tmax=t(nt)
do i=1,nt
  dp_damped(i)=dp(i)*(1.0d0-3*(t(i)/tmax)**2+2*(t(i)/tmax)**3)
enddo

!Now do the Fourier transform of the damped induced dipole moment
dE=(Emax-Emin)/(nE-1)
do i=1,nE
  E=Emin+(i-1)*dE
  do j=1,nt
    w1(j)=cos(E*t(j)/hbar)*dp_damped(j)
    w2(j)=sin(E*t(j)/hbar)*dp_damped(j)
  enddo  
  call simpson(nt,dt,w1,tr1)
  call simpson(nt,dt,w2,tr2)
  alphar(i)=mfact1*tr1/f
  alphai(i)=mfact1*tr2/f
  S(i)=mfact2*E*alphai(i)
enddo

!Save the absorption spectrum and polarizabilities
open(1,file=S_file,action='write',status='replace')
do i=1,nE
  E=Emin+(i-1)*dE
  write(1,*) E,S(i)
enddo
close(1)
open(1,file=alphar_file,action='write',status='replace')
do i=1,nE
  E=Emin+(i-1)*dE
  write(1,*) E,alphar(i)
enddo
close(1)
open(1,file=alphai_file,action='write',status='replace')
do i=1,nE
  E=Emin+(i-1)*dE
  write(1,*) E,alphai(i)
enddo
close(1)

deallocate(S,alphar,alphai)
deallocate(t,dp,dp_damped,w1,w2)

end program optprop


subroutine simpson(n,h,f,res)
!This is a subroutine for Simpson-integration of function f defined
!on a uniform grid with spacing h. Array f(1:n) should contain function
!values. n is the total number of points. If n=2 then the Simpson
!rule cannot be applied and the integration is done with the trapezoidal
!rule. If n is even than the Simpson's rule is modified to add the last
!segment separately using the same order approximation.
!The integral value is returned in res.
implicit none
integer, intent(in)  :: n
real(8), intent(in)  :: h
real(8), intent(in)  :: f(n)
real(8), intent(out) :: res
integer              :: i
real(8)              :: s2,s4

if (n<1) then
  write(*,*) 'Error in integrate_simpson: number of points must be greater or equal to 1'
  stop
endif

select case(n)
  case(1)
    !Rectangle rule
    res=h*f(1)
  case(2)
    !Since there are just two points we have to use the trapezoidal rule
    res=0.5d0*h*(f(1)+f(2))
  case(3)
    !Simpson's rule
    res=(1/3.0d0)*h*(f(1)+4*f(2)+f(3))
  case(4)
    !Simpson's rule for the first two h-segments and
    !the same order approximation for the third segment
    !which in this case yields Simpson's 3/8 rule
    res=(3.0d0/8.0d0)*h*(f(1)+3*(f(2)+f(3))+f(4))
  case default
    !Composite Simpson's rule
    if (mod(n,2)==0) then
      !If n is even, we need to add the last segment separately.
      !In this case it is no longer the classical Simpson's rule,
      !although the accuracy will be of the same order.
      s2=0.0d0
      s4=0.0d0
      do i=3,n-2,2
        s2=s2+f(i)
        s4=s4+f(i+1)
      enddo
      res=(1/24.0d0)*h*(8*f(1)+32*(f(2)+s4)+16*s2+f(n-3)-5*f(n-2)+27*f(n-1)+9*f(n))
    else
      !If n is odd then the usual Simpson's rule can be applied
      s2=0.0d0
      s4=0.0d0
      do i=3,n-1,2
        s2=s2+f(i)
        s4=s4+f(i+1)
      enddo
      res=(1/3.0d0)*h*(f(1)+4*(f(2)+s4)+2*s2+f(n))
    endif
endselect

end subroutine simpson

