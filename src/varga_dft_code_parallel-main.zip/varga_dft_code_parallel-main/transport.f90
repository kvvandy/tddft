MODULE MOD_TRANSPORT
USE MOD_GLOBAL
USE FD_POISSON
USE HAMILTON
  implicit none
! Hartree potential and electron density in the lead block
  double precision,allocatable    :: VH_lead_L(:),rho_lead_L(:)
  double precision,allocatable    :: VH_lead_R(:),rho_lead_R(:)
! Hartree potential and electron density in the device
  double precision,allocatable    :: VH_C(:),rho_C(:)
  double precision,allocatable    :: VH_Center(:),rho_Center(:)
  integer                         :: NLP_C,NLP_L,NLP_R
  integer,allocatable             :: Nx_b(:)

  CONTAINS



  subroutine init_transport_me

    implicit none
    integer             :: i,i1,i2,i3,j,k
    double precision    :: x,h1,h2,h3,su
    character*255 :: full_filename
    logical       :: file_exists

    if(N_box/=9) then
      write(log_file,*)'N_box/=9'
      stop
    endif

    NLP_L=Nx_box(1)*N_Lattice(2)*N_Lattice(3)
    NLP_C=Nx_box(5)*N_Lattice(2)*N_Lattice(3)
    NLP_R=Nx_box(6)*N_Lattice(2)*N_Lattice(3)
    allocate(VH_lead_R(NLP_R),rho_lead_R(NLP_R))
    allocate(VH_lead_L(NLP_L),rho_lead_L(NLP_L))
    allocate(VH_Center(NLP_C),rho_Center(NLP_C))

!   left
!  inquire(file=trim(adjustl(transport_density_L_filename)), exist=file_exists)
!  if(file_exists) then
!    full_filename=transport_density_L_filename
!  else
    write(full_filename,'(2a)')trim(adjustl(gs_path)),trim(adjustl(transport_density_L_filename))
!  endif
  write(log_file,*)"transport_density_L full filename: ",trim(adjustl(full_filename))

    open(transport_density_L_file,file=trim(adjustl(full_filename)))
      read(transport_density_L_file,*)i1,i2,i3
      if(i1/=Nx_box(1)) then
        write(log_file,*)'lead_L does not match'
        stop
      endif
      do i=1,NLP_L
        read(transport_density_L_file,*)VH_lead_L(i),x,rho_lead_L(i)
      end do
    close(transport_density_L_file)
!   center
!  inquire(file=trim(adjustl(transport_density_C_filename)), exist=file_exists)
!  if(file_exists) then
!    full_filename=transport_density_C_filename
!  else
    write(full_filename,'(2a)')trim(adjustl(gs_path)),trim(adjustl(transport_density_C_filename))
!  endif
  write(log_file,*)"transport_density_C full filename: ",trim(adjustl(full_filename))

    open(transport_density_C_file,file=trim(adjustl(full_filename)))
      read(transport_density_C_file,*)i1,i2,i3
      if(i1/=Nx_box(5)) then
        write(log_file,*)'lead_C does not match'
        stop
      endif
      do i=1,NLP_C
        read(transport_density_C_file,*)VH_Center(i),x,rho_Center(i)
      end do
    close(transport_density_C_file)
!   right
!  inquire(file=trim(adjustl(transport_density_R_filename)), exist=file_exists)
!  if(file_exists) then
!    full_filename=transport_density_R_filename
!  else
    write(full_filename,'(2a)')trim(adjustl(gs_path)),trim(adjustl(transport_density_R_filename))
!  endif
  write(log_file,*)"transport_density_R full filename: ",trim(adjustl(full_filename))

    open(transport_density_R_file,file=trim(adjustl(full_filename)))
      read(transport_density_R_file,*)i1,i2,i3
      if(i1/=Nx_box(6)) then
        write(log_file,*)'lead_R does not match'
        stop
      endif
      do i=1,NLP_R
        read(transport_density_R_file,*)VH_lead_R(i),x,rho_lead_R(i)
      end do
    close(transport_density_R_file)
!   left
    i=0
    do k=1,4
      j=0
      do i1=1,Nx_box(1)
        do i2=1,N_Lattice(2)
          do i3=1,N_Lattice(3)
            i=i+1; j=j+1
            density(i)=rho_lead_L(j)
            V_Hartree(i)=VH_lead_L(j)
          end do
        end do
      end do
    end do

!  center
    i=4*NLP_L
    j=0
    do i1=1,Nx_box(5)
      do i2=1,N_Lattice(2)
        do i3=1,N_Lattice(3)
          i=i+1;j=j+1
          density(i)=rho_Center(j)
          V_Hartree(i)=VH_Center(j)
        end do
      end do
    end do
! right
    i=4*NLP_L+NLP_C
    do k=1,4
      j=0
      do i1=1,Nx_box(6)
        do i2=1,N_Lattice(2)
          do i3=1,N_Lattice(3)
            i=i+1; j=j+1
            density(i)=rho_lead_R(j)
            V_Hartree(i)=VH_lead_R(j)
          end do
        end do
      end do
    end do

    call plot(1)

    call exchange_correlation_potential

    call plot(1) !jad
  end subroutine init_transport_me


  subroutine init_transport
! BC for transport
! blocks fixed in the left and in the right

    implicit none
    integer             :: i,i1,i2,i3,j,k
    double precision    :: x,h1,h2,h3,su
    character*255 :: full_filename
    logical       :: file_exists

    allocate(Nx_b(3))

    V_hartree=0.d0

    if(fd_p_full) then
      Nx_b(1)=Nx_box(1)
      Nx_b(2)=N_Lattice(1)-2*Nx_box(1)
      Nx_b(3)=Nx_box(1)
    else
      Nx_b=Nx_box
      if(N_box/=3) then
        write(log_file,*)'N_box/=3'
        stop
      endif
    endif

    write(log_file,*)'poisson box division',Nx_b

    NLP_L=Nx_b(1)*N_Lattice(2)*N_Lattice(3)
    NLP_C=Nx_b(2)*N_Lattice(2)*N_Lattice(3)
    NLP_R=Nx_b(3)*N_Lattice(2)*N_Lattice(3)
    allocate(VH_lead_R(NLP_R),rho_lead_R(NLP_R))
    allocate(VH_lead_L(NLP_L),rho_lead_L(NLP_L))
    allocate(VH_Center(NLP_C),rho_Center(NLP_C))

    if(fd_p_full) then
      allocate(VH_C(NLP_L+NLP_C+NLP_R),rho_C(NLP_L+NLP_C+NLP_R))
    else
      allocate(VH_C(NLP_C),rho_C(NLP_C))
    endif

    h1=grid_step(1)
    h2=grid_step(2)
    h3=grid_step(3)

    if(fd_p_full) then
      i1=N_Lattice(1)
    else
      i1=Nx_b(2)
    endif

    i2=N_Lattice(2)
    i3=N_Lattice(3)
    call init_Poisson(i1,i2,i3,h1,h2,h3)

!   left

!  inquire(file=trim(adjustl(transport_density_L_filename)), exist=file_exists)
!  if(file_exists) then
!    full_filename=transport_density_L_filename
!  else
    write(full_filename,'(2a)')trim(adjustl(gs_path)),trim(adjustl(transport_density_L_filename))
!  endif
  write(log_file,*)"transport_density_L full filename: ",trim(adjustl(full_filename))

    open(transport_density_L_file,file=trim(adjustl(full_filename)))
      read(transport_density_L_file,*)i1,i2,i3
      if(i1/=Nx_b(1)) then
        write(log_file,*)'lead_L does not match'
        stop
      endif
      do i=1,NLP_L
        read(transport_density_L_file,*)VH_lead_L(i),x,rho_lead_L(i)
      end do
    close(transport_density_L_file)

!   center
!  inquire(file=trim(adjustl(transport_density_C_filename)), exist=file_exists)
!  if(file_exists) then
!    full_filename=transport_density_C_filename
!  else
    write(full_filename,'(2a)')trim(adjustl(gs_path)),trim(adjustl(transport_density_C_filename))
!  endif
  write(log_file,*)"transport_density_C full filename: ",trim(adjustl(full_filename))

    open(transport_density_C_file,file=trim(adjustl(full_filename)))
      read(transport_density_C_file,*)i1,i2,i3
      if(i1/=Nx_b(2)) then
        write(log_file,*)'C does not match'
        stop
      endif
      do i=1,NLP_C
        read(transport_density_C_file,*)VH_Center(i),x,rho_Center(i)
      end do
    close(transport_density_C_file)

!   right

!  inquire(file=trim(adjustl(transport_density_R_filename)), exist=file_exists)
!  if(file_exists) then
!    full_filename=transport_density_R_filename
!  else
    write(full_filename,'(2a)')trim(adjustl(gs_path)),trim(adjustl(transport_density_R_filename))
!  endif
  write(log_file,*)"transport_density_R full filename: ",trim(adjustl(full_filename))

    open(transport_density_R_file,file=trim(adjustl(full_filename)))
      read(transport_density_R_file,*)i1,i2,i3
      if(i1/=Nx_b(3)) then
        write(log_file,*)'lead_R does not match'
        stop
      endif
      do i=1,NLP_R
        read(transport_density_R_file,*)VH_lead_R(i),x,rho_lead_R(i)
      end do
    close(transport_density_R_file)
!   left
    i=0
    j=0
    do i1=1,Nx_b(1)
      su=0.d0
      do i2=1,N_Lattice(2)
        do i3=1,N_Lattice(3)
          i=i+1; j=j+1
          density(i)=rho_lead_L(j)
          V_Hartree(i)=VH_lead_L(j)
          if(i1==Nx_b(1)) VL(i2,i3)=V_Hartree(i)-0.5d0*V_bias
          su=su+V_hartree(i)
        end do
      end do
    end do
!  center
    i=NLP_L
    j=0
    do i1=1,Nx_b(2)
      do i2=1,N_Lattice(2)
        do i3=1,N_Lattice(3)
          i=i+1;j=j+1
          density(i)=rho_Center(j)
          V_Hartree(i)=VH_Center(j)
        end do
      end do
    end do
! right
    i=NLP_L+NLP_C
    j=0
    do i1=1,Nx_b(3)
      do i2=1,N_Lattice(2)
        do i3=1,N_Lattice(3)
          i=i+1; j=j+1
          density(i)=rho_lead_R(j)
          V_Hartree(i)=VH_lead_R(j)
          if(i1==1) VR(i2,i3)=V_Hartree(i)+0.5d0*V_bias
        end do
      end do
    end do
!
    if(fd_p_full) then
      do i=1,NLP_L
        rho_C(i)=rho_lead_L(i)-rho_bg(i)
      end do
      do i=1,NLP_C
        rho_C(NLP_L+i)=rho_center(i)-rho_bg(NLP_L+i)
      end do
      do i=1,NLP_R
        rho_C(NLP_L+NLP_C+i)=rho_lead_R(i)-rho_bg(NLP_L+NLP_C+i)
      end do
    else
      do i=1,NLP_C
        rho_C(i)=rho_center(i)-rho_bg(i)
      end do
    endif

    call exchange_correlation_potential

    call plot(1)

  end subroutine init_transport



subroutine init_right_lead
! read in density and potential and map it to the new grid

  implicit none
  integer                       :: i,i1,i2,i3,j,k
  double precision, allocatable :: vold(:),rold(:),xold(:),yold(:),zold(:)
  double precision, allocatable :: xnew(:),ynew(:),znew(:)
  integer                       :: N_old(3),N_new(3)
  double precision              :: LB(3),x,grid_volume_old
    logical :: file_exists

  character*255 :: full_filename

  allocate(Nx_b(N_box))
  Nx_b=Nx_box
  NLP_R=Nx_b(1)*N_Lattice(2)*N_Lattice(3)
  allocate(VH_lead_R(NLP_R),rho_lead_R(NLP_R))
  N_new(1)=Nx_b(1)
  N_new(2)=N_Lattice(2)
  N_new(3)=N_Lattice(3)
  LB(1)=grid_step(1)*Nx_b(1)
  LB(2)=2.d0*R_size(2)
  LB(3)=2.d0*R_size(3)

  do i=1,N_box
    if(Nx_b(i).ne.Nx_b(1)) then
      write(log_file,*)'lead boxes expected to be equal in size'
      write(log_file,*)"Nx_box: ",Nx_box
      stop
    endif
  end do
!   right
  allocate(xnew(N_new(1)),ynew(N_new(2)),znew(N_new(3)))

!  inquire(file=trim(adjustl(transport_density_R_filename)), exist=file_exists)
!  if(file_exists) then
!    full_filename=transport_density_R_filename
!  else
    write(full_filename,'(2a)')trim(adjustl(gs_path)),trim(adjustl(transport_density_R_filename))
!  endif
  write(log_file,*)"transport_density_R full filename: ",trim(adjustl(full_filename))

  open(transport_density_R_file,file=trim(adjustl(full_filename)))
    read(transport_density_R_file,*)N_old(1),N_old(2),N_old(3)
    allocate(vold(N_old(1)*N_old(2)*N_old(3)),rold(N_old(1)*N_old(2)*N_old(3)),xold(N_old(1)),yold(N_old(2)),zold(N_old(3)))
    do i=1,N_old(1)*N_old(2)*N_old(3)
      read(transport_density_R_file,*)vold(i),x,rold(i)
      vold(i)=vold(i)
    end do
    do i=1,N_old(1)
      read(transport_density_R_file,*)xold(i)
    end do
    do i=1,N_old(2)
      read(transport_density_R_file,*)yold(i)
    end do
    do i=1,N_old(3)
      read(transport_density_R_file,*)zold(i)
    end do
  close(transport_density_R_file)
  xold=xold-xold(1)-0.5d0*LB(1)

  do i=1,N_new(1)
    xnew(i)=-0.5d0*LB(1)+(i-1)*grid_step(1)
  end do
  do i=1,N_new(2)
    ynew(i)=-0.5d0*LB(2)+(i-1)*grid_step(2)
  end do
  do i=1,N_new(3)
    znew(i)=-0.5d0*LB(3)+(i-1)*grid_step(3)
  end do

  grid_volume_old=(xold(2)-xold(1))*(yold(2)-yold(1))*(zold(2)-zold(1))

  call per_cos_fit(N_old,xold,yold,zold,grid_volume_old,LB,rold,N_new,xnew,ynew,znew,rho_lead_R)
  call per_cos_fit(N_old,xold,yold,zold,grid_volume_old,LB,vold,N_new,xnew,ynew,znew,VH_lead_R)

  write(log_file,*)'Mapping',sum(rold)*grid_volume_old,sum(rho_lead_R)*grid_volume
  write(log_file,*)grid_volume_old/grid_volume


!OLD
!    i=0
!    do k=1,N_box
!      j=0
!      do i1=1,Nx_b(k)
!        do i2=1,N_Lattice(2)
!          do i3=1,N_Lattice(3)
!            i=i+1; j=j+1
!            density(i)=rho_lead_R(j)
!            V_Hartree(i)=VH_lead_R(j)
!          end do
!        end do
!      end do
!    end do

!    call Exchange_Correlation_potential

  i=0
   do k=1,N_box
     j=0
     do i1=1,Nx_b(k)
       do i2=1,N_Lattice(2)
         do i3=1,N_Lattice(3)
           i=i+1; j=j+1
           if(rho_lead_R(j)>0) then
             density(i)=rho_lead_R(j)
           else
             density(i)=0.d0
           endif
           V_Hartree(i)=VH_lead_R(j)
         end do
       end do
     end do
   end do

   call Exchange_Correlation_potential

    call plot(1)
  write(log_file,*)'Mapping',sum(rold)*grid_volume_old,sum(rho_lead_R)*grid_volume

end subroutine init_right_lead


  subroutine init_left_lead
    implicit none
    integer             :: i,i1,i2,i3,j,k


  double precision, allocatable :: vold(:),rold(:),xold(:),yold(:),zold(:)
  double precision, allocatable :: xnew(:),ynew(:),znew(:)
  integer                       :: N_old(3),N_new(3)
  double precision              :: LB(3),x,grid_volume_old
  character*255 :: full_filename
    logical       :: file_exists

  allocate(Nx_b(N_box))
  Nx_b=Nx_box

  NLP_L=Nx_b(1)*N_Lattice(2)*N_Lattice(3)
  allocate(VH_lead_L(NLP_L),rho_lead_L(NLP_L))
  N_new(1)=Nx_b(1)
  N_new(2)=N_Lattice(2)
  N_new(3)=N_Lattice(3)
  LB(1)=grid_step(1)*Nx_b(1)
  LB(2)=2.d0*R_size(2)
  LB(3)=2.d0*R_size(3)
  do i=1,N_box
    if(Nx_b(i).ne.Nx_b(1)) then
      write(log_file,*)'lead boxes expected to be equal in size'
      write(log_file,*)"Nx_box: ",Nx_box
      stop
    endif
  end do
  allocate(xnew(N_new(1)),ynew(N_new(2)),znew(N_new(3)))

!   left
!  inquire(file=trim(adjustl(transport_density_L_filename)), exist=file_exists)
!  if(file_exists) then
!    full_filename=transport_density_L_filename
!  else
    write(full_filename,'(2a)')trim(adjustl(gs_path)),trim(adjustl(transport_density_L_filename))
!  endif
  write(log_file,*)"transport_density_L full filename: ",trim(adjustl(full_filename))

  open(transport_density_L_file,file=trim(adjustl(full_filename)))
    read(transport_density_L_file,*)N_old(1),N_old(2),N_old(3)
    allocate(vold(N_old(1)*N_old(2)*N_old(3)),rold(N_old(1)*N_old(2)*N_old(3)),xold(N_old(1)),yold(N_old(2)),zold(N_old(3)))
    do i=1,N_old(1)*N_old(2)*N_old(3)
      read(transport_density_L_file,*)vold(i),x,rold(i)
      vold(i)=vold(i)
    end do
    do i=1,N_old(1)
      read(transport_density_L_file,*)xold(i)
    end do
    do i=1,N_old(2)
      read(transport_density_L_file,*)yold(i)
    end do
    do i=1,N_old(3)
      read(transport_density_L_file,*)zold(i)
    end do
  close(transport_density_L_file)
  xold=xold-xold(1)-0.5d0*LB(1)
  do i=1,N_new(1)
    xnew(i)=-0.5d0*LB(1)+(i-1)*grid_step(1)
  end do
  do i=1,N_new(2)
    ynew(i)=-0.5d0*LB(2)+(i-1)*grid_step(2)
  end do
  do i=1,N_new(3)
    znew(i)=-0.5d0*LB(3)+(i-1)*grid_step(3)
  end do
  grid_volume_old=(xold(2)-xold(1))*(yold(2)-yold(1))*(zold(2)-zold(1))
  call per_cos_fit(N_old,xold,yold,zold,grid_volume_old,LB,rold,N_new,xnew,ynew,znew,rho_lead_L)
  call per_cos_fit(N_old,xold,yold,zold,grid_volume_old,LB,vold,N_new,xnew,ynew,znew,VH_lead_L)

!OLD
!    i=0
!    do k=1,N_box
!      j=0
!      do i1=1,Nx_b(k)
!        do i2=1,N_Lattice(2)
!          do i3=1,N_Lattice(3)
!            i=i+1; j=j+1
!            density(i)=rho_lead_L(j)
!            V_Hartree(i)=VH_lead_L(j)
!          end do
!        end do
!      end do
!    end do
!    call Exchange_Correlation_potential

  i=0
   do k=1,N_box
     j=0
     do i1=1,Nx_b(k)
       do i2=1,N_Lattice(2)
         do i3=1,N_Lattice(3)
           i=i+1; j=j+1
           if(rho_lead_L(j)>0) then
             density(i)=rho_lead_L(j)
           else
             density(i)=0.d0
           endif
           V_Hartree(i)=VH_lead_L(j)
         end do
       end do
     end do
   end do
   call Exchange_Correlation_potential

    call plot(1)
  write(log_file,*)'Mapping',sum(rold)*grid_volume_old,sum(rho_lead_L)*grid_volume

end subroutine init_left_lead


  subroutine hartree_transport(mix0)
    implicit none
    integer             :: i,i1,i2,i3,j,n1,is,js
    double precision    :: mix,mix0,su

    if(fd_p_full) then
      is=0
      n1=Nx_b(1)+Nx_b(2)+Nx_b(3)
    else
      is=NLP_L
      n1=Nx_b(2)
    endif

    mix=0.05d0
    i=is
    j=0
    do i1=1,n1
      su=0.d0
      do i2=1,N_Lattice(2)
        do i3=1,N_Lattice(3)
          i=i+1; j=j+1
          rho_C(j)=density(i)-rho_bg(i)
          su=su+density(i)
        end do
      end do
    end do

    call FD_P(rho_c,vh_c)

    i=is
    j=0
    do i1=1,n1
      su=0.d0
      do i2=1,N_Lattice(2)
        do i3=1,N_Lattice(3)
          i=i+1; j=j+1
          V_Hartree(i)=(1.d0-mix)*V_Hartree(i)+mix*VH_C(j)
!          V_Hartree(i)=VH_C(j)
          su=su+V_hartree(i)
        end do
      end do
    end do

    call exchange_correlation_potential

  end subroutine hartree_transport


  subroutine transport_density(mix)
    implicit none
    integer             :: i,i1,i2,i3,j,is,n1
    double precision    :: mix

    i=0
    do i1=1,N_Lattice(1)
      do i2=1,N_Lattice(2)
        do i3=1,N_Lattice(3)
          i=i+1
          density(i)=(1.d0-mix)*density(i)+mix*new_density(i)
        end do
      end do
    end do

    call hartree_transport(mix)

  end   subroutine transport_density

END MODULE MOD_TRANSPORT






