MODULE PARAMETERS
  implicit none
  integer,parameter       :: N_elements=119,N_Species_max=10
  integer,parameter       :: N_taylor=4 ! number of terms in Taylor expansion in taylor_time.f90
  integer,parameter       :: L_max=4 ! max expected angular momentum component in the PP
  integer,parameter       :: N_points_max=50000 ! max number points expected  in the PP
  integer,parameter       :: Nd=4 ! rank of discretization of
  integer,parameter       :: Neighbours_dim=1000000 ! max number of grid points around an ion
  real*8,parameter        :: Hconv=1.d-05 ! Hartree convergence

  real*8,parameter        :: gammaU=-0.1423d0,beta1U=1.0529d0,beta2U=0.3334d0,AU=0.0311d0,BU=-0.048d0
  real*8,parameter        :: CU=0.002d0,DU=-0.0116d0,cutoff_bg_potential=20.d0,cutoff_bg_density=4.d0
  real*8,parameter        :: fd_coeff_first_derivative(0:4)=(/0.d0,4.d0/5.d0,-1.d0/5.d0,4.d0/105.d0,-1.d0/280.d0/)
  real*8,parameter        :: fd_coeff_second_derivative(0:4)=(/-205.d0/72.d0,8.d0/5.d0, &
    -1.d0/5.d0,8.d0/315.d0,-1.d0/560.d0/)

  ! General constants
  real*8,parameter        :: k_Boltzmann=8.617343d-05      !in eV/Kelvin
  real*8,parameter        :: current_conversion_factor=160.2176487d0 ! converts from electrons/fs to microamps
  real*8,parameter        :: E2=14.39964415d0 !1/(4*pi*eps_0), where eps_0=0.005526349868 eV/(Angstrom*V^2)
  real*8,parameter        :: H2M=3.80998174348d0 !(hbar^2)/(2*m_e) in eV*Angstom^2
  real*8,parameter        :: a_B=0.52917720859d0 !Bohr radius
  real*8,parameter        :: hbar=0.658211899d0  !Planck constant over 2*pi in eV*fs
  real*8,parameter        :: Ry=13.60569193d0    !Rydberg constant in eV
  real*8,parameter        :: pi=3.141592653589793d0
  real*8,parameter        :: c_light=2997.92458d0 !Speed of light in Angstrom/fs
  real*8,parameter        :: c_squared=8987551.787368176d0 !in (Angstroms/fs)^2
  real*8,parameter        :: electron_mass=510998.910d0    !in eV/c^2
  real*8,parameter        :: ElectronMass=0.5d0*hbar*hbar/H2M !mass of electron in eV*fs^2/Angstrom^2
  !Conversion of the mass from SI units to units corresponding
  !to Angstrom,eV,femtosec (called here "nano"):
  !M(nano) = M(kilogram) / ( q * 10^{-10}),
  !where q is the elementary charge in SI units, q=1.602176487d-19
  real*8,parameter        :: mass_convfactor=1.66053886d0/1.602176487d-02
  
  real*8,parameter        :: pp_uVu_epsilon=1.0d-5

  real*8,parameter         :: convertT2AU=1.d0/0.02418884326505d0
  real*8,parameter         :: convertL2AU=1.d0/0.52917721092d0
  real*8,parameter         :: convertHart2eV=27.211385d0
  real*8,parameter         :: convertE2AU=1.d0/(51.4220652d0)
  

  complex*16,parameter    :: zi=(0.d0,1.d0)
  character,parameter     :: tab_char=char(9)

  character*255,parameter :: pp_suffix="_pp.dat"
  character*255,parameter :: bf_suffix="_bf.dat"
  character*255,parameter :: default_gs_path="./"

  ! Filenames
  character*255,parameter :: gb_dat_filename="gb.dat"

  character*255,parameter :: scf_data_filename="density.dat"
  character*255,parameter :: psi_data_filename="psi.dat"
  character*255,parameter :: psi_data_filename_prefix="psi" !Arthur
  character*255,parameter :: structure_output_filename_prefix="dft" !Arthur 
  character*255,parameter :: lcao_data_filename="lcao.dat"
  character*255,parameter :: hs_mat_data_filename="hs.mat"

  character*255,parameter :: c_lcao_filename="c_lcao.dat"
  character*255,parameter :: timing_output_filename="timing.dat"
  character*255,parameter :: eigenvalues_output_filename="eigenvalues.dat"
  character*255,parameter :: pseudopotential_log_filename="pseudopotential_log_file.out"
  character*255,parameter :: projection_1d_filename="projection_1d.dat"
  character*255,parameter :: mr_charge_filename="mr_charge.dat"
  character*255,parameter :: mr_current_filename="mr_current.dat"
  character*255,parameter :: mr_orbital_charge_filename="mr_orbital_charge.dat"
  character*255,parameter :: mr_orbital_current_filename="mr_orbital_current.dat"
  character*255,parameter :: mr_current_from_charge_filename="mr_current_from_charge.dat"
  character*255,parameter :: mr_density_slice_filename="mr_density_slice.dat"
  character*255,parameter :: td_total_density_filename="td_total_density.dat"
  character*255,parameter :: td_total_density_filename_prefix="dens"
  character*255,parameter :: td_total_current_density_filename="td_total_current_density.dat"
  character*255,parameter :: td_total_current_density_filename_prefix="current_dens"  
  character*255,parameter :: mixer_debug_filename="mixer_debug_log.txt"
  character*255,parameter :: convergence_de_filename="convergence_de.dat"
  character*255,parameter :: convergence_e_filename="convergence_e.dat"
  character*255,parameter :: convergence_res_filename="convergence_res.dat"
  character*255,parameter :: convergence_monitor_filename="convergence_monitor.dat"
  character*255,parameter :: cap_filename="cap_1d.dat"
  character*255,parameter :: transport_trans_filename="trans.dat"
  character*255,parameter :: transport_t_filename="t.dat"
  character*255,parameter :: transport_me_filename="transport_me.dat"
  character*255,parameter :: transport_density_L_filename="density_L.dat"
  character*255,parameter :: transport_density_C_filename="density_C.dat"
  character*255,parameter :: transport_density_R_filename="density_R.dat"
  character*255,parameter :: transport_left_filename="left.dat"
  character*255,parameter :: transport_right_filename="right.dat"
  character*255,parameter :: optical_abs_xx_filename="dp_xx.dat"
  character*255,parameter :: optical_abs_xy_filename="dp_xy.dat"
  character*255,parameter :: optical_abs_xz_filename="dp_xz.dat"
  character*255,parameter :: optical_abs_yx_filename="dp_yx.dat"
  character*255,parameter :: optical_abs_yy_filename="dp_yy.dat"
  character*255,parameter :: optical_abs_yz_filename="dp_yz.dat"
  character*255,parameter :: optical_abs_zx_filename="dp_zx.dat"
  character*255,parameter :: optical_abs_zy_filename="dp_zy.dat"
  character*255,parameter :: optical_abs_zz_filename="dp_zz.dat"
  character*255,parameter :: bloch_band_1d_filename="bloch_band_1d.dat"
  character*255,parameter :: transport_1d_device_density_filename="transport_1d_device_density.dat"
  character*255,parameter :: hamiltonian_wavefn_periodic_filename="hamiltonian_wavefn_periodic.dat"
  character*255,parameter :: basis_filename="basis.dat"
  character*255,parameter :: radial_basis_filename="radial_basis.dat"
  character*255,parameter :: box_basis_filename="box_basis.dat"
  character*255,parameter :: memory_usage_output_filename="memory_usage.dat"
  character*255,parameter :: mol_dynamics_filename="mol_dynamics.dat"
  character*255,parameter :: trajectory_filename="trajectory.xyz"
  character*255,parameter :: orbitals_filename="orbitals.dat"
  character*255,parameter :: orbital_energy_components_filename="orbital_energy_components.dat"
  character*255,parameter :: projection_filename="inner_products.dat" !Arthur
  character*255,parameter :: forces_filename="forces.dat"
  character*255,parameter :: dipole_moment_filename="dipole_moment.dat"
  character*255,parameter :: kpoint_input_filename="kpoints.inp"
  character*255,parameter :: offdiag_elem_filename="offdiag_elems.dat"
  character*255,parameter :: checkpoint_filename="checkpoint.dat"
  character*255,parameter :: iteration_filename="iteration.dat"
  character*255,parameter :: total_3D_potential_filename="total_3D_potential.dat"
  character*255,parameter :: total_3D_potential_filename_shifted="total_3D_potential_shifted.dat"  
  character*255,parameter :: total_3D_potential_filename_VisIt="total_3D_potential.3D"
  character*255,parameter :: lattice_view_bovfilename='lattice_view.bov'
  character*255,parameter :: lattice_view_datfilename='lattice_view.dat'
  character*255,parameter :: dipole_x_filename="dp_x.dat"
  character*255,parameter :: dipole_y_filename="dp_y.dat"
  character*255,parameter :: dipole_z_filename="dp_z.dat"  
  character*255,parameter :: md_forcesfilename="md_forces_xyz.dat" !cody
  character*255,parameter :: md_xyz_wE_filename="md_xyz_wIonization.dat" !cody
  
  character*255,parameter :: velocity_input_filename="velocity.inp" !Arthur
  character*255,parameter :: coordinate_map_filename="coordinate_map.dat" !Jorge
  character*255,parameter :: total_td_3D_potential_prefix="total_3D_potential_" !Arthur
  character*255,parameter :: total_td_3D_potential_filename_shifted_prefix="total_3D_potential_shifted_" !Arthur  
  character*255,parameter :: total_td_3D_potential_filename_VisIt_prefix="total_3D_potential_" !Arthur
  character*255,parameter :: restart_file_ionname="RESTART_ion" ! cody
  character*255,parameter :: restart_file_elecname="RESTART_electronic" ! cody
  character*255,parameter :: restart_file_projname="RESTART_projectile" ! cody
  character*255,parameter :: restart_file_itername="RESTART_iteration" ! cody
  character*255,parameter :: restart_file_lasername="RESTART_laser" ! cody
  character*255,parameter :: restart_file_volkname="RESTART_volkov" ! cody
  character*255,parameter :: restart_file_mPESname="RESTART_maskV_PES" ! cody  
  character*255,parameter :: restart_file_name="RESTART_FILE" ! cody
  character*255,parameter :: force_compare_file_name="force_compare_TD_GS.txt" ! cody
  character*255,parameter :: td_gs_energy_diff_filename="gs_td_energy_diff.txt"
  character*255,parameter :: td_current_cell_sum_filename="current_sum_cell.txt"
  character*255,parameter :: td_current_atom_sum_filename_x="current_atom_sum_x.txt"
  character*255,parameter :: td_current_atom_sum_filename_y="current_atom_sum_y.txt"
  character*255,parameter :: td_current_atom_sum_filename_z="current_atom_sum_z.txt"
  character*255,parameter :: td_current_plane_sum_filename_x="current_atom_sum_x.txt"
  character*255,parameter :: td_current_plane_sum_filename_y="current_atom_sum_y.txt"
  character*255,parameter :: td_current_plane_sum_filename_z="current_atom_sum_z.txt"
  character*100,parameter :: td_current_plane_sum_basename_z="current_atom_sum_z_pt"
  ! File IDs
  integer,parameter       :: log_file=2,timing_file=3,eigenvalues_file=4,pseudopotential_log_file=7
  integer,parameter       :: projection_1d_file=8,bloch_file=9,mol_dynamics_file=10
  integer,parameter       :: trajectory_file=11,c_lcao_file=12,kpoint_file=13,orbitals_file=14  
  integer,parameter       :: mr_charge_file=15,mr_current_file=16,mr_orbital_charge_file=17
  integer,parameter       :: mr_orbital_current_file=18,mr_current_from_charge_file=19
  integer,parameter       :: mr_density_slice_file=20,td_total_density_file=21,gnuplot_file=22
  integer,parameter       :: mixer_debug_file=23,convergence_de_file=24,convergence_e_file=25
  integer,parameter       :: convergence_res_file=26,convergence_monitor_file=27
  integer,parameter       :: cap_file=32,transport_trans_file=33,transport_t_file=34
  integer,parameter       :: transport_me_file=35,transport_density_L_file=36
  integer,parameter       :: transport_density_C_file=37,transport_density_R_file=38
  integer,parameter       :: lcao_data_file=39,transport_left_file=40,transport_right_file=41
  integer,parameter       :: td_total_current_density_file=42,bloch_band_1d_file=43
  integer,parameter       :: transport_1d_device_density_file=45,hamiltonian_wavefn_periodic_file=46
  integer,parameter       :: gb_dat_file=47,bf_file=48,scf_data_file=49,get_num_mr_file=50,parse_file=51
  integer,parameter       :: structure_input_file=52,structure_input_file2=1018152,hs_mat_data_file=53
  integer,parameter       :: psi_data_file=54,basis_file=55
  integer,parameter       :: radial_basis_file=56,pp_file=57,cogr_file=58,box_basis_file=59
  integer,parameter       :: gnuplot_data_file=60,orbital_energy_components_file=62
  integer,parameter       :: forces_file=63
  integer,parameter       :: dipole_moment_file=67,offdiag_elem_file=69
  integer,parameter       :: checkpoint_file=70,iteration_file=71
  integer,parameter       :: optical_abs1_file=72,optical_abs2_file=73,optical_abs3_file=74
  integer,parameter       :: total_3D_potential_file=75,total_3D_potential_file_VisIt=76
  integer,parameter       :: lattice_view_bovfile=77,lattice_view_datfile=78
  integer,parameter       :: dipole_x_file=79,dipole_y_file=80,dipole_z_file=81
  integer,parameter       :: total_3D_potential_file_shifted=82,mr_yz_density_slice_file=83
  integer,parameter       :: gen_purpose_bovfile=84,gen_purpose_datfile=85
  integer,parameter       :: velocity_input_file=86   !Arthur
  integer,parameter       :: structure_output_file=87 !Arthur
  integer,parameter       :: coordinate_map_file=88   !Jorge   
  integer,parameter       :: total_td_3D_potential_file=89,total_td_3D_potential_file_VisIt=90 !Arthur
  integer,parameter       :: total_td_3D_potential_file_shifted=91 !Arthur
  integer,parameter      :: td_average_current_density_file=92,td_SP_energy_file=93 !shenglai
  integer,parameter      :: td_current_cell_sum_file=1397461
  integer,parameter      :: td_current_atom_sum_file_x=1397471
  integer,parameter      :: td_current_atom_sum_file_y=1397472
  integer,parameter      :: td_current_atom_sum_file_z=1397473
  integer,parameter      :: td_current_plane_sum_file_x=1397481
  integer,parameter      :: td_current_plane_sum_file_y=1397482
  integer,parameter      :: td_current_plane_sum_file_z=1397483
  integer,parameter      :: laser_xyz_file=94 ! cody
  integer,parameter      :: projection_file=95 !Arthur
  integer,parameter      :: source_x=96,source_y=97 !shenglai
  integer,parameter      :: restart_file_ion=98,restart_file_electronic=99 ! cody
  integer,parameter      :: restart_file_proj=100,restart_file_iter=101 ! cody
  integer,parameter      :: mdforces_file=102,mdxyz_file=103 ! cody
  integer,parameter      :: tempopenfile=817161 ! cody   do something with file and then close 
  integer,parameter       :: dipole_all_file=104
  integer,parameter      :: projection_sum_file=105 ! cody
  integer,parameter      :: compare_force_file_number=1242048
  integer,parameter      :: td_gs_energy_diff_file=47329872
  integer,parameter      :: fragment_info_file_block=16346000
  ! Element symbols and names
  character*3,parameter   :: element_symbols(N_elements)=(/ &
    "  H"," He", &
    " Li"," Be","  B","  C","  N", &
    "  O","  F"," Ne"," Na"," Mg", &
    " Al"," Si","  P","  S"," Cl", &
    " Ar","  K"," Ca"," Sc"," Ti", &
    "  V"," Cr"," Mn"," Fe"," Co", &
    " Ni"," Cu"," Zn"," Ga"," Ge", &
    " As"," Se"," Br"," Kr"," Rb", &
    " Sr","  Y"," Zr"," Nb"," Mo", &
    " Tc"," Ru"," Rh"," Pd"," Ag", &
    " Cd"," In"," Sn"," Sb"," Te", &
    "  I"," Xe"," Cs"," Ba"," La", &
    " Ce"," Pr"," Nd"," Pm"," Sm", &
    " Eu"," Gd"," Tb"," Dy"," Ho", &
    " Er"," Tm"," Yb"," Lu"," Hf", &
    " Ta","  W"," Re"," Os"," Ir", &
    " Pt"," Au"," Hg"," Tl"," Pb", &
    " Bi"," Po"," At"," Rn"," Fr", &
    " Ra"," Ac"," Th"," Pa","  U", &
    " Np"," Pu"," Am"," Cm"," Bk", &
    " Cf"," Es"," Fm"," Md"," No", &
    " Lr"," Rf"," Db"," Sg"," Bh", &
    " Hs"," Mt"," Ds"," Rg"," Cn", &
    "Uut","Uuq","Uup","Uuh","Uus", &
    "Uuo","  D"/)

  character*13,parameter  :: element_names(N_elements)=(/ &
    "     Hydrogen","       Helium","      Lithium","    Beryllium","        Boron", &
    "       Carbon","     Nitrogen","       Oxygen","     Fluorine","         Neon", &
    "       Sodium","    Magnesium","     Aluminum","      Silicon","   Phosphorus", &
    "       Sulfur","     Chlorine","        Argon","    Potassium","      Calcium", &
    "     Scandium","     Titanium","     Vanadium","     Chromium","    Manganese", &
    "         Iron","       Cobalt","       Nickel","       Copper","         Zinc", &
    "      Gallium","    Germanium","      Arsenic","     Selenium","      Bromine", &
    "      Krypton","     Rubidium","    Strontium","      Yttrium","    Zirconium", &
    "      Niobium","   Molybdenum","   Technetium","    Ruthenium","      Rhodium", &
    "    Palladium","       Silver","      Cadmium","       Indium","          Tin", &
    "     Antimony","    Tellurium","       Iodine","        Xenon","       Cesium",  &
    "       Barium","    Lanthanum","       Cerium"," Praseodymium","    Neodymium", &
    "   Promethium","     Samarium","     Europium","   Gadolinium","      Terbium", &
    "   Dysprosium","      Holmium","       Erbium","      Thulium","    Ytterbium", &
    "     Lutetium","      Hafnium","     Tantalum","     Tungsten","      Rhenium", &
    "       Osmium","      Iridium","     Platinum","         Gold","      Mercury", &
    "     Thallium","         Lead","      Bismuth","     Polonium","     Astatine", &
    "        Radon","     Francium","       Radium","     Actinium","      Thorium", &
    " Protactinium","      Uranium","    Neptunium","    Plutonium","    Americium", &
    "       Curium","    Berkelium","  Californium","  Einsteinium","      Fermium", &
    "  Mendelevium","     Nobelium","   Lawrencium","Rutherfordium","      Dubnium", &
    "   Seaborgium","      Bohrium","      Hassium","   Meitnerium"," Darmstadtium", &
    "  Roentgenium","  Copernicium","    Ununtrium","  Ununquadium","  Ununpentium", &
    "   Ununhexium","  Ununseptium","   Ununoctium","    Deuterium"/)


  ! Approximate masses of elements (number of nucleons in the most common isotope)
  real(8),parameter :: element_num_nucleons(N_elements)=(/ &
    1.0d0,   4.0d0, &                                !H,He
    7.0d0,   9.0d0,  11.0d0,  12.0d0,  14.0d0, &     !Li,Be,B,C,N
    16.0d0,  19.0d0,  20.0d0,  23.0d0,  24.0d0, &     !O,F,Ne,Na,Mg
    27.0d0,  28.0d0,  31.0d0,  32.0d0,  35.0d0, &     !Al,Si,P,S,Cl
    40.0d0,  39.0d0,  40.0d0,  45.0d0,  48.0d0, &     !Ar,K,Ca,Sc,Ti
    51.0d0,  52.0d0,  55.0d0,  56.0d0,  59.0d0, &     !V,Cr,Mn,Fe,Co
    58.0d0,  63.0d0,  64.0d0,  69.0d0,  74.0d0, &     !Ni,Cu,Zn,Ga,Ge
    75.0d0,  80.0d0,  79.0d0,  84.0d0,  85.0d0, &     !As,Se,Br,Kr,Rb
    88.0d0,  89.0d0,  90.0d0,  93.0d0,  98.0d0, &     !Sr,Y,Zr,Nb,Mo
    97.0d0, 102.0d0, 103.0d0, 106.0d0, 107.0d0, &     !Tc,Ru,Rh,Pd,Ag
    114.0d0, 115.0d0, 120.0d0, 121.0d0, 130.0d0, &     !Cd,In,Sn,Sb,Te
    127.0d0, 132.0d0, 133.0d0, 138.0d0, 139.0d0, &     !I,Xe,Cs,Ba,La
    140.0d0, 141.0d0, 142.0d0, 145.0d0, 152.0d0, &     !Ce,Pr,Nd,Pm,Sm
    153.0d0, 158.0d0, 159.0d0, 164.0d0, 165.0d0, &     !Eu,Gd,Tb,Dy,Ho
    166.0d0, 169.0d0, 174.0d0, 175.0d0, 180.0d0, &     !Er,Tm,Yb,Lu,Hf
    181.0d0, 184.0d0, 187.0d0, 192.0d0, 193.0d0, &     !Ta,W,Re,Os,Ir
    195.0d0, 197.0d0, 202.0d0, 205.0d0, 208.0d0, &     !Pt,Au,Hg,Tl,Pb
    209.0d0, 209.0d0, 210.0d0, 222.0d0, 223.0d0, &     !Bi,Po,At,Rn,Fr
    226.0d0, 227.0d0, 232.0d0, 231.0d0, 238.0d0, &     !Ra,Ac,Th,Pa,U
    237.0d0, 244.0d0, 243.0d0, 247.0d0, 247.0d0, &     !Np,Pu,Am,Cm,Bk
    251.0d0, 252.0d0, 257.0d0, 258.0d0, 259.0d0, &     !Cf,Es,Fm,Md,No
    262.0d0, 261.0d0, 262.0d0, 266.0d0, 264.0d0, &     !Lr,Rf,Db,Sg,Bh
    277.0d0, 268.0d0, 281.0d0, 272.0d0, 285.0d0, &     !Hs,Mt,Ds,Rg,Cn
    0.0d0, 289.0d0,   0.0d0, 292.0d0,   0.0d0, &     !Uut,Uuq,Uup,Uuh,Uus
    0.0d0,   2.0d0 /)   !Uuo and D

  ! Average masses of elements (in g/mol)
  real(8),parameter :: element_average_atomic_mass(N_elements)=(/ &
    1.00794d0,  4.002602d0,  6.941d0,  9.012182d0,  10.811d0,           & !  H, He, Li, Be, B
    12.0107d0,  14.0067d0,  15.9994d0,  18.9984032d0,  20.1797d0,       & !  C, N, O, F, Ne
    22.98976928d0,  24.3050d0,  26.9815386d0,  28.0855d0,  30.973762d0, & !  Na, Mg, Al, Si, P
    32.065d0,  35.453d0,  39.948d0,  39.0983d0,  40.078d0,              & !  S, Cl, Ar, K, Ca
    44.955912d0,  47.867d0,  50.9415d0,  51.9961d0,  54.938045d0,       & !  Sc, Ti, V, Cr, Mn
    55.845d0,  58.933195d0,  58.6934d0,  63.546d0,  65.38d0,            & !  Fe, Co, Ni, Cu, Zn
    69.723d0,  72.64d0,  74.92160d0,  78.96d0,  79.904d0,               & !  Ga, Ge, As, Se, Br
    83.798d0,  85.4678d0,  87.62d0,  88.90585d0,  91.224d0,             & !  Kr, Rb, Sr, Y, Zr
    92.90638d0,  95.96d0,  98.9063d0,  101.07d0,  102.90550d0,          & !  Nb, Mo, Tc, Ru, Rh
    106.42d0,  107.8682d0,  112.411d0,  114.818d0,  118.710d0,          & !  Pd, Ag, Cd, In, Sn
    121.760d0,  127.60d0,  126.90447d0,  131.293d0,  132.9054519d0,     & !  Sb, Te, I, Xe, Cs
    137.327d0,  138.90547d0,  140.116d0,  140.90765d0,  144.242d0,      & !  Ba, La, Ce, Pr, Nd
    146.9151d0,  150.36d0,  151.964d0,  157.25d0,  158.92535d0,         & !  Pm, Sm, Eu, Gd, Tb
    162.500d0,  164.93032d0,  167.259d0,  168.93421d0,  173.054d0,      & !  Dy, Ho, Er, Tm, Yb
    174.9668d0,  178.49d0,  180.9479d0,  183.84d0,  186.207d0,          & !  Lu, Hf, Ta, W, Re
    190.23d0,  192.217d0,  195.084d0,  196.966569d0,  200.59d0,         & !  Os, Ir, Pt, Au, Hg
    204.3833d0,  207.2d0,  208.98040d0,  208.9824d0,  209.9871d0,       & !  Tl, Pb, Bi, Po, At
    222.0176d0,  223.0197d0,  226.0254d0,  227.0278d0,  232.03806d0,    & !  Rn, Fr, Ra, Ac, Th
    231.03588d0,  238.02891d0,  237.0482d0,  244.0642d0,  243.0614d0,   & !  Pa, U, Np, Pu, Am
    247.0704d0,  247.0703d0,  251.0796d0,  252.0829d0,  257.0951d0,     & !  Cm, Bk, Cf, Es, Fm
    258.0986d0,  259.1009d0,  264d0,  265d0,  268d0,                    & !  Md, No, Lr, Rf, Db
    272d0,  273d0,  276d0,  279d0,  278d0,                              & !  Sg, Bh, Hs, Mt, Ds
    283d0,  285d0,  287d0,  289d0,  291d0,                              & !  Rg, Cn, Uut, Uuq, Uup
    293d0,  295d0,  294d0, 2.01410178d0 /)                                              !  Uuh, Uus, Uuo, D
    
  !Van der Waals radii of elements
	real(8),parameter :: element_vdw_radius(N_elements)=(/ &
	1.20d0, 1.40d0, 1.82d0, 2.00d0, 2.00d0, & !H,He,Li,Be,B
	1.70d0, 1.55d0, 1.52d0, 1.47d0, 1.54d0, & !C,N,O,F,Ne
	2.27d0, 1.73d0, 2.00d0, 2.10d0, 1.80d0, & !Na,Mg,Al,Si,P
	1.80d0, 1.75d0, 1.88d0, 2.75d0, 2.00d0, & !S,Cl,Ar,K,Ca
	2.00d0, 2.00d0, 2.00d0, 2.00d0, 2.00d0, & !Sc,Ti,V,Cr,Mn
	2.00d0, 2.00d0, 1.63d0, 1.40d0, 1.39d0, & !Fe,Co,Ni,Cu,Zn
	1.87d0, 2.00d0, 1.85d0, 1.90d0, 1.85d0, & !Ga,Ge,As,Se,Br
	2.02d0, 2.00d0, 2.00d0, 2.00d0, 2.00d0, & !Kr,Rb,Sr,Y,Zr
	2.00d0, 2.00d0, 2.00d0, 2.00d0, 2.00d0, & !Nb,Mo,Tc,Ru,Rh
	1.63d0, 1.72d0, 1.58d0, 1.93d0, 2.17d0, & !Pd,Ag,Cd,In,Sn
	2.00d0, 2.06d0, 1.98d0, 2.16d0, 2.00d0, & !Sb,Te,I,Xe,Cs
	2.00d0, 2.00d0, 2.00d0, 2.00d0, 2.00d0, & !Ba,La,Ce,Pr,Nd
	2.00d0, 2.00d0, 2.00d0, 2.00d0, 2.00d0, & !Pm,Sm,Eu,Gd,Tb
	2.00d0, 2.00d0, 2.00d0, 2.00d0, 2.00d0, & !Dy,Ho,Er,Tm,Yb
	2.00d0, 2.00d0, 2.00d0, 2.00d0, 2.00d0, & !Lu,Hf,Ta,W,Re
	2.00d0, 2.00d0, 1.75d0, 1.66d0, 1.55d0, & !Os,Ir,Pt,Au,Hg
	1.96d0, 2.02d0, 2.00d0, 2.00d0, 2.00d0, & !Tl,Pb,Bi,Po,At
	2.00d0, 2.00d0, 2.00d0, 2.00d0, 2.00d0, & !Rn,Fr,Ra,Ac,Th
	2.00d0, 1.86d0, 2.00d0, 2.00d0, 2.00d0, & !Pa,U,Np,Pu,Am
	2.00d0, 2.00d0, 2.00d0, 2.00d0, 2.00d0, & !Cm,Bk,Cf,Es,Fm
	2.00d0, 2.00d0, 2.00d0, 2.00d0, 2.00d0, & !Md,No,Lr,Rf,Db
	2.00d0, 2.00d0, 2.00d0, 2.00d0, 2.00d0, & !Sg,Bh,Hs,Mt,Ds
	2.00d0, 2.00d0, 2.00d0, 2.00d0, 2.00d0, & !Rg,Cn,Uut,Uuq,Uup
	2.00d0, 2.00d0, 2.00d0, 1.20d0 /)                  !Uuh,Uus,Uuo, D
END MODULE PARAMETERS
