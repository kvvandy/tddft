
      SUBROUTINE Exc_Cor_Kernel(XC_ink,Fxc,Gxc,Hxc)

      use optics_data, only : ML,rho

      use parameters
      implicit none
      character(4),intent(IN) :: XC_ink
      real(8),intent(OUT)     :: Fxc(ML),Gxc(ML),Hxc(ML)
      optional                :: Gxc,Hxc

      select case(XC_ink)
         case('PZ','pz')   ; call PZ_Kernel
         case('VWN','vwn') ; call VWN_Kernel
         case default
            write(*,*) "Kernel name ",XC_ink," is invalid." ; stop
      end select

      return

      CONTAINS

      SUBROUTINE PZ_Kernel

      real(8),parameter :: c=-0.1423d0, b=1.0529d0, a=0.3334d0
      real(8),parameter :: Cx=0.4582d0 , t=71.4036d0
      real(8),parameter :: gammaU=-0.1423d0, beta1U=1.0529d0
      real(8),parameter :: beta2U=0.3334d0 , AU=0.0311d0, BU=-0.048d0
      real(8),parameter :: CU=0.002d0 , DU=-0.0116d0
      integer :: i
      real(8),allocatable :: trho(:),rs(:),rssq(:),rsln(:)
      real(8),allocatable :: dvx(:),dvc(:)
!      real(8) :: bet,eta,xi

      allocate( trho(ML),rs(ML),rssq(ML),rsln(ML),dvx(ML),dvc(ML) )

      trho = rho + 1.d-10
      rs   = (3.d0/(4*Pi*trho))**(1.d0/3.d0) / a_B
      rssq = sqrt(rs)
      rsln = log(rs)

!--------------------------------------------------------------- dVxc/dn

! Exchange

      dvx = -Cx*4.d0/3.d0/rs*(4*Pi*rs**3/3)/3

! Relativistic Exchange

!      do i=1,ML
!         bet=1.d0/(71.4036d0*rs(i)); eta=sqrt(1+bet**2); xi=bet+eta
!         dvx(i)=(-0.4582d0*4d0/3d0/rs(i))*(4*Pi*rs(i)**3/3)
!     &      *( -1.d0/6.d0-bet*log(xi)/(2*eta**3)+1/(2*eta**2) )
!      end do

! Correlation

      where( rs > 1.d0 )
         dvc  =  c*Pi/27*rs**4 / (1+b*rssq+a*rs)**3* ( 8*a+7*b**2+5*b/rssq + 21*b*a*rssq+16*a**2*rs )
      elsewhere
         dvc  = - 4*Pi/9d0*rs**4*(AU/rs+2d0/3d0*CU*rsln+(2*DU+CU)/3)
      end where

! exchange correlation

      Fxc = 2*Ry*a_B**3 * ( dvx + dvc )

!----------------------------------------------------------- d^2Vxc/dn^2

      if ( .not.present(Gxc) ) return

! Exchange

      dvx = Cx*128.d0/243.d0*Pi**2*rs**5

! Relativistic Exchange

!      do i=1,ML
!         bet=1.d0/(71.4036d0*rs(i)); eta=sqrt(1+bet**2); xi=bet+eta
!         dvx(i)= -32*Cx*Pi**2*( eta*( -4 - 11*bet**2 + 2*bet**4 )
!     &                         +3*( bet + 4*bet**3 )*log(xi)
!     &                        )/( 243*( t*bet*eta )**5 )
!      end do

! Correlation

      where ( rs > 1.d0 )
         dvc = - 2*c*Pi**2*rssq**13*(35*b**3*rs + 4*b**2*rssq*( &
         19 + 35*a*rs )+ 16*a*rssq*( 4 + 11*a*rs + 4*a**2*rs**2&
          )+ b*( 35 + 234*a*rs + 175*a**2*rs**2 ))/(  243*( 1 + b*rssq + a*rs )**4  )
      elsewhere
         dvc = 16.d0/243.d0 * Pi**2 * rs**6 *( 9.d0*AU + ( 6.d0*CU + 8.d0*DU + 8.d0*CU*log(rs) )*rs )
      end where

! Exchange-Correlation

      Gxc = 2*Ry*a_B**6*( dvx + dvc )

!----------------------------------------------------------- d^3Vxc/dn^3

      if ( .not.present(Hxc) ) return

! Exchange

      dvx = -Cx*2560.d0/2187.d0*Pi**3*rs**8

! Relativistic Exchange

!      do i=1,ML
!         bet=1.d0/(71.4036d0*rs(i)); eta=sqrt(1+bet**2) ; xi=bet+eta
!         dvx(i)=128.d0*Cx*Pi**3*
!     &    (  eta*( -20 -72*bet**2 -87*bet**4 +10*bet**6 )
!     &      +3.d0*bet*( 4 + 17*bet**2 + 28*bet**4 )*log(xi)
!     &    )/( 2187.d0 * (t*bet)**8 * eta**7 )
!      end do

! Correlation

      where ( rs > 1.d0 )
         dvc = 4*c*Pi**3*rssq**19*( 385*b**4*rssq**3 &
         + 5*b**3*rs*( 257 + 385*a*rs )+ b**2*rssq*(1379 &
         + 5270*a*rs + 3395*a**2*rs**2 )+ 128*a*rssq*(7 +&
          25*a*rs + 20*a**2*rs**2 + 5*a**3*rs**3)+ b*(455 &
          + 4325*a*rs + 6725*a**2*rs**2 + 2471*a**3*rs**3)) / ( 2187*(1 + b*rssq + a*rs)**5 )
      elsewhere
         dvc = - 128*Pi**3/2187 * rs**9 *(  27*AU + ( 25*CU + 28*DU + 28*CU*log(rs) )*rs  )
      end where

! Exchange-Correlation

      Hxc = 2*Ry*a_B**9*( dvx + dvc )

      deallocate( trho,rs,rssq,rsln,dvx,dvc )

      return

      END SUBROUTINE PZ_Kernel

!========================================================== VWN XC-kenel

      SUBROUTINE VWN_Kernel

      real(8),parameter :: a=-0.10498d0, b=3.72744d0, c=12.9352d0
      real(8),parameter :: AA=0.0621814d0
      real(8) :: Q
      real(8),allocatable :: rs(:),x(:),trho(:),t1(:),t2(:),t3(:)
      real(8),allocatable :: dVx(:),dVc(:)

      Q=sqrt(4*c-b**2)

      allocate( rs(ML),x(ML),trho(ML),t1(ML),t2(ML),t3(ML) )
      allocate( dVx(ML),dVc(ML) )

!--------------------------------------------------------------- dVxc/dn

      trho = rho + 1.d-10
      rs   = ( 3.d0/(4*Pi*trho) )**(1.d0/3.d0) / a_B

      x = sqrt( rs )

! Exchange

      dVx = (-0.4582d0*4.d0/3.d0/rs)*(4*Pi*rs**3/3.d0)/3.d0

! Correlation

      t1 = -(Pi*x**6*(12*c**2 + b*x**2*(6*b + 7*x)&
       + c*x*(19*b + 16*x)))/(27.*(c + x*(b + x))**2)

      t2 = (2*Pi*Q*x**7*(5*b**2 + 5*Q**2 + 24*b*x &
      + 28*x**2))/(27.*(b**2 + Q**2 + 4*b*x + 4*x**2)**2)

      t3 = (Pi*x**7*(a**2*(5*b*c + 6*b**2*x + 8*c*x &
      + 17*b*x**2 + 12*x**3) - x*(12*c**2 + b*x**2*(6*b + 7*x)&
       + c*x*(19*b + 16*x)) + 2*a*(5*c**2 + c*x*(5*b + 2*x) &
       - x**2*(b**2 + 7*b*x + 7*x**2))))/(27.*(a - x)**2*(c + x*(b + x))**2)

      dVc=AA*( t1 + 2*b/Q*t2 - b*a/(a**2+b*a+c)*(t3+2*(b+2*a)/Q*t2) )

      Fxc = ( 2*Ry*dVx + Ry*dVc ) * a_B**3

!----------------------------------------------------------- d^2Vxc/dn^2

      if ( .not.present(Gxc) ) return

! Exchange

      dVx = 0.4582d0 * 128.d0/243.d0*Pi**2*rs**5

! Correlation

      t1 = (2*Pi**2*x**12*(72*c**3 + c**2*x*(181*b + 152*x)&
       +  b*x**3*(36*b**2 + 73*b*x + 35*x**2) + c*x**2*(143*b**2 &
       + 216*b*x + 64*x**2)))/(243.*(c + x*(b + x))**3)

      t2 = (-4*Pi**2*Q*x**13*(35*b**4 + 35*Q**4 + 292*b**3*x &
      + 312*Q**2*x**2 + 560*x**4 + 292*b*x*(Q**2 + 4*x**2) + &
      2*b**2*(35*Q**2 + 444*x**2)))/(243.*(b**2 + Q**2 + 4*b*x + 4*x**2)**3)

      t3 = (2*Pi**2*x**13*(x**2* &
             (72*c**3 + c**2*x*(181*b + 152*x) + &
             b*x**3*(36*b**2 + 73*b*x + 35*x**2) + &
             c*x**2*(143*b**2 + 216*b*x + 64*x**2)) - &
             a*x*(146*c**3 + 3*c**2*x*(111*b + 82*x) + &
              3*c*x**2*(73*b**2 + 76*b*x - 6*x**2) + &
              x**3*(38*b**3 + 9*b**2*x - 105*b*x**2 - &
                 70*x**3)) + &
           a**2*(70*c**3 + 3*c**2*x*(35*b + 6*x) - &
              3*c*x**2*(3*b**2 + 76*b*x + 82*x**2) - &
              x**3*(38*b**3 + 219*b**2*x + 333*b*x**2 + &
                 146*x**3)) + &
           a**3*(36*b**3*x**2 + b**2*(73*c*x + 143*x**3) + &
              b*(35*c**2 + 216*c*x**2 + 181*x**4) + &
              8*(8*c**2*x + 19*c*x**3 + 9*x**5))))/&
       (243.*(-a + x)**3*(c + x*(b + x))**3)

      dVc=AA*( t1 + 2*b/Q*t2 - b*a/(a**2+b*a+c)*(t3+2*(b+2*a)/Q*t2) )

      Gxc=( 2*Ry*dVx + Ry*dVc )*a_B**6

!----------------------------------------------------------- d^3Vxc/dn^3

      if ( .not.present(Hxc) ) return

! Exchange

      dVx = -0.4582d0 * 2560.d0/2187.d0 * Pi**3 * rs**8

! Correlation

      t1 = (-4*Pi**3*x**18*(864*c**4 + &
           c**3*x*(3001*b + 2560*x) + &
           c**2*x**2*(3812*b**2 + 6179*b*x + 2240*x**2) + &
           b*x**4*(432*b**3 + 1273*b**2*x + 1220*b*x**2 + &
              385*x**3) + &
           c*x**3*(2113*b**3 + 4904*b**2*x + 3371*b*x**2 + &
              640*x**3)))/(2187.*(c + x*(b + x))**4)

      t2 = (8*Pi**3*Q*x**19*&
         (455*b**6 + 455*Q**6 + 5488*b**5*x + &
           5660*Q**4*x**2 + 20752*Q**2*x**4 + 24640*x**6 + &
           b**4*(1365*Q**2 + 27148*x**2) + &
           32*b**3*(343*Q**2*x + 2208*x**3) + &
           b**2*(1365*Q**4 + 32808*Q**2*x**2 + &
              102224*x**4) + &
           16*b*(343*Q**4*x + 2688*Q**2*x**3 + 4880*x**5)))&
        /(2187.*(b**2 + Q**2 + 4*b*x + 4*x**2)**4)

      t3=x**3*( 864*c**4+c**3*x*(3001*b+2560*x)&
             + c**2*x**2*(3812*b**2+6179*b*x+2240*x**2)&
             + b*x**4*(432*b**3+1273*b**2*x+1220*b*x**2+385*x**3)&
             + c*x**3*(2113*b**3+4904*b**2*x+3371*b*x**2+640*x**3)&
             )
      t3=t3-2*a*x**2&
          *( 1343*c**4 + 2*c**3*x*(2231*b + 1790*x)&
           + 2*c**2*x**2*(2657*b**2 + 3869*b*x + 1085*x**2)&
           + 2*c*x**3*(1343*b**3+2594*b**2*x+1061*b*x**2-130*x**3)&
           + x**4*( 479*b**4+1006*b**3*x+130*b**2*x**2&
                   -770*b*x**3-385*x**4 )&
           )
      t3=t3+2*a**2*x&
          *( 1372*c**4 + 7*c**3*x*(589*b + 400*x)&
           + 3*c**2*x**2*(1372*b**2 + 1299*b*x - 200*x**2)&
           + c*x**3*(1459*b**3 + 72*b**2*x - 4527*b*x**2 - 2960*x**3)&
           - x**4*( -76*b**4+1061*b**3*x+ &
                    3660*b**2*x**2+3725*b*x**3+1220*x**4 )&
           )
      t3=t3+2*a**3&
          *( -455*c**4 - 14*c**3*x*(65*b + 2*x)&
           + 2*c**2*x**2*(7*b**2 + 1459*b*x + 1579*x**2)&
           + 2*c*x**3*(433*b**3+2734*b**2*x+4267*b*x**2+1906*x**3)&
           + x**4*( 409*b**4+2546*b**3*x&
                   +5198*b**2*x**2+4322*b*x**3+1273*x**4 )&
           )
      t3=t3-a**4*( 432*b**4*x**3 + b**3*(1343*c*x**2 + 2183*x**4)&
                + 4*b**2*(343*c**2*x + 1366*c*x**3 + 991*x**5) &
                + b*(455*c**3+4189*c**2*x**2+6997*c*x**4+3071*x**6)&
                + 32*(28*c**3*x+92*c**2*x**3+88*c*x**5+27*x**7)&
                )
      t3 = -4*Pi**3*x**19 * t3 /( 2187.*(a-x)**4*(c+x*(b+x))**4 )

      dVc=AA*( t1 + 2*b/Q*t2 - b*a/(a**2+b*a+c)*(t3+2*(b+2*a)/Q*t2) )

      Hxc=( 2*Ry*dVx + Ry*dVc )*a_B**9

      deallocate( rs,x,trho,t1,t2,t3,dVx,dVc )

      END SUBROUTINE VWN_Kernel

      END SUBROUTINE Exc_Cor_Kernel

