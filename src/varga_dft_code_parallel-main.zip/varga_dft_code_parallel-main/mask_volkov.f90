Module mask_volkov
  USE MOD_GLOBAL
  USE PSEUDOPOTENTIAL
  USE TAYLOR_EXTENDED
implicit none

include 'fftw3.f'

  integer*8              :: volkov_N_points=0
  integer                :: N_Volk(3)
  real*8                 :: R_A(3),R_C(3),maskinit(3),fftfactor,Vsqrtfftf
  integer                :: td_density_counter_volkov
  integer*8              :: plan_volkov_Forward,plan_volkov_Backward
  integer,parameter      :: dirnF_FFT=FFTW_FORWARD
  integer,parameter      :: dirnR_FFT=FFTW_BACKWARD
  !complex*16             :: taylor_coeff(N_taylor)
  ! vector potential
  real*8                 :: A_vec(3),A_vec_TplusdT(3) ! for split operator
  real*8                 :: A_vec_int(3),A_vec_int_prev(3),DeltaA(3) ! for mask_volkov
  real*8                 :: A_vec_2_int(3),A_vec_2_int_prev(3),DeltaA2(3)
  real*8                 :: Afinal_int(3),Afinal_2_int(3)
  real*8                 :: vtimestep  
  
  ! arrays of size volkov_N_points
  real*4,allocatable     :: volkov_grid_point(:,:)
  real*4,allocatable     :: volkov_k_vec(:,:)
  real*4,allocatable     :: sing_prec_rearranged_dvolkov(:)
  complex*16,allocatable :: Psi_volkov(:,:,:,:)
  complex*16,allocatable :: Phi_Volkov(:,:,:),Phi_Volkov2(:,:,:)
  complex*8,allocatable :: maskV_mom_final(:,:,:,:) ! PES spectum
  complex*8,allocatable :: maskV_mom_multi(:,:,:,:)
  integer,allocatable    :: Lattice_V(:,:)
  integer,allocatable    :: bw_volkov_mapping(:,:,:)
  
  ! arrays of size less than volkov_N_points
  real*8,allocatable     :: volkov_grid_x(:),volkov_grid_y(:),volkov_grid_z(:)
  real*8,allocatable     :: volkov_k_x(:),volkov_k_y(:),volkov_k_z(:)

  !  CAP like absorbing of WF
  real*8,allocatable     :: volkov_abs_x(:),volkov_abs_y(:),volkov_abs_z(:)

  integer,parameter      :: split_op_ene_file=182736,split_op_ene_file2=182737,split_op_ene_file3=182738,avec_file=182735
  complex*16             :: split_op_imag_ts
! arrays of size N_lattice_points
  real*8,allocatable       :: mask(:)
  integer,allocatable      :: fd_volkov_mapping3(:,:)
  integer*8,allocatable    :: fd_volkov_mapping(:)
  

  
  contains

!    BAD  BAD
! subroutine get_xaxis(xaxis,newaxis,npts)
!implicit none
!integer          :: npts,i
!real*8           :: xaxis(npts),newaxis(npts)
!real*8           :: pa1,pa2,pa3,x
!
!  pa1=xaxis(1)
!  pa2=xaxis(npts)
!
!  write(log_file,*) 'Assign axis ',pa1,pa2,pa2-pa1
!  if(mod(npts,2)) then
!     do i=0,npts-1
!       if(i.le.npts/2) then
!         x=2.d0*3.14159265359*i/(pa2-pa1)
!       else
!         x=2.d0*3.14159265359*(i-npts)/(pa2-pa1)
!       endif
!       newaxis(i+1)=x
!     end do
!  else
!     do i=0,npts-1
!       if(i.lt.npts/2) then
!         x=2.d0*3.14159265359*i/(pa2-pa1)
!       else
!         x=2.d0*3.14159265359*(i-npts)/(pa2-pa1)
!       endif
!       newaxis(i+1)=x
!     end do  
!  end if
!  
!end subroutine get_xaxis

subroutine get_xaxis(xaxis,newaxis,npts,gridspace)
implicit none
integer          :: npts,i
real*8           :: xaxis(npts),newaxis(npts)
real*8           :: pa1,pa2,pa3,x,boxs,gridspace

  newaxis=0.d0
  
  pa1=xaxis(1)
  pa2=xaxis(npts)
  write(log_file,*) 'Assign axis ',pa1," to ",pa2
  boxs=npts*gridspace
  !write(*,*) 'total period',pa2-pa1
!  if(mod(npts,2)) then
!     do i=0,npts-1
!       if(i.le.npts/2) then
!         x=2.d0*3.14159265359*i/boxs!(pa2-pa1)
!       else
!         x=2.d0*3.14159265359*(i-npts)/boxs!(pa2-pa1)
!       endif
!       newaxis(i+1)=x
!     end do
!  else
     do i=0,npts-1
       if(i.le.npts/2) then
         x=2.d0*3.14159265358979323846264338d0*i/boxs!(pa2-pa1)

       else
         x=2.d0*3.14159265358979323846264338d0*(i-npts)/boxs!(pa2-pa1)

       endif
       newaxis(i+1)=x
     end do  
!  end if
end subroutine get_xaxis
  

SUBROUTINE init_Volkov
implicit none
integer :: i,special_file_number
  call init_Mask_Volkov_latt
  call init_Volkov_mask
  
  write(log_file,'(a)') "set up fft plans... be patient"
  call dfftw_plan_dft_3d(plan_volkov_Forward ,N_Volk(1),N_Volk(2),N_Volk(3),Phi_Volkov,Phi_Volkov,dirnF_FFT,FFTW_PATIENT)
  call dfftw_plan_dft_3d(plan_volkov_Backward,N_Volk(1),N_Volk(2),N_Volk(3),Phi_Volkov,Phi_Volkov,dirnR_FFT,FFTW_PATIENT)
  write(log_file,'(a)') "Done setting up fft plans"
  
  vtimestep=mask_func_freq
  vtimestep=time_step*vtimestep
  A_vec_int_prev=0.d0
  A_vec_2_int_prev=0.d0
  Vsqrtfftf=1.d0/sqrt(dfloat(volkov_N_points))
  td_density_counter_volkov=0


   DeltaA=0.d0
   DeltaA2=0.d0
   A_vec=0.d0
   A_vec_TplusdT=0.d0
   A_vec_int=0.d0
   A_vec_2_int=0.d0
   ! get final A_vec_int
   Afinal_int=0.d0; Afinal_2_int=0.d0
   
  if(MPI_master) then 
   open(avec_file,file="avec_file_preview.txt",status="replace")
   write(avec_file,'(a)') "#time        A(x)           A(y)           A(z)         E(x)        E(y)        E(z)"
   do i=1,n_time_steps
     call Avec_update(i,0)
   end do
   close(avec_file)
   write(log_file,'(a,3es20.10e3)') "Final values of A ",A_vec(1:3)
   write(log_file,'(a,3es20.10e3)') "Final values of Int(Adt)",A_vec_int(1:3)
   write(log_file,'(a,3es20.10e3)') "Final values of Int(A**2dt)",A_vec_2_int(1:3)
  end if
   

   Afinal_int=A_vec_int
   Afinal_2_int=A_vec_2_int
   if((abs(A_vec(1))>0.05).or.(abs(A_vec(1))>0.05).or.(abs(A_vec(1))>0.05)) then
     write(log_file,'(a)') "vector potential at Tfinal is too large."
	 stop
   end if
   ! reset A to 0
   A_vec=0.d0
   A_vec_TplusdT=0.d0
   A_vec_int=0.d0
   A_vec_2_int=0.d0
   
   ! open the files we need:
    ! save density total
  do i=1,N_orbitals
    if(MPItask_orbital_map(i)/=MPI_proc_rank) CYCLE ! skip if orbital is not done on this process
	special_file_number=220000+i
	call open_fort_file(special_file_number,append_or_overwrite) ! norm file
	special_file_number=330000+i
    call open_fort_file(special_file_number,append_or_overwrite) ! dipole moment file
  end do
  
END SUBROUTINE init_Volkov

subroutine clean_up_volkov
implicit none
  
  call dfftw_destroy_plan(plan_volkov_Forward)
  call dfftw_destroy_plan(plan_volkov_Backward)
  
  deallocate(volkov_grid_point)
  deallocate(fd_volkov_mapping,fd_volkov_mapping3)
  deallocate(Lattice_V,Psi_volkov,Phi_Volkov,Phi_Volkov2)
  deallocate(volkov_grid_x,volkov_grid_y,volkov_grid_z)
  deallocate(volkov_k_x,volkov_k_y,volkov_k_z)
  deallocate(sing_prec_rearranged_dvolkov)
  
   if(maskV_save_PES) then
     deallocate(maskV_mom_final)
   end if
   if(maskV_save_multi_PES) then
     deallocate(maskV_mom_multi)
   end if  
   close(3301)
   close(3302)
   close(3303) 
  
end subroutine clean_up_volkov

  
SUBROUTINE init_Mask_Volkov_latt
implicit none
 integer     :: i,nvx,nvy,nvz,j,k,l,m,l1,l2,l3,fdlatt
 integer*8   :: idx
 real*8      :: rs_max_x,rs_max_y,rs_max_z,vcapbgn(3),vcapbgn2(3),dpos,arg1,abswid
 real*8      :: vgridx,vgridy,vgridz,v1,vmemreq,v2,v3,fd_lat_max(3)
 real*8      :: volkov_cap_mixVSzero
 ! initialize large grid
 ! make sure that large grid has points that coincide with regular grid.
 if(MPI_master) then 
   write(log_file,*) 'Initialize Mask function and Volkov Basis'
   write(log_file,*) 'volkov_distance1=',volkov_distance(1)
   write(log_file,*) 'volkov_distance2=',volkov_distance(2)
   write(log_file,*) 'volkov_distance3=',volkov_distance(3)
   write(log_file,*) 'volkov_mask_depth=',volkov_mask_depth
 end if
 vgridx=xgrid(1) ! X grid
 do i=1,999999 
   vgridx=vgridx-grid_step(1)
   if(abs(vgridx)> volkov_distance(1) ) then
     exit
   end if
 end do
 v1=vgridx
 do i=1,999999 
   if(v1>volkov_distance(1)) then
     nvx=i
	 exit
   end if
   v1=v1+grid_step(1)
 end do
 vgridy=ygrid(1) ! y grid
 do i=1,999999 
   vgridy=vgridy-grid_step(2)
   if(abs(vgridy)> volkov_distance(2) ) then
     exit
   end if
 end do
 v1=vgridy
 do i=1,999999 
   if(v1>volkov_distance(2)) then
     nvy=i
	 exit
   end if
   v1=v1+grid_step(2)
 end do
 vgridz=zgrid(1) ! Z grid points
 do i=1,999999 
   vgridz=vgridz-grid_step(3)
   if(abs(vgridz)> volkov_distance(3) ) then
     exit
   end if
 end do
 v1=vgridz
 do i=1,999999 
   if(v1>volkov_distance(3)) then
     nvz=i
	 exit
   end if
   v1=v1+grid_step(3)
 end do
 volkov_N_points=nvx*nvy*nvz
 if(MPI_master) write(log_file,*) 'volkov basis ',nvx,nvy,nvz
 if(MPI_master) write(log_file,*) ' a total of ',volkov_N_points,' points'
 !  using 2 phi orbitals for calculations
 vmemreq=volkov_N_points*16*(N_orbitals+2+0.5)/1000000
 if(MPI_master) write(log_file,*) '-- Wavefunction will require',vmemreq,' MB'
 if(maskV_save_PES) then
   vmemreq=volkov_N_points*8*(N_orbitals)/1000000
   if(MPI_master) write(log_file,*) '-- PES array will require',vmemreq,' MB' 
 end if
 vmemreq=volkov_N_points*4/1000000 
 if(MPI_master) write(log_file,*) '-- Density Files will require',vmemreq,' MB' 
 vmemreq=volkov_N_points*12*2/1000000 ! xyz and kvec 
 if(MPI_master) write(log_file,*) '-- grid coordinates will require',vmemreq,' MB' 
 
 N_Volk(1)=nvx
 N_Volk(2)=nvy
 N_Volk(3)=nvz
 
 if(MPI_master) write(log_file,*) "Mask_volkov grid", N_Volk(1)," points in x"
 if(MPI_master) write(log_file,*) "Mask_volkov grid", N_Volk(2)," points in y"
 if(MPI_master) write(log_file,*) "Mask_volkov grid", N_Volk(3)," points in z"
 
 allocate(volkov_grid_point(3,volkov_N_points))
 !allocate(volkov_k_vec(3,volkov_N_points))
 allocate(fd_volkov_mapping(N_lattice_points))
 allocate(fd_volkov_mapping3(3,N_lattice_points))
 allocate(bw_volkov_mapping(N_Volk(1),N_Volk(2),N_Volk(3)))
 
 allocate(Lattice_V(3,volkov_N_points))
 allocate(Psi_volkov(N_Volk(1),N_Volk(2),N_Volk(3),N_orbitals))
 allocate(Phi_volkov(N_Volk(1),N_Volk(2),N_Volk(3)))
 allocate(Phi_volkov2(N_Volk(1),N_Volk(2),N_Volk(3)))
 ! used for photoelectron spectrum
 if(maskV_save_PES) then
   allocate(maskV_mom_final(N_Volk(1),N_Volk(2),N_Volk(3),N_orbitals))
   maskV_mom_final=0.d0
 end if
 if(maskV_save_multi_PES) then
   allocate(maskV_mom_multi(N_Volk(1),N_Volk(2),N_Volk(3),N_orbitals))
   maskV_mom_multi=0.d0
 end if
 allocate(volkov_grid_x(N_Volk(1)),volkov_grid_y(N_Volk(2)),volkov_grid_z(N_Volk(3)))
 allocate(volkov_k_x(N_Volk(1)),volkov_k_y(N_Volk(2)),volkov_k_z(N_Volk(3)))
 allocate(volkov_abs_x(N_Volk(1)),volkov_abs_y(N_Volk(2)),volkov_abs_z(N_Volk(3)))
 allocate(sing_prec_rearranged_dvolkov(volkov_N_points))
 fd_lat_max(1)=abs(xgrid(1))
 fd_lat_max(2)=abs(ygrid(1))
 fd_lat_max(3)=abs(zgrid(1))
 fd_volkov_mapping=0
 fd_volkov_mapping3=0
 bw_volkov_mapping=0
 
 
 idx=0

 do i=1,N_Volk(1)
   volkov_grid_x(i)=vgridx+(grid_step(1)*(i-1))
 end do
 do i=1,N_Volk(2)
   volkov_grid_y(i)=vgridy+(grid_step(2)*(i-1))
 end do
 do i=1,N_Volk(3)
   volkov_grid_z(i)=vgridz+(grid_step(3)*(i-1))
 end do
 do i=1,N_Volk(1)
   v1=volkov_grid_x(i)
   do j=1,N_Volk(2)
     v2=volkov_grid_y(j)
	 do k=1,N_Volk(3)
	   v3=volkov_grid_z(k)
	   idx=idx+1
	   volkov_grid_point(1,idx)=v1
	   volkov_grid_point(2,idx)=v2
	   volkov_grid_point(3,idx)=v3
	   Lattice_V(1,idx)=i
	   Lattice_V(2,idx)=j
	   Lattice_V(3,idx)=k
	   
	   if(abs(v1)<fd_lat_max(1)+0.01d0) then
	     if(abs(v2)<fd_lat_max(2)+0.01d0) then
           if(abs(v3)<fd_lat_max(3)+0.01d0) then
             ! generate mapping 
			 m=0
!			 do l=1,N_lattice_points
!			   if(abs(v1-grid_point(1,l))<0.00001) then
!                 if(abs(v2-grid_point(2,l))<0.00001) then
!				   if(abs(v3-grid_point(3,l))<0.00001) then
!				     fd_volkov_mapping(l)=idx
!					 fd_volkov_mapping3(1,l)=i
!					 fd_volkov_mapping3(2,l)=j
!					 fd_volkov_mapping3(3,l)=k
!					 m=idx
!				   end if
!				 end if
!			   end if
!			 end do
             do l1=1,N_Lattice(1)
			   if(abs(v1-xgrid(l1))<0.00001) then
                 do l2=1,N_Lattice(2)
				   if(abs(v2-ygrid(l2))<0.00001) then
                     do l3=1,N_Lattice(3)
                       if(abs(v3-zgrid(l3))<0.00001) then
					     fdlatt=Lattice_inv_xyz(l1,l2,l3)
    				     fd_volkov_mapping(fdlatt)=idx
    					 fd_volkov_mapping3(1,fdlatt)=i
    					 fd_volkov_mapping3(2,fdlatt)=j
    					 fd_volkov_mapping3(3,fdlatt)=k
    					 m=idx
                         bw_volkov_mapping(i,j,k)=fdlatt						 
					   end if
			         end do    
                   end if					 
			     end do     
               end if			   
			 end do
			 if(m.eq.0) then
			   write(*,'(a,3f15.5)') 'bad mapping volkov point:',v1,v2,v3
			   write(log_file,'(a,3f15.5)') 'bad mapping volkov point:',v1,v2,v3
			   stop
			 end if			 
		   end if
		 end if
	   end if
	   
	 end do
   end do

 end do
 
 ! get k axis
  call get_xaxis(volkov_grid_x,volkov_k_x,N_Volk(1),grid_step(1))
  call get_xaxis(volkov_grid_y,volkov_k_y,N_Volk(2),grid_step(1))
  call get_xaxis(volkov_grid_z,volkov_k_z,N_Volk(3),grid_step(1))
  
  if(MPI_master) then
    open(3323,file="volkov_grid_Angstroms.dat",status="replace")
    write(3323,*) 'X axis Volkov basis in real and k-space. Units Angstroms'
    do i=1,N_Volk(1)
      write(3323,'(i5,2f15.5)') i,volkov_grid_x(i),volkov_k_x(i)
    end do
  
    write(3323,*) 'Y axis Volkov basis in real and k-space,  Units Angstroms'
    do i=1,N_Volk(2)
      write(3323,'(i5,2f15.5)') i,volkov_grid_y(i),volkov_k_y(i)
    end do
  
    write(3323,*) 'Z axis Volkov basis in real and k-space,  Units Angstroms'
    do i=1,N_Volk(3)
      write(3323,'(i5,2f15.5)') i,volkov_grid_z(i),volkov_k_z(i)
    end do
    close(3323)
  
    write(*,*) 'Volkov X grid ',volkov_grid_x(1),volkov_grid_x(N_Volk(1))
    write(*,*) 'Volkov Y grid ',volkov_grid_y(1),volkov_grid_y(N_Volk(2))
    write(*,*) 'Volkov Z grid ',volkov_grid_z(1),volkov_grid_z(N_Volk(3))
    write(log_file,*) 'Volkov X grid ',volkov_grid_x(1),volkov_grid_x(N_Volk(1))
    write(log_file,*) 'Volkov Y grid ',volkov_grid_y(1),volkov_grid_y(N_Volk(2))
    write(log_file,*) 'Volkov Z grid ',volkov_grid_z(1),volkov_grid_z(N_Volk(3))  
  end if
  
  ! make array for absorbing the wave function
  fd_lat_max(1)=abs(xgrid(1))
  fd_lat_max(2)=abs(ygrid(1))
  fd_lat_max(3)=abs(zgrid(1))
  volkov_abs_x=1.d0
  volkov_abs_y=1.d0
  volkov_abs_z=1.d0
  !                                          capdist
  !       ---------------------------------|--------|
  !                                 capbgn |   | vcapbfn2
  vcapbgn(1)=volkov_grid_x(N_Volk(1))-volkov_capdist_x
  vcapbgn(2)=volkov_grid_y(N_Volk(2))-volkov_capdist_y
  vcapbgn(3)=volkov_grid_z(N_Volk(3))-volkov_capdist_z
  volkov_cap_mixVSzero=0.5d0
  vcapbgn2(1)=vcapbgn(1)+volkov_capdist_x*volkov_cap_mixVSzero
  vcapbgn2(2)=vcapbgn(2)+volkov_capdist_y*volkov_cap_mixVSzero
  vcapbgn2(3)=vcapbgn(3)+volkov_capdist_z*volkov_cap_mixVSzero
  if(MPI_master) then
      do i=1,3
        if(fd_lat_max(i)>vcapbgn(i)) then
    	  write(log_file,*) "Mask region and volkov absorbing region overlapping for axix",i
    	  write(log_file,*) fd_lat_max(i),vcapbgn(i)
    	  stop
    	else 
    	  write(log_file,'(a,i1,a,f20.5,a)') "Volkov region size for axis ",i," is ",vcapbgn(i)-fd_lat_max(i)," Angstrom"
    	end if	
      end do
      write(812,*) '#X axis Volkov absorbing function'
      write(812,'(a,4es26.16)') "# ",volkov_grid_x(N_Volk(1)),volkov_capdist_x,vcapbgn(1),vcapbgn2(1)
  end if
  j=1
  do i=1,N_Volk(1)
    dpos=volkov_grid_x(i)
	abswid=volkov_capdist_x*volkov_cap_mixVSzero
	arg1=0.d0
    if((dpos>vcapbgn(j)).AND.(dpos<vcapbgn2(j))) then
      ! old volkov_abs_x(i)=exp(-1*volkov_capparm*((volkov_grid_x(i)-vcapbgn(1))/(volkov_grid_x(N_Volk(1))-vcapbgn(1)))**2)
	  arg1=(dpos-vcapbgn(j))*3.141592d0/(2.d0*abswid)
	  volkov_abs_x(i)=1.d0-(sin(arg1)**2)
	else if((dpos>=vcapbgn2(j)).OR.(dpos<=-vcapbgn2(j))) then
	  volkov_abs_x(i)=0.d0
    else if((dpos<-vcapbgn(j)).AND.(dpos>-vcapbgn2(j))) then
	  !old volkov_abs_x(i)=exp(-1*volkov_capparm*((volkov_grid_x(i)+vcapbgn(1))/(volkov_grid_x(1)+vcapbgn(1)))**2)
	  arg1=(dpos+vcapbgn(j))*3.141592d0/(2.d0*abswid)
	  volkov_abs_x(i)=1.d0-(sin(arg1)**2)
	end if
	if(MPI_master) write(812,'(3es26.16)') volkov_grid_x(i),volkov_abs_x(i),arg1
  end do  
  if(MPI_master) write(812,*) '#Y axis Volkov absorbing function'
  j=2
  do i=1,N_Volk(2)
!    if(volkov_grid_y(i)>vcapbgn(2)) then
!      volkov_abs_y(i)=exp(-1*volkov_capparm*((volkov_grid_y(i)-vcapbgn(2))/(volkov_grid_y(N_Volk(2))-vcapbgn(2)))**2)
!    else if(volkov_grid_y(i)<-vcapbgn(2)) then
!	  volkov_abs_y(i)=exp(-1*volkov_capparm*((volkov_grid_y(i)+vcapbgn(2))/(volkov_grid_y(1)+vcapbgn(2)))**2)
!	end if
    dpos=volkov_grid_y(i)
	abswid=volkov_capdist_y*volkov_cap_mixVSzero
    if((dpos>vcapbgn(j)).AND.(dpos<vcapbgn2(j))) then
	  arg1=(dpos-vcapbgn(j))*3.141592d0/(2.d0*abswid)
	  volkov_abs_y(i)=1.d0-(sin(arg1)**2)
	else if((dpos>=vcapbgn2(j)).OR.(dpos<=-vcapbgn2(j))) then
	  volkov_abs_y(i)=0.d0
    else if((dpos<-vcapbgn(j)).AND.(dpos>-vcapbgn2(j))) then
	  arg1=(dpos+vcapbgn(j))*3.141592d0/(2.d0*abswid)
	  volkov_abs_y(i)=1.d0-(sin(arg1)**2)
	end if
	if(MPI_master) write(812,'(2es26.16)') volkov_grid_y(i),volkov_abs_y(i)
  end do    
  if(MPI_master) write(812,*) '#Z axis Volkov absorbing function'
  j=3
  do i=1,N_Volk(3)
!    if(volkov_grid_z(i)>vcapbgn(3)) then
!      volkov_abs_z(i)=exp(-1*volkov_capparm*((volkov_grid_z(i)-vcapbgn(3))/(volkov_grid_z(N_Volk(3))-vcapbgn(3)))**2)
!    else if(volkov_grid_z(i)<-vcapbgn(3)) then
!	  volkov_abs_z(i)=exp(-1*volkov_capparm*((volkov_grid_z(i)+vcapbgn(3))/(volkov_grid_z(1)+vcapbgn(3)))**2)
!	end if
    dpos=volkov_grid_z(i)
	abswid=volkov_capdist_z*volkov_cap_mixVSzero
    if((dpos>vcapbgn(j)).AND.(dpos<vcapbgn2(j))) then
	  arg1=(dpos-vcapbgn(j))*3.141592d0/(2.d0*abswid)
	  volkov_abs_z(i)=1.d0-(sin(arg1)**2)
	else if((dpos>=vcapbgn2(j)).OR.(dpos<=-vcapbgn2(j))) then
	  volkov_abs_z(i)=0.d0
    else if((dpos<-vcapbgn(j)).AND.(dpos>-vcapbgn2(j))) then
	  arg1=(dpos+vcapbgn(j))*3.141592d0/(2.d0*abswid)
	  volkov_abs_z(i)=1.d0-(sin(arg1)**2)
	end if
	if(MPI_master) write(812,'(2es26.16)') volkov_grid_z(i),volkov_abs_z(i)
  end do     
  
  ! convert to AU
  volkov_grid_x=volkov_grid_x*convertL2AU
  volkov_grid_y=volkov_grid_y*convertL2AU
  volkov_grid_z=volkov_grid_z*convertL2AU
  ! HERE
  call get_xaxis(volkov_grid_x,volkov_k_x,N_Volk(1),grid_step(1)*convertL2AU)
  call get_xaxis(volkov_grid_y,volkov_k_y,N_Volk(2),grid_step(1)*convertL2AU)
  call get_xaxis(volkov_grid_z,volkov_k_z,N_Volk(3),grid_step(1)*convertL2AU)
  
  if(MPI_master) then 
    open(3323,file="volkov_grid_Atomic.dat",status="replace")
    write(3323,*) 'X axis Volkov basis in real and k-space. ATOMIC UNITS'
    do i=1,N_Volk(1)
      write(3323,'(i5,2f15.5)') i,volkov_grid_x(i),volkov_k_x(i)
    end do
  
    write(3323,*) 'Y axis Volkov basis in real and k-space,  ATOMIC UNITS'
    do i=1,N_Volk(2)
      write(3323,'(i5,2f15.5)') i,volkov_grid_y(i),volkov_k_y(i)
    end do
  
    write(3323,*) 'Z axis Volkov basis in real and k-space,   ATOMIC UNITS'
    do i=1,N_Volk(3)
      write(3323,'(i5,2f15.5)') i,volkov_grid_z(i),volkov_k_z(i)
    end do  
    
    write(*,'(a,2f15.7)') 'Volkov X grid in Bohr ',volkov_grid_x(1),volkov_grid_x(N_Volk(1))
    write(*,'(a,2f15.7)') 'Volkov Y grid in Bohr ',volkov_grid_y(1),volkov_grid_y(N_Volk(2))
    write(*,'(a,2f15.7)') 'Volkov Z grid in Bohr ',volkov_grid_z(1),volkov_grid_z(N_Volk(3))
    close(3323)
  end if 

end SUBROUTINE init_Mask_Volkov_latt

subroutine revmap_3dwf_to_1dwf(wf_3d,wf1d)
implicit none
  integer    :: i1,i2,i3,n1,n2,n3
  complex*16,intent(in)  :: wf_3d(:,:,:)
  complex*16,intent(out) :: wf1d(:)
  
  wf1d=(0.d0,0.d0)
  n1=size(wf_3d,1)
  n2=size(wf_3d,2)
  n3=size(wf_3d,3)
	do i3=1,n3
	  do i2=1,n2
	    do i1=1,n1
			wf1d(Lattice_inv_xyz(i1,i2,i3))=wf_3d(i1,i2,i3)
        end do
      end do
    end do  

end subroutine revmap_3dwf_to_1dwf

subroutine revmap_3dwf_to_1dwf_Vel2Len(wf_3d,wf1d,Ause)
implicit none
  integer    :: i1,i2,i3,n1,n2,n3
  real*8     :: Ause(3)
  complex*16,intent(in)  :: wf_3d(:,:,:)
  complex*16,intent(out) :: wf1d(:)
  complex*16             :: phase1
  
  wf1d=(0.d0,0.d0)
  n1=size(wf_3d,1)
  n2=size(wf_3d,2)
  n3=size(wf_3d,3)
	do i3=1,n3
	  do i2=1,n2
	    do i1=1,n1
		  phase1=Ause(1)*xgrid(i1)*convertL2AU
		  phase1=phase1+ Ause(2)*ygrid(i2)*convertL2AU
		  phase1=phase1+ Ause(3)*zgrid(i3)*convertL2AU
			wf1d(Lattice_inv_xyz(i1,i2,i3))=wf_3d(i1,i2,i3)*exp(zi*phase1)
			
        end do
      end do
    end do  

end subroutine revmap_3dwf_to_1dwf_Vel2Len

subroutine map_1dwf_to_3dwf(wf1d,wf_3d)
implicit none
  integer    :: i1,i2,i3,n1,n2,n3
  complex*16,intent(out)  :: wf_3d(:,:,:)
  complex*16,intent(in)   :: wf1d(:)
  
  wf_3d=(0.d0,0.d0)
  n1=size(wf_3d,1)
  n2=size(wf_3d,2)
  n3=size(wf_3d,3)
	do i3=1,n3
	  do i2=1,n2
	    do i1=1,n1
			wf_3d(i1,i2,i3)=wf1d(Lattice_inv_xyz(i1,i2,i3))
        end do
      end do
    end do  

end subroutine map_1dwf_to_3dwf

subroutine map_1dwf_to_3dwf_Len2Vel(wf1d,wf_3d,Ause)
implicit none
  integer    :: i1,i2,i3,n1,n2,n3
  real*8     :: Ause(3)
  complex*16,intent(out)  :: wf_3d(:,:,:)
  complex*16,intent(in)   :: wf1d(:)
  complex*16              :: phase1
  
  wf_3d=(0.d0,0.d0)
  n1=size(wf_3d,1)
  n2=size(wf_3d,2)
  n3=size(wf_3d,3)
	do i3=1,n3
	  do i2=1,n2
	    do i1=1,n1
		  phase1=Ause(1)*xgrid(i1)*convertL2AU
		  phase1=phase1+ Ause(2)*ygrid(i2)*convertL2AU
		  phase1=phase1+ Ause(3)*zgrid(i3)*convertL2AU
			wf_3d(i1,i2,i3)=wf1d(Lattice_inv_xyz(i1,i2,i3))*exp(-zi*phase1)
        end do
      end do
    end do  

end subroutine map_1dwf_to_3dwf_Len2Vel

SUBROUTINE init_Volkov_split_op
implicit none
   integer  :: i,n,i1,i2,i3,k
   real*8   :: au_xgrid(N_Lattice(1)),au_ygrid(N_Lattice(2)),au_zgrid(N_Lattice(3))
  
  write(log_file,*) "allocate vso_kphi vso_rphi phi_c2"
  allocate(vso_kphi(N_Lattice(1),N_Lattice(2),N_Lattice(3)))
  allocate(vso_rphi(N_Lattice(1),N_Lattice(2),N_Lattice(3)))
  allocate(phi_c2(N_lattice_points))
  vso_rphi=0.d0
  vso_kphi=0.d0
  phi_c2=0.d0
  
  write(log_file,*) "setup fftw3 plans. Using FFTW_PATIENT"
  
  call dfftw_plan_dft_3d(plan_volkov_Forward ,N_Lattice(1),N_Lattice(2),N_Lattice(3),vso_rphi,vso_kphi,dirnF_FFT,FFTW_PATIENT)
  call dfftw_plan_dft_3d(plan_volkov_Backward,N_Lattice(1),N_Lattice(2),N_Lattice(3),vso_kphi,vso_rphi,dirnR_FFT,FFTW_PATIENT) 
  
  write(log_file,*) " Done setting up fftw3 plans."
  
  A_vec=0.d0
  fftfactor=1.d0/dfloat(N_lattice_points)
  td_density_counter_volkov=0	
  au_xgrid=xgrid*convertL2AU
  au_ygrid=ygrid*convertL2AU
  au_zgrid=zgrid*convertL2AU
  allocate(volkov_k_x(N_Lattice(1)),volkov_k_y(N_Lattice(2)),volkov_k_z(N_Lattice(3)))
  volkov_k_x=0.d0
  volkov_k_y=0.d0
  volkov_k_z=0.d0
  ! get k axis
  !units1
  !call get_xaxis(au_xgrid,volkov_k_x,N_Lattice(1),grid_step(1)*convertL2AU)
  !call get_xaxis(au_ygrid,volkov_k_y,N_Lattice(2),grid_step(2)*convertL2AU)
  !call get_xaxis(au_zgrid,volkov_k_z,N_Lattice(3),grid_step(3)*convertL2AU) 
  call get_xaxis(xgrid,volkov_k_x,N_Lattice(1),grid_step(1))
  call get_xaxis(ygrid,volkov_k_y,N_Lattice(2),grid_step(2))
  call get_xaxis(zgrid,volkov_k_z,N_Lattice(3),grid_step(3))
  do i1=1,N_Lattice(1)
    write(9090,*) i1,xgrid(i1),volkov_k_x(i1)
  end do
  close(9090)
  do i1=1,N_Lattice(2)
    write(9091,*) i1,ygrid(i1),volkov_k_y(i1)
  end do
  close(9091)
  do i1=1,N_Lattice(3)
    write(9092,*) i1,zgrid(i1),volkov_k_z(i1)
  end do
  close(9092)
  
  write(log_file,*) "get fft axis for x y z grids of size"
  write(log_file,*) N_Lattice(1),N_Lattice(2),N_Lattice(3)
  
  ! check Lattice_inv_xyz
    	do i3=1,N_Lattice(3)
    	  do i2=1,N_Lattice(2)
    	    do i1=1,N_Lattice(1)
              i=Lattice_inv_xyz(i1,i2,i3)
        	  if(i<1 .OR. i>N_Lattice_points ) then
        	    write(*,*) "lattice value <1 or >N_Lattice_points ",i,i1,i2,i3
        		stop
        	  end if
    	    end do
    	  end do 
    	end do
		
  if(propagator=="split_v_krk".OR.propagator=="split_v_krk_imagt".OR.propagator=="split_v_mix") then ! need vso_kpsi
      write(log_file,*) " allocate vso_kpsi"
	  allocate(vso_kpsi(N_Lattice(1),N_Lattice(2),N_Lattice(3),N_orbitals))
      vso_kpsi=0.d0

      do n=1,N_orbitals
	    Phi_c(:)=Psi_c(:,n)
	    call map_1dwf_to_3dwf(Phi_c,vso_rphi)

    	write(log_file,*) "mapped orbital ",n," for FFT, norm=",sum(real(conjg(vso_rphi)*vso_rphi))*grid_volume

		call dfftw_execute_dft(plan_volkov_Forward,vso_rphi,vso_kphi)
		vso_kphi=vso_kphi*sqrt(fftfactor)
		!write(log_file,*) "Fourier coeff norm=",sum(real(conjg(vso_kphi)*vso_kphi))*grid_volume
    	vso_kpsi(:,:,:,n)=vso_kphi(:,:,:)
      end do
	  write(log_file,*) "KRK propagator, or K-space -> Real space -> K-space method"
	  write(log_file,*) "Propagator split up. using ",N_taylor," order taylor expansion of potential in real space."
	  
  end if
  
  open(split_op_ene_file2,file="energies_split_op.txt",status="replace")
  open(split_op_ene_file,file="energies_split_op_comp.txt",status="replace")
  open(split_op_ene_file3,file="energies_split_op_comp_imag.txt",status="replace")
  write(split_op_ene_file,'(a)') &
  "#orb      time            split_op_ene                      K part                      V part"
  write(split_op_ene_file3,'(a)') &
  "#orb      time            split_op_ene                      K part                      V part"
  write(split_op_ene_file2,'(a)') &
  "#time                 energy_sp_split(eV)                   total_split(eV)"
  
  write(log_file,*) "--END VOLKOV SPLIT OP INITIALIZATION--"
  
  allocate(Psi_debug(N_Lattice_points,N_orbitals))
  Psi_debug=1.d0
  Psi_debug=0.d0
  Psi_debug=Psi_c
  
end SUBROUTINE init_Volkov_split_op

subroutine split_op_v_imag_time_minimization
implicit none
  integer :: i,j,n
  real*8  :: T1,E1,tottime
       split_op_imag_ts=split_op_inital_imag_ts
	   ! check initial ene call volkov_split_timestep_krk(-split_op_num_imag_ts-1)
	   j=0
	   T1=pi/dfloat(split_op_num_imag_ts*2) ! want phase factor to by exp(i*pi/2) at end
	  do i=-split_op_num_imag_ts,0
	    if(propagator=="split_v_krk") call volkov_split_imag_timestep_krk(i)
		if(propagator=="split_v_rkr") call volkov_split_imag_timestep_rkr(i)
		if(propagator=="split_v_mix") then
		  if(mod(i,2)==0) then
		    call volkov_split_imag_timestep_krk(i)
		  else
		    call volkov_split_imag_timestep_rkr(i)
			do n=1,N_Total_orbitals
			  Phi_c(:)=Psi_c(:,n)
			  call map_1dwf_to_3dwf(Phi_c,vso_rphi)
	          call dfftw_execute_dft(plan_volkov_Forward,vso_rphi,vso_kphi)
	          vso_kphi=vso_kphi*sqrt(fftfactor)
			  vso_kpsi(:,:,:,n)=vso_kphi(:,:,:)
			end do
		  end if
		end if
		call calculate_rho_grid
		call Hamiltonian_density
		call split_op_energy_noA(i,E1)
		j=j+1
		if(.NOT.use_split_op_cpximagtime) then
		  write(log_file,'(a,es29.16e3,a,f15.10,a,i6)') &
		    "total_ene_sp_split_op= ",E1," dt=",real(split_op_imag_ts)," iter=",j
		  if(mod(j,split_op_num_imag_tsdecay)==0) then
		    write(log_file,*) "change split_op_imag_ts from",split_op_imag_ts
		    write(log_file,*) "to ",split_op_imag_ts/3
		    split_op_imag_ts=split_op_imag_ts/3
		  end if
		else ! imaginary time step with phase factor changes in phase going from 1 to i
		  write(log_file,'(a,es29.16e3,a,2f15.10,a,i6)') &
		    "total_ene_sp_split_op= ",E1," dt=",real(split_op_imag_ts),imag(split_op_imag_ts)," iter=",j
		  !split_op_imag_ts=split_op_inital_imag_ts*exp(zi*T1*j)
		  split_op_imag_ts=split_op_inital_imag_ts*exp(zi*split_op_imag_ts_phase)
		end if
		if((mod(abs(i),4)==0).OR.(i==0)) then
		  Psi_c=real(Psi_c) ! mostly entirely real, but keep roundoff down
		  if(propagator=="split_v_rkr") then
		    write(log_file,*) "Orthogonalize wavefunction..."
		    call Orthogonalization_Psi_c(1,N_Total_orbitals)
		  else if(propagator=="split_v_krk".or.propagator=="split_v_mix") then
		    write(log_file,*) "Orthogonalize wavefunction..."
		    call Orthogonalization_vso_kpsi(1,N_Total_orbitals)
		  end if
		end if
	  end do
	  
	  if(split_op_save_imagt_gs) then
	    Psi=real(Psi_c)
		call calculate_rho_grid
       	call output_psi
        call output_scf		
	  end if
	  
	  tottime=0.d0
	  do i=1,split_op_num_ramp_ts
	    split_op_imag_ts=zi*time_step*(dfloat(i)/split_op_num_ramp_ts)
		tottime=tottime+imag(split_op_imag_ts)
	    if(propagator=="split_v_krk") call volkov_split_imag_timestep_krk(i)
		if(propagator=="split_v_rkr") call volkov_split_imag_timestep_rkr(i)
		if(propagator=="split_v_mix") then
		  if(mod(i,2)==0) then
		    call volkov_split_imag_timestep_krk(i)
		  else
		    call volkov_split_imag_timestep_rkr(i)
			do n=1,N_Total_orbitals
			  Phi_c(:)=Psi_c(:,n)
			  call map_1dwf_to_3dwf(Phi_c,vso_rphi)
	          call dfftw_execute_dft(plan_volkov_Forward,vso_rphi,vso_kphi)
	          vso_kphi=vso_kphi*sqrt(fftfactor)
			  vso_kpsi(:,:,:,n)=vso_kphi(:,:,:)
			end do
		  end if
		end if
		call calculate_rho_grid
		call Hamiltonian_density
		call split_op_energy_noA(i,E1)
		call Total_Energy_grid_c(i)
        write(log_file,'(a,2es29.16e3,a,f15.10,a,i6,2f15.10)') &
		  "init_split_op_realtime= ",E1,Energy," dt=",imag(split_op_imag_ts),&
		  " iter=",i,tottime,time_step*(dfloat(i)/split_op_num_ramp_ts)
		
	  end do
	  
	  
	  
end subroutine split_op_v_imag_time_minimization

subroutine PplusAsquared_AU(phasef1,iter)
implicit none ! generate H**2/2m (P+A)**2 
  integer   :: i,n,i1,i2,i3,iter
  complex*16 :: phasef1(N_Lattice(1),N_Lattice(2),N_Lattice(3))
  complex*16 :: term1,term2,term3,phase2
  real*8     :: Hsq2M_AU=0.5d0
  character(255)    :: fname1


	do i3=1,N_Lattice(3)
	  do i2=1,N_Lattice(2)
	    do i1=1,N_Lattice(1)
          term1=(volkov_k_x(i1)**2+volkov_k_y(i2)**2+volkov_k_z(i3)**2)/(convertL2AU**2)
		  term2=(+(2*volkov_k_x(i1)*A_vec(1))&
		         +(2*volkov_k_y(i2)*A_vec(2))&
		         +(2*volkov_k_z(i3)*A_vec(3)))/convertL2AU
		  term3=(A_vec(1)**2+A_vec(2)**2+A_vec(3)**2)
		  phase2=-zi*time_step*convertT2AU
		  phasef1(i1,i2,i3)=Hsq2M_AU*(term1+term2+term3)*phase2
        end do
      end do
    end do
	
  
end subroutine PplusAsquared_AU

subroutine volkov_split_timestep_krk(iter)
implicit none
  integer   :: i,n,i1,i2,i3,iter,maxele
  integer   :: lp(3)
  complex*16 :: term1,term2,term3,phase2,potxyz
  complex*16 :: allpotentials
  real*8     :: maxv1,eneKpart1,eneRSpart2,eneSPtot,ene_regular,ene_reg_V,ene_Konly
  complex*16 :: term1units,term2units,term3units,phase2units
  complex*16 :: phase_a3d(N_Lattice(1),N_Lattice(2),N_Lattice(3))
  
  !write(log_file,'(a,3f15.5)') "A(r)_AU ",A_vec
  lp=0
  eneSPtot=0.d0
  call PplusAsquared_AU(phase_a3d,iter)
  
  do n=1,N_orbitals
!    ! test
!    Phi_c(:)=Psi_c(:,n)
!	call map_1dwf_to_3dwf_Len2Vel(Phi_c,vso_rphi,A_vec)
!	call dfftw_execute_dft(plan_volkov_Forward,vso_rphi,vso_kphi)
!	vso_kphi=vso_kphi*sqrt(fftfactor)
!	write(log_file,'(a,i6,i3,es30.16e3)') "max_diff ",iter,n,maxval(abs(vso_kpsi(:,:,:,n)-vso_kphi(:,:,:)))    
!    !test
	
	vso_kphi(:,:,:)=vso_kpsi(:,:,:,n)

    vso_kphi=vso_kphi*exp(phase_a3d*0.5d0) ! propagator in k space	
	call dfftw_execute_dft(plan_volkov_Backward,vso_kphi,vso_rphi)
    vso_rphi=vso_rphi*sqrt(fftfactor)
	call revmap_3dwf_to_1dwf_Vel2Len(vso_rphi,Phi_c,A_vec)
	call taylor_expV_phi(n,1.d0,1) ! propagator in real space
	call map_1dwf_to_3dwf_Len2Vel(Phi_c,vso_rphi,A_Vec)
	call dfftw_execute_dft(plan_volkov_Forward,vso_rphi,vso_kphi)
	vso_kphi=vso_kphi*sqrt(fftfactor)
	vso_kphi=vso_kphi*exp(phase_a3d*0.5d0) ! propagator in k space	
	
	vso_kpsi(:,:,:,n)=vso_kphi(:,:,:)

	!map back to Psi_c to update potentials
	call dfftw_execute_dft(plan_volkov_Backward,vso_kphi,vso_rphi)
	vso_rphi=vso_rphi*sqrt(fftfactor)

	call revmap_3dwf_to_1dwf_Vel2Len(vso_rphi,Phi_c,A_Vec_Tplusdt)
	Psi_c(:,n)=Phi_c(:)
	

  end do

  
!	!call V_wavefn_c_noLaser
!	call V_wavefn_c_wL(iter,1.d0,phi_c,H_Phi_c)
!	eneRSpart2=real(sum(conjg(Phi_c)*H_Phi_c))*grid_volume
!	
!	call Hamiltonian_wavefn_c(iter,1.d0,Phi_c,H_Phi_c)
!	ene_regular=real(sum(conjg(Phi_c)*H_Phi_c))*grid_volume
!	
!	write(split_op_ene_file,'(i4,f12.4,4es29.16e3)') n,time_step*iter,eneRSpart2+eneKpart1,eneRSpart2,eneKpart1,ene_regular
!	eneSPtot=eneSPtot+Occupation(n)*(eneRSpart2+eneKpart1)
 ! outside do loop
!  energy_split_op_sp_tot=eneSPtot+E_Exchange+E_Hartree+E_Ion_Ion
!  write(split_op_ene_file2,'(f12.4,2es29.16e3)') time_step*iter,eneSPtot,energy_split_op_sp_tot
!  write(log_file,'(a,i7,f12.4,es29.16e3)') 'i_t_eSO ',iter,time_step*iter,energy_split_op_sp_tot
end subroutine volkov_split_timestep_krk

subroutine volkov_split_imag_timestep_krk(iter)
implicit none
  integer   :: i,n,i1,i2,i3,iter,maxele
  integer   :: lp(3)
  complex*16 :: term1,phase2,potxyz,phase3units
  complex*16 :: allpotentials
  real*8     :: maxv1,eneKpart1,eneRSpart2,eneSPtot,ene_regular,normimagt
  
  !write(log_file,*) A_vec
  lp=0
  eneSPtot=0.d0

		  !units1
	phase2=-h2m*split_op_imag_ts/(hbar*2.d0)
	!phase3units=-0.5d0*split_op_imag_ts*convertT2AU/(2.d0*convertL2AU**2)
	      !write(log_file,*) "1 ",phase2," 2 ",phase3units  
  
  do n=1,N_orbitals

	vso_kphi(:,:,:)=vso_kpsi(:,:,:,n)
    ! propagator in k space	
	do i3=1,N_Lattice(3)
	  do i2=1,N_Lattice(2)
	    do i1=1,N_Lattice(1)
		  term1=(volkov_k_x(i1)**2+volkov_k_y(i2)**2+volkov_k_z(i3)**2)
          vso_kphi(i1,i2,i3)=vso_kphi(i1,i2,i3)*exp(term1*phase2)         
        end do
      end do
    end do
    
	call dfftw_execute_dft(plan_volkov_Backward,vso_kphi,vso_rphi)
    vso_rphi=vso_rphi*sqrt(fftfactor)
	call revmap_3dwf_to_1dwf(vso_rphi,Phi_c)
	! propagator in real space
	call taylor_imagtime_expV_phi(n,1.d0,1)
	
	call map_1dwf_to_3dwf(Phi_c,vso_rphi)
	call dfftw_execute_dft(plan_volkov_Forward,vso_rphi,vso_kphi)
	vso_kphi=vso_kphi*sqrt(fftfactor)

	eneKpart1=0.d0
	do i3=1,N_Lattice(3)
	  do i2=1,N_Lattice(2)
	    do i1=1,N_Lattice(1)
		  term1=(volkov_k_x(i1)**2+volkov_k_y(i2)**2+volkov_k_z(i3)**2)
          vso_kphi(i1,i2,i3)=vso_kphi(i1,i2,i3)*exp(term1*phase2)
		  !eneKpart1=eneKpart1+real(term1*h2m*conjg(vso_kphi(i1,i2,i3))*vso_kphi(i1,i2,i3))
        end do
      end do
    end do
    
	!map back to Psi_c to update potentials
	call dfftw_execute_dft(plan_volkov_Backward,vso_kphi,vso_rphi)
	vso_rphi=vso_rphi*sqrt(fftfactor)
	
	normimagt=sum(real(conjg(vso_rphi)*vso_rphi))*grid_volume
	!write(log_file,'(a,i3,a,f12.7,a)') "orb ",n," imag_time_norm=",normimagt," renormalize"
	vso_kphi=vso_kphi/sqrt(normimagt)
	vso_rphi=vso_rphi/sqrt(normimagt)
	
	vso_kpsi(:,:,:,n)=vso_kphi(:,:,:)
	
	call revmap_3dwf_to_1dwf(vso_rphi,Phi_c)
	Psi_c(:,n)=Phi_c(:)
	

  end do
  

end subroutine volkov_split_imag_timestep_krk



! some OLD code for RKR timestep
!	! full Dt in k space
!	do i3=1,N_Lattice(3)
!	  do i2=1,N_Lattice(2)
!	    do i1=1,N_Lattice(1)
!          term1=(volkov_k_x(i1)**2+volkov_k_y(i2)**2+volkov_k_z(i3)**2)/(convertL2AU**2)
!		  term2=(+(2*volkov_k_x(i1)*A_vec(1))&
!		         +(2*volkov_k_y(i2)*A_vec(2))&
!		         +(2*volkov_k_z(i3)*A_vec(3)))/convertL2AU
!		  term3=(A_vec(1)**2+A_vec(2)**2+A_vec(3)**2)
!		  phase2=-zi*time_step*convertT2AU
!		  vso_kphi(i1,i2,i3)=vso_kphi(i1,i2,i3)*exp(0.5d0*(term1+term2+term3)*phase2)     
!        end do
!      end do
!    end do
subroutine volkov_split_timestep_rkr(iter)
implicit none
  integer   :: i,n,i1,i2,i3,iter
  complex*16 :: term1,term2,term3,phase2
  complex*16 :: phase_a3d(N_Lattice(1),N_Lattice(2),N_Lattice(3))
  !write(*,*) "call volkov_split_timestep_rkr step ",iter ! adddebug

  call PplusAsquared_AU(phase_a3d,iter)
  
  do n=1,N_orbitals
    Phi_c(:)=Psi_c(:,n)
   
	! 1/2 taylor expanded exponential of the potential 
	call taylor_expV_phi(n,0.5d0,1)
	
    call map_1dwf_to_3dwf_Len2Vel(Phi_c,vso_rphi,A_vec)
	call dfftw_execute_dft(plan_volkov_Forward,vso_rphi,vso_kphi)
	vso_kphi=vso_kphi*sqrt(fftfactor)

    vso_kphi=vso_kphi*exp(phase_a3d)

	call dfftw_execute_dft(plan_volkov_Backward,vso_kphi,vso_rphi)
    vso_rphi=vso_rphi*sqrt(fftfactor)
    call revmap_3dwf_to_1dwf_Vel2Len(vso_rphi,Phi_c,A_Vec_Tplusdt)
	
	! 1/2 taylor expanded exponential of the potential 
	call taylor_expV_phi(n,0.5d0,1)	

	Psi_c(:,n)=Phi_c(:)

!    do i=1,N_Lattice_points
!	  if(Psi_c(i,n)/=Psi_debug(i,n)) then
!	    write(log_file,'(i6,i3,i7,4es30.16e3)') iter,n,i,Psi_c(i,n),Psi_debug(i,n)
!	  end if
!	end do
	
!    Phi_c(:)=Psi_c(:,n)
!	call map_1dwf_to_3dwf_Len2Vel(Phi_c,vso_rphi)
!	call dfftw_execute_dft(plan_volkov_Forward,vso_rphi,vso_kphi)
!	vso_kphi=vso_kphi*sqrt(fftfactor)
!	
!	vso_kphi=vso_kphi*exp(phase_a3d*0.5d0) ! propagator in k space	
!	call dfftw_execute_dft(plan_volkov_Backward,vso_kphi,vso_rphi)
!    vso_rphi=vso_rphi*sqrt(fftfactor)
!	call revmap_3dwf_to_1dwf_Vel2Len(vso_rphi,Phi_c)
!	call taylor_expV_phi(n,1.d0,1)   ! propagator in real space
!	call map_1dwf_to_3dwf_Len2Vel(Phi_c,vso_rphi)
!	call dfftw_execute_dft(plan_volkov_Forward,vso_rphi,vso_kphi)
!	vso_kphi=vso_kphi*sqrt(fftfactor)
!	vso_kphi=vso_kphi*exp(phase_a3d*0.5d0) ! propagator in k space
!	
!	call dfftw_execute_dft(plan_volkov_Backward,vso_kphi,vso_rphi)
!	vso_rphi=vso_rphi*sqrt(fftfactor)
!	call revmap_3dwf_to_1dwf_Vel2Len(vso_rphi,Phi_c)
!	Psi_c(:,n)=Phi_c(:)
!	! test
!	call map_1dwf_to_3dwf_Len2Vel(Phi_c,vso_rphi)
!	call dfftw_execute_dft(plan_volkov_Forward,vso_rphi,vso_kphi)
!	vso_kphi=vso_kphi*sqrt(fftfactor)
!	call dfftw_execute_dft(plan_volkov_Backward,vso_kphi,vso_rphi)
!	vso_rphi=vso_rphi*sqrt(fftfactor)
!	call revmap_3dwf_to_1dwf_Vel2Len(vso_rphi,Phi_c)	
!    do i=1,N_Lattice_points
!	  if(Psi_c(i,n)/=Phi_c(i)) then
!	    write(log_file,'(a,i6,i3,i7,4es30.16e3)') "cdiff ",iter,n,i,Psi_c(i,n),Phi_c(i)
!	  end if
!	end do
!	write(log_file,'(a,i6,i3,es30.16e3)') "max_diff ",iter,n,maxval(abs(Psi_c(:,n)-Phi_c(:)))
  end do
  
  Psi_debug=Psi_c
end subroutine volkov_split_timestep_rkr

! debug test
!subroutine volkov_split_timestep_krk(iter)
!implicit none
!  integer   :: i,n,i1,i2,i3,iter
!  complex*16 :: term1,term2,term3,phase2
!  complex*16 :: phase_a3d(N_Lattice(1),N_Lattice(2),N_Lattice(3))
!  !write(*,*) "call volkov_split_timestep_rkr step ",iter ! adddebug
!
!  call PplusAsquared_AU(phase_a3d,iter)
!  
!  do n=1,N_orbitals
!!    Phi_c(:)=Psi_c(:,n)
!    
!!	! 1/2 taylor expanded exponential of the potential 
!!	call taylor_expV_phi(n,0.5d0,1)
!!	
!!    call map_1dwf_to_3dwf_Len2Vel(Phi_c,vso_rphi)
!!	call dfftw_execute_dft(plan_volkov_Forward,vso_rphi,vso_kphi)
!!	vso_kphi=vso_kphi*sqrt(fftfactor)
!!
!!    vso_kphi=vso_kphi*exp(phase_a3d)
!!
!!	call dfftw_execute_dft(plan_volkov_Backward,vso_kphi,vso_rphi)
!!    vso_rphi=vso_rphi*sqrt(fftfactor)
!!    call revmap_3dwf_to_1dwf_Vel2Len(vso_rphi,Phi_c)
!!	
!!	! 1/2 taylor expanded exponential of the potential 
!!	call taylor_expV_phi(n,0.5d0,1)	
!!
!!	Psi_c(:,n)=Phi_c(:)
!
!    Phi_c(:)=Psi_c(:,n)
!	call map_1dwf_to_3dwf_Len2Vel(Phi_c,vso_rphi)
!	call dfftw_execute_dft(plan_volkov_Forward,vso_rphi,vso_kphi)
!	vso_kphi=vso_kphi*sqrt(fftfactor)
!	do i3=1,N_Lattice(3)
!	  do i2=1,N_Lattice(2)
!	    do i1=1,N_Lattice(1)
!		  if(abs(vso_kphi(i1,i2,i3)-vso_kpsi(i1,i2,i3,n))>1.d-8) then
!		    write(log_file,'(i6,3i4,4es28.16e3)') iter,i1,i2,i3,vso_kphi(i1,i2,i3),vso_kpsi(i1,i2,i3,n)
!		  end if
!        end do
!      end do
!    end do
!	vso_kphi=vso_kphi*exp(phase_a3d*0.5d0)
!	call dfftw_execute_dft(plan_volkov_Backward,vso_kphi,vso_rphi)
!    vso_rphi=vso_rphi*sqrt(fftfactor)
!	call revmap_3dwf_to_1dwf_Vel2Len(vso_rphi,Phi_c)
!	call taylor_expV_phi(n,1.d0,1)
!	call map_1dwf_to_3dwf_Len2Vel(Phi_c,vso_rphi)
!	call dfftw_execute_dft(plan_volkov_Forward,vso_rphi,vso_kphi)
!	vso_kphi=vso_kphi*sqrt(fftfactor)
!	vso_kphi=vso_kphi*exp(phase_a3d*0.5d0)
!	vso_kpsi(:,:,:,n)=vso_kphi(:,:,:)
!	call dfftw_execute_dft(plan_volkov_Backward,vso_kphi,vso_rphi)
!	vso_rphi=vso_rphi*sqrt(fftfactor)
!	call revmap_3dwf_to_1dwf_Vel2Len(vso_rphi,Phi_c)
!	Psi_c(:,n)=Phi_c(:)	
!  end do
!
!end subroutine volkov_split_timestep_krk

subroutine volkov_split_imag_timestep_rkr(iter)
implicit none
  integer   :: i,n,i1,i2,i3,iter
  complex*16 :: term1,term2,term3,phase2
  real*8     :: normimagt

  phase2=-h2m*split_op_imag_ts/hbar
  
  do n=1,N_orbitals
    Phi_c(:)=Psi_c(:,n)

	! 1/2 taylor time step
	call taylor_imagtime_expV_phi(n,0.5d0,1)

	call map_1dwf_to_3dwf(Phi_c,vso_rphi)
	call dfftw_execute_dft(plan_volkov_Forward,vso_rphi,vso_kphi)
	vso_kphi=vso_kphi*sqrt(fftfactor)

	! full Dt in k space
	do i3=1,N_Lattice(3)
	  do i2=1,N_Lattice(2)
	    do i1=1,N_Lattice(1)
		  term1=(volkov_k_x(i1)**2+volkov_k_y(i2)**2+volkov_k_z(i3)**2)
          vso_kphi(i1,i2,i3)=vso_kphi(i1,i2,i3)*exp(term1*phase2)
        end do
      end do
    end do

	call dfftw_execute_dft(plan_volkov_Backward,vso_kphi,vso_rphi)
    vso_rphi=vso_rphi*sqrt(fftfactor)
    call revmap_3dwf_to_1dwf(vso_rphi,Phi_c)
	
	! 1/2 taylor time step
	call taylor_imagtime_expV_phi(n,0.5d0,1)	
	normimagt=sum(real(conjg(Phi_c)*Phi_c))*grid_volume
	!write(log_file,'(a,i3,a,f12.7,a)') "orb ",n," imag_time_norm=",normimagt," renormalize"
	Phi_c=Phi_c/sqrt(normimagt)
	Psi_c(:,n)=Phi_c(:)
  end do
  

end subroutine volkov_split_imag_timestep_rkr  


subroutine volkov_split_timestep_krkrkr(iter)
implicit none
  integer   :: i,n,i1,i2,i3,iter
  complex*16 :: phase_a3d(N_Lattice(1),N_Lattice(2),N_Lattice(3))
  
  !write(log_file,'(a,3f15.5)') "A(r)_AU ",A_vec

  call PplusAsquared_AU(phase_a3d,iter)
  
  do n=1,N_orbitals
	if(mod(iter,2)==0) then
	    !write(log_file,*) "Do krk step"
    	vso_kphi(:,:,:)=vso_kpsi(:,:,:,n)
        !write(log_file,*) n,sum(real(conjg(vso_kphi)*vso_kphi))*grid_volume
        vso_kphi=vso_kphi*exp(phase_a3d*0.5d0) ! propagator in k space	
    	call dfftw_execute_dft(plan_volkov_Backward,vso_kphi,vso_rphi)
        vso_rphi=vso_rphi*sqrt(fftfactor)
    	call revmap_3dwf_to_1dwf_Vel2Len(vso_rphi,Phi_c,A_vec)
    	call taylor_expV_phi(n,1.d0,1) ! propagator in real space
    	call map_1dwf_to_3dwf_Len2Vel(Phi_c,vso_rphi,A_Vec)
    	call dfftw_execute_dft(plan_volkov_Forward,vso_rphi,vso_kphi)
    	vso_kphi=vso_kphi*sqrt(fftfactor)
    	vso_kphi=vso_kphi*exp(phase_a3d*0.5d0) ! propagator in k space	
    	
    	vso_kpsi(:,:,:,n)=vso_kphi(:,:,:)
    
    	!map back to Psi_c to update potentials
    	call dfftw_execute_dft(plan_volkov_Backward,vso_kphi,vso_rphi)
    	vso_rphi=vso_rphi*sqrt(fftfactor)
    	call revmap_3dwf_to_1dwf_Vel2Len(vso_rphi,Phi_c,A_Vec_Tplusdt)
		!write(log_file,*) n,sum(real(conjg(Phi_c)*phi_c))*grid_volume
    	Psi_c(:,n)=Phi_c(:)
	else
	    !write(log_file,*) "Do rkr step"
        Phi_c(:)=Psi_c(:,n)
    	call taylor_expV_phi(n,0.5d0,1) ! 1/2 taylor expanded exponential of the potential 
        call map_1dwf_to_3dwf_Len2Vel(Phi_c,vso_rphi,A_vec)
    	call dfftw_execute_dft(plan_volkov_Forward,vso_rphi,vso_kphi)
    	vso_kphi=vso_kphi*sqrt(fftfactor)
        vso_kphi=vso_kphi*exp(phase_a3d)
    	call dfftw_execute_dft(plan_volkov_Backward,vso_kphi,vso_rphi)
        vso_rphi=vso_rphi*sqrt(fftfactor)
        call revmap_3dwf_to_1dwf_Vel2Len(vso_rphi,Phi_c,A_Vec_Tplusdt)
    	call taylor_expV_phi(n,0.5d0,1)	 ! 1/2 taylor expanded exponential of the potential 
    	Psi_c(:,n)=Phi_c(:)	
		! set up vso_kpsi 
		call map_1dwf_to_3dwf_Len2Vel(Phi_c,vso_rphi,A_vec_TplusdT)
		call dfftw_execute_dft(plan_volkov_Forward,vso_rphi,vso_kphi)
		vso_kphi=vso_kphi*sqrt(fftfactor)
		vso_kpsi(:,:,:,n)=vso_kphi(:,:,:)
	end if

  end do

end subroutine volkov_split_timestep_krkrkr


subroutine taylor_expV_phi(orb,scalef,smode)
implicit none
  integer :: n,orb,i,smode
  complex*16 :: taylor_coeff(N_taylor),scalef_c,tc_n,expVphi(N_Lattice_points)
  real*8     :: scalef
  !write(*,'(a,i4,a,f20.10)') "taylor_expV_phi for KS orb=",orb," scale_f=",scalef ! adddebug
  !scalef_c=scalef
  taylor_coeff=0.d0
  expVphi=0.d0
  do i=1,N_taylor
    taylor_coeff(i)=(-zi*scalef*time_step/hbar)**i
    do n=1,i
      taylor_coeff(i)=taylor_coeff(i)/dfloat(n)
    enddo
  enddo
  !write(log_file,*)'tc2',taylor_coeff
    phi_c2=phi_c
	do i=1,N_Lattice_points
	  expVphi(i)=phi_c(i)
	end do
	
    if(spin_polarized) then
      if(orb<N_orbitals_down+1) then
        spin_down=.TRUE.
        spin_up=.FALSE.
      else
        spin_up=.TRUE.
        spin_down=.FALSE.
      endif
    endif  
    do n=1,N_taylor
      if(smode==1) then
	    call V_wavefn_c_noLaser
	  else
	    write(log_file,*) "unrecognized mode for taylor_expV_phi(orb,scalef,smode)"
        stop
      end if
      do i=1,N_Lattice_points  
        Phi_c(i)=H_Phi_c(i)
      enddo
	  tc_n=taylor_coeff(n)
      do i=1,N_Lattice_points
        expVphi(i)=expVphi(i)+tc_n*Phi_c(i)
      enddo  
    enddo  
  !phi_c=expVphi
  do i=1,N_Lattice_points
    phi_c(i)=expVphi(i)
  end do
end subroutine taylor_expV_phi

subroutine taylor_expV_phi_pass(orb,scalef,smode,phi)
implicit none
  integer :: n,orb,i,smode
  complex*16 :: taylor_coeff(N_taylor),scalef_c,tc_n,expVphi(N_Lattice_points)
  complex*16,intent(inout) :: phi(N_Lattice_points)
  real*8     :: scalef
  write(*,'(a,i4,a,f20.10)') "taylor_expV_phi for KS orb=",orb," scale_f=",scalef ! adddebug
  !scalef_c=scalef
  !taylor_coeff=0.d0
  do i=1,N_taylor
    taylor_coeff(i)=(-zi*scalef*time_step/hbar)**i
    do n=1,i
      taylor_coeff(i)=taylor_coeff(i)/dfloat(n)
    enddo
  enddo
  !write(log_file,*)'tc2',taylor_coeff
    expVphi=phi
	
    if(spin_polarized) then
      if(orb<N_orbitals_down+1) then
        spin_down=.TRUE.
        spin_up=.FALSE.
      else
        spin_up=.TRUE.
        spin_down=.FALSE.
      endif
    endif  
    do n=1,N_taylor
      if(smode==1) then
	    call V_wavefn_c_noLaser_pass(phi) ! returns phi as Hphi
	  else
	    write(log_file,*) "unrecognized mode for taylor_expV_phi(orb,scalef,smode)"
        stop
      end if
	  tc_n=taylor_coeff(n)
      do i=1,N_Lattice_points
        expVphi(i)=expVphi(i)+tc_n*phi(i)
      enddo  
    enddo  
  phi=expVphi

end subroutine taylor_expV_phi_pass

subroutine taylor_imagtime_expV_phi(orb,scalef,smode)
implicit none
  real*8,intent(in)  :: scalef
  integer,intent(in) :: orb,smode
  integer :: n,i
  complex*16 :: expVphi(N_Lattice_points)
  !real*8     :: scalef,taylor_coeff(N_taylor),scalef_c,tc_n
  complex*16 :: taylor_coeff(N_taylor),scalef_c,tc_n
  
  scalef_c=scalef
  taylor_coeff=0.d0
  expVphi=0.d0
  do i=1,N_taylor
    taylor_coeff(i)=(-scalef_c*split_op_imag_ts/hbar)**i
    do n=1,i
      taylor_coeff(i)=taylor_coeff(i)/dfloat(n)
    enddo
  enddo
  !write(log_file,*)'tc2',taylor_coeff
    phi_c2=phi_c
	do i=1,N_Lattice_points
	  expVphi(i)=phi_c(i)
	end do
	
    if(spin_polarized) then
      if(orb<N_orbitals_down+1) then
        spin_down=.TRUE.
        spin_up=.FALSE.
      else
        spin_up=.TRUE.
        spin_down=.FALSE.
      endif
    endif  
    do n=1,N_taylor
      if(smode==1) then
	    call V_wavefn_c_noLaser
		!call V_wavefn_c_noLaser_noCAP
	  else
	    write(log_file,*) "unrecognized mode for taylor_expV_phi(orb,scalef,smode)"
        stop
      end if
      do i=1,N_Lattice_points  
        Phi_c(i)=H_Phi_c(i)
      enddo
	  tc_n=taylor_coeff(n)
      do i=1,N_Lattice_points
        expVphi(i)=expVphi(i)+tc_n*Phi_c(i)
      enddo  
    enddo  
  !phi_c=expVphi
  do i=1,N_Lattice_points
    phi_c(i)=expVphi(i)
  end do
end subroutine taylor_imagtime_expV_phi

subroutine split_op_energy_noA(iter,eneOUT)
implicit none
  integer,intent(in)  :: iter
  real*8,intent(out)  :: eneOUT
  integer   :: i,n,i1,i2,i3
  real*8     :: maxv1,eneKpart1,eneRSpart2,eneSPtot
  
  complex*16 :: term1
  
  eneKpart1=0.d0
  eneRSpart2=0.d0
  eneSPtot=0.d0
  
  do n=1,N_orbitals
    Phi_c(:)=Psi_c(:,n)
    if(propagator=="split_v_krk".or.propagator=="split_v_mix") then
      vso_kphi(:,:,:)=vso_kpsi(:,:,:,n)
	else
	  call map_1dwf_to_3dwf_Len2Vel(Phi_c,vso_rphi,A_vec)
	  call dfftw_execute_dft(plan_volkov_Forward,vso_rphi,vso_kphi)
	  vso_kphi=vso_kphi*sqrt(fftfactor)
	end if
	do i3=1,N_Lattice(3)
	  do i2=1,N_Lattice(2)
	    do i1=1,N_Lattice(1)
!		  term1=(volkov_k_x(i1)**2+volkov_k_y(i2)**2+volkov_k_z(i3)**2)
	      term1=(volkov_k_x(i1)**2+volkov_k_y(i2)**2+volkov_k_z(i3)**2)
		  eneKpart1=eneKpart1+real(term1*h2m*conjg(vso_kphi(i1,i2,i3))*vso_kphi(i1,i2,i3))
		  !eneKpart1=eneKpart1+real(term1*0.5*conjg(vso_kphi(i1,i2,i3))*vso_kphi(i1,i2,i3))
        end do
      end do
    end do
	eneKpart1=eneKpart1*grid_volume
	
	call V_wavefn_c_noLaser
	eneRSpart2=real(sum(conjg(Phi_c)*H_Phi_c))*grid_volume
	write(split_op_ene_file3,'(i4,f12.4,3es29.16e3)') n,time_step*iter,eneRSpart2+eneKpart1,eneRSpart2,eneKpart1
	eneSPtot=eneSPtot+Occupation(n)*(eneRSpart2+eneKpart1)	
  end do
  !write(log_file,'(a,es29.16e3)') "total_ene_sp_split_op= ",eneSPtot
  eneOUT=eneSPtot
end subroutine split_op_energy_noA

SUBROUTINE init_Volkov_mask
implicit none
  integer    :: i,l,j,k
  real*8     :: RA,RC,maskv1,fd_lat_max(3),arg1
  
  allocate(mask(N_lattice_points))
!  volkov_mask_grid=1.d0
!  
! fd_lat_max(1)=abs(xgrid(1))
! fd_lat_max(2)=abs(ygrid(1))
! fd_lat_max(3)=abs(zgrid(1))
! do l=1,N_lattice_points
!   
!   do i=1,3
!     RA=fd_lat_max(i)
!	 RC=fd_lat_max(i)-volkov_mask_depth
!     maskv1=1.d0
!	 if(grid_point(i,l)>RC) then
!       arg1=(grid_point(i,l)-RC)*3.1415926535897932384d0/(2*(RA-RC))
!	   maskv1=1.d0 - (sin(arg1)**2)
!	 else if (grid_point(i,l)<-RC) then
!       arg1=(grid_point(i,l)-RC)*3.1415926535897932384d0/(2*(RA-RC))
!	   maskv1=1.d0 - (sin(arg1)**2)	   
!	 !end if 
!	 !allow for x y z mask
!	 end if
!	 volkov_mask_grid(l)=volkov_mask_grid(l)*maskv1
!   end do
! end do  

   ! mask function
 write(log_file,*) 'Initialize Mask'  
  ! mask end and start, not bigger than max real space grid!
  !R_A(1)=abs(grid_point(1,1))!+grid_step(1)
  R_A(1)=abs(xgrid(1))
  R_C(1)=R_A(1)-volkov_mask_depth
 write(log_file,'(a,f10.3,a,f10.3)') 'Mask_X: Max RSG=',R_A(1),' Mask R_Cx=',R_C(1) 
  !R_A(2)=abs(grid_point(2,1))!+grid_step(2)
  R_A(2)=abs(ygrid(1))
  R_C(2)=R_A(2)-volkov_mask_depth
 write(log_file,'(a,f10.3,a,f10.3)') 'Mask_Y: Max RSG=',R_A(2),' Mask R_Cy=',R_C(2)  
  !R_A(3)=abs(grid_point(2,1))!+grid_step(2)
  R_A(3)=abs(zgrid(1))
  R_C(3)=R_A(3)-volkov_mask_depth
 write(log_file,'(a,f10.3,a,f10.3)') 'Mask_Z: Max RSG=',R_A(3),' Mask R_Cz=',R_C(3)  
  mask=0.d0
 do l=1,N_lattice_points
   do i=1,3
	 maskinit(i)=1.d0
     if(grid_point(i,l)>R_C(i)) then
         arg1=(grid_point(i,l)-R_C(i))*3.1415926535897932384d0/(2*(R_A(i)-R_C(i)))
	     maskinit(i)=1.d0 - (sin(arg1)**2)
	 else if (grid_point(i,l)<-R_C(i)) then
         arg1=(grid_point(i,l)+R_C(i))*3.1415926535897932384d0/(2*(R_A(i)-R_C(i)))
	     maskinit(i)=1.d0 - (sin(arg1)**2)	 
	 end if
	 
	 
   end do
   mask(l)=maskinit(1)*maskinit(2)*maskinit(3)
 end do
 open(3323,file="volkov_mask.dat",status="replace")
 do i=1,N_lattice_points
   write(3323,'(3f8.3,f15.8)') grid_point(1,i),grid_point(2,i),grid_point(3,i),mask(i)
 end do
 close(3323)
 write(log_file,*) "Mask stored in file volkov_mask.dat"
 open(3323,file="volkov_mask_xy.dat",status="replace")
 do i=1,N_Lattice(1)
   do j=1,N_Lattice(2)
     k=N_Lattice(3)/2
     write(3323,'(3f8.3,f15.8)') xgrid(i),ygrid(j),zgrid(k),mask(Lattice_inv_xyz(i,j,k))
   end do
 end do
 close(3323)
 write(log_file,*) "Mask stored in file volkov_mask.dat and volkov_mask_xy.dat"

 
END SUBROUTINE init_Volkov_mask

subroutine Avec_update(iter,opform)
implicit none
  real*8     :: eflaser(3),eflaser2(3)
  integer    :: i,iter,opform
  
  ! 1 = 51.4220652 V/A
  ! 1 = 2.418884326505(16)×10−17 s	= .02418884326505(16) fs	
  
  call laser_at_time_t(iter,1.d0,eflaser)
  call laser_at_time_t(iter+1,1.d0,eflaser2)
  do i=1,3
    !  A_vec = - int[E*dt]
    ! BUT... the way the laser field is defined in this code, the sign is positive instead of negative???
    A_vec(i)=A_vec(i)-eflaser(i)*time_step*convertT2AU*convertE2AU
    A_vec_int(i)=A_vec_int(i)+A_vec(i)*time_step*convertT2AU        
    A_vec_2_int(i)=A_vec_2_int(i)+A_vec(i)**2*time_step*convertT2AU
	if(iter==1) A_vec_TplusdT(i)=A_Vec(i)
	A_vec_TplusdT(i)=A_vec_TplusdT(i)-eflaser2(i)*time_step*convertT2AU*convertE2AU
  end do
  write(avec_file,'(f10.4,3es10.2e2,3es10.2e2)') iter*time_step,A_vec,eflaser
  if(MPI_master) then
    if(opform==1) write(log_file,'(a,f10.4,6es10.2e2)') "Avec_Evec ",iter*time_step,A_vec,eflaser
  end if
end subroutine Avec_update


subroutine mask_volkov_time_step(it)
implicit none
  integer     :: it,i,j,k1,k2,k3,ind,special_file_number
  complex*16  :: swap1,swap2,pdiff
  real*8      :: phase1,vnorm1,vnorm2,vnumele1,mvalue,getdp,tdiff
  real*8      :: VDPMx,VDPMy,VDPMz,VDPall(3,N_orbitals),correct_sign
  character(255) :: fnameVDC
  character(7)   :: ch7
  complex*16,allocatable  ::  pes_add(:,:,:)
  
  ! FFTW is best at handling sizes of the form 2^a3^b5^c7^d11^e13^f
  ! , where e+f is either 0 or 1, and the other exponents are arbitrary
  
  vnumele1=0.d0
  swap1=0.d0
  swap2=0.d0
  phase1=0.d0
  getdp=0.d0
  
  if(volkov_save_dens.AND.(mod(it,volkov_save_dens_freq)==0)) then
	sing_prec_rearranged_dvolkov=0.d0
  end if
  
  if(maskV_save_PES) then
    allocate(pes_add(N_Volk(1),N_Volk(2),N_Volk(3)))
    pes_add=0.d0
  end if
  do i=1,3
	  DeltaA(i)=A_vec_int(i)-A_vec_int_prev(i)
	  DeltaA2(i)=A_vec_2_int(i)-A_vec_2_int_prev(i)	
  end do
  if(MPI_master) write(log_file,'(a,i7,f16.8)') ' VOLKOV:',it,it*time_step
  if(MPI_master) write(log_file,'(a,3f12.7)') ' VOLKOV: deltaA=',DeltaA(1:3)
  ! apply propagator
  correct_sign=1.d0
  do i=1,N_orbitals
    if(MPItask_orbital_map(i)/=MPI_proc_rank) CYCLE ! skip if orbital is not done on this process
    !Phi_Volkov2=Psi_volkov(:,:,:,i)
    do k3=1,N_Volk(3)
      do k2=1,N_Volk(2)
        do k1=1,N_Volk(1)
		! units !  time==fs  k==1/Angstrom  DeltaA==V*fs/Angstrom
          phase1=(vtimestep*convertT2AU*(volkov_k_x(k1)**2 + volkov_k_y(k2)**2 + volkov_k_z(k3)**2 ))
          phase1=phase1+(2.d0*volkov_k_x(k1)*DeltaA(1))*correct_sign
  		  phase1=phase1+(2.d0*volkov_k_y(k2)*DeltaA(2))*correct_sign
  		  phase1=phase1+(2.d0*volkov_k_z(k3)*DeltaA(3))*correct_sign
  		  phase1=phase1+DeltaA2(1)+DeltaA2(2)+DeltaA2(3)
     	  Psi_Volkov(k1,k2,k3,i)=Psi_Volkov(k1,k2,k3,i)*exp(-zi*0.5d0*phase1)
        end do
      end do
    end do
	Phi_Volkov2(:,:,:)=Psi_Volkov(:,:,:,i) ! needed for subtraction later... used in PES

	Phi_Volkov=0.d0
	call dfftw_execute_dft(plan_volkov_Backward,Phi_Volkov2,Phi_Volkov)
	Phi_Volkov=Phi_Volkov*Vsqrtfftf
	! absorb wave function at boundary

    do k3=1,N_Volk(3)
      do k2=1,N_Volk(2)
        do k1=1,N_Volk(1)
     	  Phi_Volkov2(k1,k2,k3)=Phi_Volkov(k1,k2,k3)*volkov_abs_x(k1)*volkov_abs_y(k2)*volkov_abs_z(k3)
		end do
      end do
    end do
	
	if(maskV_save_PES) pes_add=Phi_volkov2
	
	! length gauge  
    do k3=1,N_Volk(3)
      do k2=1,N_Volk(2)
        do k1=1,N_Volk(1)
		  phase1=A_Vec(1)*volkov_grid_x(k1)
		  phase1=phase1+ A_Vec(2)*volkov_grid_y(k2)
		  phase1=phase1+ A_Vec(3)*volkov_grid_z(k3)
     	  Phi_Volkov2(k1,k2,k3)=Phi_Volkov2(k1,k2,k3)*exp(zi*phase1)
		end do
      end do
    end do	
	Phi_Volkov=Phi_Volkov2
    VDPMx=0.d0
	VDPMy=0.d0
	VDPMz=0.d0

	! mask
	vnorm1=0.d0
	vnorm2=0.d0
	do j=1,N_lattice_points
	  mvalue=mask(j)
	  swap1=mvalue*Psi_c(j,i)+ mvalue*Phi_Volkov(fd_volkov_mapping3(1,j),fd_volkov_mapping3(2,j),fd_volkov_mapping3(3,j))
	  mvalue=1.d0-mask(j)
	  swap2=mvalue*Psi_c(j,i)+ mvalue*Phi_Volkov(fd_volkov_mapping3(1,j),fd_volkov_mapping3(2,j),fd_volkov_mapping3(3,j))
	  Psi_c(j,i)=swap1
	  Phi_Volkov2(fd_volkov_mapping3(1,j),fd_volkov_mapping3(2,j),fd_volkov_mapping3(3,j))=swap2
	  vnorm1=vnorm1+real(conjg(swap1)*swap1)
	  vnorm1=vnorm1+2*real(conjg(swap1)*swap2)
	  VDPMx=VDPMx+real(conjg(swap1)*grid_point(1,j)*swap1)
	  VDPMx=VDPMx+2*real(conjg(swap1)*grid_point(1,j)*swap2)
	  VDPMy=VDPMy+real(conjg(swap1)*grid_point(2,j)*swap1)
	  VDPMy=VDPMy+2*real(conjg(swap1)*grid_point(2,j)*swap2)
	  VDPMz=VDPMz+real(conjg(swap1)*grid_point(3,j)*swap1)
	  VDPMz=VDPMz+2*real(conjg(swap1)*grid_point(3,j)*swap2)
	end do

	! save density if desired 

	if(volkov_save_dens.AND.(mod(it,volkov_save_dens_freq)==0)) then
      ind=0
      do k3=1,N_Volk(3)
        do k2=1,N_Volk(2)
          do k1=1,N_Volk(1)
            ind=ind+1
			getdp=0.d0
			getdp=conjg(Phi_Volkov2(k1,k2,k3))*Phi_Volkov2(k1,k2,k3)
            if (bw_volkov_mapping(k1,k2,k3)>0) then
			  getdp=getdp+ &
			    conjg(Psi_c(bw_volkov_mapping(k1,k2,k3),i))*Psi_c(bw_volkov_mapping(k1,k2,k3),i)
			  getdp=getdp+ &
			    2.d0*real(conjg(Phi_Volkov2(k1,k2,k3))*Psi_c(bw_volkov_mapping(k1,k2,k3),i))
			end if
			sing_prec_rearranged_dvolkov(ind)=sing_prec_rearranged_dvolkov(ind)+getdp		
          enddo
        enddo
      enddo	  
	end if
	Phi_Volkov=0.d0
	! velocity gauge
    do k3=1,N_Volk(3)
      do k2=1,N_Volk(2)
        do k1=1,N_Volk(1)
		  VDPMx=VDPMx+real(conjg(Phi_Volkov2(k1,k2,k3))*volkov_grid_x(k1)*Phi_Volkov2(k1,k2,k3))
		  VDPMy=VDPMy+real(conjg(Phi_Volkov2(k1,k2,k3))*volkov_grid_y(k2)*Phi_Volkov2(k1,k2,k3))
		  VDPMz=VDPMz+real(conjg(Phi_Volkov2(k1,k2,k3))*volkov_grid_z(k3)*Phi_Volkov2(k1,k2,k3))
		  vnorm2=vnorm2+conjg(Phi_Volkov2(k1,k2,k3))*Phi_Volkov2(k1,k2,k3)
		  phase1=A_Vec(1)*volkov_grid_x(k1)
		  phase1=phase1+ A_Vec(2)*volkov_grid_y(k2)
		  phase1=phase1+ A_Vec(3)*volkov_grid_z(k3)
     	  Phi_Volkov(k1,k2,k3)=Phi_Volkov2(k1,k2,k3)*exp(-zi*phase1)            		  
        end do
      end do
    end do
	! normalization 
	vnorm1=vnorm1*grid_volume
	vnorm2=vnorm2*grid_volume
	vnumele1=vnumele1+vnorm1+vnorm2
	!write(log_file,'(a,i4,a,f18.12,a,f18.12)') ' VOLKOV: orbital',i,' normV=',vnorm2,' normTOT=',vnorm1+vnorm2	
	
	! save dipole moment for each orbital  VDPall(3,N_orbitals)
	VDPall(1,i)=VDPMx*grid_volume
	VDPall(2,i)=VDPMy*grid_volume
	VDPall(3,i)=VDPMz*grid_volume
	
	if(maskV_save_PES) then
	  pes_add=Phi_volkov-pes_add ! get difference. what mask function changed
	  call dfftw_execute_dft(plan_volkov_Forward,pes_add,pes_add)
	  pes_add=pes_add*Vsqrtfftf	  
	  tdiff=(n_time_steps-it)*time_step*convertT2AU
	  write(log_file,*) "maxval PES_ADD=",maxval(abs(pes_add(:,:,:)))
	  do k3=1,N_Volk(3)
        do k2=1,N_Volk(2)
          do k1=1,N_Volk(1)
			phase1=(tdiff*(volkov_k_x(k1)**2 + volkov_k_y(k2)**2 + volkov_k_z(k3)**2 ))
            phase1=phase1+(2.d0*volkov_k_x(k1)*(Afinal_int(1)-A_vec_int(1)))*correct_sign
  		    phase1=phase1+(2.d0*volkov_k_y(k2)*(Afinal_int(2)-A_vec_int(2)))*correct_sign
  		    phase1=phase1+(2.d0*volkov_k_z(k3)*(Afinal_int(3)-A_vec_int(3)))*correct_sign
  		    phase1=phase1+(Afinal_2_int(1)-A_vec_2_int(1))
			phase1=phase1+(Afinal_2_int(2)-A_vec_2_int(2))
			phase1=phase1+(Afinal_2_int(3)-A_vec_2_int(3))
		    maskV_mom_final(k1,k2,k3,i)=maskV_mom_final(k1,k2,k3,i)&
			 +pes_add(k1,k2,k3)*exp(-zi*0.5d0*phase1)
		    if(maskV_save_multi_PES) maskV_mom_multi(k1,k2,k3,i)=maskV_mom_multi(k1,k2,k3,i)&
			 +pes_add(k1,k2,k3)*exp(-zi*0.5d0*phase1)
          end do
        end do
      end do
      !write(log_file,'(a,i4,a,es20.10e3)') "maxval maskV_mom_final orb num ",i," = ",maxval(abs(maskV_mom_final(:,:,:,i)))
	end if
	Phi_Volkov2=0.d0
	call dfftw_execute_dft(plan_volkov_Forward,Phi_Volkov,Phi_Volkov2)
	Phi_Volkov2=Phi_Volkov2*Vsqrtfftf
	
	Psi_volkov(:,:,:,i)= Phi_Volkov2(:,:,:)

    ! save density total
	special_file_number=220000+i
	write(special_file_number,'(f10.5,3es26.16)') it*time_step,vnumele1,vnorm1,vnorm2
    ! write dipole moment to file
	special_file_number=330000+i
    write(special_file_number,'(f10.5,3es26.16)') it*time_step,VDPall(1:3,i)

  end do
  A_vec_int_prev=A_vec_int
  A_vec_2_int_prev=A_vec_2_int
  
  if(volkov_save_dens.AND.(mod(it,volkov_save_dens_freq)==0)) then
	call output_td_density_volkov_MPI(it)
  end if

end subroutine mask_volkov_time_step

! cody
SUBROUTINE output_td_density_volkov_MPI(iter)
!This subroutine saves electron density of volkov as bov format
integer :: iter,td_volkov_density_file
integer :: i,j,k,ind,pl,fnl,dk1,dk2,dk3,k1min,k2min,k3min,k1max,k2max,k3max
character(255) :: fname1,fname2
character(5)   :: ch5
character(16)  :: str1,str2,str3
real*4         :: sing_prec_rearranged_dvolkov2(volkov_N_points)

  call MPI_Reduce(sing_prec_rearranged_dvolkov,sing_prec_rearranged_dvolkov2, &
  & volkov_N_points,MPI_REAL,MPI_SUM,0,taylor_time_communicator,MPI_ierror)

if(MPI_master) then
  td_volkov_density_file=3323
  !k1min=N_Lattice_min(1)
  !k1max=N_Lattice_max(1)
  !k2min=N_Lattice_min(2)
  !k2max=N_Lattice_max(2)
  !k3min=N_Lattice_min(3)
  !k3max=N_Lattice_max(3)
  k1min=1
  k1max=N_Volk(1)
  k2min=1
  k2max=N_Volk(2)
  k3min=1
  k3max=N_Volk(3)
  
  dk1=(k1max-k1min+1)
  dk2=(k2max-k2min+1)
  dk3=(k3max-k3min+1)
  
  !Bov format (bricks of data) which can easily be read by VisIt software.
  !It is fast and reasonable in terms of disk space. Works only in the
  !case of rectangular box
      write(ch5,'(i5.5)') td_density_counter_volkov
      write(fname1,'(a,a,a,a)') 'volkov_dens',ch5(1:5),'.dat'
      write(fname2,'(a,a,a,a)') 'volkov_dens',ch5(1:5),'.bov'
      fnl=len_trim(fname1)
      !First write the density into a data file, which is of binary form.
      !Note that the density data is rearranged as z,y,x --> x,y,z (C-like
      !storage of array elements)  and converted to single precision before
      !saving it to disk (single precision is used to reduce disk usage).
      !Rearrangement must be done using an auxiliary array
      !(called sing_prec_rearranged_dvolkov) because the data cannot be
      !simply written into the binary file by making an appropriate do-loop
      !(writing an entire array at once and writing it step-by-step gives
      !different result in fortran when it is a binary file).
      open(td_volkov_density_file,file=fname1,form='unformatted',status='replace')
      write(td_volkov_density_file) sing_prec_rearranged_dvolkov
      close(td_volkov_density_file)
      !Now create a header file corresponding to the above datafile. The header file
      !is in ascii text form
      open(td_volkov_density_file,file=fname2,status='replace')
      write(td_volkov_density_file,'(1x,a,1x,es23.15)') 'TIME:',iter*time_step
      write(td_volkov_density_file,'(1x,a,1x,a)') 'DATA_FILE:',fname1(1:fnl)
      write(td_volkov_density_file,'(1x,a,3(1x,i6))') 'DATA_SIZE:',dk1,dk2,dk3
      write(td_volkov_density_file,'(1x,a)') 'DATA_FORMAT:  FLOAT'
      write(td_volkov_density_file,'(1x,a)') 'VARIABLE:  density'
      write(td_volkov_density_file,'(1x,a)') 'DATA_ENDIAN:  LITTLE'
      write(td_volkov_density_file,'(1x,a)') 'CENTERING:  zonal'
      write(td_volkov_density_file,'(1x,a,3(1x,es23.15))') 'BRICK_ORIGIN:',&
  	  volkov_grid_x(k1min),volkov_grid_y(k2min),volkov_grid_z(k3min)
      write(td_volkov_density_file,'(1x,a,3(1x,es23.15))') 'BRICK_SIZE:', &
          volkov_grid_x(k1max)-volkov_grid_x(k1min),volkov_grid_y(k2max)-volkov_grid_y(k2min)&
  		,volkov_grid_z(k3max)-volkov_grid_z(k3min)
      write(td_volkov_density_file,'(1x,a)') 'BYTE_OFFSET: 4'
      close(td_volkov_density_file)
  
  td_density_counter_volkov=td_density_counter_volkov+1
end if

END SUBROUTINE output_td_density_volkov_MPI

! cody
SUBROUTINE maskV_save_PES_bovANDtxt(iter)
!This subroutine saves PES volkov as bov and txt format
integer :: iter,td_volkov_density_file
integer :: i,j,k,ind,pl,fnl,dk1,dk2,dk3,k1min,k2min,k3min,k1max,k2max,k3max
character(255) :: fname1,fname2
character(5)   :: ch5
character(16)  :: str1,str2,str3
integer        :: kmin(3),kmax(3),k1,k2,k3,orb
td_volkov_density_file=3323
k1min=1
k1max=N_Volk(1)
k2min=1
k2max=N_Volk(2)
k3min=1
k3max=N_Volk(3)

dk1=(k1max-k1min+1)
dk2=(k2max-k2min+1)
dk3=(k3max-k3min+1)
kmin=1 ! 1st component should be 0, guaranteed not the smallest
kmax=1 ! 1st component should be 0, guaranteed not the largest
! get min and max kvec indecies
do i=1,N_Volk(1)
  if(volkov_k_x(i)<volkov_k_x(kmin(1))) kmin(1)=i
  if(volkov_k_x(i)>volkov_k_x(kmax(1))) kmax(1)=i
end do
do i=1,N_Volk(2)
  if(volkov_k_y(i)<volkov_k_y(kmin(2))) kmin(2)=i
  if(volkov_k_y(i)>volkov_k_y(kmax(2))) kmax(2)=i
end do
do i=1,N_Volk(3)
  if(volkov_k_z(i)<volkov_k_z(kmin(3))) kmin(3)=i
  if(volkov_k_z(i)>volkov_k_z(kmax(3))) kmax(3)=i
end do
write(log_file,'(a,2i7)') "save PES max/min ind x", kmax(1),kmin(1)
write(log_file,'(a,2i7)') "save PES max/min ind y", kmax(2),kmin(2)
write(log_file,'(a,2i7)') "save PES max/min ind z", kmax(3),kmin(3)

    sing_prec_rearranged_dvolkov=0.d0
	
    do orb=1,N_orbitals
	  ind=0
      do k3=kmin(3),N_Volk(3)
        do k2=kmin(2),N_Volk(2)
          do k1=kmin(1),N_Volk(1)
            ind=ind+1
			sing_prec_rearranged_dvolkov(ind)=sing_prec_rearranged_dvolkov(ind)+abs(maskV_mom_final(k1,k2,k3,orb))**2
		  end do
          do k1=1,kmax(1)
             ind=ind+1
			 sing_prec_rearranged_dvolkov(ind)=sing_prec_rearranged_dvolkov(ind)+abs(maskV_mom_final(k1,k2,k3,orb))**2           
		  end do
		end do
		do k2=1,kmax(2)
          do k1=kmin(1),N_Volk(1)
            ind=ind+1
			sing_prec_rearranged_dvolkov(ind)=sing_prec_rearranged_dvolkov(ind)+abs(maskV_mom_final(k1,k2,k3,orb))**2
		  end do
          do k1=1,kmax(1)
             ind=ind+1
			 sing_prec_rearranged_dvolkov(ind)=sing_prec_rearranged_dvolkov(ind)+abs(maskV_mom_final(k1,k2,k3,orb))**2           
		  end do		
		end do
	  end do
      do k3=1,kmax(3)
        do k2=kmin(2),N_Volk(2)
          do k1=kmin(1),N_Volk(1)
            ind=ind+1
			sing_prec_rearranged_dvolkov(ind)=sing_prec_rearranged_dvolkov(ind)+abs(maskV_mom_final(k1,k2,k3,orb))**2
		  end do
          do k1=1,kmax(1)
             ind=ind+1
			 sing_prec_rearranged_dvolkov(ind)=sing_prec_rearranged_dvolkov(ind)+abs(maskV_mom_final(k1,k2,k3,orb))**2           
		  end do
		end do
		do k2=1,kmax(2)
          do k1=kmin(1),N_Volk(1)
            ind=ind+1
			sing_prec_rearranged_dvolkov(ind)=sing_prec_rearranged_dvolkov(ind)+abs(maskV_mom_final(k1,k2,k3,orb))**2
		  end do
          do k1=1,kmax(1)
             ind=ind+1
			 sing_prec_rearranged_dvolkov(ind)=sing_prec_rearranged_dvolkov(ind)+abs(maskV_mom_final(k1,k2,k3,orb))**2           
		  end do		
		end do
	  end do	  
	end do
    write(fname1,'(a)') 'photoelectron_momenta.dat'
    write(fname2,'(a)') 'photoelectron_momenta.bov'
    fnl=len_trim(fname1)
    open(td_volkov_density_file,file=fname1,form='unformatted',status='replace')
    write(td_volkov_density_file) sing_prec_rearranged_dvolkov
    close(td_volkov_density_file)
    open(td_volkov_density_file,file=fname2,status='replace')
    write(td_volkov_density_file,'(1x,a,1x,es23.15)') 'TIME:',iter*time_step
    write(td_volkov_density_file,'(1x,a,1x,a)') 'DATA_FILE:',fname1(1:fnl)
    write(td_volkov_density_file,'(1x,a,3(1x,i6))') 'DATA_SIZE:',dk1,dk2,dk3
    write(td_volkov_density_file,'(1x,a)') 'DATA_FORMAT:  FLOAT'
    write(td_volkov_density_file,'(1x,a)') 'VARIABLE:  density'
    write(td_volkov_density_file,'(1x,a)') 'DATA_ENDIAN:  LITTLE'
    write(td_volkov_density_file,'(1x,a)') 'CENTERING:  zonal'
    write(td_volkov_density_file,'(1x,a,3(1x,es23.15))') 'BRICK_ORIGIN:',&
	  volkov_k_x(kmin(1)),volkov_k_y(kmin(2)),volkov_k_z(kmin(3))
    write(td_volkov_density_file,'(1x,a,3(1x,es23.15))') 'BRICK_SIZE:', &
        volkov_k_x(kmax(1))-volkov_k_x(kmin(1)),volkov_k_y(kmax(2))-volkov_k_y(kmin(2)),&
		volkov_k_z(kmax(3))-volkov_k_z(kmin(3))
    write(td_volkov_density_file,'(1x,a)') 'BYTE_OFFSET: 4'
    close(td_volkov_density_file)

	open(td_volkov_density_file,file="mask_grid_point.txt",status='replace')
	write(td_volkov_density_file,'(i7)') N_Volk(1)
	write(td_volkov_density_file,'(i7)') N_Volk(2)
	write(td_volkov_density_file,'(i7)') N_Volk(3)
	close(td_volkov_density_file)
	
	! output text form
!    write(fname1,'(a)') 'photoelectron_momenta.txt'
!    open(td_volkov_density_file,file=trim(adjustl(fname1)),status='replace')	
!	do k3=1,N_Volk(3)
!      do k2=1,N_Volk(2)
!        do k1=1,N_Volk(1)
!		  write(td_volkov_density_file,'(3es14.5e2,es14.4e3)') volkov_k_x(k1),volkov_k_y(k2),volkov_k_z(k3),sum(abs(maskV_mom_final(k1,k2,k3,1:N_orbitals))**2)
!	    end do
!	  end do
!	end do
!	close(td_volkov_density_file)
	
END SUBROUTINE maskV_save_PES_bovANDtxt



! cody
SUBROUTINE maskV_save_PES_bov_orb(iter)
!This subroutine saves PES volkov as bov and txt format
integer :: iter,td_volkov_density_file
integer :: i,j,k,ind,pl,fnl,dk1,dk2,dk3,k1min,k2min,k3min,k1max,k2max,k3max
character(255) :: fname1,fname2
character(5)   :: ch5
character(3)   :: ch3
character(16)  :: str1,str2,str3
integer        :: kmin(3),kmax(3),k1,k2,k3,orb
td_volkov_density_file=3323
k1min=1
k1max=N_Volk(1)
k2min=1
k2max=N_Volk(2)
k3min=1
k3max=N_Volk(3)

dk1=(k1max-k1min+1)
dk2=(k2max-k2min+1)
dk3=(k3max-k3min+1)
kmin=1 ! 1st component should be 0, guaranteed not the smallest
kmax=1 ! 1st component should be 0, guaranteed not the largest
! get min and max kvec indecies
do i=1,N_Volk(1)
  if(volkov_k_x(i)<volkov_k_x(kmin(1))) kmin(1)=i
  if(volkov_k_x(i)>volkov_k_x(kmax(1))) kmax(1)=i
end do
do i=1,N_Volk(2)
  if(volkov_k_y(i)<volkov_k_y(kmin(2))) kmin(2)=i
  if(volkov_k_y(i)>volkov_k_y(kmax(2))) kmax(2)=i
end do
do i=1,N_Volk(3)
  if(volkov_k_z(i)<volkov_k_z(kmin(3))) kmin(3)=i
  if(volkov_k_z(i)>volkov_k_z(kmax(3))) kmax(3)=i
end do
write(log_file,'(a,2i7)') "save PES max/min ind x", kmax(1),kmin(1)
write(log_file,'(a,2i7)') "save PES max/min ind y", kmax(2),kmin(2)
write(log_file,'(a,2i7)') "save PES max/min ind z", kmax(3),kmin(3)

    
	
  do orb=1,N_orbitals
      sing_prec_rearranged_dvolkov=0.d0
	  ind=0
      do k3=kmin(3),N_Volk(3)
        do k2=kmin(2),N_Volk(2)
          do k1=kmin(1),N_Volk(1)
            ind=ind+1
			sing_prec_rearranged_dvolkov(ind)=sing_prec_rearranged_dvolkov(ind)+abs(maskV_mom_final(k1,k2,k3,orb))**2
		  end do
          do k1=1,kmax(1)
             ind=ind+1
			 sing_prec_rearranged_dvolkov(ind)=sing_prec_rearranged_dvolkov(ind)+abs(maskV_mom_final(k1,k2,k3,orb))**2           
		  end do
		end do
		do k2=1,kmax(2)
          do k1=kmin(1),N_Volk(1)
            ind=ind+1
			sing_prec_rearranged_dvolkov(ind)=sing_prec_rearranged_dvolkov(ind)+abs(maskV_mom_final(k1,k2,k3,orb))**2
		  end do
          do k1=1,kmax(1)
             ind=ind+1
			 sing_prec_rearranged_dvolkov(ind)=sing_prec_rearranged_dvolkov(ind)+abs(maskV_mom_final(k1,k2,k3,orb))**2           
		  end do		
		end do
	  end do
      do k3=1,kmax(3)
        do k2=kmin(2),N_Volk(2)
          do k1=kmin(1),N_Volk(1)
            ind=ind+1
			sing_prec_rearranged_dvolkov(ind)=sing_prec_rearranged_dvolkov(ind)+abs(maskV_mom_final(k1,k2,k3,orb))**2
		  end do
          do k1=1,kmax(1)
             ind=ind+1
			 sing_prec_rearranged_dvolkov(ind)=sing_prec_rearranged_dvolkov(ind)+abs(maskV_mom_final(k1,k2,k3,orb))**2           
		  end do
		end do
		do k2=1,kmax(2)
          do k1=kmin(1),N_Volk(1)
            ind=ind+1
			sing_prec_rearranged_dvolkov(ind)=sing_prec_rearranged_dvolkov(ind)+abs(maskV_mom_final(k1,k2,k3,orb))**2
		  end do
          do k1=1,kmax(1)
             ind=ind+1
			 sing_prec_rearranged_dvolkov(ind)=sing_prec_rearranged_dvolkov(ind)+abs(maskV_mom_final(k1,k2,k3,orb))**2           
		  end do		
		end do
	  end do	  
	
	write(ch3,'(i3.3)') orb
    write(fname1,'(a,a,a)') 'photoelectron_momenta_orb',ch3,'.dat'
    write(fname2,'(a,a,a)') 'photoelectron_momenta_orb',ch3,'.bov'
    fnl=len_trim(fname1)
    open(td_volkov_density_file,file=fname1,form='unformatted',status='replace')
    write(td_volkov_density_file) sing_prec_rearranged_dvolkov
    close(td_volkov_density_file)
    open(td_volkov_density_file,file=fname2,status='replace')
    write(td_volkov_density_file,'(1x,a,1x,es23.15)') 'TIME:',iter*time_step
    write(td_volkov_density_file,'(1x,a,1x,a)') 'DATA_FILE:',fname1(1:fnl)
    write(td_volkov_density_file,'(1x,a,3(1x,i6))') 'DATA_SIZE:',dk1,dk2,dk3
    write(td_volkov_density_file,'(1x,a)') 'DATA_FORMAT:  FLOAT'
    write(td_volkov_density_file,'(1x,a)') 'VARIABLE:  density'
    write(td_volkov_density_file,'(1x,a)') 'DATA_ENDIAN:  LITTLE'
    write(td_volkov_density_file,'(1x,a)') 'CENTERING:  zonal'
    write(td_volkov_density_file,'(1x,a,3(1x,es23.15))') 'BRICK_ORIGIN:',&
	  volkov_k_x(kmin(1)),volkov_k_y(kmin(2)),volkov_k_z(kmin(3))
    write(td_volkov_density_file,'(1x,a,3(1x,es23.15))') 'BRICK_SIZE:', &
        volkov_k_x(kmax(1))-volkov_k_x(kmin(1)),volkov_k_y(kmax(2))-volkov_k_y(kmin(2)),&
		  volkov_k_z(kmax(3))-volkov_k_z(kmin(3))
    write(td_volkov_density_file,'(1x,a)') 'BYTE_OFFSET: 4'
    close(td_volkov_density_file)
	
  end do
	
END SUBROUTINE maskV_save_PES_bov_orb




SUBROUTINE maskV_save_multi_PES_bovANDtxt(iter)
!This subroutine saves PES volkov as bov and txt format
integer :: iter,td_volkov_density_file
integer :: i,j,k,ind,pl,fnl,dk1,dk2,dk3,k1min,k2min,k3min,k1max,k2max,k3max
character(255) :: fname1,fname2
character(5)   :: ch5
character(16)  :: str1,str2,str3
integer        :: kmin(3),kmax(3),k1,k2,k3,orb
td_volkov_density_file=3323
k1min=1
k1max=N_Volk(1)
k2min=1
k2max=N_Volk(2)
k3min=1
k3max=N_Volk(3)

dk1=(k1max-k1min+1)
dk2=(k2max-k2min+1)
dk3=(k3max-k3min+1)
kmin=1 ! 1st component should be 0, guaranteed not the smallest
kmax=1 ! 1st component should be 0, guaranteed not the largest
! get min and max kvec indecies
do i=1,N_Volk(1)
  if(volkov_k_x(i)<volkov_k_x(kmin(1))) kmin(1)=i
  if(volkov_k_x(i)>volkov_k_x(kmax(1))) kmax(1)=i
end do
do i=1,N_Volk(2)
  if(volkov_k_y(i)<volkov_k_y(kmin(2))) kmin(2)=i
  if(volkov_k_y(i)>volkov_k_y(kmax(2))) kmax(2)=i
end do
do i=1,N_Volk(3)
  if(volkov_k_z(i)<volkov_k_z(kmin(3))) kmin(3)=i
  if(volkov_k_z(i)>volkov_k_z(kmax(3))) kmax(3)=i
end do
write(log_file,'(a,2i7)') "save PES max/min ind x", kmax(1),kmin(1)
write(log_file,'(a,2i7)') "save PES max/min ind y", kmax(2),kmin(2)
write(log_file,'(a,2i7)') "save PES max/min ind z", kmax(3),kmin(3)

  if(maskv_save_multi_PES_full) then
    sing_prec_rearranged_dvolkov=0.d0
	
    do orb=1,N_orbitals
	  ind=0
      do k3=kmin(3),N_Volk(3)
        do k2=kmin(2),N_Volk(2)
          do k1=kmin(1),N_Volk(1)
            ind=ind+1
			sing_prec_rearranged_dvolkov(ind)=sing_prec_rearranged_dvolkov(ind)+abs(maskV_mom_multi(k1,k2,k3,orb))**2
		  end do
          do k1=1,kmax(1)
             ind=ind+1
			 sing_prec_rearranged_dvolkov(ind)=sing_prec_rearranged_dvolkov(ind)+abs(maskV_mom_multi(k1,k2,k3,orb))**2           
		  end do
		end do
		do k2=1,kmax(2)
          do k1=kmin(1),N_Volk(1)
            ind=ind+1
			sing_prec_rearranged_dvolkov(ind)=sing_prec_rearranged_dvolkov(ind)+abs(maskV_mom_multi(k1,k2,k3,orb))**2
		  end do
          do k1=1,kmax(1)
             ind=ind+1
			 sing_prec_rearranged_dvolkov(ind)=sing_prec_rearranged_dvolkov(ind)+abs(maskV_mom_multi(k1,k2,k3,orb))**2           
		  end do		
		end do
	  end do
      do k3=1,kmax(3)
        do k2=kmin(2),N_Volk(2)
          do k1=kmin(1),N_Volk(1)
            ind=ind+1
			sing_prec_rearranged_dvolkov(ind)=sing_prec_rearranged_dvolkov(ind)+abs(maskV_mom_multi(k1,k2,k3,orb))**2
		  end do
          do k1=1,kmax(1)
             ind=ind+1
			 sing_prec_rearranged_dvolkov(ind)=sing_prec_rearranged_dvolkov(ind)+abs(maskV_mom_multi(k1,k2,k3,orb))**2           
		  end do
		end do
		do k2=1,kmax(2)
          do k1=kmin(1),N_Volk(1)
            ind=ind+1
			sing_prec_rearranged_dvolkov(ind)=sing_prec_rearranged_dvolkov(ind)+abs(maskV_mom_multi(k1,k2,k3,orb))**2
		  end do
          do k1=1,kmax(1)
             ind=ind+1
			 sing_prec_rearranged_dvolkov(ind)=sing_prec_rearranged_dvolkov(ind)+abs(maskV_mom_multi(k1,k2,k3,orb))**2           
		  end do		
		end do
	  end do	  
	end do
    write(fname1,'(a,i8.8,a)') 'photoelectron_momenta_',iter,'.dat'
    write(fname2,'(a,i8.8,a)') 'photoelectron_momenta_',iter,'.bov'
    fnl=len_trim(fname1)
    open(td_volkov_density_file,file=fname1,form='unformatted',status='replace')
    write(td_volkov_density_file) sing_prec_rearranged_dvolkov
    close(td_volkov_density_file)
    open(td_volkov_density_file,file=fname2,status='replace')
    write(td_volkov_density_file,'(1x,a,1x,es23.15)') 'TIME:',iter*time_step
    write(td_volkov_density_file,'(1x,a,1x,a)') 'DATA_FILE:',fname1(1:fnl)
    write(td_volkov_density_file,'(1x,a,3(1x,i6))') 'DATA_SIZE:',dk1,dk2,dk3
    write(td_volkov_density_file,'(1x,a)') 'DATA_FORMAT:  FLOAT'
    write(td_volkov_density_file,'(1x,a)') 'VARIABLE:  density'
    write(td_volkov_density_file,'(1x,a)') 'DATA_ENDIAN:  LITTLE'
    write(td_volkov_density_file,'(1x,a)') 'CENTERING:  zonal'
    write(td_volkov_density_file,'(1x,a,3(1x,es23.15))') 'BRICK_ORIGIN:',&
	  volkov_k_x(kmin(1)),volkov_k_y(kmin(2)),volkov_k_z(kmin(3))
    write(td_volkov_density_file,'(1x,a,3(1x,es23.15))') 'BRICK_SIZE:', &
        volkov_k_x(kmax(1))-volkov_k_x(kmin(1)),volkov_k_y(kmax(2))-volkov_k_y(kmin(2)),&
		volkov_k_z(kmax(3))-volkov_k_z(kmin(3))
    write(td_volkov_density_file,'(1x,a)') 'BYTE_OFFSET: 4'
    close(td_volkov_density_file)

	open(td_volkov_density_file,file="mask_k_point.txt",status='replace')
	write(td_volkov_density_file,'(i7)') N_Volk(1)
	write(td_volkov_density_file,'(i7)') N_Volk(2)
	write(td_volkov_density_file,'(i7)') N_Volk(3)
	write(td_volkov_density_file,'(i7)') volkov_k_x(kmin(1))
	write(td_volkov_density_file,'(i7)') volkov_k_x(kmax(1))
	write(td_volkov_density_file,'(i7)') volkov_k_y(kmin(2))
	write(td_volkov_density_file,'(i7)') volkov_k_y(kmax(2))
	write(td_volkov_density_file,'(i7)') volkov_k_z(kmin(3))
	write(td_volkov_density_file,'(i7)') volkov_k_z(kmax(3))
	close(td_volkov_density_file)
   
   endif
   
   if(maskv_save_multi_PES_avgs) then
	! output text form  slices
    write(fname1,'(a,i8.8,a)') 'photoelectron_momenta_XY_',iter,'.txt'
    open(td_volkov_density_file,file=trim(adjustl(fname1)),status='replace')	
	!do k3=1,N_Volk(3)
      do k2=1,N_Volk(2)
        do k1=1,N_Volk(1)
		  write(td_volkov_density_file,'(2es14.5e2,es14.4e3)') volkov_k_x(k1),&
		    volkov_k_y(k2),sum(abs(maskV_mom_multi(k1,k2,1:N_Volk(3),1:N_orbitals))**2)
	    end do
	  end do
	!end do
	close(td_volkov_density_file)
    write(fname1,'(a,i8.8,a)') 'photoelectron_momenta_YZ_',iter,'.txt'
    open(td_volkov_density_file,file=trim(adjustl(fname1)),status='replace')	
	do k3=1,N_Volk(3)
      do k2=1,N_Volk(2)
        !do k1=1,N_Volk(1)
		  write(td_volkov_density_file,'(2es14.5e2,es14.4e3)') volkov_k_y(k2),&
		    volkov_k_z(k3),sum(abs(maskV_mom_multi(1:N_Volk(1),k2,k3,1:N_orbitals))**2)
	    !end do
	  end do
	end do
	close(td_volkov_density_file)
    write(fname1,'(a,i8.8,a)') 'photoelectron_momenta_XZ_',iter,'.txt'
    open(td_volkov_density_file,file=trim(adjustl(fname1)),status='replace')	
	do k3=1,N_Volk(3)
      !do k2=1,N_Volk(2)
        do k1=1,N_Volk(1)
		  write(td_volkov_density_file,'(2es14.5e2,es14.4e3)') volkov_k_x(k1),&
		    volkov_k_z(k3),sum(abs(maskV_mom_multi(k1,1:N_Volk(2),k3,1:N_orbitals))**2)
	    end do
	  !end do
	end do
	close(td_volkov_density_file)
	
  endif
END SUBROUTINE maskV_save_multi_PES_bovANDtxt

subroutine ft_slow(f,N1,N2,N3,mode)
implicit none
integer  :: n1,n2,n3,mode
complex*16   :: f(n1,n2,n3),ft(n1,n2,n3)
complex*16   :: cf1,cf2,cf3,w
integer      :: i1,i2,i3,k1,k2,k3

cf1=2.d0*zi*pi/dble(n1)*mode
cf2=2.d0*zi*pi/dble(n2)*mode
cf3=2.d0*zi*pi/dble(n3)*mode
ft=(0.d0,0.d0)

  do i3=0,n3-1
    do i2=0,n2-1
	  do i1=0,n1-1
  do k3=0,n3-1
    do k2=0,n2-1
	  do k1=0,n1-1
        w=exp(cf1*k1*i1+cf2*k2*i2+cf3*k3*i3)
	    ft(i1+1,i2+1,i3+1)= ft(i1+1,i2+1,i3+1) + w*f(k1+1,k2+1,k3+1)
  end do
  end do
  end do
  end do
  end do
  end do
  f=ft/dble(n1*n2*n3)
end subroutine ft_slow


subroutine volkov_split_timestep_krktest(iter)
implicit none
  integer   :: i,k,n,i1,i2,i3,iter,maxele
  integer   :: lp(3)
  complex*16 :: term1,phase2,potxyz
  complex*16 :: allpotentials
  real*8     :: maxv1
  complex*16 :: tc(N_taylor),tc2(N_taylor),phi_c3(N_Lattice_points),phi_c4(N_Lattice_points),Phi_T(N_Lattice_points)
  
  do i=1,N_taylor
    tc(i)=(-zi*time_step/hbar)**i
    do k=1,i
      tc(i)=tc(i)/k
    enddo
  enddo
  do i=1,N_taylor
    tc2(i)=(-zi*0.5d0*time_step/hbar)**i
    do k=1,i
      tc2(i)=tc2(i)/k
    enddo
  enddo    
  
  write(log_file,*) A_vec
  lp=0
  do n=1,N_orbitals

        !vso_kphi(:,:,:)=vso_kpsi(:,:,:,n)
    	do i3=1,N_Lattice(3)
    	  do i2=1,N_Lattice(2)
    	    do i1=1,N_Lattice(1)
    	      vso_kphi(i1,i2,i3)=vso_kpsi(i1,i2,i3,n)
    	    end do
    	  end do
    	end do
	
	
	
	do i3=1,N_Lattice(3)
	  do i2=1,N_Lattice(2)
	    do i1=1,N_Lattice(1)
	      term1=(volkov_k_x(i1)**2+volkov_k_y(i2)**2+volkov_k_z(i3)**2)&
		  +(2*volkov_k_x(i1)*A_vec(1))&
		  +(2*volkov_k_y(i2)*A_vec(2))&
		  +(2*volkov_k_z(i3)*A_vec(3))&
		  +(A_vec(1)**2+A_vec(2)**2+A_vec(3)**2)
	      phase2=-zi*h2m*time_step/(hbar*2.d0)
		  !phase2=-zi*0.5d0*time_step*convertT2AU/(2.d0*convertL2AU**2)
		  !phase2=-zi*0.5d0*time_step*convertT2AU/2.d0
          vso_kphi(i1,i2,i3)=vso_kphi(i1,i2,i3)*exp(term1*phase2)          
        end do
      end do
    end do


	! do taylor version to check
    Phi_c=Psi_c(:,n)
	Phi_c2=Phi_c
	do i=1,N_taylor
	  call Kinetic_c(Phi_c2,Phi_T)
      Phi_c2=Phi_T
	  Phi_c=Phi_c+tc2(i)*Phi_c2
	end do
    Phi_c2=Phi_c
	Phi_c4=Phi_c
	
	call dfftw_execute_dft(plan_volkov_Backward,vso_kphi,vso_rphi)
    vso_rphi=vso_rphi*sqrt(fftfactor)
	do i3=1,N_Lattice(3)
	  do i2=1,N_Lattice(2)
	    do i1=1,N_Lattice(1)
		    !write(log_file,*) i3,Lattice_inv_xyz(i1,i2,i3),Lattice(3,Lattice_inv_xyz(i1,i2,i3))
			Phi_c(Lattice_inv_xyz(i1,i2,i3))=vso_rphi(i1,i2,i3)
        end do
      end do
    end do
	
	do i=1,N_Lattice_points
    !write(77700000+n*10000+iter*100+0,'(4es30.16e3)')  real(Phi_c(i)),imag(phi_c(i)),real(Phi_c4(i)),imag(phi_c4(i))
	write(77700000+n*10000+iter*100+0,'(2es30.16e3)')  phi_c(i)-phi_c4(i)
	end do
	
	! non-local psuedopotential is stupid, so we have to use taylor
	call taylor_expV_phi(n,1.d0,1)
	Phi_c3=Phi_c

	Phi_c=Phi_c4
	Phi_c2=Phi_c4
	do i=1,N_taylor
	  call V_wavefn_c_noLaser
      Phi_c=H_Phi_c
	  Phi_c2=Phi_c2+tc(i)*Phi_c
	end do	
	Phi_c=Phi_c2
	Phi_c4=Phi_c2
	
	Phi_c=Phi_c3
	do i=1,N_Lattice_points
    !write(77700000+n*10000+iter*100+0,'(4es30.16e3)')  real(Phi_c(i)),imag(phi_c(i)),real(Phi_c4(i)),imag(phi_c4(i))
	write(77700000+n*10000+iter*100+1,'(2es30.16e3)')  phi_c(i)-phi_c4(i)
	end do
	

	do i3=1,N_Lattice(3)
	  do i2=1,N_Lattice(2)
	    do i1=1,N_Lattice(1)
			vso_rphi(i1,i2,i3)=Phi_c(Lattice_inv_xyz(i1,i2,i3))
        end do
      end do
    end do
	
	call dfftw_execute_dft(plan_volkov_Forward,vso_rphi,vso_kphi)
	vso_kphi=vso_kphi*sqrt(fftfactor)

	do i3=1,N_Lattice(3)
	  do i2=1,N_Lattice(2)
	    do i1=1,N_Lattice(1)
	      term1=(volkov_k_x(i1)**2+volkov_k_y(i2)**2+volkov_k_z(i3)**2)&
		  +(2*volkov_k_x(i1)*A_vec(1))&
		  +(2*volkov_k_y(i2)*A_vec(2))&
		  +(2*volkov_k_z(i3)*A_vec(3))&
		  +(A_vec(1)**2+A_vec(2)**2+A_vec(3)**2)
		  ! h2m in AU is 0.5
	      phase2=-zi*h2m*time_step/(hbar*2.d0)
		  !phase2=-zi*0.5d0*time_step*convertT2AU/(2.d0*convertL2AU**2)
		  !phase2=-zi*0.5d0*time_step*convertT2AU/2.d0
          vso_kphi(i1,i2,i3)=vso_kphi(i1,i2,i3)*exp(term1*phase2)          
        end do
      end do
    end do

	!vso_kpsi(:,:,:,n)=vso_kphi(:,:,:)
    	do i3=1,N_Lattice(3)
    	  do i2=1,N_Lattice(2)
    	    do i1=1,N_Lattice(1)
    	      vso_kpsi(i1,i2,i3,n)=vso_kphi(i1,i2,i3)
    	    end do
    	  end do 
    	end do
	
	! map back to Psi_c
	call dfftw_execute_dft(plan_volkov_Backward,vso_kphi,vso_rphi)
	vso_rphi=vso_rphi*sqrt(fftfactor)
	do i3=1,N_Lattice(3)
	  do i2=1,N_Lattice(2)
	    do i1=1,N_Lattice(1)
		   ! ------------------------------------------------------------
		    ! debug1 change back
			Psi_c(Lattice_inv_xyz(i1,i2,i3),n)=vso_rphi(i1,i2,i3)
        end do
      end do
    end do
	
	Phi_c2=Phi_c4
	Phi_c=Phi_c4
	do i=1,N_taylor
	  call Kinetic_c(Phi_c2,Phi_T)
      Phi_c2=Phi_T
	  Phi_c=Phi_c+tc2(i)*Phi_c2
	end do
    Phi_c2=Phi_c
	Phi_c4=Phi_c
	phi_c=psi_c(:,n)
	do i=1,N_Lattice_points
    !write(77700000+n*10000+iter*100+0,'(4es30.16e3)')  real(Phi_c(i)),imag(phi_c(i)),real(Phi_c4(i)),imag(phi_c4(i))
	write(77700000+n*10000+iter*100+2,'(2es30.16e3)')  phi_c(i)-phi_c4(i)
	end do

  end do

end subroutine volkov_split_timestep_krktest

SUBROUTINE Orthogonalization_vso_kpsi(N_o_min,N_o_max)
  ! Gram-Schmidt orthogonalization
  integer :: orbital,i,N_o_min,N_o_max
  real*8  :: s
  complex*16 :: overlap

  do orbital=N_o_min,N_o_max
!    if(orbital>N_o_min) then
      do i=N_o_min,orbital-1
        overlap=sum(conjg(vso_kpsi(:,:,:,i))*vso_kpsi(:,:,:,orbital))*Grid_Volume
        vso_kpsi(:,:,:,orbital)=vso_kpsi(:,:,:,orbital)-overlap*vso_kpsi(:,:,:,i)
      enddo
!    endif
    s=sum(abs(vso_kpsi(:,:,:,orbital))**2)*Grid_Volume
    vso_kpsi(:,:,:,orbital)=vso_kpsi(:,:,:,orbital)/sqrt(s)
  enddo
END SUBROUTINE Orthogonalization_vso_kpsi

end module mask_volkov