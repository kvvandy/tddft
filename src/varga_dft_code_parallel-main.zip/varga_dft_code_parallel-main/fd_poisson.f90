MODULE FD_POISSON
USE PARAMETERS
  integer                                    :: NP(3)
  integer                                    :: NPDIM
  integer, dimension(:,:), allocatable       :: PL
  integer, dimension(:,:,:), allocatable     :: PL_inv
  real*8,  dimension(:,:,:), allocatable     :: wwf
  real*8                                     :: p_h(3)
  real*8, dimension(:), allocatable          :: vec,P_vec
  real*8,  dimension(:,:), allocatable       :: VL,VR
  integer,parameter                          :: N_discretization=4

  CONTAINS

  subroutine FD_P(r0,v)
!
! BC: v=vl,vr on the left and right surface in the x direction
!            , periodic on all other surfaces
!
    implicit none
    real*8                             :: r(npdim),v(npdim),r0(npdim)
    integer                            :: k2,k3

    real*8, dimension(:), allocatable  :: vve
    integer                            :: i,ii

!    write(logfile,*)"FD_P"
!    write(logfile,*)NP
!    write(logfile,*)P_h
!    write(logfile,*)r0
!    write(logfile,*)VL
!    write(logfile,*)VR

    r=-4.d0*pi*r0
    do k2=1,NP(2)
      do k3=1,NP(3)
        r(PL_inv(1,k2,k3))=r(PL_inv(1,k2,k3))-VL(k2,k3)/p_h(1)**2/E2
        r(PL_inv(NP(1),k2,k3))=r(PL_inv(NP(1),k2,k3))-VR(k2,k3)/p_h(1)**2/E2
      end do
    end do

    call CoGr(r,NPDIM)
    v=vec*E2

!    write(logfile,*)v


end subroutine FD_P


  subroutine init_Poisson(n1,n2,n3,h1,h2,h3)
    implicit none
    integer                            :: n1,n2,n3
    real*8                             :: h1,h2,h3
    integer                            :: Nd,k1,k2,k3,num,i,k

    NP(1)=n1
    NP(2)=n2
    NP(3)=n3
    p_h(1)=h1
    p_h(2)=h2
    p_h(3)=h3

    NPDIM=NP(1)*NP(2)*NP(3)
    Nd=N_discretization

    allocate(PL(3,NPDIM),PL_inv(NP(1),NP(2),NP(3)))
    allocate(wwf(-Nd:NP(1)+Nd,-Nd:NP(2)+Nd,-Nd:NP(3)+Nd))
    allocate(vec(NPDIM),P_vec(NPDIM),VL(NP(2),NP(3)),VR(NP(2),NP(3)))

    num=0
    do k1=1,NP(1)
      do k2=1,NP(2)
        do k3=1,NP(3)
          num=num+1
          PL(1,num)=k1-1
          PL(2,num)=k2-1
          PL(3,num)=k3-1
          PL_inv(k1,k2,k3)=num
        end do
      end do
    end do

  end subroutine init_Poisson


  SUBROUTINE periodic_bc

!     impose periodic boundary condition

      implicit none

      integer                                 :: k


      do k = 0 ,N_discretization - 1
!        wwf(NP(1)+k,0:NP(2)-1,0:NP(3)-1)=wwf(k,0:NP(2)-1,0:NP(3)-1)
                        wwf(0:NP(1)-1,NP(2)+k,0:NP(3)-1)=wwf(0:NP(1)-1,k,0:NP(3)-1)
                        wwf(0:NP(1)-1,0:NP(2)-1,NP(3)+k)=wwf(0:NP(1)-1,0:NP(2)-1,k)
      end do

      do k = - N_discretization, -1
!        wwf(k,0:NP(2)-1,0:NP(3)-1)=wwf(k+NP(1),0:NP(2)-1,0:NP(3)-1)
                        wwf(0:NP(1)-1,k,0:NP(3)-1)=wwf(0:NP(1)-1,k+NP(2),0:NP(3)-1)
                        wwf(0:NP(1)-1,0:NP(2)-1,k)=wwf(0:NP(1)-1,0:NP(2)-1,k+NP(3))
      end do

  end subroutine periodic_bc


      SUBROUTINE nabla1

!     impose periodic boundary condition

      implicit none

      integer                                 :: i,i1,i2,i3
      real*8                                  :: K_x,K_y,K_z

      do i=1,NPDIM

        i1=PL(1,i); i2=PL(2,i); i3=PL(3,i)

          K_x=(-2.d0*wwf(i1,i2,i3)+wwf(i1+1,i2,i3)+wwf(i1-1,i2,i3))/p_h(1)**2
          K_y=(-2.d0*wwf(i1,i2,i3)+wwf(i1,i2+1,i3)+wwf(i1,i2-1,i3))/p_h(2)**2
          K_z=(-2.d0*wwf(i1,i2,i3)+wwf(i1,i2,i3+1)+wwf(i1,i2,i3-1))/p_h(3)**2

          P_vec(i)=K_x+K_y+K_z

      end do

      end subroutine nabla1

SUBROUTINE operator

      implicit none

      integer                                    :: i1,i2,i3,kpoint,grid

      wwf=0.d0

      do grid=1,NPDIM
        i1=PL(1,grid)
        i2=PL(2,grid)
        i3=PL(3,grid)
        wwf(i1,i2,i3)=vec(grid)
      end do

        call periodic_bc
        call nabla1


end subroutine operator


subroutine CoGr(b,NL)
implicit none
integer                                  :: NL
real*8                                   :: b(NL)
real*8                                   :: g0,g1,alfa,beta,rr,bn,con
integer                                  :: iteration,i,j
integer,parameter                        :: N_iteration_p=500
real*8,parameter                         :: eps=1.d-6
real*8,  dimension(:), allocatable       :: r1,p1,r2,p2,h1,h2,v

allocate(r1(NL),p1(NL),r2(NL),p2(NL),h1(NL),h2(NL),v(NL))

bn=sqrt(dot_product(b,b))
v=0.
vec=v;  call operator;  r1=b-P_vec
vec=r1; call operator;  r2=P_vec
p1=r1
p2=r2
g0=dot_product(r2,r1)

do iteration=1,N_iteration_p
  con=abs(sqrt(dot_product(r1,r1))/bn)
  write(cogr_file,*)iteration,con
  if(con.gt.eps) then
    vec=p1; call operator; h1=P_vec
    vec=p2; call operator; h2=P_vec
    alfa=g0/dot_product(p2,h1)
    v=v+alfa*p1
    r1=r1-alfa*h1
    r2=r2-alfa*h2
    g1=dot_product(r2,r1)
    beta=g1/g0; g0=g1
    p1=r1+beta*p1
    p2=r2+beta*p2
  endif
end do
vec=v

if(con.gt.eps) then
  write(log_file,*)'Poisson is not converged!'
endif

deallocate(r1,p1,r2,p2,h1,h2,v)

end subroutine CoGr

END MODULE FD_POISSON




