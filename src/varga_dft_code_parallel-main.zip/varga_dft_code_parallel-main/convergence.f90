!=== Convergence Monitoring goes here ===!
module mod_converged
  use mod_global

  private

    logical :: converge_plot = .True.
    logical :: fopened = .False.
    logical :: check_energy = .False.    !False => check density

  type monitor
     integer :: iteration
     real*8 :: energy
     real*8 :: endiff     ! abs( Energy(i-1) - Energy(i) )
     real*8 :: residual   ! norm of residual / normalized to tot. charge
     real*8 :: rhodiff    ! max( abs(density - new_density))
  end type monitor

  type(monitor) :: scfmon

  public :: monitor
  public :: scfmon
  public :: update_monitor
  public :: converged
  public :: set_monitor_iteration

contains

  subroutine update_monitor(i,en,rho,new_rho)
    integer, intent(in) :: i
    real*8, intent(in)  :: en
    real*8, dimension(:), intent(in)  :: rho, new_rho

    !first iteration
    if (i==1) then
       scfmon%iteration = 1
       scfmon%energy    = en
       scfmon%endiff    = 0.0d0
       scfmon%residual  = 0.0d0
       scfmon%rhodiff   = 0.0d0
    else
       scfmon%iteration = i
       scfmon%endiff    = abs(scfmon%energy - en)
       scfmon%energy    = en
       scfmon%residual  = sqrt(dot_product(rho-new_rho,rho-new_rho))
       scfmon%rhodiff   = abs(maxval(rho-new_rho))

       call write_cmon
    end if
  end subroutine update_monitor

  subroutine set_monitor_iteration(i)
    integer :: i
    scfmon%iteration = i
  end subroutine set_monitor_iteration


  subroutine write_cmon()
    character(len=30) :: fmt="(I3,1X,4(ES16.6,1X))"
    character(len=30) :: fmt2="(I3,1X,ES16.6)"
    character(len=30) :: fmt3="(I3,1X,ES23.15)"

    if (fopened) then
       open(convergence_monitor_file, file=trim(adjustl(convergence_monitor_filename)), position='append')
    else
       open(convergence_monitor_file, file=trim(adjustl(convergence_monitor_filename)))
       fopened = .True.
    end if


    !=== header line ===!
    !character(len=30) :: fmt2="(4(A,8X),A)"
    !write(convergence_monitor_file,fmt2) 'it','Energy','dE','drho','res

    write(convergence_monitor_file, fmt) scfmon%iteration-1, scfmon%energy, scfmon%endiff, &
         scfmon%rhodiff, scfmon%residual
    close(convergence_monitor_file)

    if (converge_plot) then
        i = scfmon%iteration - 1
        if (i==1) then
            open(convergence_de_file, file=trim(adjustl(convergence_de_filename)))
            open(convergence_e_file, file=trim(adjustl(convergence_e_filename)))
            open(convergence_res_file, file=trim(adjustl(convergence_res_filename)))
        else
            open(convergence_de_file, file=trim(adjustl(convergence_de_filename)), position='append')
            open(convergence_e_file, file=trim(adjustl(convergence_e_filename)), position='append')
            open(convergence_res_file, file=trim(adjustl(convergence_res_filename)), position='append')
        end if
        write(convergence_de_file,fmt2) i,scfmon%endiff
        write(convergence_e_file,fmt3) i,scfmon%energy
        write(convergence_res_file,fmt2) i,scfmon%residual
        close(convergence_de_file)
        close(convergence_e_file)
        close(convergence_res_file)
    end if


  end subroutine write_cmon

  function converged()
    logical :: converged    
    converged = .False.

    if ((scfmon%iteration < 3).OR.(.not.check_convergence)) then
        converged = .False.
    else
       if (check_energy) then       
          if (scfmon%endiff < ediff) then
             converged = .True.
             write(log_file,*)"CONVERGED: energy change below threshold"             
          else
             converged = .False.
          end if
       else
          if (scfmon%rhodiff < pdiff) then
             converged = .True.
             write(log_file,*)"CONVERGED: density change below threshold"
          else
             converged = .False.
          end if
       end if
    end if
    
    return
  end function converged


end module mod_converged

