#!/bin/bash

# Make sure these point to the correct files on your system
source /opt/intel/bin/compilervars.sh intel64
time /home/joe/code/dft/release/dft
