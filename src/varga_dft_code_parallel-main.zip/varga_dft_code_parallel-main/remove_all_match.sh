#!/bin/bash

kw=$1
swt=$2
echo "arg1 keyword arg2 flag"
echo "flag==1 remove"
echo "keyword=$kw"
echo "flag=$swt"
echo "use arg=1 to remove lines from files"
list=$(ls *.f90)

echo $list
grep $kw *.f90

if [ "$swt" == "1" ]; then
 echo "flag==1"
 for f in $list; do
  echo "removing from $f"
  n1=$(wc -l $f | awk '{print $1}')
  sed -i "/${kw}/d" $f
  n2=$(wc -l $f | awk '{print $1}')
  let j=n1-n2
  echo $j lines removed.
 done
fi

