from ase import *
from ase.data.molecules import *
from ase.lattice.surface import *
from dft_util import *


class Device:
    def __init__(self, **kwargs):

        self.L = None
        self.C = None
        self.R = None
        
        self.p = {
            'M' : None,          #molecule
            'iM' : None,         #molecule atom to connect to left lead
            'lead_type' : 'Au',
            'a' : 4.18,     #Au lattice constant
            'nb' : 0,          #lead layers in C
            'lsize' : (4, 4, 3),         #lead size (#of units in direction) 
            'lb' : 2.18,    #left/ right bond lengths
            'rb' : 2.18+0.00512037601593,
            'calc' : 'dft',     #which code to setup for
            'dbond' : 0.0}     # fudge factor should be small!!!
            
        self.set(**kwargs)

        self.set_leads()
        self.set_center()

        calc = self.p['calc']
        if calc == 'gpaw':
            self.set_gpaw()
        elif calc == 'openmx':
            self.set_openmx()
        elif calc == 'dft':
            self.set_dft()
        else:
            raise TypeError('Bad calculator type: ' + calc)
            

    def set(self, **kwargs):
        for k in kwargs:
            if self.p.has_key(k):
                self.p[k] = kwargs[k]
            else:
                raise TypeError('Parameter not defined: '+ str(k))
            
    def left_lead(self, **kwargs):
        p = self.p
        s = p['lsize']  
        
        if kwargs.has_key('n'):
            s = s[0], s[1], kwargs['n']                                    

        t = p['lead_type']
        a = p['a']
        
        l = fcc111(symbol = t, a = a, size = s, orthogonal = True)
        l.center()
        return l

    def right_lead(self, **kwargs):
        if kwargs.has_key('n'):
            n = kwargs['n']
            l = self.left_lead(n=n)
        else:
            l = self.left_lead()

        #l.positions *= -1
        l.center()
        return l
        
    def set_leads(self):
        self.L = self.left_lead()
        self.R = self.right_lead()

    def set_center(self):
        p = self.p

        pos = 'ontop'
        ofs = 1,2

        M = p['M']
        iM = p['iM']
        left_bond = p['lb']
        right_bond = p['rb']

        dbond = p['dbond']
        left_bond += dbond / 2.0
        right_bond += dbond / 2.0

        L1 = self.left_lead()     #ABC
        L2 = self.right_lead(n=4) #CABC
                        
        add_adsorbate(L1, M, left_bond, 
                      position = pos, 
                      offset = ofs,
                      mol_index = iM)

        # start of Lead 2
        # length of L1 + Z size of molecule + Right bond
        dz = Lz(L1) + right_bond
        L2.translate(array([0, 0, dz]))

        C = L1 + L2
        
        cell = C.get_cell()
        cell[2,2] = Lz(C) + p['a'] / sqrt(3.0)
        C.set_cell(cell)
        
        C.center()
        self.C = C


    ##################################################################
    #### Calculator Specific setup

    # GPAW


    def set_gpaw(self):
        # Set C to L + C + R
        # L/R are ABC unit cells with tags 0/2 , C.tags = 1

        L = self.left_lead()  #ABC        
        L.set_tags(zeros(L.get_number_of_atoms()))
        L[0].tag = 90
        self.L = L

        R = self.left_lead()  #ABC
        R.set_tags(2*ones(R.get_number_of_atoms()))
        n = R.get_number_of_atoms() - 1
        R[n].tag = 91
        self.R = R

        C = self.C
        C.set_tags(ones(C.get_number_of_atoms()))

        dC = L.get_cell()[2,2]
        dR = dC + C.get_cell()[2,2]
        
        C.translate(array([0, 0, dC]))
        R.translate(array([0, 0, dR]))

        C = L + C + R

        cell = C.get_cell()
#        cell[2,2] += 4*dC + self.p['a'] / sqrt(3.0)
        cell[2,2] = Lz(C) + self.p['a'] / sqrt(3.0)
        C.set_cell(cell)
       
        cell = L.get_cell()
        x = cell[0,0]
        y = cell[1,1]
        z = cell[2,2]
 
        self.pl_cell = x, y, z
        
        C.center()

        self.pl1 = []
        self.pl2 = []
        self.mol_atoms = []
        for i in range(C.get_number_of_atoms()):
            t = C[i].tag
            if (t == 0 or t == 90):
                self.pl1.append(i)
            elif (t == 2 or t == 91):
                self.pl2.append(i)                
            else:
                self.mol_atoms.append(i)                             

        C.set_pbc((True, True, True))
        self.C = C
        self.set_edge_atoms()

        
        
        
    def set_edge_atoms(self):
        # i/j is atom index in lead_cell/scattering cell
        L = self.L
        C = self.C
        R = self.R

        pl1 = self.pl1
        pl2 = self.pl2


        for i in range(len(pl1)):
            if C[pl1[i]].tag == 90: i0 = i

        for i in range(len(pl2)):
            if C[pl2[i]].tag == 91: i1 = i

        for j in range(C.get_number_of_atoms()):            
            t = C[j].tag
            if t == 90: j0 = j
            elif t == 91: j1 = j


        self.edge_atoms = [[i0, i1], [j0, j1]]
        
   

    ######### OPENMX ###########################################

    def align_to_x(self, atoms):
        c1 = atoms.get_cell()
        c2 = atoms.get_cell()
        
        c2[0,0] = c1[2,2]
        c2[2,2] = c1[0,0]               

        atoms.rotate('y', pi/2.0)
        atoms.set_cell(c2)

        atoms.center()
        return atoms

    def set_openmx(self):

        self.L = self.align_to_x(self.L)
        self.C = self.align_to_x(self.C)
        self.R = self.align_to_x(self.R)
            
        dx = self.L.get_cell()[0,0]
        self.L.translate(array([-dx, 0, 0]))
        #self.C.translate(array([dx, 0, 0]))
        
        #dx += self.C.get_cell()[0,0]
        dx = self.C.get_cell()[0,0]
        self.R.translate(array([dx, 0, 0]))
        print dx
 
    ####### In house DFT ########################################
    def align_to_x2(self, atoms):
        c1 = atoms.get_cell()
        c2 = atoms.get_cell()
        
        c2[0,0] = c1[2,2]
        c2[2,2] = c1[0,0]               

        atoms.rotate('y', pi/2.0)
        atoms.set_cell(c2)

        cm = atoms.get_center_of_mass()
        atoms.translate(-cm)

        return atoms

    def set_dft(self):
        self.L = self.align_to_x2(self.L)
        self.C = self.align_to_x2(self.C)
        self.R = self.align_to_x2(self.R)


