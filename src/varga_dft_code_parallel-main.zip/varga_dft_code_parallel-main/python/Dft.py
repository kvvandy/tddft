# A python class for interacting with the dft code
# - For this to work 'dev' should be in the path
# - Also 'xyz2dft.pl' should be in the path
# - As a minimum a,b,c,ngxa,ngxb,ngy,ngz and name must be defined
# 
# Todo: 
# - replace dev completely internally
# - add checks on input sanity
# - improve interface with ASE

import os
import sys

import ase
from ase.io import write


dft_cmd  = 'mpirun dft'
email_ad = 'brandongc@gmail.com'

pp_dir = '/shared/home/cookbr/data/dft/'
bf_dir = pp_dir + 'Ng_6/'


class Dft:
    def __init__(self, a,b,c, **kwargs):
        
        self.a = a
        self.b = b
        self.c = c

        self.controls = {
            'niter' : 200,
            'continuation': False,
            'type'  : 13,
            'pp'    : pp_dir,
            'bf'    : bf_dir,
            'mtype' : 0,
            'mhist' : 5,
            'minit' : 7,
            'mbeta' : 0.01,
            'mrtol' : 0.1,
            'ediff' : 1e-4,
            'ngxac' : None,   #xgrid points for a.inp
            'ngxb'  : None,   #xgrid points for b.inp
            'ngy'   : None,
            'ngz'   : None,
            'grid'  : None,
            'name'  : None,
            'nprocs': 1 }



        
        self.set(**kwargs)

    def set(self, **kwargs):
        for k in kwargs:
            if self.controls.has_key(k):
                self.controls[k] = kwargs[k]
            else:
                raise TypeError('Parameter not defined: '+ str(k))
                
    
    def write_control_inp(self, **kwargs):
        # writes control.inp

        # d1 translates to the longer names for the file
        d1 = {
            'continuation' : 'continuation',
            'ediff' : 'ediff',
            'niter' : 'n_scf_iter_max',
            'pp' : 'pp_path',
            'bf' : 'bf_path',
            'mrtol' : 'mix_rtol',
            'mtype' : 'mix_type',
            'mhist' : 'mix_hist',
            'mbeta' : 'mix_beta',  #also density_mixing
            'minit' : 'mix_init'
            'type'  : 'run_type'}                    


        p = self.controls
        f = open('control.inp', 'w')

        for k, v in p.items():
            if ((v is not None) and (k in d1.keys())):
                f.write(d1[k] + ' = ')
                
                if type(v) == type(bool()):
                    if v:
                        f.write('true')
                    else:
                        f.write('false')
                else:
                    f.write('%s' % p[k])
                    
                f.write('\n')

        f.close()

    def write_pbs(self, **kwargs):
        # write run.pbs

        p = self.controls

        lines = ['#!/bin/bash',
                 '#PBS -l nodes=1:ppn='+str(p['nprocs']),
                 '#PBS -l walltime=99:00:00',
                 '#PBS -j oe',
                 '#PBS -o log.txt',
                 '#PBS -N '+p['name'],
                 '#PBS -m abe',
                 '#PBS -M '+email_ad,
                 '#PBS -V ',
                 'cd $PBS_O_WORKDIR',
                 dft_cmd]

        f = open('run.pbs','w')
        for i in range(len(lines)):
            f.write(lines[i] + '\n')

        f.close()


    def write_dft_inp(self, **kwargs):
        # write dft.inp 
        # uses calls to 'dev' and 'xyz2dft.pl'
        # these functions should be internalized eventually

        p = self.controls

        a = self.a
        b = self.b
        c = self.c

        ngxac = p['ngxac']
        ngxb  = p['ngxb']
        ngy   = p['ngy']
        ngz   = p['ngz']

        dict = {
            'a' : a,
            'b' : b,
            'c' : c }
       

        for i in ['a', 'b', 'c']:
            nxyz = i + '.xyz'
            ndat = i + '.dat'
            
            write(nxyz, dict[i], format='xyz')
            
            cmd = 'xyz2dft.pl ' + nxyz + ' ' + ndat
            os.system(cmd)

        for i in ['a', 'c']:
            f = open( i + '.dat', 'a')

            ll = 3*(str(p['grid'])+' ')+str(ngxac)+' '+ str(ngy)+' '+str(ngz)

            f.write(ll)
            f.close()

        f = open('b.dat', 'a')
        ll = 3*(str(p['grid'])+' ')+str(ngxb)+' '+ str(ngy)+' '+str(ngz)
        f.write(ll)
        f.close()

        # now call 'dev' to put the .dat files together
        # my version is hard coded with 3 1 3 ...
        os.system('dev')


    def run(self):
        # calls 'qsub run.pbs' to submit the job
        # puts the job in it's own directory
        
        cmd = 'qsub run.pbs'

        nm = self.controls['name']

        os.system('mkdir '+nm)
        os.chdir(nm)

        self.write_control_inp()
        self.write_pbs()
        self.write_dft_inp()
        
        os.system(cmd)
