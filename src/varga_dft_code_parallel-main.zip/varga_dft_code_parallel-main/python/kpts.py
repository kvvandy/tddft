#!/usr/bin/env python
"""
Generates kpoint.inp files

usage: ./kpts.py nkx nky nkz


note: first kpoint in always 0 0 0
"""

from ase.dft.kpoints import monkhorst_pack
from sys import argv
from numpy import zeros

kx = int(argv[1])
ky = int(argv[2])
kz = int(argv[3])

k = monkhorst_pack((kx, ky, kz))

n=kx*ky*kz

igamma=-1
for i in range(n):
    if k[i][0] == k[i][1] == k[i][2] == 0.0:
        igamma = i

if igamma < 0:
    k.resize(n+1,3)
    n += 1

for i in range(n):
    if k[i][0] == k[i][1] == k[i][2] == 0.0:
        igamma = i

assert(igamma >= 0)
tmp = k[0].copy()
k[0] = k[igamma].copy()
k[igamma] = tmp.copy()

f = open('kpoints.inp', 'w')
f.write(str(n) + '\n')
for i in range(n):
    for j in range(3): f.write(str(k[i][j]) + ' ')
    f.write('\n')

f.close()

