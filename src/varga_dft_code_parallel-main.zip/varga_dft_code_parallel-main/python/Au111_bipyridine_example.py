#!/usr/bin/env python

from ase import *
from dft_util import *
from transport_device import Device
from sys import argv

#lat_const = float(argv[1])

mol = io.read('bipyridine.xyz')
mol.rotate('y', -pi/2.0)

d =  Device(M = mol, iM = 0, 
            calc = 'dft', 
            lsize=(3,4,3),
            a=4.18,
            dbond = 0.00512037601593)

view(d.C)
view(d.L)
view(d.R)

#### sort atoms by x value for optimal efficiency
a, b, c = xsort(d.L), xsort(d.C), xsort(d.R)

g = grid(a, b, c)
print 'grid points center',g.nc
print 'grid points lead',g.nl
print 'scaling ratio',g.ratio

# scale the center region so it lines up nicely with grid points
b.positions[:,0] *= g.ratio
b.cell[0,0] *= g.ratio

a = xcenter(a)
b = xcenter(b)
c = xcenter(c)

#### output some .dat files for dft
write_dat(a, 'a', g.h, g.nl)
write_dat(b, 'b', g.h, g.nc)
write_dat(c, 'c', g.h, g.nl)


