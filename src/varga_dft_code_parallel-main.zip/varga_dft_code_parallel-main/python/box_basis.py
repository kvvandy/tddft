#!/usr/bin/env python

# adds a specified number of states to the end of the dft.inp file
# for run types 17 & 56

from sys import argv
from os import rename

fname = 'dft.inp'

if len(argv) != 3:
    print 'usage: ./box_basis.py n_states_lead n_states_scat'

nstates_lead = int(argv[1])
nstates_scat = int(argv[2])

f = open(fname, 'r')
lines = f.readlines()
f.close()

num_boxes = int(lines[-1].split()[0])
center_box_indx = (num_boxes + 1) / 2

imin = -num_boxes
for i in range(num_boxes):
    j = imin + i
    line = lines[j][:-1]
    if i == center_box_indx - 1:
        box_indx = center_box_indx
        nstates = nstates_scat
    else:
        box_indx = 1
        nstates = nstates_lead
    line += (' '+str(nstates)+' '+str(box_indx)+'\n')
    lines[j] = line

rename(fname, fname + '.backup')

f = open(fname, 'w')
f.writelines(lines)
f.close()
