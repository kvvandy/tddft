#!/usr/bin/env python

# little utility for vizualizing hs.mat

from pylab import spy, show
from dft_util import read_hs_mat

H, S = read_hs_mat()
spy(H, precision=0)
show()
