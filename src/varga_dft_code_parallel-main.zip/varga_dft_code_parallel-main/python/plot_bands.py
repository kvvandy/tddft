#!/usr/bin/env python
""" Utility for viewing band structures

usage: ./plot_bands bs.dat
"""

from pylab import *
from sys import argv


f=open(argv[1], 'r')
s=f.readlines()
f.close()

l=s[0].split()
nkpt=int(l[0])
norb=int(l[1])

nmax=len(s)**2

kp=zeros(nmax)
en=zeros((nmax,norb))

ik=0
for i in range(1,len(s)):
    x = s[i].split()
    if (len(x)==2):
        en[ik][int(x[0])-1]=float(x[1])
    elif (len(x)==4):
        kp[ik]=float(x[1])
        ik+=1

for i in range(ik):
    x=kp[i]
    for j in range(norb):
        y=en[i][j]
        plot(x,y,',')

show()
