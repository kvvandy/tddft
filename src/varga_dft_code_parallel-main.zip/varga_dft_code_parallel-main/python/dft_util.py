# Random helpful Python routines
from ase import *
from numpy import *

def xv(a): return a.x
def zv(a): return a.z
def yv(a): return a.y
def Lx(s): return max(s, key=xv).x - min(s, key=xv).x
def Lz(s): return max(s, key=zv).z - min(s, key=zv).z
def Ly(s): return max(s, key=yv).y - min(s, key=yv).y

def Size(m):
    c = m.get_cell()
    c[0,0] = Lx(m)
    c[1,1] = Ly(m)
    c[2,2] = Lz(m)
    return c

def xsort(atoms): 
    id = atoms.positions.argsort(0)
    n = len(id)
    p = zeros((n, 3))
    s = zeros(n)
    for i in range(n):
        p[i] = atoms.positions[id[i][0]]
        s[i] = atoms[id[i][0]].number

    atoms.positions = p
    atoms.set_atomic_numbers(s)
    return atoms

def dist(a1, a2):
    r = a2.position - a1.position
    return linalg.norm(r)

def check_dupes(atoms):
    n = len(atoms)
    for i in range(n):
        for j in range(i+1, n):
            r = dist(atoms[i], atoms[j])
            if r < 1.0:
                print 'atoms too close!'
                print i,j,r

def xcenter(atoms):
    dx = min(atoms, key=xv).x + max(atoms, key=xv).x
    dr = 0.5 * array([dx, 0, 0])
    atoms.translate(-dr)
    return atoms

def acenter(atoms):
    dy = -(min(atoms, key=yv).y + max(atoms, key=yv).y) / 2.0
    dz = -(min(atoms, key=zv).z + max(atoms, key=zv).z) / 2.0
    dx = -(min(atoms, key=xv).x + max(atoms, key=xv).x) / 2.0
    atoms.translate((dx, dy, dz))  
    return atoms
    
def write_dat(atoms, name, h, n):
    f = open(name + '.dat', 'w')
    f.write(str(atoms.get_number_of_atoms()) + '\n')
    for a in atoms:
        line = str(a.x) + ' ' + str(a.y) + ' ' + str(a.z) + ' '
        line += str(a.get_atomic_number()) + '\n'
        f.write(line)
    for i in range(3): f.write(str(h[i])+' ')
    for i in range(3): f.write(str(n[i])+' ')
    f.close()

def read_dat(name):
    f = open(name, 'r')
    lines = f.readlines()
    n = int(lines[0].split()[0])
    atoms = Atoms()
    for i in range(1, n+1):
        s = lines[i].split()
        x, y, z = float(s[0]), float(s[1]), float(s[2])
        num = int(s[3])
        atom = Atom(position=(x,y,z))
        atom.number = num
        atoms.append(atom)
    s = lines[n+1].split()
    lx = float(s[0])*float(s[3])
    ly = float(s[1])*float(s[4])
    lz = float(s[2])*float(s[5])

    atoms.cell=(lx,ly,lz)

    return atoms
        
def F2A(f):
    # converts a Filter class back to Atoms
    return Atoms(numbers = f.get_atomic_numbers(),
                 positions = f.get_positions())

def read_hs_mat():
    # usage H, S = read_hs_mat()
    f = open('hs.mat', 'r')
    n = int(f.readline().split()[0])
    s = f.readline().split()
    if (len(s) < 4):
        nb = n
        mm = int(s[0])
        nl = int(f.readline().split()[0])
        nc = int(f.readline().split()[0])
        nr = int(f.readline().split()[0])
        n =  int(f.readline().split()[0])
        H = zeros((n,n))
        S = zeros((n,n))
        for i in range(n):
            for j in range(n):
                l = f.readline().split()
                h = float(l[0])
                s = float(l[1])
                H[j,i] = h
                S[j,i] = s                        
    else:
        H = zeros((n,n))
        S = zeros((n,n))
        i = int(s[0])
        j = int(s[1])
        H[i,j] = float(s[2])
        S[i,j] = float(s[3])
        for line in f:
            s = line.split()
#            if len(s) > 1:
            i = int(s[0])-1
            j = int(s[1])-1
            H[i,j] = float(s[2])
            S[i,j] = float(s[3])
    return H, S
            

def rotate_z2x(atoms):
    atoms.rotate('z', 'x')
    t = atoms.cell[0,0]
    atoms.cell[0,0] = atoms.cell[2,2]
    atoms.cell[2,2] = t
    atoms.center()
    return atoms

class grid:
    def __init__(self, a,b,c):
        self.L = a
        self.C = b
        self.R = c
        self.h = [0.3, 0.3, 0.3]
        self.nc = [1, 1, 1]
        self.nl = [1, 1, 1]
        self.grid_points()
        self.set_yz_grid()

    def grid_points(self):
        # need odd number of grid points in L, C, and R                
        xLead = self.L.get_cell()[0,0]
        xCenter = self.C.get_cell()[0,0]
        hmin = 0.2
        hmax = 0.3

        nptsLeadMin = int(floor(xLead/hmax))
        # if even go down one...
        if not nptsLeadMin % 2:
            nptsLeadMin -= 1
            print nptsLeadMin

        nptsLeadMax = int(ceil(xLead/hmin))
        if not nptsLeadMax % 2:
            nptsLeadMax += 1
            print nptsLeadMax

#        nh = nptsLeadMax - nptsLeadMin
        nh = nptsLeadMax - nptsLeadMin
        nh2 = nh / 2
        ht = zeros(nh)
        diff = zeros(nh)
        

        nn = zeros(nh)

        j = 0
#        for i in range(0,nh,1):
        for i in range(0,nh,1):
            ni = nptsLeadMin + i
            ht[j] = xLead / float(ni)                    
            nc = round(xCenter / ht[j])
            if (nc % 2 == 0):
                nc += 1
            nn[j] = nc
            if nc % 2:
                diff[j] = abs(xCenter - nc * ht[j])
            else:
                diff[j] = 10000000.0
            j += 1                      
        i = diff.argmin()

        print diff[i], ht[i], nn[i]

        if (nn[i] % 2 == 0):
            print 'warning: center not odd'

        hx = ht[i]        

        print 'npts, diff (Lx_C / hx - npts * hx)',nn[i],diff[i]
        
        self.nl[0] = int(self.L.cell[0,0]/hx)
        self.nc[0] = int(nn[i])
        self.ratio = (diff[i] / xCenter) + 1.0
        
        y = self.L.get_cell()[1,1]
        nmin = int(floor(y/hmax))
        nmax = int(ceil(y/hmin))
        n = nmax - nmin
        ht = zeros(n/2)
        diff = zeros(n/2)

        j = 0
        for i in range(0,n,2):
            ni = nmin + i
            ht[j] = y / float(ni)
            
            diff[j] = 111
               
        self.h[0] = hx



    def g_refine(self, L):
        hmax = 0.3

        i = 0
        nmin = 1
        h = L / nmin
        while h > hmax:
            n = nmin + i
            h = L / float(n)
            i += 2

        return h, n



    def set_yz_grid(self):
        # do not worry about setting grid spacing in this direction
        # only need the number of grid points and will keep the 
        # 0.3 default spacing
        
        Ly = self.L.cell[1,1]
        Lz = self.L.cell[2,2]
        
        h1, n1 = self.g_refine(Ly)
        h2, n2 = self.g_refine(Lz)
        self.nc[1] = n1
        self.nc[2] = n2
        self.nl[1] = n1
        self.nl[2] = n2

