MODULE MAIN
  ! Coordinates in Angstroms, energies in eV
  USE MOD_GLOBAL
  USE MOD_LATTICE
  USE PSEUDOPOTENTIAL
  USE HAMILTON
  USE RADIAL_BASIS
  USE TAYLOR_TIME
  USE FFT_POISSON
  use moldynamics

  implicit none
  
CONTAINS

subroutine initialize
use libxc_stuff
  write(log_file,'(2a)')"Initialize started: ",trim(adjustl(timestamp()))

  ! Setup for OpenMP
  thread_id=omp_get_thread_num()
  num_threads=omp_get_max_threads()
  num_procs_avail=omp_get_num_procs()
  if(MPI_master) write(log_file,'(a,i5)') 'Number of processors available =',num_procs_avail
  if(MPI_master) write(log_file,'(a,i5)') 'Number of threads to execute = ',num_threads

  ! call init_angular
  call input_atom
  call setup_lattice
  if(MPI_master) call find_closest_ions(Position_init,closest_ion_init)
!  if(complexbasis) call scale_kpoints
!  call init_kpoints

  if(MPI_master) call open_files
  call input_pseudo_potential
  call ion_ion_energy

  call init_potential
!  call init_mesh
  call init_pp
  
  if(xc_functional_mode==7) call init_xc
  
  if(move_atoms) then
    write(log_file,*) "Setup MD"
    if(split_up_gen_nlpp) then !
      if(MPI_nlpp_slave) then
	    call init_molecular_dynamics
	  else if(MPI_master) then
	    call init_molecular_dynamics_NO_OPEN
      else
	    call init_molecular_dynamics_SLAVE
	  end if
    else ! regular. Master does MD and nl_PP	
      if(MPI_master) then
	    call init_molecular_dynamics
      else
	    call init_molecular_dynamics_SLAVE
	  end if
	end if
  end if
  
  write(log_file,*)"Done with initialization"
end subroutine initialize

subroutine open_files
  open(timing_file,file=trim(adjustl(timing_output_filename)))
  open(eigenvalues_file,file=trim(adjustl(eigenvalues_output_filename)))
  open(pseudopotential_log_file,file=trim(adjustl(pseudopotential_log_filename)))

  !if(output_plot) open(projection_1d_file,file=trim(adjustl(projection_1d_filename)))

  if(output_full_td_density) then
    if(trim(adjustl(td_density_output_format))=="default") then
      write(log_file,*) "only td_density_output_format=bov is supported"
      stop
	elseif(trim(adjustl(td_density_output_format))=="bov") then
      !in case of the "bov" format we will be writing each density snapshot in a new file
      !so nothing really can be opened here
    endif
  endif
  if(output_full_td_current_density) then
    if(trim(adjustl(td_current_density_output_format))=="default") then
      write(log_file,*) "only td_current_density_output_format=bov is supported"
	  stop
    elseif(trim(adjustl(td_current_density_output_format))=="bov") then
      !in case of the "bov" format we will be writing each current density snapshot in a new file
      !so nothing really can be opened here
    endif
  endif

  open(orbitals_file,file=trim(adjustl(orbitals_filename)))
  open(orbital_energy_components_file,file=trim(adjustl(orbital_energy_components_filename)))
  if(output_inner_product) open(projection_file,file=trim(adjustl(projection_filename)))

  if (n_time_steps>=offdiag_elem_check_frequency) then
    open(offdiag_elem_file,file=trim(adjustl(offdiag_elem_filename)),status='replace')
  endif
  open(iteration_file, file=trim(adjustl(iteration_filename)))
  write(iteration_file,*) 0,0.0d0
end subroutine open_files

subroutine close_files

  if(output_full_td_density.AND.(trim(adjustl(td_density_output_format))=="default")) then
    close(td_total_density_file)
  endif

  if(output_full_td_current_density.AND.(trim(adjustl(td_current_density_output_format))=="default")) then
    close(td_total_current_density_file)
  endif

  close(pseudopotential_log_file)
  close(eigenvalues_file)

  close(orbitals_file)
  close(orbital_energy_components_file)
!  close(transport_1d_device_density_file)
!  close(hamiltonian_wavefn_periodic_file)

 if (move_atoms) then
   if (moldyn_output_level>0) close(mol_dynamics_file)
   if (save_trajectory) close(trajectory_file)
 endif

 if(output_inner_product) close(projection_file) !Arthur

  if (n_time_steps>=offdiag_elem_check_frequency) then
    close(offdiag_elem_file)
  endif
  close(iteration_file)

  close(timing_file)
  close(log_file)

end subroutine close_files

subroutine calculate

  if(run_type==14) then
    if(MPI_master) then
	  write(log_file,*) "run_type=14 not yet supported."
	  stop
    end if
	call dft_grid
  else if(run_type==24) then
    call tddft_grid
  else
    write(log_file,*) "Unsupported run_type"
  endif
end subroutine calculate

subroutine dft_grid
  real*8 :: mixer_beta_backup,mixer_beta_max_backup

  call init_grid

  if(continuation) then
    if(combine_gs) then
	  call input_psi_combined
	else
      call input_psi
	end if
  else
    if (init_random) then 
      call initial_random_wavefunction
    else
      write(log_file,*) "solve using WF with Gaussians not supported"
	  STOP
    endif
  endif

  ! this seems to be needed to keep solutions from blowing up
  mixer_ninit = 35

    if(spin_polarized) then
      write(6,*)'???'
      call solve_grid_spin_polarized(N_scf_iter_max)
    else
      call solve_grid(N_scf_iter_max)
    endif

  write(log_file,*)"OUTPUTTING PSI"
  call output_psi
  call output_scf
  write(log_file,*)"PSI OUTPUT FINISHED"
  if (calculate_forces.and.(.not.periodic)) then
    call save_forces_r()
    call save_dipole_moment()
  endif
  if(output_orbitals) call save_real_orbitals()
  
  write(log_file,*)" ----------- END DFT_GRID ----------- "
end subroutine dft_grid

subroutine tddft_grid
 integer :: k1min,k1max,k2min,k2max,k3min,k3max
    k1min=N_Lattice_min(1)
   k1max=N_Lattice_max(1)
   k2min=N_Lattice_min(2)
   k2max=N_Lattice_max(2)
   k3min=N_Lattice_min(3)
   k3max=N_Lattice_max(3)
  ! time propagation of the wave function on a grid
  ! this calculation preceded by a self consistent ground state
  ! calculation which produced self consistent potential and density
  if(MPI_master) then
    !call init_grid ! real arrays are not really needed only Psi real to load GS.
	allocate(wphi(k1min-Nd-1:k1max+Nd,k2min-Nd-1:k2max+Nd,k3min-Nd-1:k3max+Nd))
    wphi=0.0d0
	allocate(Psi(N_lattice_points,N_total_orbitals))
    if(combine_gs) then
	  call input_psi_combined
	else
      call input_psi
	end if
  end if

  call taylor_time_evolution
  if(MPI_master) then
    call output_psi
    call output_scf
  end if
end subroutine tddft_grid


! cody optimize geometry on grid
subroutine optimize_geometry_grid
! run_type==77
   integer  :: i,atom,j
   real*8   :: atom_displacement,max_atom_force,iter,max_atom_disp
   
   write(log_file,*) 'BEGIN OPTIMIZATION PROCEDURE'
   write(log_file,*) 'Number of steps = ',N_opt_grid_steps
   write(log_file,*) '(max) step size factor=',opt_grid_step_size
   write(log_file,*) 'force scale parameter=',opt_grid_force_k
   call dft_grid ! use dft grid to set everything up
   write(log_file,*) ' Initial SCF cycle complete'
   call init_optimization
   do i=1,N_opt_grid_steps
     write(log_file,*) 'START OPT STEP',i
     call background()
	 write(log_file,*) 'setup pseudopotential'
     call create_pseudo_potential() 
	 write(log_file,*) 'Local pseudopotential'
     call local_pseudo_potential()  
	 write(log_file,*) 'ion-ion ENE'
     call ion_ion_energy()
   
   
     Psi_c=Psi ! calculate force uses complex psi
     write(log_file,*) 'OPT iter=',i
	 write(log_file,*) 'calculate force'
     call calculate_force
	 if(printf_and_quit) then
	    call print_ion_forcesTofile(0,0.d0)
        call output_psi
        call output_scf
		write(log_file,*) 'forces printed.'
		return
	 end if 
	 max_atom_force=0.d0
	 max_atom_disp=0.d0
     do atom=1,N_total_atom
	    do j=1,3
		   atom_displacement=opt_grid_step_size*force(j,atom)/opt_grid_force_k
		   if(abs(atom_displacement) > opt_grid_step_size) atom_displacement=opt_grid_step_size*force(j,atom)/abs(force(j,atom))
		   write(log_file,*) 'Atom ',atom,' DIR=',j,' F=',force(j,atom)
		   write(log_file,*) 'Atom ',atom,' DIR=',j,' D=',atom_displacement
		   Position(j,atom)=Position(j,atom)+atom_displacement
		   if(abs(force(j,atom)) > max_atom_force) max_atom_force=abs(force(j,atom))
		   if(abs(atom_displacement) > max_atom_disp) max_atom_disp=abs(atom_displacement)
		end do
	 end do
	 write(log_file,*) 'Max Force=',max_atom_force
	 write(log_file,*) 'Max Displacement=',max_atom_disp

       if(spin_polarized) then
         call solve_grid_spin_polarized(N_scf_iter_max)
       else
         call solve_grid(N_scf_iter_max)
       endif

	 iter=0.d0
	 call update_trajectory_file(i,iter)
	 write(log_file,*) 'OPT iter=',i,' Energy=',Energy
   end do
   close(trajectory_file)
   open(trajectory_file,file="final_crd.xyz")
   call update_trajectory_file(i,iter)
   call output_psi
   call output_scf
end subroutine optimize_geometry_grid

subroutine init_optimization
   write(log_file,*) 'Initialize arrays needed to calculate forces'
   call taylor_time_init_ALL
   if(MPI_master) call taylor_time_init_MASTER
   call init_molecular_dynamics
   if(.not.allocated(force)) allocate(force(3,N_total_atom))
   if(.not.allocated(Psi_c)) allocate(Psi_c(N_lattice_points,N_orbitals))
   if(.not.allocated(grad_density)) allocate(grad_density(3,N_lattice_points))
end subroutine init_optimization


subroutine print_grid_info
  complex*16, dimension(:,:,:),allocatable :: wfn
  real*8,    dimension(:,:,:),allocatable :: wfnR
  character(255) :: fname1
  integer        :: i,i1,i2,i3,k,j
  real*8         :: get_r1(3)
  
  !allocate(wfn(N_L(1),N_L(2),N_L(3)))
  allocate(wfnR(N_Lattice(1),N_Lattice(2),N_Lattice(3)))
  
  call dft_grid
  
!  do i=1,N_lattice_points
!    i1=Lattice(1,i)+1
!    i2=Lattice(2,i)+1
!    i3=Lattice(3,i)+1
!    wfn(i1,i2,i3)=Psi(i)
!  enddo	
!  fname1="mapped_psi.dat"
!  open(199,file=trim(adjustl(fname1)),form='unformatted',status='replace',action='write')
!  write(199) wfn
!  close(199)
  if(spin_polarized) then
	write(log_file,*) 'mode 78 does not yet support spin polarization'
	stop
  end if
  if(.NOT.allocated(density)) allocate(density(N_lattice_points))
  if(.NOT.allocated(full_density_save)) allocate(full_density_save(N_lattice_points))
  allocate(Psi_c(N_lattice_points,N_total_orbitals))
  Psi_c=Psi
  call calculate_rho_grid
!  do k=1,N_orbitals
!    do i=1,N_lattice_points
!      density(i)=density(i)+(real(Psi_c(j,k))**2+imag(Psi_c(j,k))**2)*occ_k
!    enddo  
!  end do
  fname1="unmapped_density.dat"
  open(199,file=trim(adjustl(fname1)),form='unformatted',status='replace',action='write')
  write(199) density
  close(199)  
  
  write(*,*) 'load into 3D matrix ',N_Lattice(1),N_Lattice(2),N_Lattice(3)
  do i=1,N_lattice_points
    i1=Lattice(1,i)
    i2=Lattice(2,i)
    i3=Lattice(3,i)
	!write(*,*) 'i1=',i1,' i2=',i2,' i3=',i3,' D=',density(i)
    wfnR(i1,i2,i3)=density(i)
  enddo	
  write(*,*) 'save'
  fname1="mapped_density.dat"
  open(199,file=trim(adjustl(fname1)),form='unformatted',status='replace',action='write')
  write(199) wfnR
  close(199)  
  fname1="xpoints.dat"
  open(199,file=trim(adjustl(fname1)),form='unformatted',status='replace',action='write')
  do i=1,N_lattice_points
     write(199) grid_point(1,i)
  end do
  close(199)  
  fname1="xpoints_map.dat"
  open(199,file=trim(adjustl(fname1)),form='unformatted',status='replace',action='write')
  do i=1,N_lattice(1)
     write(199) xgrid(i)
  end do
  close(199)  

  
  fname1="ypoints.dat"
  open(199,file=trim(adjustl(fname1)),form='unformatted',status='replace',action='write')
  do i=1,N_lattice_points
     write(199) grid_point(2,i)
  end do
  close(199)
  fname1="ypoints_map.dat"
  open(199,file=trim(adjustl(fname1)),form='unformatted',status='replace',action='write')
  do i=1,N_lattice(2)
     write(199) ygrid(i)
  end do
  close(199)  

  fname1="zpoints.dat"
  open(199,file=trim(adjustl(fname1)),form='unformatted',status='replace',action='write')
  do i=1,N_lattice_points
     write(199) grid_point(3,i)
  end do
  close(199)  
  fname1="zpoints_map.dat"
  open(199,file=trim(adjustl(fname1)),form='unformatted',status='replace',action='write')
  do i=1,N_lattice(3)
     write(199) zgrid(i)
  end do
  close(199)  
  
  fname1="xyz_points.dat"
  open(199,file=trim(adjustl(fname1)),form='unformatted',status='replace',action='write')
  write(199) grid_point
  close(199)  
  
  !if(.not.allocated(Psi_c)) allocate(Psi_c(N_lattice_points,N_total_orbitals))
  !Phi_c=Psi
  do i=1,N_total_orbitals
    write(log_file,*) 'save orbital ',i
    call output_positive_neg_psi_c(i,0)
  enddo
  
  write(log_file,*) "expectation values of X,Y,Z"
  
  do i=1,N_total_orbitals
    get_r1=0.d0
    do j=1,N_lattice_points
      get_r1(1)=get_r1(1)+Grid_Point(1,j)*Psi(j,i)**2
	  get_r1(2)=get_r1(2)+Grid_Point(2,j)*Psi(j,i)**2
	  get_r1(3)=get_r1(3)+Grid_Point(3,j)*Psi(j,i)**2
    enddo
	 get_r1(1)=get_r1(1)*grid_volume
	 get_r1(2)=get_r1(2)*grid_volume
	 get_r1(3)=get_r1(3)*grid_volume
     write(log_file,'(i4,3ES20.10E3)') i,get_r1(1:3)
  
  end do
  
  stop
end subroutine print_grid_info


! cody
subroutine print_lattice_info
implicit none
  character(255) :: fname1
  integer        :: i
 
  fname1="xpoints_map.dat"
  open(199,file=trim(adjustl(fname1)),form='unformatted',status='replace',action='write')
  do i=1,N_lattice(1)
     write(199) xgrid(i)
  end do
  close(199)  

  fname1="ypoints_map.dat"
  open(199,file=trim(adjustl(fname1)),form='unformatted',status='replace',action='write')
  do i=1,N_lattice(2)
     write(199) ygrid(i)
  end do
  close(199)  

  fname1="zpoints_map.dat"
  open(199,file=trim(adjustl(fname1)),form='unformatted',status='replace',action='write')
  do i=1,N_lattice(3)
     write(199) zgrid(i)
  end do
  close(199)  

  fname1="xpoints_map.txt"
  open(199,file=trim(adjustl(fname1)),form='formatted',status='replace',action='write')
  do i=1,N_lattice(1)
     write(199,*) xgrid(i)
  end do
  close(199)  

  fname1="ypoints_map.txt"
  open(199,file=trim(adjustl(fname1)),form='formatted',status='replace',action='write')
  do i=1,N_lattice(2)
     write(199,*) ygrid(i)
  end do
  close(199)  

  fname1="zpoints_map.txt"
  open(199,file=trim(adjustl(fname1)),form='formatted',status='replace',action='write')
  do i=1,N_lattice(3)
     write(199,*) zgrid(i)
  end do
  close(199)  
  
  fname1="xyz_points.dat"
  open(199,file=trim(adjustl(fname1)),form='unformatted',status='replace',action='write')
  write(199) grid_point
  close(199)  

  fname1="N_Lattice_MinMax.txt"
  open(199,file=trim(adjustl(fname1)),form='formatted',status='replace',action='write')
  write(199,*) N_Lattice_min(1),N_Lattice_max(1)
  write(199,*) N_Lattice_min(2),N_Lattice_max(2)
  write(199,*) N_Lattice_min(3),N_Lattice_max(3)
  close(199)    
  
  ! Lattice_inv_xyz array
  fname1="Lattice_inv_xyz.dat"
  open(199,file=trim(adjustl(fname1)),form='unformatted',status='replace',action='write')
  write(199) Lattice_inv_xyz
  close(199)    

end subroutine print_lattice_info

subroutine cleanup
  write(log_file,'(2a)')"Run finished: ",trim(adjustl(timestamp()))
  if(run_type/=1) call close_files
end subroutine cleanup



subroutine make_communicator_nlpp
implicit none
integer :: world_group, new_group
integer,allocatable :: ranks_to_include(:)
integer :: num_ranks_to_include,i,new_rank,new_size

  allocate(ranks_to_include(MPI_num_proc-1))
  if(MPI_num_proc<2) then
    write(log_file,*) "must have more than 1 process to use split_up_gen_nlpp"
	stop
  end if
  
  write(log_file,*) "create comm group"
  call MPI_Comm_group(MPI_COMM_WORLD, world_group, MPI_ierror)
  if (MPI_ierror /= MPI_SUCCESS) then
    write(log_file,*) "error in MPI comm grouping"
	stop
  end if
  
  num_ranks_to_include=MPI_num_proc-1 
  ! remember rank starts at 0
  MPI_nlpp_process=MPI_num_proc-1 ! last process is the one that will calculate the nl PP stuff
  do i=0,MPI_num_proc-2
    ranks_to_include(i+1)=i 
  end do
  
  call MPI_Group_incl(world_group, num_ranks_to_include, &
                           ranks_to_include(1:num_ranks_to_include), &
                           new_group, MPI_ierror)
  if (MPI_ierror /= MPI_SUCCESS) then
    write(log_file,*) "Error in MPI_Group_incl"
    stop
  end if
  
  write(log_file,*) "Create taylor communicator"
  call MPI_Comm_create(MPI_COMM_WORLD, new_group, taylor_time_communicator, MPI_ierror)
  if (MPI_ierror /= MPI_SUCCESS) then
    write(log_file,*) "Error in MPI_Comm_create"
    stop
  end if
  
 if (taylor_time_communicator /= MPI_COMM_NULL) then
      call MPI_Comm_rank(taylor_time_communicator, new_rank, MPI_ierror)
      call MPI_Comm_size(taylor_time_communicator, new_size, MPI_ierror)
      write(log_file,*) "Process ", MPI_proc_rank, " (world) is rank ", new_rank, &
               " of ", new_size, " in taylor_time_communicator"
  else
      write(log_file,*) "Process ", MPI_proc_rank, " (world) is not in the taylor_time_communicator"
	  MPI_nlpp_slave=.TRUE.
  end if
  
end subroutine make_communicator_nlpp


END MODULE MAIN

PROGRAM DFT
  USE MAIN
  implicit none
  integer :: iargc,num_args,i
  character*4 :: ch4
  LOGICAL :: log_file_exists,log_file_exists2
  
  call MPI_INIT(MPI_ierror)
  ! Process command-line arguments
  control_input_filename="control.inp" ! default
  num_args=iargc()
  if((num_args/=0).AND.(num_args/=1))then
    write(6,*); write(6,*)" Usage: dft [control_input_filename]"; write(6,*)
    stop
  elseif(num_args==1) then
    call getarg(1,control_input_filename)
  endif

  
  call MPI_COMM_SIZE(MPI_COMM_WORLD, MPI_num_proc,MPI_ierror)
  call MPI_COMM_RANK(MPI_COMM_WORLD, MPI_proc_rank,MPI_ierror)
  
  if(MPI_proc_rank==0) then
    MPI_master=.TRUE.
	call parse_quick(trim(adjustl(control_input_filename)))
	
	  !INQUIRE(FILE=trim(adjustl(log_output_filename)), EXIST=log_file_exists)
    log_output_filename="monitor.out"
  else
    write(ch4,'(i4.4)') MPI_proc_rank
    write(log_output_filename,'(a,a,a)') "monitor.proc",ch4,".out"
  end if
  
  INQUIRE(FILE=trim(adjustl(log_output_filename)), EXIST=log_file_exists)
  INQUIRE(FILE=trim(adjustl(restart_file_name)), EXIST=log_file_exists2)
  
  if(smart_restart_detect.AND.log_file_exists2) then
    resume_from_restart_taylor=.TRUE.
	do_not_overwrite=.TRUE.
	change_name_monitor=.TRUE.
	append_or_overwrite=.TRUE.
  end if
  
  call MPI_BCAST(resume_from_restart_taylor,1,MPI_LOGICAL   ,0,MPI_COMM_WORLD,MPI_ierror)
  call MPI_BCAST(do_not_overwrite,1,MPI_LOGICAL   ,0,MPI_COMM_WORLD,MPI_ierror)
  call MPI_BCAST(change_name_monitor,1,MPI_LOGICAL   ,0,MPI_COMM_WORLD,MPI_ierror)
  call MPI_BCAST(split_up_gen_nlpp,1,MPI_LOGICAL   ,0,MPI_COMM_WORLD,MPI_ierror)
  
  if((do_not_overwrite).AND.(log_file_exists)) then 
    if((change_name_monitor).AND.(MPI_master)) then
	  log_output_filename="monitor.out.restart_intro"
	  log_file_exists2=.TRUE.
	  i=1
	  do WHILE (log_file_exists2) 
        write(ch4,'(i4.4)') i
        write(log_output_filename,'(a,a)') "monitor.out.restart_intro",ch4
		INQUIRE(FILE=trim(adjustl(log_output_filename)), EXIST=log_file_exists2)
		i=i+1
		write(*,*) trim(adjustl(log_output_filename))," exists try ",i
	  end do
	  open(log_file,file=trim(adjustl(log_output_filename))) ! open it with a different name
	else
	  ! do not overwrite, but do not alter name either, just append.
	  open(log_file,file=trim(adjustl(log_output_filename)), status="old", position="append", action="write")
	end if
  else  
    open(log_file,file=trim(adjustl(log_output_filename)))
  end if
  
  write(log_file,*) "MPI PROCESS ",MPI_proc_rank," out of ",MPI_num_proc
  
  ! set up communicators
  ! nl_pp split Setup
  write(log_file,*) "Setup communicators"
  write(*,*) "Setup communicators"
  if(split_up_gen_nlpp) then
    call make_communicator_nlpp
  else
    call MPI_Comm_dup(MPI_COMM_WORLD, taylor_time_communicator, MPI_ierror)
    if (MPI_ierror /= MPI_SUCCESS) then
      write(log_file,*) "could not create taylor_time_communicator"
      stop
    end if
	! the master will do the nl_pp stuff
	MPI_nlpp_process=0
  end if
  
  do i = 0, MPI_num_proc-1
    if(i == MPI_proc_rank) then
        call initialize
    end if
    call MPI_BARRIER( MPI_COMM_WORLD, MPI_ierror)
  enddo
  
  if(xc_functional_mode==4 .OR. xc_functional_mode==5 .OR. xc_functional_mode==7) then
    if(MPI_num_proc>2) then
      MPI_xc_process=1
	else
	  MPI_xc_process=0
	end if
  else
    MPI_xc_process=0
  end if
  if(MPI_proc_rank==MPI_xc_process) then
    MPI_xc_slave=.TRUE.
	write(log_file,*) "This process is the MPI_xc_slave"
  end if
  if(MPI_master) write(log_file,*) "Process",MPI_xc_process," will do xc calc"
  
  call calculate
  call cleanup
  
  call MPI_FINALIZE(MPI_ierror)
  
END PROGRAM DFT

