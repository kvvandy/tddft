MODULE MOD_LATTICE
  use parameters
  USE MOD_GLOBAL
  USE WORKPROCS
  USE MOD_IO
  implicit none

CONTAINS

SUBROUTINE setup_rectangular_lattice
integer :: i,k,k1,k2,k3,num_i,num_o,j,i1,i2,i3,kk2,atom,it,jt,grid,N(3),pair,l,m
integer :: ss,s1,s2,s3,bs,b1,b2,b3,m1,m2,m3,k1min,k1max,k2min,k2max,k3min,k3max
integer :: j1,j2,j3,t1,t2,t3,v1,v2,v3,w1,w2,w3
integer :: mem
real*8  :: x,y,z,r
logical :: pnf
N(:)=N_Lattice(:)
Grid_Volume=Grid_step(1)*grid_step(2)*grid_step(3)
N_lattice_points=N(1)*N(2)*N(3)
R_size(:)=(N(:)-1)*grid_step(:)*0.5d0
if(periodic) R_size(:)=N(:)*grid_step(:)*0.5d0
write(log_file,*)'Box size',2.d0*R_size



allocate(Lattice(3,N_lattice_points))
allocate(Lattice_inv_xyz(N(1),N(2),N(3)))
!allocate(Lattice_inv_yzx(N(2),N(3),N(1)))
!allocate(Lattice_inv_zxy(N(3),N(1),N(2)))
allocate(Grid_point(3,N_lattice_points))

mem=3*N_lattice_points + N(1)*N(1) + N(2)*N(2) + N(3)*N(3) + 4*(N(1)+N(2)+N(3))


allocate(tm1(N(1),N(1)),tm2(N(2),N(2)),tm3(N(3),N(3)))
allocate(xr1(N(1)),xr2(N(2)),xr3(N(3)))
allocate(wr1(N(1)),wr2(N(2)),wr3(N(3)))

if(grid_type==1) then
  call finite_diff(N(1),-R_size(1),R_size(1),xr1,wr1,tm1)
  call finite_diff(N(2),-R_size(2),R_size(2),xr2,wr2,tm2)
  call finite_diff(N(3),-R_size(3),R_size(3),xr3,wr3,tm3)
  N_gc(1)=Nd
  N_gc(2)=Nd
  N_gc(3)=Nd
endif
if(grid_type==2) then
  call sin_cardinal(N(1),-R_size(1),R_size(1),xr1,wr1,tm1)
  call sin_cardinal(N(2),-R_size(2),R_size(2),xr2,wr2,tm2)
  call sin_cardinal(N(3),-R_size(3),R_size(3),xr3,wr3,tm3)
endif
if(grid_type==3) then
  call sinc_basis(N(1),-R_size(1),R_size(1),xr1,wr1,tm1)
  call sinc_basis(N(2),-R_size(2),R_size(2),xr2,wr2,tm2)
  call sinc_basis(N(3),-R_size(3),R_size(3),xr3,wr3,tm3)
  N_gc(1)=min(5,N(1))
  N_gc(2)=min(5,N(2))
  N_gc(3)=min(5,N(3))
endif
!  Grid_Volume=(xr1(2)-xr1(1))*(xr2(2)-xr2(1))*(xr3(2)-xr3(1))

tm1=-h2m*tm1
tm2=-h2m*tm2
tm3=-h2m*tm3

allocate(xgrid(N(1)),ygrid(N(2)),zgrid(N(3)))
k1min=1
k1max=N_Lattice(1)
k2min=1
k2max=N_Lattice(2)
k3min=1
k3max=N_Lattice(3)

if(.NOT.no_crappy_mapping) then

 ss=map_subblock_size
 bs=map_block_size
 b1=N(1)/bs; if (mod(N(1),bs)>0) b1=b1+1
 b2=N(2)/bs; if (mod(N(2),bs)>0) b2=b2+1
 b3=N(3)/bs; if (mod(N(3),bs)>0) b3=b3+1
 
 if(MPI_master) open(9090,file="lattice_mapping_block_info.txt",status='replace',action='write')
 if(MPI_master) write(9090,*) "map_subblock_size"
 if(MPI_master) write(9090,*) map_subblock_size
 if(MPI_master) write(9090,*) "map_block_size"
 if(MPI_master) write(9090,*) map_block_size
 if(MPI_master) close(9090)
 write(log_file,*) "map_subblock_size",map_subblock_size
 write(log_file,*) "map_block_size",map_block_size

 num_i=0
 do i1=1,b1
  m1=min(k1min-1+i1*bs,k1max)            !m1 - last elements of current block  
  t1=m1-(k1min-1+(i1-1)*bs)              !t1 - number of elements of current block
  s1=t1/ss; if (mod(t1,ss)>0) s1=s1+1    !s1 - number of subblocks in current block
  do i2=1,b2
    m2=min(k2min-1+i2*bs,k2max)
    t2=m2-(k2min-1+(i2-1)*bs)
    s2=t2/ss; if (mod(t2,ss)>0) s2=s2+1
    do i3=1,b3
      m3=min(k3min-1+i3*bs,k3max)
      t3=m3-(k3min-1+(i3-1)*bs)
      s3=t3/ss; if (mod(t3,ss)>0) s3=s3+1
      do j1=1,s1
        v1=k1min+(i1-1)*bs+(j1-1)*ss       !v1 - first element in the current subblock
        w1=k1min-1+(i1-1)*bs+min(j1*ss,t1) !w1 - last element in the current subblock
        do j2=1,s2
          v2=k2min+(i2-1)*bs+(j2-1)*ss
          w2=k2min-1+(i2-1)*bs+min(j2*ss,t2)
          do j3=1,s3
            v3=k3min+(i3-1)*bs+(j3-1)*ss
            w3=k3min-1+(i3-1)*bs+min(j3*ss,t3)          
            do k1=v1,w1  
              do k2=v2,w2
                do k3=v3,w3                    
                  num_i=num_i+1
                  Lattice(1,num_i)=k1-1
                  Lattice(2,num_i)=k2-1
                  Lattice(3,num_i)=k3-1
                  Lattice_inv_xyz(k1,k2,k3)=num_i
                  !Lattice_inv_yzx(k2,k3,k1)=num_i
                  !Lattice_inv_zxy(k3,k1,k2)=num_i

                    grid_point(1,num_i)=xr1(k1)
                    grid_point(2,num_i)=xr2(k2)
                    grid_point(3,num_i)=xr3(k3)
                    xgrid(k1)=xr1(k1)
                    ygrid(k2)=xr2(k2)
                    zgrid(k3)=xr3(k3)
                   
                enddo
              enddo
            enddo
          enddo
        enddo
      enddo  
    enddo
  enddo
 enddo
else
  write(log_file,*) "mapping of lattice has been turned off."
  write(log_file,*) "Generating lattice"
  num_i=0
  do k1=1,k1max
    do k2=1,k2max
      do k3=1,k3max
        num_i=num_i+1
        Lattice(1,num_i)=k1-1
		Lattice(2,num_i)=k2-1
		Lattice(3,num_i)=k3-1
		Lattice_inv_xyz(k1,k2,k3)=num_i
		!Lattice_inv_yzx(k2,k3,k1)=num_i
		!Lattice_inv_zxy(k3,k1,k2)=num_i
                    grid_point(1,num_i)=xr1(k1)
                    grid_point(2,num_i)=xr2(k2)
                    grid_point(3,num_i)=xr3(k3)
                    xgrid(k1)=xr1(k1)
                    ygrid(k2)=xr2(k2)
                    zgrid(k3)=xr3(k3)
      end do
    end do
  end do  
end if
 
N_lattice_min(1)=k1min
N_Lattice_max(1)=k1max
N_lattice_min(2)=k2min
N_Lattice_max(2)=k2max
N_lattice_min(3)=k3min
N_Lattice_max(3)=k3max

if(MPI_master) then
  write(log_file,*)'Lattice points in the x direction'
  do k1=1,N(1)
    write(log_file,*)k1,xgrid(k1)
  end do
  write(log_file,*)'Lattice points in the y direction'
  do k1=1,N(2)
    write(log_file,*)k1,ygrid(k1)
  end do
  write(log_file,*)'Lattice points in the z direction'
  do k1=1,N(3)
    write(log_file,*)k1,zgrid(k1)
  end do
endif

END SUBROUTINE setup_rectangular_lattice

function truncdown(r)
real(8) r
integer truncdown,i
i=int(r)
if ((r>=0.0d0).or.(r-i==0.0d0)) then
  truncdown=i
else
  truncdown=-int(-r+1.0d0)
endif
end function truncdown


function truncup(r)
real(8) r
integer truncup,i
i=int(r)
if ((r<0.0d0).or.(r-i==0.0d0)) then
  truncup=i
else
  truncup=int(r+1.0d0)
endif
end function truncup


subroutine save_lattice_view_on_disk()
integer k1,k2,k3,k1min,k1max,k2min,k2max,k3min,k3max,dk1,dk2,dk3,ind
k1min=N_Lattice_min(1)
k1max=N_Lattice_max(1)
k2min=N_Lattice_min(2)
k2max=N_Lattice_max(2)
k3min=N_Lattice_min(3)
k3max=N_Lattice_max(3)
dk1=(k1max-k1min+1)
dk2=(k2max-k2min+1)
dk3=(k3max-k3min+1)
!Store actual data in binary form (3D array needs to have its dimension order changed, linearized, and
!converted to single precision)
ind=0
do k3=k3min,k3max
  do k2=k2min,k2max
    do k1=k1min,k1max
      ind=ind+1
      if (Lattice_inv_xyz(k1,k2,k3)>0) then
        sing_prec_rearranged_density(ind)=1.0
      else
        sing_prec_rearranged_density(ind)=0.0
      endif
    enddo
  enddo
enddo
open(lattice_view_datfile,file=trim(adjustl(lattice_view_datfilename)),form='unformatted',status='replace')
write(lattice_view_datfile) sing_prec_rearranged_density
close(lattice_view_datfile)
!Now create a header file corresponding to the above datafile. The header file
!is in ascii text form
open(lattice_view_bovfile,file=trim(adjustl(lattice_view_bovfilename)),status='replace')
write(lattice_view_bovfile,'(1x,a,1x,es23.15)') 'TIME:',0.0d0
write(lattice_view_bovfile,'(1x,a,1x,a)') 'DATA_FILE:',trim(adjustl(lattice_view_datfilename))
write(lattice_view_bovfile,'(1x,a,3(1x,i6))') 'DATA_SIZE:',dk1,dk2,dk3
write(lattice_view_bovfile,'(1x,a)') 'DATA_FORMAT:  FLOAT'
write(lattice_view_bovfile,'(1x,a)') 'VARIABLE:  lattice_map'
write(lattice_view_bovfile,'(1x,a)') 'DATA_ENDIAN:  LITTLE'
write(lattice_view_bovfile,'(1x,a)') 'CENTERING:  zonal'
write(lattice_view_bovfile,'(1x,a,3(1x,es23.15))') 'BRICK_ORIGIN:',k1min*grid_step(1),k2min*grid_step(2),k3min*grid_step(3)
write(lattice_view_bovfile,'(1x,a,3(1x,es23.15))') 'BRICK_SIZE:',dk1*grid_step(1),dk2*grid_step(2),dk3*grid_step(3)
write(lattice_view_bovfile,'(1x,a)') 'BYTE_OFFSET: 4'
close(lattice_view_bovfile)
end subroutine save_lattice_view_on_disk


SUBROUTINE setup_lattice
  integer       :: i,k,k1,k2,k3,num_i,num_o,j,i1,i2,i3,kk2,atom,it,jt,grid,N(3),pair,l,m,num_mr
  integer       :: memrq
  real*8        :: xx,c1,c2,dr1,dr2,c,x,y,z,xl,xr,yr,yl,dr,xlb,xrb,sphrad2,dist2,captmp1,captmp2
  real*8        :: x_min,x_max,xstart1,xstart2,xstop1,xstop2
  character*255 :: temp

  call setup_rectangular_lattice

  i1=N_Lattice_max(1)-N_Lattice_min(1)+1
  i2=N_Lattice_max(2)-N_Lattice_min(2)+1
  i3=N_Lattice_max(3)-N_Lattice_min(3)+1
  i=i1*i2*i3
  if (save_lattice_view.or.output_full_td_density) then
    allocate(sing_prec_rearranged_density(i))
  endif
  if (output_full_td_current_density) then
    allocate(sing_prec_rearranged_current_density(3*i))
  endif
  if (output_tot_td_pot) then
    allocate(v_total_3d(N_Lattice_points))
    allocate(sing_prec_rearranged_potential(N_Lattice_points))
  endif

  !Saving the lattice view (big enclosing rectangular box showing where the actual
  !points are; useful for nonrectangular box_type)
  !The rearranged array with the map is stored in Bov/dat format (bricks of data) which
  !can easily be read by VisIt software.
  if (save_lattice_view) then
    call save_lattice_view_on_disk()
    if (.not.output_full_td_density) deallocate(sing_prec_rearranged_density)
  endif

  x=dfloat(N_Lattice_points)/i
  !Print the total number of actual lattice points, the number of lattice
  !points in the enclosing rectangular box, and the fill factor
  write(log_file,'(1x,a,i8,1x,i8,1x,f7.3)') &
       'N_lattice_points, N_rectang_points, ratio: ',N_Lattice_points,i,x
  write(log_file,*) 'Enclosing rectangular box size (points): ',i1,i2,i3
  write(log_file,'(1x,a,3(1x,f8.3))') 'Enclosing rectangular box size (Angstroms): ', &
       (i1-1)*grid_step(1),(i2-1)*grid_step(2),(i3-1)*grid_step(3)
  write(log_file,*) 'Grid_volume: ',Grid_volume
  write(log_file,*) 'map_block_size: ',map_block_size

  num_mr=size(mr)
  write(log_file,*)"Number of measurement regions: ",num_mr
  do i=1,num_mr
    if(user_set_xmr(i)==1) then
      mr(i)=int((xmr(i)-grid_point(1,1))/grid_step(1))
    else ! default is to just equally space the measurement regions
      mr(i)=int(dfloat(i*N_Lattice(1))/dfloat(num_mr+1))
      if(mr(i)==0) mr(i)=1
      xmr(i)=grid_point(1,1)+(mr(i)-1)*grid_step(1)
    endif
    write(temp,*)i
    write(log_file,'(1x,5a,F16.8,i7)')"xmr(",trim(adjustl(temp)),"), mr(",trim(adjustl(temp)),")=",xmr(i),mr(i)
  enddo

  do i=1,num_mr
    if ((mr(i)<1).OR.(mr(i)>N_Lattice(1))) then
      write(log_file,*) 'Error in setup_lattice: measurement region ',i,'  lies'
      write(log_file,*) 'outside of the simulation box.'
      stop
    endif
  enddo

  i=N_lattice_points
  memrq = 18*N_lattice_points + N_species
  allocate(VH(i),VH_bg(i),Rho_bg(i),Density(i),new_density(i),old_Density(i))
  allocate(atomic_density(i),V_Hartree(i),V_Exchange(i),V_nl_pp(i),grad_density(3,i))
  allocate(V_l_pp(i),VEH(i),Phi(i),H_Phi(i),wf_rad(N_species),V_td(i))
  density=0.d0

  if(spin_polarized) then
    memrq=memrq+6*N_lattice_points
    allocate(V_exchange_down(i),V_Exchange_up(i),density_up(i),density_down(i))
    allocate(density_up_new(i),density_down_new(i))
	  if(output_full_td_current_density) then
  	  allocate(current_density_up(3,i),current_density_down(3,i))
      current_density_up=0.d0
      current_density_down=0.d0
	  endif
  else
    if(output_full_td_current_density.OR.output_td_current_cell_sum.OR.output_td_current_atom_sum) then
      allocate(current_density(3,i))
      current_density=0.d0
    endif
  endif


  if((laser1_start_x>xgrid(N_Lattice_max(1))).OR.(laser1_end_x<xgrid(N_Lattice_min(1))) &
      .OR.(abs(E_laser1)<1.d-15).OR.(abs(laser_pulse_width1)<1.d-15)) then
    using_v_laser1=.FALSE.
  else
    using_v_laser1=.TRUE.
    memrq=memrq+N_lattice_points
    allocate(V_laser1(i))
    V_laser1=0.d0
  endif

  if((laser2_start_x>xgrid(N_Lattice_max(1))).OR.(laser2_end_x<xgrid(N_Lattice_min(1))) &
      .OR.(abs(E_laser2)<1.d-15).OR.(abs(laser_pulse_width2)<1.d-15)) then
    using_v_laser2=.FALSE.
  else
    using_v_laser2=.TRUE.
    memrq=memrq+N_lattice_points
    allocate(V_laser2(i))
    V_laser2=0.d0
  endif

  if((laser3_start_x>xgrid(N_Lattice_max(1))).OR.(laser3_end_x<xgrid(N_Lattice_min(1))) &
      .OR.(abs(E_laser3)<1.d-15).OR.(abs(laser_pulse_width3)<1.d-15)) then
    using_v_laser3=.FALSE.
  else
    using_v_laser3=.TRUE.
    memrq=memrq+N_lattice_points
    allocate(V_laser3(i))
    V_laser3=0.d0
  endif

  if(abs(E_ext)<1.d-15) then
    using_v_ext=.FALSE.
  else
    using_v_ext=.TRUE.
    memrq=memrq+N_lattice_points
    allocate(V_ext(N_lattice_points))
    V_ext=0.d0
	write(log_file,*) "using constant external field ",E_ext
	write(log_file,*) "  Direction = ",e_ext_direction
  endif

 if (abs(V_step)<1.d-15) then
     using_v_step=.FALSE.
  else
     using_v_step=.TRUE.
     memrq=memrq+N_lattice_points
     allocate(V_steppot(N_lattice_points))
     V_steppot=0.d0
  endif
  
  if (using_v_fromfile) then ! cody
    memrq=memrq+(N_lattice_points * 3)
    allocate(V_laser1(i))
    V_laser1=0.d0
    allocate(V_laser2(i))
    V_laser2=0.d0
    allocate(V_laser3(i))
    V_laser3=0.d0
  endif
  
  if (run_type == 12) dipole_direction = -1

  if(dipole_direction==(-1)) then
    using_opt_pot=.FALSE.
  else
    using_opt_pot=.TRUE.

    memrq=memrq+3*N_lattice_points
    allocate(V_opt_pot(3,N_Lattice_points))
    V_opt_pot=0.d0
    sphrad2=exp_kick_radius**2
    do i=1,N_Lattice_points
      x=Grid_Point(1,i)
      y=Grid_Point(2,i)
      z=Grid_Point(3,i)
      dist2=(x-exp_kick_center_x)**2+(y-exp_kick_center_y)**2+(z-exp_kick_center_z)**2
      if (dist2<sphrad2) then
        V_opt_pot(1,i)=exp(zi*exp_kick_strength*x)
        V_opt_pot(2,i)=exp(zi*exp_kick_strength*y)
        V_opt_pot(3,i)=exp(zi*exp_kick_strength*z)
      endif
    enddo
  endif
 
  x_min=MINVAL(position(1,:))
  x_max=MAXVAL(position(1,:))
  xstart2=V_step_end+x_min
  xstart1=xstart2+buffer
  xstop2=x_max-V_step_end
  xstop1=xstop2-buffer
  do i=1,N_Lattice_points
    x=grid_point(1,i)
    y=grid_point(2,i)
    z=grid_point(3,i)
    if(using_v_ext) then
	  if(e_ext_direction==1) V_ext(i)=E_ext*x
	  if(e_ext_direction==2) V_ext(i)=E_ext*y
	  if(e_ext_direction==3) V_ext(i)=E_ext*z
	end if
    if(using_v_step) then
       if(x<xstart2) then
             V_steppot(i)=-V_step
       else if((x>=xstart2).and.(x<xstart1)) then
             V_steppot(i)=-(xstart1-x)*V_step/buffer
       else if((x>=xstart1).and.(x<=xstop1)) then
             V_steppot(i)=0
       else if ((x>xstop1).and.(x<=xstop2)) then 
             V_steppot(i)=(x-xstop1)*V_step/buffer
       else
          V_steppot(i)=V_step
       end if
    end if
    if(using_v_laser1.AND.(x>laser1_start_x).AND.(x<laser1_end_x)&
                    &.AND.(y>laser1_start_y).AND.(y<laser1_end_y)&
                    &.AND.(z>laser1_start_z).AND.(z<laser1_end_z)) V_laser1(i)=E_laser1*x
    if(using_v_laser2.AND.(x>laser2_start_x).AND.(x<laser2_end_x)&
                    &.AND.(y>laser2_start_y).AND.(y<laser2_end_y)&
                    &.AND.(z>laser2_start_z).AND.(z<laser2_end_z)) V_laser2(i)=E_laser2*y
    if(using_v_laser3.AND.(x>laser3_start_x).AND.(x<laser3_end_x)&
                    &.AND.(y>laser3_start_y).AND.(y<laser3_end_y)&
                    &.AND.(z>laser3_start_z).AND.(z<laser3_end_z)) V_laser3(i)=E_laser3*z
	 ! cody: if external field is read from file
	if(using_v_fromfile) then
	   V_laser1(i)=x
	   V_laser2(i)=y
	   V_laser3(i)=z
	endif
  enddo

  time_factor=0.d0

  if(run_type==42) then
    cap_left1=xgrid(N_Lattice(1))
  endif
  if(run_type==43) then
    cap_right1=-xgrid(N_lattice(1))
  endif

  cap_exist(1:3)=.true.
  if( (cap_left1<xgrid(N_Lattice_min(1))).AND.(cap_right1>(xgrid(N_Lattice_max(1)))) ) cap_exist(1)=.false.
  if( (cap_left2<ygrid(N_Lattice_min(2))).AND.(cap_right2>(ygrid(N_Lattice_max(2)))) ) cap_exist(2)=.false.
  if( (cap_left3<zgrid(N_Lattice_min(3))).AND.(cap_right3>(zgrid(N_Lattice_max(3)))) ) cap_exist(3)=.false.  
  
  if ((cap_exist(1)).OR.(cap_exist(2)).OR.(cap_exist(3))) then
    using_cap=.TRUE.
    memrq=memrq+2*N_lattice_points
    allocate(captotal(N_Lattice_points))
    captotal=0.0d0
  else  
    using_cap=.FALSE.    
  endif

  if(run_type==41) then
    memrq=memrq+N_lattice_points
    allocate(V_bias_pot(N_Lattice_points))
    V_bias_pot=0.d0
    k=nx_box(1)
    xlb=grid_point(1,Lattice_inv_xyz(k,1,1))
    k=k+nx_box(2)
    xrb=grid_point(1,Lattice_inv_xyz(k,1,1))
    do i=1,N_Lattice_points
      x=grid_point(1,i)
!      V_bias_pot(i)=0.5d0*V_bias*(2.d0*x-xrb-xlb)/(xrb-xlb)
      if(x<=xlb) V_bias_pot(i)=-0.5d0*V_bias
      if(x>xrb)  V_bias_pot(i)=+0.5d0*V_bias
    enddo
  endif

  if(using_cap) then
    if((box_type==1).or.(box_type==3)) then
      open(cap_file,file=trim(adjustl(cap_filename)))
      do j=1,3
        if (cap_exist(j)) then
          if (j==1) then
            c1=cap_left1
            c2=cap_right1
            write(log_file,*)'left CAP  starts at ',cap_left1        
            write(log_file,*)'right CAP  starts at ',cap_right1          
          endif  
          if (j==2) then
            c1=cap_left2
            c2=cap_right2
            write(log_file,*)'bottom CAP  starts at ',cap_left2        
            write(log_file,*)'top CAP  starts at ',cap_right2          
          endif 
          if (j==3) then
            c1=cap_left3
            c2=cap_right3
            write(log_file,*)'rear CAP  starts at ',cap_left3        
            write(log_file,*)'front CAP  starts at ',cap_right3          
          endif
          if (transport_cap) then !shenglai
              x_min=MINVAL(position(1,:))
              x_max=MAXVAL(position(1,:))
              dr1=x_min-c1-cap_parameter+cap_buffer
              dr2=x_max-c2+cap_parameter-cap_buffer
          else
          dr1=-r_size(j)-c1-cap_parameter
          dr2=r_size(j)-c2+cap_parameter
          endif 
          write(log_file,*) j,' dr1 dr2 ',dr1,dr2
          c=2.62d0
          do i=1,N_Lattice_points
            x=grid_point(j,i)
            captmp1=0.d0
            captmp2=0.d0
            xl=c*(x-c1)/dr1
            xr=c*(x-c2)/dr2
			if(abs(c-xr)<1.d-15) xr=xr+1d-10
			if(abs(c-xl)<1.d-15) xl=xl+1d-10
			if(abs(c+xr)<1.d-15) xr=xr+1d-10
			if(abs(c+xl)<1.d-15) xl=xl+1d-10
            yr=4.d0/(c-xr)**2+4.d0/(c+xr)**2-8.d0/c**2
            yl=4.d0/(c-xl)**2+4.d0/(c+xl)**2-8.d0/c**2
           if (transport_cap) then
            if((x<=c1).and.(x>=x_min+cap_buffer)) captmp1=-h2m*(2*pi/dr1)**2*yl
            if((x>=c2).and.(x<=x_max-cap_buffer)) captmp2=-h2m*(2*pi/dr2)**2*yr
            if (cap_to_edge) then
                if (huge_cap_edge) then
                  if (x<x_min+cap_buffer) captmp1=-huge(0.d0)
                  if (x>x_max-cap_buffer) captmp2=-huge(0.d0)
                 else
                  xl=c*(x_min+cap_buffer-c1)/dr1
                  xr=c*(x_max-cap_buffer-c2)/dr2
                  yr=4.d0/(c-xr)**2+4.d0/(c+xr)**2-8.d0/c**2
                  yl=4.d0/(c-xl)**2+4.d0/(c+xl)**2-8.d0/c**2
                  if (x<x_min+cap_buffer) captmp1=-h2m*(2*pi/dr1)**2*yl
                  if (x>x_max-cap_buffer) captmp2=-h2m*(2*pi/dr2)**2*yr
                 endif
             endif
             if ( ((j==1).AND.(Lattice(2,i)==1).AND.(Lattice(3,i)==1)) .OR. &
                 ((j==2).AND.(Lattice(1,i)==1).AND.(Lattice(3,i)==1)) .OR. &
                 ((j==3).AND.(Lattice(1,i)==1).AND.(Lattice(2,i)==1)) ) then
              write(cap_file,*)x,captmp1+captmp2
             endif
            captotal(i)=captotal(i)+captmp1+captmp2  
            else
            if(x<=c1) captmp1=-h2m*(2*pi/dr1)**2*yl
            if(x>=c2) captmp2=-h2m*(2*pi/dr2)**2*yr
            if ( ((j==1).AND.(Lattice(2,i)==1).AND.(Lattice(3,i)==1)) .OR. &
                 ((j==2).AND.(Lattice(1,i)==1).AND.(Lattice(3,i)==1)) .OR. &
                 ((j==3).AND.(Lattice(1,i)==1).AND.(Lattice(2,i)==1)) ) then
              write(cap_file,*)x,captmp1+captmp2
            endif
            captotal(i)=captotal(i)+captmp1+captmp2
           endif
          enddo
          write(cap_file,*)
        endif
      enddo
      close(cap_file)
    endif
    if(box_type==2) then
      c1=cap_left1
      write(log_file,*)'left CAP  starts at ',cap_left
      dr=r_size(1)-c1-cap_parameter
      c=2.62d0
      do i=1,N_Lattice_points
        x=sqrt(grid_point(1,i)**2+grid_point(2,i)**2+grid_point(3,i)**2)
        xl=c*(x-c1)/dr
        yr=4.d0/(c-xr)**2+4.d0/(c+xr)**2-8.d0/c**2
        if(x>c1) captotal(i)=captotal(i)-h2m*(2*pi/dr)**2*yl
      enddo
    endif
  endif
  
  if (using_cap.and.save_cap) then
    call save_bov_dat_real(captotal,'cap','cap')
  endif 

  Density=0.d0
  if(box_basis_type==2) then
    N_diag=sum(N_box_basis)
  else
    call input_basis
  endif

  write(log_file,*)"Gaussian basis parameters:"
  do j=1,Ng
    gauss_p(j)=1.d0/(a0*x0**(j-1))**2
    write(log_file,'(i7,ES16.8)')j,gauss_p(j)
  enddo


  allocate(atom_pairs(N_total_atom,N_total_atom))
  if(using_cap) allocate(wm(N_diag,N_diag))
  allocate(eval(n_diag))
  allocate(evec(n_diag,n_diag))
  allocate(hm(n_diag,n_diag))

  memrq=3*n_diag**2 + N_total_atom**2 + n_diag

  if (.not. cache_basis) then
     memrq=memrq+3*n_diag**2
     allocate(hm1(N_diag,N_diag))
     allocate(hm2(N_diag,N_diag))
     allocate(om0(N_diag,N_diag))
     allocate(om(n_diag,n_diag))
  end if

  memrq = memrq + 3*ng**2 + ng
  allocate(hmx(ng,ng),omx(ng,ng),vmx(ng,ng),emx(ng))

  if(using_cap) memrq=memrq+N_diag**2
  write(log_file,*)'setup_lattice  :  OK'
end subroutine setup_lattice

END MODULE MOD_LATTICE
