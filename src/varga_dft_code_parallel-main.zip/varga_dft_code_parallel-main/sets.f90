MODULE Sets

  !--------------------------------------------------------------------------
  ! History:
  ! Version 2.0.0 (980912)
  ! Version 2.0.1 (981103) Added Elements.
  ! Version 2.1.0 (981213) Operators + and -, clean-up.
  ! Version 2.1.1 (990130) Operators *, /, UNION, INTERSECTION, SYMMETRIC,
  !                        COMPLEMENT and IN.
  ! Version 2.2.0 (990306) N_Set extended. PRIVATE.
  ! 071119: Parameter wk, Random_Integer, some minor improvements.
  ! 071128: Added Sub_IS. Add_SI and Sub_SI changed due to gfortran bug.
  ! 071202: Added Max_Element, Min_Element. Extended Next_Element and gave it
  !         a correct behaviour. Dropped First_element. Improved Elements.
  ! 07128: Write_Set, Read_Set
  !               
  ! PH Lundow <phl@kth.se>
  !
  ! A module for sets of positive integers.
  !
  ! USE Sets
  ! TYPE(Set) :: a, b
  !
  ! Assignments lhs = rhs:
  !    lhs is a SET and rhs is a SET or an INTEGER-array.
  !    lhs is an INTEGER-array and rhs is a SET (see also Elements).
  !
  ! Set-operations:
  !    Union (a, b), Intersection (a, b), Symmetric (a, b) (ie symmetric
  !    difference), Complement (a), Complement (a, b) (ie relative complement
  !    or difference). The second argument of Union and Complement may be
  !    replaced with an array of INTEGERs. Alternatively, one may use the
  !    operators .UNION., .INTERSECTION., .SYMMETRIC. and .COMPLEMENT..
  !    Subroutines Add_Element and Delete_Element.
  !
  ! Set-comparisons:
  !    ==, /=, <=, <, >=, > where a <= b means that a is a subset of b and
  !    a < b means a is a proper subset of b. Instead of a <= b we may also
  !    write SubsetQ (a, b).
  !
  ! Element-wise operations:
  !    a + k and k + a returns the set {a1+k,a2+k,..,an+k}.
  !    a * k and k * a returns the set {a1*k,a2*k,..,an*k}.
  !    a - k returns the set {a1-k,a2-k,..,an-k}.
  !    k - a returns the set {k-a1,k-a2,..,k-an}.
  !    a / k returns the set {a1/k,a2/k,..,an/k}.
  !    Note that these are end-off operations. Eg, if the set a contains x
  !    then the set a+k contains x+k if and only if 1 <= x+k <= max_card.
  !
  ! Rank/Unrank-functions:
  !    Rank_Set, Rank_Subset, Rank_k_Set, Unrank_Set, Unrank_Subset and
  !    Unrank_k_Set.
  !
  ! Next-subroutines:
  !    Next_Set, Next_Subset, Next_k_Set, Next_Gray_Set
  !
  ! Random-sets:
  !    Random_Subset, Random_k_Subset
  !
  ! Other functions and subroutines:
  !    To_Set, N_Set, Cardinality, MemberQ, EmptyQ, DisjointQ, SubsetQ,
  !    Permute_Set, Elements. Also, the operator .IN. as an alternative
  !    to MemberQ (eg, 2 .IN. x tests whether 2 is a member of set x).
  !    Min_Element, Max_Element, Next_Element, Write_Set, Read_set
  !
  !
  ! Public parameters:
  !    empty_set, universal_set, max_card
  !
  ! The user needs to give the initial maximum cardinality of a SET.
  ! Sets are stored by setting individual bits of an INTEGER(wk) array,
  ! the kind type value of which may be changed by the user.
  ! It is assumed that the computer uses 2-complement binary arithmetic.
  ! Procedures involving rank assume that rank are of type REAL(rk) where 
  ! the kind type value also may be changed by the user. All ranks give
  ! correct values if they are within the precision of rk.
  ! This module is written in Essential Fortran 90.
  !--------------------------------------------------------------------------

  IMPLICIT NONE

  !--------------------------------------------------------------------------
  !
  !* USER DEFINED PARAMETERS:
  !
  !* initial_max_card  = initial maximum cardinality of a set. The maximum 
  !       cardinality of a set is given by the public parameter max_card.
  !* sets_rank_kind = kind type value of set ranks. Set according to desired
  !       speed or range. Normally this is the value for a double precision 
  !       real, ie KIND (0.0D0) or P=15.
  !* sets_word_kind = kind type value of the array that a set is stored in.
  !       Normally this is the value for an integer, ie KIND (0) or R=9.
  !
  !   changed initial_max_card to 500*200**2 = 20000000
  !     This corresponds to a very big lattice... 
  INTEGER, PUBLIC, PARAMETER ::                   & ! ***USER DEFINED***
       initial_max_card = 20000000,               & ! See max_card below
       sets_rank_kind = SELECTED_REAL_KIND (P=15),& ! See rk below
       sets_word_kind = SELECTED_INT_KIND (R=9)     ! See wk below
  !
  !--------------------------------------------------------------------------

  INTEGER, PRIVATE, PARAMETER ::      &
       rk  = sets_rank_kind,          & ! Kind of ranks.
       wk  = sets_word_kind,          & ! Kind of words.
       wp = KIND (0.0D0),             & ! Kind value for internal use.
       dig = DIGITS (0.0_rk),         & ! Max card for ranks to be accurate
       bs  = BIT_SIZE (0_wk),         & ! Bit-size, must be multiple of 4.
       msw = (initial_max_card-1)/bs, & ! Most significant word.
       msb = bs - 1                     ! Most significant bit.

  INTEGER, PUBLIC, PARAMETER ::   &
       max_card = bs * (msw + 1)

  REAL(rk), PRIVATE, PARAMETER :: &
       zero  = 0.0_rk,            &
       half  = 0.5_rk,            &
       one   = 1.0_rk,            &
       two   = 2.0_rk,            &
       base  = two ** bs,         &
       limit = two ** dig

  REAL(rk), PRIVATE :: binom( 0:dig, 0:dig )
  LOGICAL,  PRIVATE :: init = .FALSE.

  TYPE, PUBLIC :: Set
     INTEGER(wk) :: word( 0:msw )
  END TYPE Set

  TYPE(Set), PUBLIC, PARAMETER ::  &
       empty_set     = Set (0_wk), &
       universal_set = Set (-1_wk)

  INTERFACE ASSIGNMENT(=)
     MODULE PROCEDURE Assign_SI1
     MODULE PROCEDURE Assign_I1S
  END INTERFACE

  INTERFACE OPERATOR(==)
     MODULE PROCEDURE EQ_SS
  END INTERFACE

  INTERFACE OPERATOR(/=)
     MODULE PROCEDURE NE_SS
  END INTERFACE

  INTERFACE OPERATOR(<=)
     MODULE PROCEDURE LE_SS
  END INTERFACE

  INTERFACE OPERATOR(<)
     MODULE PROCEDURE LT_SS
  END INTERFACE

  INTERFACE OPERATOR(>=)
     MODULE PROCEDURE GE_SS
  END INTERFACE

  INTERFACE OPERATOR(>)
     MODULE PROCEDURE GT_SS
  END INTERFACE

  INTERFACE OPERATOR(+)
     MODULE PROCEDURE Add_SI
     MODULE PROCEDURE Add_IS
  END INTERFACE

  INTERFACE OPERATOR(-)
     MODULE PROCEDURE Sub_SI
     MODULE PROCEDURE Sub_IS
  END INTERFACE

  INTERFACE OPERATOR(*)
     MODULE PROCEDURE Mul_SI
     MODULE PROCEDURE Mul_IS
  END INTERFACE

  INTERFACE OPERATOR(/)
     MODULE PROCEDURE Div_SI
  END INTERFACE

  INTERFACE OPERATOR(.IN.)
     MODULE PROCEDURE MemberQ2
  END INTERFACE

  INTERFACE OPERATOR(.UNION.)
     MODULE PROCEDURE Union_SS
     MODULE PROCEDURE Union_SI1
  END INTERFACE

  INTERFACE OPERATOR(.INTERSECTION.)
     MODULE PROCEDURE Intersection_SS
  END INTERFACE

  INTERFACE OPERATOR(.SYMMETRIC.)
     MODULE PROCEDURE Symmetric_SS
  END INTERFACE

  INTERFACE OPERATOR(.COMPLEMENT.)
     MODULE PROCEDURE Complement_S
     MODULE PROCEDURE Complement_SS
     MODULE PROCEDURE Complement_SI1
  END INTERFACE

  INTERFACE Union
     MODULE PROCEDURE Union_SS
     MODULE PROCEDURE Union_SI1
  END INTERFACE

  INTERFACE Intersection
     MODULE PROCEDURE Intersection_SS
  END INTERFACE

  INTERFACE Symmetric
     MODULE PROCEDURE Symmetric_SS
  END INTERFACE

  INTERFACE Complement
     MODULE PROCEDURE Complement_S
     MODULE PROCEDURE Complement_SS
     MODULE PROCEDURE Complement_SI1
  END INTERFACE

  INTERFACE N_Set
     MODULE PROCEDURE N_Set_1
     MODULE PROCEDURE N_Set_2
     MODULE PROCEDURE N_Set_3
  END INTERFACE

  PUBLIC :: &
       ASSIGNMENT(=), OPERATOR(==), OPERATOR(/=), OPERATOR(<=), OPERATOR(<), &
       OPERATOR(>=), OPERATOR(>), OPERATOR(+), OPERATOR(-), OPERATOR(*),     &
       OPERATOR(/),OPERATOR(.IN.),OPERATOR(.UNION.),OPERATOR(.INTERSECTION.),&
       OPERATOR(.SYMMETRIC.), OPERATOR(.COMPLEMENT.), Union, Intersection,   &
       Symmetric, Complement, To_Set, N_Set, Rank_Set,Rank_Subset,Rank_k_Set,&
       Unrank_Set,Unrank_Subset,Unrank_k_Set,Next_Set,Next_Subset,Next_k_Set,&
       Next_Gray_Set, Random_Subset, Random_k_Subset,Permute_Set,Cardinality,&
       MemberQ,EmptyQ,SubsetQ,DisjointQ,Elements, Min_Element, Max_Element,  &
       Next_Element, Add_Element, Delete_Element, Binomial,Write_Set,Read_Set

  PRIVATE :: &
       Assign_SI1, Assign_I1S, EQ_SS, NE_SS, LE_SS, LT_SS,GE_SS,GT_SS,Add_SI,&
       Add_IS, Sub_SI, Sub_IS, Mul_SI, Mul_IS, Div_SI, MemberQ2, Union_SS,   &
       Union_SI1, Intersection_SS, Symmetric_SS, Complement_S, Complement_SS,&
       Complement_SI1, N_Set_1, N_Set_2, N_Set_3, Random_Integer, Init_Binom,&
       Ibrev

CONTAINS

  !--------------------------------------------------------------------------
  SUBROUTINE Assign_SI1 (a, e)
    ! Sets a to {e1,e2,..}.
    ! my version ignores e(i) = 0 instead of stopping...
    TYPE(Set), INTENT(OUT) :: a
    INTEGER,   INTENT(IN ) :: e( : )
    INTEGER :: i, j
    a = empty_set
    loop : DO i = 1, SIZE (e)
       if (e(i) < 1 .or. e(i) > max_card) then
          IF (e(i) == 0) THEN
             CYCLE loop
          ELSE
             write(*,*) 'errot in sets'
             write(*,*) 'e(i)',i,e(i),max_card
             STOP 'ERROR: Assign_SI1'
          END IF
       end if
!       IF ( e( i ) < 1 .OR. e( i ) > max_card ) STOP 'ERROR: Assign_SI1'
       j = (e( i ) - 1) / bs
       a % word( j ) = IBSET (a % word( j ), MOD (e( i ) - 1, bs))
    END DO loop
    RETURN
  END SUBROUTINE Assign_SI1

  SUBROUTINE Assign_SI1_old (a, e)
    ! Sets a to {e1,e2,..}.
    TYPE(Set), INTENT(OUT) :: a
    INTEGER,   INTENT(IN ) :: e( : )
    INTEGER :: i, j
    a = empty_set
    DO i = 1, SIZE (e)
!       write(*,*) 'ei',e(i)
       if (e(i) < 1 .or. e(i) > max_card) then
          write(*,*) 'error info'
          write(*,*) 'e(i)',i,e(i),max_card
          STOP 'ERROR: Assign_SI1'
       end if
!       end if
!       IF ( e( i ) < 1 .OR. e( i ) > max_card ) STOP 'ERROR: Assign_SI1'
       j = (e( i ) - 1) / bs
       a % word( j ) = IBSET (a % word( j ), MOD (e( i ) - 1, bs))
    END DO
    RETURN
  END SUBROUTINE Assign_SI1_old

  !--------------------------------------------------------------------------

  SUBROUTINE Assign_I1S (e, a)

    ! Puts the elements of a in the first positions of the array e.
    ! Any remaining positions of e are padded with zeroes.

    INTEGER,   INTENT(OUT) :: e( : )
    TYPE(Set), INTENT(IN ) :: a
    INTEGER :: i, n

    CALL Elements (a, n, e)

    DO i = n+1, SIZE (e)
       e( i ) = 0
    END DO

    RETURN
  END SUBROUTINE Assign_I1S

  !--------------------------------------------------------------------------

  FUNCTION EQ_SS (a, b) RESULT (q)
    ! Tests whether a == b.
    TYPE(Set), INTENT(IN) :: a, b
    LOGICAL :: q  ! RESULT
    q = ALL (a % word == b % word)
    RETURN
  END FUNCTION EQ_SS

  !--------------------------------------------------------------------------

  FUNCTION NE_SS (a, b) RESULT (q)
    ! Tests whether a /= b.
    TYPE(Set), INTENT(IN) :: a, b
    LOGICAL :: q  ! RESULT
    q = ANY (a % word /= b % word)
    RETURN
  END FUNCTION NE_SS

  !--------------------------------------------------------------------------

  FUNCTION LE_SS (a, b) RESULT (q)
    ! Tests whether a is a subset of b.
    TYPE(Set), INTENT(IN) :: a, b
    LOGICAL :: q  ! RESULT
    q = ALL (a % word == IAND (a % word, b % word))
    RETURN
  END FUNCTION LE_SS

  !--------------------------------------------------------------------------

  FUNCTION LT_SS (a, b) RESULT (q)
    ! Tests whether a is a proper subset of b.
    TYPE(Set), INTENT(IN) :: a, b
    LOGICAL :: q  ! RESULT
    q = ( a <= b ) .AND. ( a /= b )
    RETURN
  END FUNCTION LT_SS

  !--------------------------------------------------------------------------

  FUNCTION GE_SS (a, b) RESULT (q)
    ! Tests whether a is a superset of b.
    TYPE(Set), INTENT(IN) :: a, b
    LOGICAL :: q  ! RESULT
    q = b <= a
    RETURN
  END FUNCTION GE_SS

  !--------------------------------------------------------------------------

  FUNCTION GT_SS (a, b) RESULT (q)
    ! Tests whether a is a proper superset of b.
    TYPE(Set), INTENT(IN) :: a, b
    LOGICAL :: q  ! RESULT
    q = ( b <= a ) .AND. ( a /= b )
    RETURN
  END FUNCTION GT_SS

  !--------------------------------------------------------------------------

  FUNCTION Add_SI (a, k) RESULT (b)

    ! Returns the set {a1+k, a2+k,..,an+k}.
    ! Note that this is an end-off operation.

    TYPE(Set), INTENT(IN) :: a
    INTEGER,   INTENT(IN) :: k
    TYPE(Set) :: b  ! RESULT

    INTEGER(wk) :: tmp( 0:msw )
    INTEGER :: i, m

    SELECT CASE (k)
    CASE (:-1)
       b = a - ABS (k)
    CASE (0)
       b = a
    CASE (1:max_card)
       m = MOD (k, bs)
       tmp = EOSHIFT (a % word, -k / bs)
       b % word = ISHFT (tmp, m)
       !CALL MVBITS (tmp( 0:msw-1 ), bs-m, m, b % word( 1:msw ), 0)
       ! Previous line doesn't work on gfortran. Use DO-loop instead.
       DO i = 0, msw-1
          CALL MVBITS (tmp( i ), bs-m, m, b % word( i+1 ), 0)
       END DO
    CASE DEFAULT
       b = empty_set
    END SELECT

    RETURN
  END FUNCTION Add_SI

  !--------------------------------------------------------------------------

  FUNCTION Add_IS (k, a) RESULT (b)
    ! Returns the set {k+a1, k+a2,..,k+an}.
    ! Note that this is an end-off operation.
    INTEGER,   INTENT(IN) :: k
    TYPE(Set), INTENT(IN) :: a
    TYPE(Set) :: b  ! RESULT
    b = a + k
    RETURN
  END FUNCTION Add_IS

  !--------------------------------------------------------------------------

  FUNCTION Sub_SI (a, k) RESULT (b)

    ! Returns the set {a1-k, a2-k,..,an-k}.
    ! Note that this is an end-off operation.

    TYPE(Set), INTENT(IN) :: a
    INTEGER,   INTENT(IN) :: k
    TYPE(Set) :: b  ! RESULT
    INTEGER(wk) :: tmp( 0:msw )
    INTEGER :: i, m

    SELECT CASE (k)
    CASE (:-1)
       b = a + ABS (k)
    CASE (0)
       b = a
    CASE (1:max_card)
       m = MOD (k, bs)
       tmp = EOSHIFT (a % word, k / bs)
       b % word = ISHFT (tmp, -m)
       !CALL MVBITS (tmp( 1:msw ), 0, m, b % word( 0:msw-1 ), bs-m)
       ! Previous line doesn't work on gfortran. Use DO-loop instead.
       DO i = 1, msw
          CALL MVBITS (tmp( i ), 0, m, b % word( i-1 ), bs-m)
       END DO
    CASE DEFAULT
       b = empty_set
    END SELECT

    RETURN
  END FUNCTION Sub_SI

  !--------------------------------------------------------------------------

  FUNCTION Sub_IS (k, a) RESULT (b)

    ! Returns the set {k-a1, k-a2,..,k-an}.
    ! Note that this is an end-off operation.

    INTEGER,   INTENT(IN) :: k
    TYPE(Set), INTENT(IN) :: a
    TYPE(Set) :: b  ! RESULT

    INTEGER :: i

    SELECT CASE (k)
    CASE (:1)
       b = empty_set
    CASE (2*max_card+1:)
       b = empty_set
    CASE DEFAULT

       !2 <= k <= 2*max_card

       ! First we let B = (max_card + 1) - A.  This is obtained by 
       ! reversing the entries and bits of array a%word.

       DO i = 0, msw
          b % word( msw-i ) = Ibrev (a % word( i ))
       END DO

       ! k - A = k - (max_card+1) + (max_card+1) - A = B + (k-max_card-1)

       ! -(max_card - 1) <= k - max_card - 1 <= max_card - 1

       b = b + (k - max_card - 1)
       
    END SELECT

    RETURN
  END FUNCTION Sub_IS

  !--------------------------------------------------------------------------

  FUNCTION Mul_SI (a, k) RESULT (b)

    ! Returns the set {a1*k, a2*k,..,an*k}.
    ! Note that this is an end-off operation.
    ! Not very efficient.

    TYPE(Set), INTENT(IN) :: a
    INTEGER,   INTENT(IN) :: k
    TYPE(Set) :: b  ! RESULT

    INTEGER :: i, n, e( max_card )

    b = empty_set
    CALL Elements (a, n, e)

    DO i = 1, n
       e( i ) = k * e( i )
       IF ( 1 <= e( i ) .AND. e( i ) <= max_card ) THEN
          CALL Add_Element (b, e( i ))
       END IF
    END DO

    RETURN
  END FUNCTION Mul_SI

  !--------------------------------------------------------------------------

  FUNCTION Mul_IS (k, a) RESULT (b)
    ! Returns the set {k*a1, k*a2,..,k*an}.
    ! Note that this is an end-off operation.
    ! Not very efficient.
    INTEGER,   INTENT(IN) :: k
    TYPE(Set), INTENT(IN) :: a
    TYPE(Set) :: b  ! RESULT
    b = a * k
    RETURN
  END FUNCTION Mul_IS

  !--------------------------------------------------------------------------

  FUNCTION Div_SI (a, k) RESULT (b)

    ! Returns the set {a1/k, a2/k,..,an/k}.
    ! Note that this is an end-off operation.
    ! Not very efficient.

    TYPE(Set), INTENT(IN) :: a
    INTEGER,   INTENT(IN) :: k
    TYPE(Set) :: b  ! RESULT

    INTEGER :: i, n, e( max_card )

    b = empty_set
    CALL Elements (a, n, e)

    DO i = 1, n
       e( i ) = e( i ) / k
       IF ( 1 <= e( i ) .AND. e( i ) <= max_card ) THEN
          CALL Add_Element (b, e( i ))
       END IF
    END DO

    RETURN
  END FUNCTION Div_SI

  !--------------------------------------------------------------------------

  FUNCTION Union_SS (a, b) RESULT (c)
    ! Returns the union of a and b.
    TYPE(Set), INTENT(IN) :: a, b
    TYPE(Set) :: c  ! RESULT
    c % word = IOR (a % word, b % word)
    RETURN
  END FUNCTION Union_SS

  !--------------------------------------------------------------------------

  FUNCTION Union_SI1 (a, e) RESULT (c)
    ! Returns the union of a and {e1,e2,...}.
    TYPE(Set), INTENT(IN) :: a
    INTEGER,   INTENT(IN) :: e( : )
    TYPE(Set) :: c  ! RESULT
    c = e
    c = Union (a, c)
    RETURN
  END FUNCTION Union_SI1

  !--------------------------------------------------------------------------

  FUNCTION Intersection_SS (a, b) RESULT (c)
    ! Returns the intersection of a and b.
    TYPE(Set), INTENT(IN) :: a, b
    TYPE(Set) :: c  ! RESULT
    c % word = IAND (a % word, b % word)
    RETURN
  END FUNCTION Intersection_SS

  !--------------------------------------------------------------------------

  FUNCTION Symmetric_SS (a, b) RESULT (c)
    ! Returns the symmetric difference of a and b.
    TYPE(Set), INTENT(IN) :: a, b
    TYPE(Set) :: c  ! RESULT
    c % word = IEOR (a % word, b % word)
    RETURN
  END FUNCTION Symmetric_SS

  !--------------------------------------------------------------------------

  FUNCTION Complement_S (a) RESULT (c)
    ! Returns the complement of a.
    TYPE(Set), INTENT(IN) :: a
    TYPE(Set) :: c  ! RESULT
    c % word = NOT (a % word)
    RETURN
  END FUNCTION Complement_S

  !--------------------------------------------------------------------------

  FUNCTION Complement_SS (a, b) RESULT (c)
    ! Returns the difference (relative complement) a - b.
    TYPE(Set), INTENT(IN) :: a, b
    TYPE(Set) :: c  ! RESULT
    c % word = IAND (a % word, NOT (b % word))
    RETURN
  END FUNCTION Complement_SS

  !--------------------------------------------------------------------------

  FUNCTION Complement_SI1 (a, e) RESULT (c)
    ! Returns the difference (relative complement) a - {e1,e2,...}.
    TYPE(Set), INTENT(IN) :: a
    INTEGER,   INTENT(IN) :: e( : )
    TYPE(Set) :: c  ! RESULT
    c = e
    c = Complement (a, c)
    RETURN
  END FUNCTION Complement_SI1

  !--------------------------------------------------------------------------

  FUNCTION To_Set (e) RESULT (a)
    ! Returns the set {e1,e2,...}.
    INTEGER, INTENT(IN) :: e( : )
    TYPE(Set) :: a  ! RESULT
    a = e
    RETURN
  END FUNCTION To_Set

  !--------------------------------------------------------------------------

  FUNCTION N_Set_1 (n) RESULT (a)

    ! Returns the set {1,2,..,n}.
    ! If n = 0 then the empty set is returned.

    INTEGER, INTENT(IN) :: n
    TYPE(Set) :: a  ! RESULT

    INTEGER :: j

    IF ( n < 0 .OR. n > max_card ) STOP 'ERROR: N_Set'

    a = empty_set
    j = n / bs
    a % word( 0:j-1 ) = -1_wk
    IF ( j <= msw ) a % word( j ) = IBITS (-1_wk, 0, MOD (n, bs))

    RETURN
  END FUNCTION N_Set_1

  !--------------------------------------------------------------------------

  FUNCTION N_Set_2 (m, n) RESULT (a)
    ! Returns the set {m,m+1,m+2,..,n}.
    ! If m > n then the empty set is returned.
    INTEGER, INTENT(IN) :: m, n
    TYPE(Set) :: a  ! RESULT
    a = Complement (N_Set (n), N_Set (m-1))
    RETURN
  END FUNCTION N_Set_2

  !--------------------------------------------------------------------------

  FUNCTION N_Set_3 (m, n, k) RESULT (a)
    ! Returns the set {m,m+k,m+2k,..,n}.
    INTEGER, INTENT(IN) :: m, n, k
    TYPE(Set) :: a  ! RESULT
    INTEGER :: i
    a = empty_set
    DO i = m, n, k
       CALL Add_Element (a, i)
    END DO
    RETURN
  END FUNCTION N_Set_3

  !--------------------------------------------------------------------------

  FUNCTION Rank_Set (a) RESULT (r)

    ! Returns the rank of the set a.
    ! The empty set has rank zero.

    TYPE(Set), INTENT(IN) :: a
    REAL(rk) :: r  ! RESULT
    REAL(rk) :: tmp
    INTEGER  :: j

    r = zero
    tmp = one

    DO j = 0, msw
       IF ( a % word( j ) < 0_wk ) THEN
          r = r + tmp * (base + REAL (a % word( j ), rk))
       ELSE
          r = r + tmp * REAL (a % word( j ), rk)
       END IF
       tmp = tmp * base
    END DO

    IF ( r >= limit ) STOP 'ERROR: Rank_Set'

    RETURN
  END FUNCTION Rank_Set

  !--------------------------------------------------------------------------

  FUNCTION Rank_Subset (a, b) RESULT (r)

    ! Returns the rank of the set a seen as a subset of b.
    ! a <= b.
    ! The empty set has rank zero.

    TYPE(Set), INTENT(IN) :: a, b
    REAL(rk) :: r  ! RESULT
    REAL(rk) :: tmp
    INTEGER  :: i, j

    r = zero
    tmp = one

    DO j = 0, msw
       IF ( b % word( j ) == 0_wk ) CYCLE
       DO i = 0, msb
          IF ( BTEST (b % word( j ), i) ) THEN
             IF ( BTEST (a % word( j ), i) ) r = r + tmp
             tmp = tmp * two
          END IF
       END DO
    END DO

    IF ( r >= limit ) STOP 'ERROR: Rank_Subset'

    RETURN
  END FUNCTION Rank_Subset

  !--------------------------------------------------------------------------

  FUNCTION Rank_k_Set (a) RESULT (r)

    ! Returns the rank of the set a seen as a k-set, where k = |A|.
    ! The sets are numbered in the co-lexicographical (squashed) order.
    ! The empty set has rank zero and k-sets are numbered
    ! 0,1,...,C(max_card,k)-1, where C(n,k) is 'n choose k'.

    TYPE(Set), INTENT(IN) :: a
    REAL(rk) :: r  ! RESULT
    INTEGER  :: h, i, j, k

    IF ( .NOT. init ) CALL Init_Binom ()

    r = zero
    k = 0

    DO j = 0, msw
       IF ( a % word( j ) == 0_wk ) CYCLE
       DO i = 0, msb
          IF ( BTEST (a % word( j ), i) ) THEN
             h = i + j * bs
             k = k + 1
             IF ( h > dig .OR. k > dig ) STOP 'ERROR: Rank_k_Set 1'
             r = r + binom( h, k )
          END IF
       END DO
    END DO

    IF ( r >= limit ) STOP 'ERROR: Rank_k_Set 2'

    RETURN
  END FUNCTION Rank_k_Set

  !--------------------------------------------------------------------------

  FUNCTION Unrank_Set (r) RESULT (a)

    ! Returns the set with rank r.
    ! This is the inverse function of Rank_Set.

    REAL(rk), INTENT(IN) :: r
    TYPE(Set) :: a  ! RESULT
    REAL(rk), PARAMETER  ::           &
         inverse_base = two ** (-bs), &
         half_base    = two ** (bs - 1)
    REAL(rk) :: x, y, z
    INTEGER  :: j

    IF ( r < zero .OR. r >= limit ) STOP 'ERROR: Unrank_Set 1'

    a = empty_set
    x = AINT (r)
    j = 0

    DO WHILE ( x > zero )
       y = AINT (x * inverse_base)
       z = x - y * base  ! 0 <= z < 2**bs
       x = y
       IF ( j > msw ) STOP 'ERROR: Unrank_Set 2'
       IF ( z < half_base ) THEN
          a % word( j ) = INT (z, wk)
       ELSE
          a % word( j ) = INT (z - base, wk)
       END IF
       j = j + 1
    END DO

    RETURN
  END FUNCTION Unrank_Set

  !--------------------------------------------------------------------------

  FUNCTION Unrank_Subset (r, b) RESULT (a)

    ! Returns the r:th subset of b.
    ! This is the inverse function of Rank_Subset.
    ! 0 <= r < 2**|b|.

    REAL(rk),  INTENT(IN) :: r
    TYPE(Set), INTENT(IN) :: b
    TYPE(Set) :: a  ! RESULT
    REAL(rk) :: x, y, z
    INTEGER  :: i, j

    IF ( r < zero .OR. r >= limit ) STOP 'ERROR: Unrank_Subset 1'

    a = empty_set
    x = AINT (r)

    Loop: DO j = 0, msw
       IF ( b % word( j ) == 0_wk ) CYCLE
       DO i = 0, msb
          IF ( BTEST (b % word( j ), i) ) THEN
             IF ( x == zero ) EXIT Loop
             y = AINT (x * half)
             z = x - y * two
             x = y
             IF ( z == one ) a % word( j ) = IBSET (a % word( j ), i)
          END IF
       END DO
    END DO Loop

    IF ( x > zero ) STOP 'ERROR: Unrank_Subset 2'

    RETURN
  END FUNCTION Unrank_Subset

  !--------------------------------------------------------------------------

  FUNCTION Unrank_k_Set (r, k) RESULT (a)

    ! Returns the r:th k-set.
    ! This is the inverse function of Rank_k_Set.

    REAL(rk), INTENT(IN) :: r
    INTEGER,  INTENT(IN) :: k
    TYPE(Set) :: a  ! RESULT
    REAL(rk)  :: x
    INTEGER   :: i, j

    IF ( k > dig  .OR. k > max_card ) STOP 'ERROR: Unrank_k_Set 1'
    IF ( r < zero .OR. r >= limit   ) STOP 'ERROR: Unrank_k_Set 2'

    IF ( .NOT. init ) CALL Init_Binom ()

    a = empty_set
    x = AINT (r)

    DO j = k, 1, -1
       ! Find first i such that C(i,j) > x
       DO i = j, dig
          IF ( binom( i, j ) > x ) EXIT
       END DO
       IF ( i > dig ) STOP 'ERROR: Unrank_k_Set 3'
       CALL Add_Element (a, i)
       x = x - binom( i-1, j )
    END DO

    RETURN
  END FUNCTION Unrank_k_Set

  !--------------------------------------------------------------------------

  SUBROUTINE Next_Set (a)

    ! Updates a to the next set.
    ! Equivalent to: Unrank_Set (1+Rank_Set (a))
    ! After universal_set comes the empty_set.

    TYPE(Set), INTENT(IN OUT) :: a
    INTEGER :: j

    ! Add 1 to the binary number that represents the set.

    DO j = 0, msw
       IF ( a % word( j ) == -1_wk ) THEN
          a % word( j ) = 0_wk
       ELSE
          a % word( j ) = a % word( j ) + 1_wk
          EXIT
       END IF
    END DO

    RETURN
  END SUBROUTINE Next_Set

  !--------------------------------------------------------------------------

  SUBROUTINE Next_Subset (a, b)

    ! Updates a to the next subset of b.
    ! Equivalent to: Unrank_Subset (1+Rank_Subset (a, b), b)

    TYPE(Set), INTENT(IN OUT) :: a
    TYPE(Set), INTENT(IN    ) :: b
    INTEGER :: i, j

    ! Reset 1's to 0's until a 0 is found. Then set this 0 to 1.

    Loop: DO j = 0, msw
       IF ( b % word( j ) == 0_wk ) CYCLE
       DO i = 0, msb
          IF ( BTEST (b % word( j ), i) ) THEN
             IF ( BTEST (a % word( j ), i) ) THEN
                a % word( j ) = IBCLR (a % word( j ), i)
             ELSE
                a % word( j ) = IBSET (a % word( j ), i)
                EXIT Loop
             END IF
          END IF
       END DO
    END DO Loop
    
    RETURN
  END SUBROUTINE Next_Subset

  !--------------------------------------------------------------------------

  SUBROUTINE Next_k_Set (a)

    ! Updates a to the next k-set, where k is the cardinality of a.
    ! Equivalent to: Unrank_k_Set (1+Rank_k_Set (a), cardinality (a))

    TYPE(Set), INTENT(IN OUT) :: a
    INTEGER :: i, j, k
    LOGICAL :: done

    ! Find the first 1 (if any).

    done = .FALSE.

    Loop1: DO j = 0, msw
       IF ( a % word( j ) == 0_wk ) CYCLE Loop1
       DO i = 0, msb
          IF ( BTEST (a % word( j ), i) ) THEN
             done = .TRUE.
             EXIT Loop1 ! i and j are used below
          END IF
       END DO
    END DO Loop1

    IF ( .NOT. done ) RETURN ! a=empty_set, next 0-set is also empty_set

    ! Find the first 0 (if any).
    ! The 1's are set to 0 on the way.
    ! Count the 1's from position (j, i).

    k = 0  ! number of 1's
    done = .FALSE.

    Loop2: DO WHILE ( j <= msw )
       DO WHILE ( i <= msb )
          IF ( BTEST (a % word( j ), i) ) THEN
             a % word( j ) = IBCLR (a % word( j ), i)
             k = k + 1
          ELSE
             a % word( j ) = IBSET (a % word( j ), i)
             k = k - 1
             done = .TRUE.
             EXIT Loop2
          END IF
          i = i + 1
       END DO
       i = 0
       j = j + 1
    END DO Loop2

    IF ( .NOT. done ) STOP 'ERROR: Next_k_Set' ! No 0's. Universe too small.

    ! Set the first k bits to 1 while keeping the other 1's.

    j = k / bs
    a % word( 0:j-1 ) = -1_wk
    a % word( j ) = IOR (a % word( j ), IBITS (-1_wk, 0, MOD (k, bs)))
    
    RETURN
  END SUBROUTINE Next_k_Set

  !--------------------------------------------------------------------------
  
  SUBROUTINE Next_Gray_Set (a, card, elem)

    ! Updates a to the next set in the order imposed by the Gray Code.
    ! On entry, card must be the cardinality of a, 0 <= card <= max_card.
    ! On return, elem is the element that was switched, 1 <= elem <= max_card.
    ! We have seen all subsets of {1,..,n} when elem > n for the first time.
    ! Not cyclic behaviour.
    ! Example: This loop will run over all subsets of {1,...,n}.
    !
    ! a = empty_set; k = 0; e = 0;
    ! DO WHILE ( e <= n );
    !    ... (do stuff with the set a) ...
    !    CALL Next_Gray_Set (a, k, e)
    ! END DO

    TYPE(Set), INTENT(IN OUT) :: a
    INTEGER,   INTENT(IN OUT) :: card
    INTEGER,   INTENT(   OUT) :: elem
    INTEGER, PARAMETER :: msb1 = msb - 1
    INTEGER :: i, j, w, b

    ! If card is even then flip the first bit, otherwise flip the bit
    ! after the first 1.

    IF ( MOD (card, 2) == 0 ) THEN ! card is even

       w = 0  ! word
       b = 0  ! bit

    ELSE

       Loop: DO j = 0, msw
          DO i = 0, msb1
             IF ( BTEST (a % word( j ), i) ) THEN
                w = j
                b = i + 1
                EXIT Loop
             END IF
          END DO
          ! Here i = msb
          IF ( BTEST (a % word( j ), i) ) THEN
             IF ( j == msw ) STOP 'ERROR: Next_Gray_Set'
             w = j + 1
             b = 0
             EXIT Loop
          END IF
       END DO Loop

    END IF

    ! flip bit and update card

    IF ( BTEST (a % word( w ), b) ) THEN
       a % word( w ) = IBCLR (a % word( w ), b)
       card = card - 1
    ELSE
       a % word( w ) = IBSET (a % word( w ), b)
       card = card + 1
    END IF

    ! compute the switched element

    elem = 1 + b + w * bs

    RETURN
  END SUBROUTINE Next_Gray_Set

  !--------------------------------------------------------------------------

  FUNCTION Random_Subset (a) RESULT (b)

    ! Returns a random subset of the set a.
    ! Randomize the random number generator.

    TYPE(Set), INTENT(IN) :: a
    TYPE(Set) :: b  ! RESULT
    INTEGER :: j

    ! Fill each word of b with random bits and take the intersection with a.

    DO j = 0, msw
       IF ( a % word( j ) == 0_wk ) THEN
          b % word( j ) = 0_wk
       ELSE
          CALL Random_Integer (b % word( j ))
          b % word( j ) = IAND (a % word( j ), b % word( j ))
       END IF
    END DO

    RETURN
  END FUNCTION Random_Subset

  !--------------------------------------------------------------------------

  FUNCTION Random_k_Subset (n, k) RESULT (a)

    ! Returns a random k-subset of {1,2,...,n}.
    ! 0 <= k <= n <= max_card.

    INTEGER, INTENT(IN) :: n, k
    TYPE(Set) :: a  ! RESULT
    INTEGER :: i, j, tmp, index( min(n,max_card) )
    REAL(wp) :: rnd( min(k,max_card) )

    IF ( n > max_card .OR. k > n ) STOP 'ERROR: Random_k_Subset'

    DO i = 1, n
       index( i ) = i
    END DO

    CALL RANDOM_NUMBER (rnd)

    DO i = 1, k
       j = i + INT ((n - i + 1)*rnd( i ))
       tmp = index( i )
       index( i ) = index( j )
       index( j ) = tmp
    END DO

    a = index( 1:k )

    RETURN
  END FUNCTION Random_k_Subset

  !--------------------------------------------------------------------------

  FUNCTION Permute_Set (a, p) RESULT (b)

    ! Returns the set a permuted by the permutation p.

    TYPE(Set), INTENT(IN) :: a
    INTEGER,   INTENT(IN) :: p( : )
    TYPE(Set) :: b  ! RESULT
    INTEGER :: i, j, k, szp

    szp = SIZE (p)
    b = empty_set

    DO j = 0, msw
       IF ( a % word( j ) == 0_wk ) CYCLE
       DO i = 0, msb
          IF ( BTEST (a % word( j ), i) ) THEN
             k = 1 + i + j * bs
             IF ( k > szp ) STOP 'ERROR: Permute_Set'
             CALL Add_Element (b, p( k ))
          END IF
       END DO
    END DO

    RETURN
  END FUNCTION Permute_Set

  !--------------------------------------------------------------------------

  FUNCTION Cardinality (a) RESULT (c)

    ! Returns the number of elements in a.

    TYPE(Set), INTENT(IN) :: a
    INTEGER :: c  ! RESULT
    INTEGER, PARAMETER :: &
         lookup( 0:15 ) = (/0,1,1,2,1,2,2,3,1,2,2,3,2,3,3,4/)
    INTEGER :: i, j

    ! Take 4 bits at a time and look up the number in the table.

    c = 0

    DO j = 0, msw
       IF ( a % word( j ) == 0_wk ) CYCLE
       DO i = 0, msb, 4
          c = c + lookup( IBITS (a % word( j ), i, 4) )
       END DO
    END DO

    RETURN
  END FUNCTION Cardinality

  !--------------------------------------------------------------------------

  FUNCTION MemberQ (a, e) RESULT (q)

    ! Tests whether e is a member of a.

    TYPE(Set), INTENT(IN) :: a
    INTEGER,   INTENT(IN) :: e
    LOGICAL :: q  ! RESULT

    IF ( e < 1 .OR. e > max_card ) THEN
       q = .FALSE.
    ELSE
       q = BTEST (a % word( (e-1)/bs ), MOD (e-1, bs))
    END IF

    RETURN
  END FUNCTION MemberQ

  !--------------------------------------------------------------------------

  FUNCTION MemberQ2 (e, a) RESULT (q)
    ! Tests whether e is a member of a.
    INTEGER,   INTENT(IN) :: e
    TYPE(Set), INTENT(IN) :: a
    LOGICAL :: q  ! RESULT
    q = MemberQ (a, e)
    RETURN
  END FUNCTION MemberQ2

  !--------------------------------------------------------------------------

  FUNCTION EmptyQ (a) RESULT (q)
    ! Tests whether the set a is empty.
    TYPE(Set), INTENT(IN) :: a
    LOGICAL :: q  ! RESULT
    q = ALL (a % word == 0_wk)
    RETURN
  END FUNCTION EmptyQ

  !--------------------------------------------------------------------------

  FUNCTION SubsetQ (a, b) RESULT (q)
    ! Tests whether a is a subset of b.
    TYPE(Set), INTENT(IN) :: a, b
    LOGICAL :: q  ! RESULT
    q = ALL (a % word == IAND (a % word, b % word))
    RETURN
  END FUNCTION SubsetQ

  !--------------------------------------------------------------------------

  FUNCTION DisjointQ (a, b) RESULT (q)
    ! Tests whether the sets a and b are disjoint.
    TYPE(Set), INTENT(IN) :: a, b
    LOGICAL :: q  !RESULT
    q = ALL (IAND (a % word, b % word) == 0_wk)
    RETURN
  END FUNCTION DisjointQ

  !--------------------------------------------------------------------------

  SUBROUTINE Elements (a, n, e)

    ! Returns the elements of a in the n first positions of e.
    ! Improved version. Old version and experimental version below.

    TYPE(Set), INTENT(IN ) :: a
    INTEGER,   INTENT(OUT) :: n, e( : )
    INTEGER :: i, j, sze

    INTEGER, PARAMETER :: bs2 = bs / 2, msb2 = bs2 - 1

    n = 0
    sze = SIZE (e)

    DO j = 0, msw

       ! Check the first half:
       IF ( IBITS (a % word( j ), 0, bs2) /= 0_wk ) THEN
             
          ! Count in the first half:
          DO i = 0, msb2
             IF ( BTEST (a % word( j ), i) ) THEN
                n = n + 1
                IF ( n > sze ) STOP 'ERROR: Elements'
                e( n ) = 1 + i + j * bs
             END IF
          END DO

       END IF ! End of first half.

       ! Check the second half:
       IF ( IBITS (a % word( j ), bs2, bs2) /= 0_wk ) THEN
          
          ! Count in the second half:
          DO i = bs2, msb
             IF ( BTEST (a % word( j ), i) ) THEN
                n = n + 1
                IF ( n > sze ) STOP 'ERROR: Elements'
                e( n ) = 1 + i + j * bs
             END IF
          END DO
          
       END IF ! End of second half.

    END DO ! End of word.

    RETURN
  END SUBROUTINE Elements

!   SUBROUTINE Elements (a, n, e)
!     ! Returns the elements of a in the n first positions of e.
!     ! Old version.
!     TYPE(Set), INTENT(IN ) :: a
!     INTEGER,   INTENT(OUT) :: n, e( : )
!     INTEGER :: i, j, sze
!     n = 0
!     sze = SIZE (e)
!     DO j = 0, msw
!        IF ( a % word( j ) == 0_wk ) CYCLE
!        DO i = 0, msb
!           IF ( BTEST (a % word( j ), i) ) THEN
!              n = n + 1
!              IF ( n > sze ) STOP 'ERROR: Elements'
!              e( n ) = 1 + i + j * bs
!           END IF
!        END DO
!     END DO    
!     RETURN
!   END SUBROUTINE Elements

!   SUBROUTINE Elements (a, n, e)
!     ! Returns the elements of a in the n first positions of e.
!     ! Looks good but is actually slower so I leave it commented for now.
!     ! Will probably return to this subject later.
!     TYPE(Set), INTENT(IN ) :: a
!     INTEGER,   INTENT(OUT) :: n, e( : )
!     INTEGER :: i, j, k, l, m, w, sze
!     INTEGER, PARAMETER :: &
!          table1( 0:1, 0:15 ) = RESHAPE ((/0,1,1,1,1,2,2,1,1,3,2,5,2,2,3,1,&
!          1,4, 2,11, 2,9, 3,8, 2,3, 3,5, 3,2, 4,1/), (/2, 16/))
!     INTEGER, PARAMETER :: &
!          table2( 12 ) = (/1,2,3,4,1,3,4,1,2,4,1,4/)
!     n = 0
!     sze = SIZE (e)
!     DO j = 0, msw
!        ! Check this word:
!        IF ( a % word( j ) == 0_wk ) CYCLE
!        DO i = 0, msb, 4
!           w = IBITS (a % word( j ), i, 4)
!           IF ( w == 0 ) CYCLE
!           m = table1( 0, w )
!           l = table1( 1, w )
!           IF ( m + n > sze ) STOP 'ERROR: Elements'
!           e( n+1:n+m ) = i + j*bs + table2( l:l+m-1 )
!           n = n + m
!        END DO
!     END DO ! End of word.
!     RETURN
!   END SUBROUTINE Elements

  !--------------------------------------------------------------------------

  FUNCTION Next_Element (a, e, s) RESULT (f)

    ! Next or previous element of a set.
    ! Returns the next element nearest e of the set a in the direction given 
    ! by the sign of s. That is, s > 0 gives the next bigger element and 
    ! s < 0 gives the next smaller element. If there is no such element then 
    ! HUGE(0) is returned for s > 0 and -HUGE(0)-1 is returned for s < 0.
    ! Examples:
    !    if e <= 1 and s < 0 then -HUGE(0)-1 is returned
    !    if e >= max_card and s > 0 then HUGE(0) is returned
    !    if e < 1 and s > 0 then MINVAL (a) is returned
    !    if e > max_card and s < 0 then MAXVAL (a) is returned.
    !    if s == 0 then an error occurs.

    TYPE(Set), INTENT(IN) :: a
    INTEGER,   INTENT(IN) :: e, s
    INTEGER :: f  ! RESULT

    INTEGER :: e0, i0, j0, i, j

    IF ( s > 0 ) THEN

       e0 = MIN (MAX (0, e), max_card) ! next element minus one
       j0 = e0 / bs                    ! word of e0
       i0 = MOD (e0, bs)               ! bit of e0

       ! Search the current word:
       IF ( a % word( j0 ) /= 0_wk ) THEN
          DO i = i0, msb
             IF ( BTEST (a % word( j0 ), i) ) THEN
                f = 1 + i + j0 * bs
                RETURN
             END IF
          END DO
       END IF

       ! Search the remaining words:
       DO j = j0+1, msw
          IF ( a % word( j ) == 0_wk ) CYCLE
          DO i = 0, msb
             IF ( BTEST (a % word( j ), i) ) THEN
                f = 1 + i + j * bs
                RETURN
             END IF
          END DO
       END DO

       f = HUGE (0)  ! No element found

    ELSE IF ( s < 0 ) THEN

       e0 = MIN (MAX (-1, e-2), max_card-1) ! previous element minus one
       j0 = e0 / bs                         ! word of e0
       i0 = MOD (e0, bs)                    ! bit of e0

       ! Search the current word:
       IF ( a % word( j0 ) /= 0_wk ) THEN
          DO i = i0, 0, -1
             IF ( BTEST (a % word( j0 ), i) ) THEN
                f = 1 + i + j0 * bs
                RETURN
             END IF
          END DO
       END IF

       ! Search the remaining words:
       DO j = j0-1, 0, -1
          IF ( a % word( j ) == 0_wk ) CYCLE
          DO i = msb, 0, -1
             IF ( BTEST (a % word( j ), i) ) THEN
                f = 1 + i + j * bs
                RETURN
             END IF
          END DO
       END DO

       f = -HUGE (0) - 1 ! No element found

    ELSE ! s == 0

       STOP 'ERROR: Nearest_S'

    END IF

    RETURN
  END FUNCTION Next_Element

!   FUNCTION Next_Element (a, e) RESULT (f)
!     ! Returns an element of the set a that is bigger than e.
!     ! If there is no such member then -1 is returned.
!     ! Next_Element (a, 0) is equivalent to First_Element (a).
!     ! Old version.
!     TYPE(Set), INTENT(IN) :: a
!     INTEGER,   INTENT(IN) :: e
!     INTEGER :: f  ! RESULT
!     INTEGER :: e0, i0, j0, i, j
!     e0 = MIN (MAX (0, e), max_card)
!     j0 = e0 / bs
!     i0 = MOD (e0, bs)
!     IF ( a % word( j0 ) /= 0_wk ) THEN
!        DO i = i0, msb
!           IF ( BTEST (a % word( j0 ), i) ) THEN
!              f = 1 + i + j0 * bs
!              RETURN
!           END IF
!        END DO
!     END IF
!     DO j = j0+1, msw
!        IF ( a % word( j ) == 0_wk ) CYCLE
!        DO i = 0, msb
!           IF ( BTEST (a % word( j ), i) ) THEN
!              f = 1 + i + j * bs
!              RETURN
!           END IF
!        END DO
!     END DO
!     f = -1  ! No element found
!     RETURN
!   END FUNCTION Next_Element


  !--------------------------------------------------------------------------

  FUNCTION Min_Element (a) RESULT (e)

    ! MINVAL (a).
    ! Returns the minimum element in the set a.
    ! If the set is empty then HUGE(0) is returned.
    ! Replaces First_Element.

    TYPE(Set), INTENT(IN) :: a
    INTEGER :: e  ! RESULT
    INTEGER :: i, j

    DO j = 0, msw
       IF ( a % word( j ) == 0_wk ) CYCLE
       DO i = 0, msb
          IF ( BTEST (a % word( j ), i) ) THEN
             e = 1 + i + j * bs
             RETURN
          END IF
       END DO
    END DO

    e = HUGE (0)  ! No element found

    RETURN
  END FUNCTION Min_Element

!   FUNCTION First_Element (a) RESULT (e)
!     ! Returns the first (smallest) element in the set a.
!     ! If a is empty then -1 is returned.
!     ! Obsolete. See Min_Element and Next_Element.
!     TYPE(Set), INTENT(IN) :: a
!     INTEGER :: e  ! RESULT
!     INTEGER :: i, j
!     DO j = 0, msw
!        IF ( a % word( j ) == 0_wk ) CYCLE
!        DO i = 0, msb
!           IF ( BTEST (a % word( j ), i) ) THEN
!              e = 1 + i + j * bs
!              RETURN
!           END IF
!        END DO
!     END DO
!     e = -1  ! No element found
!     RETURN
!   END FUNCTION First_Element

  !--------------------------------------------------------------------------

  FUNCTION Max_Element (a) RESULT (e)
    
    ! MAXVAL (a).
    ! Returns the maximum element in the set a.
    ! If the set is empty then -HUGE(0)-1 is returned.

    TYPE(Set), INTENT(IN) :: a
    INTEGER :: e  ! RESULT
    INTEGER :: i, j

    DO j = msw, 0, -1
       IF ( a % word( j ) == 0_wk ) CYCLE
       DO i = msb, 0, -1
          IF ( BTEST (a % word( j ), i) ) THEN
             e = 1 + i + j * bs
             RETURN
          END IF
       END DO
    END DO

    e = -HUGE (0) - 1  ! No element found

    RETURN
  END FUNCTION Max_Element

  !--------------------------------------------------------------------------

  SUBROUTINE Add_Element (a, e)

    ! Adds element e to the set a.

    TYPE(Set), INTENT(IN OUT) :: a
    INTEGER,   INTENT(IN    ) :: e
    INTEGER :: j

    IF ( e < 1 .OR. e > max_card ) STOP 'ERROR: Add_Element'

    j = (e - 1) / bs
    a % word( j ) = IBSET (a % word( j ), MOD (e - 1, bs))

    RETURN
  END SUBROUTINE Add_Element

  !--------------------------------------------------------------------------

  SUBROUTINE Delete_Element (a, e)

    ! Deletes element e from the set a.

    TYPE(Set), INTENT(IN OUT) :: a
    INTEGER,   INTENT(IN    ) :: e
    INTEGER :: j

    IF ( e < 1 .OR. e > max_card ) STOP 'ERROR: Delete_Element'

    j = (e - 1) / bs
    a % word( j ) = IBCLR (a % word( j ), MOD (e - 1, bs))

    RETURN
  END SUBROUTINE Delete_Element

  !--------------------------------------------------------------------------

  subroutine write_set (unit, x, iostat)

    ! Prints the set x to unit in a nice format. 
    ! First the set size is printed on one line and then, on the following
    ! lines, the elements are printed, at most 16 on each line until the 
    ! entire set is printed.
    ! Example: (1,3,5,7) comes out as 
    ! 4
    ! 1 3 5 7

    integer,           intent(in ) :: unit
    type(set),         intent(in ) :: x
    integer, optional, intent(out) :: iostat

    integer :: i, j, k, err, e( max_card )

    call elements (x, k, e)

    write (unit=unit, fmt='(i0)', iostat=err) k

    if ( err /= 0 ) then
       if ( present (iostat) ) then
          iostat = err
          return
       else
          stop 'error: write_set 1'
       end if
    end if

    do i = 1, k, 16
       j = min (i+15, k)
       write (unit=unit, fmt="(16(i0,' '))", iostat=err) e( i:j )
       if ( err /= 0 ) exit
    end do

    if ( present (iostat) ) then
       iostat=err
    else if ( err /= 0 ) then
       stop 'error: write_set 2'
    end if

    return
  end subroutine write_set

  !---------------------------------------------------------------------------

  subroutine read_set (unit, x, iostat)

    ! Reads a set from unit that is printed in the format described under 
    ! write_set and returns the result in the k first positions of array x.

    integer,           intent(in ) :: unit
    type(set),         intent(out) :: x
    integer, optional, intent(out) :: iostat

    integer :: i, j, k, err, e( max_card )

    read (unit=unit, fmt=*, iostat=err) k
    
    if ( err /= 0 ) then
       if ( present (iostat) ) then
          iostat = err
          return
       else
          stop 'error: read_set 1'
       end if
    end if

    if ( k > max_card ) then
       if ( present (iostat) ) then
          iostat = huge (0)
          return
       else
          stop 'error: read_set 2'
       end if
    end if

    do i = 1, k, 16
       j = min (i+15, k)
       read (unit=unit, fmt=*, iostat=err) e( i:j )
       if ( err /= 0 ) exit
    end do

    x = e( 1:k )

    if ( present (iostat) ) then
       iostat = err
    else if ( err /= 0 ) then
       stop 'error: read_set'
    end if

    return
  end subroutine read_set

  !---------------------------------------------------------------------------

  FUNCTION Binomial (n, k) RESULT (f)
    ! Returns 'n choose k'.
    INTEGER, INTENT(IN) :: n, k
    REAL(rk) :: f  ! RESULT
    IF ( .NOT. init ) CALL Init_Binom ()
    IF ( n < 0 .OR. n > dig ) STOP 'error: binomial'
    ! 0 <= n <= dig
    IF ( k < 0 .OR. n < k ) THEN
       f = zero
    ELSE ! 0 <= k <= n <= dig
       f = binom( n, k )
    END IF
    RETURN
  END FUNCTION Binomial

  !---------------------------------------------------------------------------

  SUBROUTINE Random_Integer (x)

    ! Sets the argument x to random bits using the built-in random number
    ! generator. From each real we take nb bits at a time. It is not set to 
    ! use all mantissa bits of a real as random, but the user may change nb
    ! according to how many bits can be treated as random. 
    ! For internal use only.

    INTEGER(wk), INTENT(OUT) :: x

    INTEGER, PARAMETER ::          &
         nb = DIGITS (0.0_wp) - 8, & ! number of random bits per real
         nr = (bs + nb - 1) / nb,  & ! number of random reals
         mb = MIN (nb, bs)

    REAL(wp), PARAMETER ::      &
         a = 2.0_wp ** bs,      &
         b = 2.0_wp ** (bs - 1),&
         c = 2.0_wp ** nb

    REAL(wp) :: rnd( nr )
    INTEGER(wk) :: tmp( nr )
    INTEGER :: i

    CALL RANDOM_NUMBER (rnd) ! 0 <= rnd < 1

    IF ( bs <= nb ) THEN ! nr = 1, ie we need only one real
       rnd( 1 ) = AINT (a * rnd( 1 )) ! 0 <= rnd <= 2**bs-1
       x = INT (rnd( 1 ) - b, wk)     ! -2**(bs-1) <= x <= 2**(bs-1)-1
    ELSE ! nr > 1, nb < bs
       rnd = c * rnd       ! 0 <= rnd <= 2**nb-1 <= 2**(bs-1)-1 = huge(0_wk)
       tmp = INT (rnd, wk)
       x = 0_wk
       DO i = 1, nr
          ! Here mb = nb. Need mb to fool the compiler.
          x = IOR (ISHFT (x, mb), tmp( i ))
       END DO
    END IF

    RETURN
  END SUBROUTINE Random_Integer
    
  !--------------------------------------------------------------------------

  SUBROUTINE Init_Binom ()

    ! Initializes the binomial coefficients
    ! binom( n, k ) = C(n,k) = 'n choose k'
    ! For internal use only.

    INTEGER :: n, k

    DO n = 0, dig
       binom( n, 0 ) = one
    END DO

    DO k = 1, dig
       binom( 0, k ) = zero
    END DO

    DO k = 1, dig
       DO n = 1, dig
          binom( n, k ) = binom( n-1, k ) + binom( n-1, k-1 )
       END DO
    END DO
    init = .TRUE.

    RETURN
  END SUBROUTINE Init_Binom

  !--------------------------------------------------------------------------

  FUNCTION Ibrev (x) RESULT (y)

    ! Returns the word x with the bit-order reversed.

    INTEGER(wk), INTENT(IN) :: x
    INTEGER(wk) :: y  ! RESULT

    INTEGER(wk), PARAMETER :: &
         reverse( 0:15 ) = (/0,8,4,12,2,10,6,14,1,9,5,13,3,11,7,15/)

    INTEGER(wk) :: z
    INTEGER :: i

    y = 0_wk
    DO i = 0, msb, 4
       z = reverse( IBITS (x, i, 4) )
       y = IOR (z, ISHFT (y, 4))
    END DO

    RETURN
  END FUNCTION Ibrev

  !--------------------------------------------------------------------------

END MODULE Sets
