! Transforming fhi98pp 
PROGRAM pstr
  implicit none
  integer,parameter                 :: nm=1000
! real*8, parameter                 :: a_B=0.529177d0,Ry=13.6058d0,pi=3.141592653589793d0,h=0.01d0,E2=14.4d0
  real*8, parameter                 :: a_B=0.52917720859d0,Ry=13.60569193d0,pi=3.141592653589793d0,h=0.01d0,E2=14.39964415d0
  integer                           :: l,n,lmax,nmax,idum,i,iargc,num_args,j
  real*8,dimension(:),allocatable   :: x,y,y2,rc
  real*8,dimension(:,:),allocatable :: r,u,v,ut,vt
  real*8                            :: Z,yp1,ypn,t,t1,t2,t3
  character*255                     :: input_filename,output_filename,input_filename2,str
  character*1                       :: ch1
  
  ! Process command-line arguments
  num_args=iargc()
  if(num_args/=3) then
    write(6,*); write(6,*)" Usage: pstr <ncpp.cpi> <ncpp.dat> <output_filename>"; write(6,*)
    stop
  elseif(num_args==3) then
    call getarg(1,input_filename)
    call getarg(2,input_filename2)
    call getarg(3,output_filename)
  endif
  
  open(1,file=trim(adjustl(input_filename)))
  read(1,*)Z,lmax
  lmax=lmax-1
  
  ! Skip the next 10 lines in the input file
  do i=1,10
    read(1,*)
  enddo
  
  do l=0,lmax
    read(1,*)nmax
    if(l==0) then
      allocate(r(nmax,0:lmax),u(nmax,0:lmax),v(nmax,0:lmax),x(nmax))
      allocate(y(nmax),y2(nmax),vt(0:nm,0:lmax),ut(0:nm,0:lmax),rc(0:lmax))
    endif
  
    do n=1,nmax
      read(1,*)idum,r(n,l),u(n,l),v(n,l)   
      r(n,l)=r(n,l)*a_b
      u(n,l)=u(n,l)/sqrt(a_b)
      v(n,l)=v(n,l)*Ry*2.d0
    enddo
    yp1=1.d+40
    ypn=1.d+40

    write(6,*)l,l,lmax
    x(:)=r(:,l)
    y(:)=v(:,l)

    call spline(x,y,nmax,yp1,ypn,y2)
 
    do i=0,nm
      t=i*h
      if(i.eq.0) t=0.001d0
      call splint(x,y,y2,nmax,t,vt(i,l))
    enddo

    y(:)=u(:,l)

    call spline(x,y,nmax,yp1,ypn,y2)

    do i=0,nm
      t=i*h    
      if(i.eq.0) t=0.001d0
      call splint(x,y,y2,nmax,t,ut(i,l))
    enddo
  enddo    

!  do l=0,lmax
!    rc(l)=0.d0
!    do n=1,nm
!      t=n*h
!      if(rc(l).eq.0.d0) then
!        if(abs(vt(n,l)+E2*Z/t).lt.0.001d0) rc(l)=t
!      endif
!    enddo
!  enddo

  open(8,file=trim(adjustl(input_filename2)))
  read(8,'(a255)') str
  do while (str(1:18)/='  l  n     radius:')
    read(8,'(a255)') str
  enddo
  do l=0,lmax
    read(8,*) ch1,i,j,t1,t2,rc(l)
    rc(l)=rc(l)*a_B
  enddo
  close(8)

  open(3,file=trim(adjustl(output_filename)))
  write(3,*)nm,h,lmax,Z
  write(3,1000)(rc(l),l=0,lmax)
  do n=0,nm
    write(3,1000)n*h,(vt(n,l),l=0,lmax)
  enddo
  do n=0,nm
    write(3,1000)n*h,(ut(n,l),l=0,lmax)
  enddo  
1000 format(1x,5d16.8)
  write(6,*)rc
  deallocate(r,u,v,ut,vt,y,y2,x,rc)
END PROGRAM pstr
   
      SUBROUTINE spline(x,y,n,yp1,ypn,y2)
      INTEGER n,NMAX
      real*8 yp1,ypn,x(n),y(n),y2(n)
      PARAMETER (NMAX=1500)
      INTEGER i,k
      real*8 p,qn,sig,un,u(NMAX)
      if (yp1.gt..99e30) then
        y2(1)=0.
        u(1)=0.
      else
        y2(1)=-0.5
        u(1)=(3./(x(2)-x(1)))*((y(2)-y(1))/(x(2)-x(1))-yp1)
      endif
      do 11 i=2,n-1
        sig=(x(i)-x(i-1))/(x(i+1)-x(i-1))
        p=sig*y2(i-1)+2.
        y2(i)=(sig-1.)/p
        u(i)=(6.*((y(i+1)-y(i))/(x(i+1)-x(i))-(y(i)-y(i-1))/(x(i)-x(i-1)))/(x(i+1)-x(i-1))-sig*u(i-1))/p
11    continue
      if (ypn.gt..99e30) then
        qn=0.
        un=0.
      else
        qn=0.5
        un=(3./(x(n)-x(n-1)))*(ypn-(y(n)-y(n-1))/(x(n)-x(n-1)))
      endif
      y2(n)=(un-qn*u(n-1))/(qn*y2(n-1)+1.)
      do 12 k=n-1,1,-1
        y2(k)=y2(k)*y2(k+1)+u(k)
12    continue
      return
      END

      SUBROUTINE splint(xa,ya,y2a,n,x,y)
      INTEGER n
      real*8 x,y,xa(n),y2a(n),ya(n)
      INTEGER k,khi,klo
      real*8 a,b,h
      klo=1
      khi=n
1     if (khi-klo.gt.1) then
        k=(khi+klo)/2
        if(xa(k).gt.x)then
          khi=k
        else
          klo=k
        endif
      goto 1
      endif
      h=xa(khi)-xa(klo)
      if (h.eq.0.d0) pause 'bad xa input in splint'
      a=(xa(khi)-x)/h
      b=(x-xa(klo))/h
      y=a*ya(klo)+b*ya(khi)+((a**3-a)*y2a(klo)+(b**3-b)*y2a(khi))*(h**2)/6.d0
      return
			END
