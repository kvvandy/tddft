#!/usr/bin/env perl
use strict;
use warnings;

`mkdir converted`;
#my @filenames=<*\:tm.ini>;
my @filenames=<*.ini>;
foreach my $filename (@filenames) {
  $filename=~/^\s*\d+\-(\S+)\:/;
  my $output_filename="converted/".lc($1)."_pp.dat";
  print "$filename\t$output_filename";

  #`/home2/bubin/fp/fhi98PP/bin/Tools/psgen_modified -xc 3 -ts t $filename`;
  `/home2/bubin/fp/fhi98PP/bin/Tools/psgen_modified $filename`;
  `/home2/bubin/fp/fhi98PP/mywork/pstr ncpp.cpi ncpp.dat $output_filename`;
  
  print "\n";
}

